Saved design only — not implemented, compiled, tested, adopted or integrated. Work stopped immediately at the user's battery/save request. Do not describe this as a completed optimization.

I11 candidate: block-local power-of-two quantization scales, preserving the current integer rejection proof and exact float-distance confirmation. This is separate from the previously rejected whole-table maximum-residual bound. The main repository is concurrently developing coordinate-chunk early exit in QuantizedQueryBound; that feature is also distinct from this proposal's blocks of database rows.

Current evidence:

- FlatIndex::finish currently scans all resident vectors for one maximum magnitude, obtains one quantization_step, and encodes all row coordinates with it. One outlier can coarsen every row's codes.
- QuantizedQueryBound already safely encodes a query at one power-of-two step and uses its existing outward-rounded full-dimensional cap. An unencodable/nonfinite query or unsupported FP environment disables rejection conservatively.
- Gaussian data may have the same power-of-two step in most blocks. Norm ordering can make low-norm blocks tighter, but any gain is unmeasured; per-row step lookup and additional query encodings may cost more than they save. Outlier and mixed-scale clustered workloads are more plausible beneficiaries. No speedup is claimed.

Minimal proposed interface, still pending review:

1. Default-off `MVDB_ENABLE_BLOCK_QUANT_SCALE`; start with 256 consecutive index ordinals per block. Try 512 only as an ablation. Keep existing row order.
2. Store one uint8 step ID per block plus at most eight distinct double steps. Their powers of two make equality/dedup exact. Calculate the old global maximum in the same pass. If more than eight steps, insufficient budget, optional allocation failure, or invalid input, discard the candidate metadata and use the complete original table-scale construction.
3. Encode each row using its block's selected step; do not keep a second full code matrix. Extend ResidentView with scale-table/ID pointers and block size. With local-scale codes, expose a zero legacy scalar step so any accidentally unadapted old consumer disables its bound rather than comparing incompatible codes.
4. New query-scale cache wrapper owns one existing QuantizedQueryBound per distinct step. Constructors run once per query worker, never once per row. `definitely_greater(codes, ordinal, threshold)` selects the correct step ID; each bound preserves its own mutable threshold cache. Workers must never share these mutable objects.
5. Adapt both unfiltered exec loops and filtered db.scan_vectors rejection paths. Existing db.h accepts a QuantizedQueryBound pointer, so a safe implementation needs an adapter/interface change there as well; changing only exec would silently lose filtered acceleration. ANN ordinals also use the original ordinal to choose a scale.

Budget proposal, not yet proved in code:

- Keep the original code-array allowance and total global index cap unchanged.
- Charge block IDs, retained step array, construction scratch and query cache allowance before admission. The cache should have a hard per-worker ceiling (tentatively 32 KiB including bound objects and actual coded_query capacities) and at most eight entries; account for two workers. Reserving this transient allowance against the index budget is conservative and can reduce eligibility near a boundary.
- Dimension and distinct-step count must satisfy this cap at index construction; otherwise use the entire old table-scale path. Cache construction must verify actual vector capacity; optional failure disables rejection safely for that query.
- Avoid coexistence of old and local full code arrays. Build scratch must be counted while retained metadata is live. The exact accounting and fallback order need review before code is written.

Required tests before adoption:

- Independent uint64 code-distance and canonical double-distance oracles on Gaussian, clustered, mixed-scale and outlier datasets, with an independent training/test seed. Compare all rejection decisions against exact distances, never only approximate recall.
- Every row/block boundary, partial final block, more than eight scales and budget edge, no-scale-improvement fallback, nonfinite values, signed zero/subnormals/float extrema, midpoint ties, threshold neighbors, nondefault rounding/FTZ/DAZ, and a query encodable for some steps but not others.
- Exact TopK ties, K=0/1/10/100, ascending/descending, filtered/unfiltered, serial/two-worker and ANN fallback, plus UPDATE/rollback/restart invalidation.
- Fault injection for metadata/cache allocation; verify no incompatible codes/step table is published and no extra memory budget is consumed.
- Paired whole-request performance versus the same source with the macro disabled. Include ordinary Gaussian data, not only specially favorable outlier cases, and keep all regressions. Linux compilation and sanitizer validation are prerequisites; none has run.

No commit, push, CI or main repository edit was performed for this design.
