# I07 local WIP checkpoint

Saved on the user low-battery stop. Isolated and default-off; NOT compiled or tested.

Base: e47cb44695b8e547d2d91cb099c03c030c6f9717. Source/test: candidate/minivec. Patch: I07-spill-filter-WIP.patch. Hashes, pending checks and limitations: manifest.json. No main-repo application, commit, push, or CI was performed for I07.

Next compile (not run):

```sh
g++ -std=c++17 -O2 -Wall -Wextra -pthread -Isrc -DMVDB_ENABLE_SPILL_FILTER -DMVDB_SPILL_BYTES=1 tests/test_spill_filter.cpp src/db.cpp src/exec.cpp src/sql.cpp src/value.cpp src/flat_index.cpp -Wl,--wrap=pread -o /tmp/test_spill_filter
```

Also check macro-off, tiny global budgets (1/8192 bytes), ASan/UBSan, existing flat/index-budget/filter tests, and lifecycle performance. Do not adopt from this WIP checkpoint alone.
