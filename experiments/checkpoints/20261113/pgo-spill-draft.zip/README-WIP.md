# I15 spill PGO draft checkpoint — 2026-11-13

Status: **WIP, not compiled, not run, not selected for release**. Work stopped immediately at the user's battery/save request. No main-repository file was changed for this draft; no CI was started and nothing was committed or pushed by this agent.

## Saved files

- `train-original.cpp`: exact copy of the existing build-only training helper.
- `train.cpp`: existing helper plus POSIX headers, a request-count accessor, and `generate-spill` / `exercise-spill` commands; includes `spill-training.inc`. Original `generate` behavior is intended to stay unchanged, but equality has not yet been run.
- `spill-training.inc`: independent seed `2026111301`; 4096 rows × 128 dimensions with 8192-byte strings, minimum vector+string payload 35,651,584 bytes (>32 MiB). One single-thread lifecycle, three process phases, 24/8/4 main queries. Equality, range and compound predicates; K1/10/100; UPDATE, explicit rollback, commit, error cases, restart and shutdown rollback. Uses the existing independent exact dyadic-distance oracle and full response comparison.
- `run-training.sh`: keeps the original six training runs; `PGO_SPILL_TRAINING=0|1` enables one extra spill lifecycle. Adds a byte-for-byte comparison of original/generated base corpora, separate spill evidence, and wall-time accounting. Existing nonempty profile count/hash checks and refusal of gcov errors remain.
- `Dockerfile.matrix`: isolated pinned GCC13.3 experiment. Switches `ENABLE_PGO=0|1`, `ENABLE_LTO=0|1`, `PGO_SPILL_TRAINING=0|1`; generation/use both retain `/src`, `src/*.cpp`, `/minivec`, identical LTO setting, strict missing-profile/coverage-mismatch errors and atomic counters. No profile correction or fast math. Release only copies binary and empty data directory.
- `.dockerignore`: allowlist updated for the above helper/include files.
- `Dockerfile.reference`: unmodified root Dockerfile snapshot used during preparation.

## Important unfinished checks

1. **No C++ compilation, shell syntax check, Docker build, oracle run, sanitizer or performance run has been executed on this draft.** Windows currently has no local Linux C++/Docker toolchain; Linux validation must precede any adoption.
2. `.payload`/`.flat` are unlinked after creation. The live driver inspects `/proc/<child>/fd` at four checkpoints, records target/size/link count, and requires both files. Payload must exceed 32 MiB; flat must cover all 4096 × (128×4+16) bytes. This mechanism is implemented but untested.
3. Review the live child's pipe/error/timeout/cleanup behavior. Per-response reads have a 120-second timeout and outer spill execution a 240-second timeout. Full oracle comparison occurs after each process phase; failed phases must never be accepted as training success.
4. Confirm the original corpus files compare exactly and the actual live spill files meet thresholds after mutation and both restarts.
5. Confirm GCC13.3 PGO+LTO generates the expected nonempty per-translation-unit profiles. Do not weaken profile-count or compiler mismatch guards to make a failed experiment pass.
6. The reusable matrix orchestration/collector has **not been written**. Existing historical `compare.sh`/`report.py` cannot simply be reused: their fixed two-variant and six-run schema needs explicit extension. Root Dockerfile integration would also need `spill-training.inc`, `train-original.cpp`, and original-helper compilation; copying only `train.cpp` is insufficient.
7. Wide strings are only a spill trigger, never a filter, and only a few projections return them. Even one extension can overweight parsing/copying in PGO; this requires measured original-vs-extended ablation. Training/generation/oracle costs must be reported separately from DB query gains.

## Proposed next experiment (not executed)

Freeze one source commit and the pinned compiler image. Compare O3, O3+PGO, O3+LTO (`-flto=2`), O3+PGO+LTO. To isolate the new training, keep `PGO_SPILL_TRAINING=0` and `=1` variants; a complete matrix has six unique binaries (O3/LTO shared). Train each PGO+LTO binary with LTO enabled in both compiler stages rather than reusing the non-LTO feedback.

Gate every extracted release binary with JSON protocol, exact TopK serial/two-thread and official public protocol checks; verify profile hashes and release packaging. Then use the existing paired benchmark with evaluation seeds 7319/8911/13337, five alternating pairs, standard10k with 1000 queries per phase, two actual allowed CPUs and complete stderr/resources. Standard screening first; preselected boundary verification and a final direct comparison are separate phases. Preserve all negatives; no formal E/6000 conversion. Build/training elapsed time, source/binary/image SHA and actual CPU flags must be recorded.

Reference checked while drafting: GCC13.3 Instrumentation Options describes profile directory and output-name-sensitive `.gcda` naming: https://gcc.gnu.org/onlinedocs/gcc-13.3.0/gcc/Instrumentation-Options.html . It does not substitute for testing this particular LTO build.
