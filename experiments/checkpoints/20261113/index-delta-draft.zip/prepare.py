"""Create an isolated UPDATE-only delta candidate; never write the source repo."""
from pathlib import Path
import hashlib
import json

root = Path(__file__).resolve().parent
repo = root.parent / "seekdb"
source = repo / "minivec" / "src"
dest = root / "minivec" / "src"
dest.mkdir(parents=True, exist_ok=True)
base = root / "base"
base.mkdir(exist_ok=True)
for path in source.iterdir():
    if path.is_file():
        (dest / path.name).write_bytes(path.read_bytes())
for name in ("db.h", "db.cpp"):
    (base / name).write_bytes((source / name).read_bytes())

def change(text, old, new, expected=1):
    assert text.count(old) == expected, (old[:100], text.count(old), expected)
    return text.replace(old, new)

h = (dest / "db.h").read_text(encoding="utf-8")
h = change(h, "struct RowUndoImage;", "struct RowUndoImage;\n#ifdef MVDB_ENABLE_INDEX_DELTA\nstruct IndexDelta;\n#endif")
h = change(h, "  std::shared_ptr<FlatIndex> vector_index;", """  std::shared_ptr<FlatIndex> vector_index;
#ifdef MVDB_ENABLE_INDEX_DELTA
  // Experimental UPDATE-only delta. Its reserved allowance is charged to the
  // same global index budget; no state is persisted to snapshot or WAL.
  std::shared_ptr<IndexDelta> index_delta;
  size_t index_delta_budget = 0;
#endif
  void invalidate_vector_index() {
    vector_index.reset();
#ifdef MVDB_ENABLE_INDEX_DELTA
    // The index borrows floats retained by these owners: discard it first.
    index_delta.reset();
    index_delta_budget = 0;
#endif
  }""")

c = (dest / "db.cpp").read_text(encoding="utf-8")
c = change(c, "#include <algorithm>", "#include <algorithm>\n#ifdef MVDB_ENABLE_INDEX_DELTA\n#include <array>\n#include <type_traits>\n#endif")
c = change(c, "namespace {\n\nusing TableMap", """#ifdef MVDB_ENABLE_INDEX_DELTA
struct IndexDelta {
  static constexpr size_t kMaxSlots=64;
  std::array<size_t,kMaxSlots> slots{};
  std::array<std::shared_ptr<Row>,kMaxSlots> owners;
  std::vector<uint64_t> suppressed;
  size_t count=0,limit=0,bytes=0;
  bool excludes(size_t slot) const {
    return slot/64<suppressed.size() &&
           (suppressed[slot/64] & (uint64_t(1)<<(slot%64)));
  }
};
#endif

namespace {

using TableMap""")

# All invalidation sites discard the delta owners after the borrowing index.
c = c.replace("table.vector_index.reset();", "table.invalidate_vector_index();")
c = c.replace("it->second.vector_index.reset();", "it->second.invalidate_vector_index();")
c = c.replace("tb.vector_index.reset();", "tb.invalidate_vector_index();")
c = c.replace("  vector_index.reset();", "  invalidate_vector_index();")
c = change(c, "void enforce_payload_budget(TableMap& tables) {", """#ifdef MVDB_ENABLE_INDEX_DELTA
// All optional allocations and admission checks precede the first move from
// the live Row. After that point only noexcept operations remain; bad_alloc
// before it simply asks the caller to use its ordinary rebuild path.
bool preserve_index_for_update(Table& table,size_t slot) {
  if(!table.vector_index || table.vector_index->disk_backed() ||
     table.payload_store || !table.index_delta_budget)return false;
  auto delta=table.index_delta;
  if(delta && delta->excludes(slot))return true;
  if(delta && delta->count==delta->limit)return false;
  const Row& old=table.rows[slot];
  size_t retained=sizeof(Row)+2*sizeof(void*)+old.vals.capacity()*sizeof(Value);
  for(const Value& value:old.vals)
    retained+=value.s.capacity()+1+value.v.capacity()*sizeof(float);
  if(retained>table.index_delta_budget)return false;
  try {
    if(!delta) {
      delta=std::make_shared<IndexDelta>();
      const size_t words=table.rows.size()/64+(table.rows.size()%64!=0);
      const size_t fixed=sizeof(IndexDelta)+2*sizeof(void*);
      if(fixed>table.index_delta_budget || words>(table.index_delta_budget-fixed)/sizeof(uint64_t))
        return false;
      delta->suppressed.assign(words,0);
      delta->bytes=fixed+delta->suppressed.capacity()*sizeof(uint64_t);
      delta->limit=std::min<size_t>(IndexDelta::kMaxSlots,
          std::max<size_t>(1,table.vector_index->size()/100));
    }
    if(delta->bytes>table.index_delta_budget ||
       retained>table.index_delta_budget-delta->bytes)return false;
    auto owner=std::make_shared<Row>();
    static_assert(std::is_nothrow_move_assignable<Row>::value,"Row ownership transfer must not throw");
    // The original vector allocation moves intact: base index pointers keep
    // exactly the same addresses. Repeated updates retain only this first Row.
    *owner=std::move(table.rows[slot]);
    delta->owners[delta->count]=std::move(owner);
    delta->slots[delta->count++]=slot;
    delta->suppressed[slot/64]|=uint64_t(1)<<(slot%64);
    delta->bytes+=retained;
    table.index_delta=std::move(delta);
    return true;
  } catch(const std::bad_alloc&) {
    return false;
  }
}
#endif

void enforce_payload_budget(TableMap& tables) {""")
c = change(c, """void Table::replace_row(size_t slot, Row row) {
  invalidate_vector_index();
  if (payload_store) {
    payload_offsets[slot]=store_payload(*payload_store,row);
    rows[slot].rid=row.rid;
  } else {
    payload_bytes-=std::min(payload_bytes,row_heap_bytes(rows[slot]));
    payload_bytes+=row_heap_bytes(row);
    rows[slot]=std::move(row);
    spill_payloads(*this);
  }
}""", """void Table::replace_row(size_t slot, Row row) {
  if (payload_store) {
    invalidate_vector_index();
    payload_offsets[slot]=store_payload(*payload_store,row);
    rows[slot].rid=row.rid;
  } else {
    const uint64_t old_bytes=row_heap_bytes(rows[slot]);
#ifdef MVDB_ENABLE_INDEX_DELTA
    if(!preserve_index_for_update(*this,slot))invalidate_vector_index();
#else
    invalidate_vector_index();
#endif
    payload_bytes-=std::min(payload_bytes,old_bytes);
    payload_bytes+=row_heap_bytes(row);
    rows[slot]=std::move(row);
    spill_payloads(*this);
  }
}""")
c = change(c, """  build_vector_index(it->second);
  return it->second.vector_index->resident_view(view);""", """#ifdef MVDB_ENABLE_INDEX_DELTA
  // Raw views contain the immutable base and must never bypass suppression.
  if(it->second.index_delta)return false;
#endif
  build_vector_index(it->second);
  return it->second.vector_index->resident_view(view);""")
c = change(c, """  build_vector_index(it->second);
  return it->second.vector_index.get();""", """#ifdef MVDB_ENABLE_INDEX_DELTA
  // The ANN caller needs current partitions. Keep its established rebuild path.
  if(it->second.index_delta)it->second.invalidate_vector_index();
#endif
  build_vector_index(it->second);
  return it->second.vector_index.get();""")
c = change(c, """    const size_t used=kv.second.vector_index->resident_bytes();
    budget-=std::min(budget,used);""", """    size_t used=kv.second.vector_index->resident_bytes();
#ifdef MVDB_ENABLE_INDEX_DELTA
    used+=kv.second.index_delta_budget;
#endif
    budget-=std::min(budget,used);""")
c = change(c, """  table.vector_index=std::move(index);
}""", """  table.vector_index=std::move(index);
#ifdef MVDB_ENABLE_INDEX_DELTA
  if(!table.vector_index->disk_backed() && count) {
    const size_t unused=budget-std::min(budget,table.vector_index->resident_bytes());
    table.index_delta_budget=std::min<size_t>(256u<<10,unused);
  }
#endif
}""")
c = change(c, """  if (!compile_pred(table, conds, &predicate) || predicate.never) return;
  build_vector_index(table);""", """  if (!compile_pred(table, conds, &predicate) || predicate.never) return;
#ifdef MVDB_ENABLE_INDEX_DELTA
  if(table.index_delta && !conds.empty())table.invalidate_vector_index();
  if(table.index_delta) {
    const auto& delta=*table.index_delta;
    bool more=true;
    table.vector_index->scan([&](int64_t pk,uint64_t slot,const float* vector,size_t dimension) {
      if(slot>=table.rows.size() || table.dead[static_cast<size_t>(slot)])
        throw std::runtime_error("stale delta base slot");
      if(delta.excludes(static_cast<size_t>(slot)))return true;
      more=cb(pk,vector,dimension);return more;
    });
    if(!more)return;
    for(size_t j=0;j<delta.count;++j) {
      const Row& row=table.rows[delta.slots[j]];
      const auto& vector=row.vals[table.schema.vec_idx].v;
      if(!cb(row.vals[table.schema.pk_idx].i,vector.data(),vector.size()))return;
    }
    return;
  }
#endif
  build_vector_index(table);""")

for name, text in (("db.h", h), ("db.cpp", c)):
    # Preserve each source file's existing line-ending convention.
    original=(base/name).read_bytes()
    if b"\r\n" in original:text=text.replace("\n", "\r\n")
    (dest/name).write_bytes(text.encode("utf-8"))
manifest={"status":"draft_uncompiled_not_adopted", "macro":"MVDB_ENABLE_INDEX_DELTA",
          "scope":"resident indexed UPDATE only; at most 64 or 1% slots; <=256KiB reserved within global index budget",
          "base":{p.name:hashlib.sha256(p.read_bytes()).hexdigest() for p in base.iterdir()},
          "candidate":{name:hashlib.sha256((dest/name).read_bytes()).hexdigest() for name in ("db.h","db.cpp")}}
(root/"manifest.json").write_text(json.dumps(manifest,indent=2)+"\n",encoding="utf-8")
print(json.dumps(manifest))
