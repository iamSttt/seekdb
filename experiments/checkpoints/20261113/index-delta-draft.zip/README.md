Frozen local experiment, not compiled, run, adopted or integrated.

`index-delta-update-only.patch` contains only candidate `db.h`, `db.cpp` and the new test. Base file hashes and candidate hashes are in `manifest.json`; `base/` preserves the source used to prepare it. Other copied source files are context, not part of the patch. Do not overwrite the main repository from this directory.

The default-off `MVDB_ENABLE_INDEX_DELTA` candidate covers resident indexed UPDATE only. It retains the original complete Row in a shared owner by noexcept move, so the base index's original float addresses remain allocated. All optional allocation/admission work precedes that move. Repeated changes to one slot retain only its first owner. The cap is min(64, max(1, base-live-rows/100)) unique slots and at most 256 KiB reserved from the existing global 16 MiB index budget, including old-row capacities and delta metadata. No delta is persisted.

The raw ResidentView is unavailable while delta exists. Unfiltered exact queries use base scan with dirty slots suppressed, then current dirty rows, through the same TopK visitor. Predicates and ANN rebuild; INSERT, DELETE, spill, rollback and DDL invalidate index and delta together. This is a measurable UPDATE-only subset of user report I06, not the complete INSERT/DELETE delta design.

Required before adoption:

- Compile/run `test_index_delta.cpp` with `-DMVDB_ENABLE_INDEX_DELTA`, using the candidate source files and ASan/UBSan. It tests original-pointer lifetime, exact ascending/descending ties and K limits, repeated updates, slot cap, optional allocation failures, byte-budget fallback, filtering/ANN, INSERT/DELETE, statement/full rollback, DROP and restart.
- Run broader SQL/recovery/TopK and production cross-table-spill tests with the macro. Existing `test_resident_update.cpp` asserts every small UPDATE resets its index and exposes a fresh raw view; those assertions describe the old implementation and need a separately reviewed delta-aware variant. Do not simply weaken/remove the assertions. Add explicit live-delta success/failure while Undo migration forces spill, and global multi-table allowance checks before considering this experiment validated.
- Confirm the default-off build remains semantically equivalent. No local Linux compiler was available, so even successful compilation is still unverified.
- Compare alternating UPDATE/query and UPDATE followed by 64 queries. The generic visitor path loses the original direct, quantized, parallel loop while delta exists; that cost can exceed the saved rebuild. Ordinary read-only and spilled workloads should also be checked for budget or code-layout regressions.

No commit, push or CI was performed for this draft.
