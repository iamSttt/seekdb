from pathlib import Path
import difflib
import hashlib
import json

root=Path(__file__).resolve().parent
parts=[]
for name in ("db.h","db.cpp"):
    before=(root/"base"/name).read_text(encoding="utf-8").splitlines()
    after=(root/"minivec"/"src"/name).read_text(encoding="utf-8").splitlines()
    path="minivec/src/"+name
    parts.append("diff --git a/"+path+" b/"+path+"\n")
    parts.extend(line+"\n" for line in difflib.unified_diff(before,after,"a/"+path,"b/"+path,lineterm=""))
path="minivec/tests/test_index_delta.cpp"
parts.append("diff --git a/"+path+" b/"+path+"\nnew file mode 100644\n")
parts.extend(line+"\n" for line in difflib.unified_diff([], (root/path).read_text(encoding="utf-8").splitlines(),
    "/dev/null","b/"+path,lineterm=""))
patch=root/"index-delta-update-only.patch"
patch.write_bytes("".join(parts).encode("utf-8"))
manifest=json.loads((root/"manifest.json").read_text(encoding="utf-8"))
manifest["patch_sha256"]=hashlib.sha256(patch.read_bytes()).hexdigest()
manifest["test_sha256"]=hashlib.sha256((root/path).read_bytes()).hexdigest()
manifest["status"]="frozen_draft_uncompiled_not_adopted"
(root/"manifest.json").write_text(json.dumps(manifest,indent=2)+"\n",encoding="utf-8")
print(str(patch));print(manifest["patch_sha256"])
