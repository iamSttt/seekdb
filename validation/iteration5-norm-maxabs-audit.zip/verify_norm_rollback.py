import hashlib
import json
import subprocess
from pathlib import Path

work = Path(__file__).resolve().parent
repo = work / 'seekdb'
git = ['git', '-c', 'safe.directory=' + repo.as_posix(), '-C', str(repo)]
reference = '33a52a7dd4426af059ec2334b7c93a07c38c93c9'
paths = ['Dockerfile', '.dockerignore', 'minivec/src', 'minivec/third_party',
         'minivec/Makefile', 'minivec/tools/pgo']
def output(*args):
    return subprocess.check_output(git + list(args))

old_paths = sorted(output('ls-tree', '-r', '--name-only', reference, '--', *paths).decode().splitlines())
staged_paths = sorted(output('ls-files', '--', *paths).decode().splitlines())
assert old_paths == staged_paths, 'Runtime/build input path set changed'
files = []
for path in old_paths:
    old = output('show', reference + ':' + path)
    staged = output('show', ':' + path)
    assert old == staged, path
    files.append({'path': path, 'bytes': len(staged), 'sha256': hashlib.sha256(staged).hexdigest()})
proof = {'status': 'all_staged_runtime_and_root_build_inputs_identical',
         'reference_commit': reference, 'canonical_git_blobs_compared': True,
         'files': files, 'files_checked': len(files), 'new_builds': 0,
         'new_database_runs': 0, 'formal_submission': False,
         'limit': 'Source/build-input identity only; does not claim a new PGO binary or a new CI run.'}
target = work / 'norm-maxabs-staged-rollback-proof.json'
target.write_text(json.dumps(proof, ensure_ascii=False, indent=2) + '\n', encoding='utf-8')
print(json.dumps({'status': proof['status'], 'files_checked': len(files),
                  'sha256': hashlib.sha256(target.read_bytes()).hexdigest()}))
