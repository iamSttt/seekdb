# PGO 的 ISA／维度覆盖：只读审计

结论分两层：R/acdd 这一份实际 profile 的 AVX2 只观察到一轮 16 元素向量循环，两个 SSE2 内核均未执行；但项目历史已经在不支持 AVX512 的机器上完成过完整 16／128／512 维 PGO。因此“第一次训练 AVX2 长向量”应排除，尚未找到的独立方向是**同一份 profile 有意覆盖 native 和较低 ISA 的完整维度路径**。这不证明它会提高性能，更不是正式分数下跌的已知原因。

建议：**目前没有足够证据把混合 ISA 训练作为必须立即进行的下一轮**。最新 norm 候选本身已经在 AVX2／无 AVX512 的机器训练并运行，仍未通过 EE 单 CPU 主标准；因此“给 128 维补一次 AVX2 训练就会解决弱 CPU 退化”的简单假设不成立。混合画像只保留为有条件备选，不实施、不新增 CI。

## 当前入口与真正新增的计数证据

`minivec/tools/pgo/train.cpp:207–244` 的三组向量维度为 16／128／512，主阶段分别 100／500／100 次查询，128 维表 10,000 行，其他表 1,024 行。训练包括创建索引前后的查询、修改和恢复。`run-training.sh:8–23` 把三阶段分别以 parser/query=1 和 2 运行，共六次 oracle 验证；没有 ISA 覆盖参数或独立 SSE/AVX2 循环。根 Docker 同一套四宏、源码路径和输出名做 generate/use，未设置 `-march=native`。

`quantized_bound.h:105–115` 优先选择 AVX512F+BW+AVX2，其次 AVX2/SSE2；`distance.h:279–287` 优先 AVX512F+AVX2，其次 AVX2/SSE2。两个 AVX512 函数在 `n<32` 时调用 AVX2。普通四宏没有开启量化分块；`QuantizedQueryBound::definitely_greater` 和 `DistanceBoundContext::definitely_greater` 向内核传完整维度，不把 128 拆成若干 16 来调用 AVX2。这里的“AVX2 内核”指对应函数，并不表示 AVX512 函数内部没有使用 AVX2 指令。

本轮重新读取归档 instrumented ELF 和 `minivec-exec.gcda`，按 function ident／line／CFG 校验值绑定。与旧审计相比，进一步查看了 instrumented 函数的实际 `lock add __gcov0` 位置，因此不再仅靠未标注的非零 arc 数组推断循环次数：

| 内核 | 入口计数 | 16 元素循环体计数 | scalar tail 计数 |
|---|---:|---:|---:|
| quantized distance_avx2 | 108,400，slot 0，函数偏移 0x33 | 108,400，slot 3，偏移 0x78；回边 0xbb→0x78 | 0，slot 9，偏移 0x126 |
| float bound_sum_avx2 | 33,450，slot 0，偏移 0x33 | 33,450，slot 1，偏移 0xb2；回边 0xc6→0x90 | 0，slot 5，偏移 0x135 |

在已核实训练域 n∈{16,128,512}、非分块完整维度调用下，每次执行至少一轮；总循环体次数等于入口次数，所以这一份 profile 中没有 8 轮的 n=128 或 32 轮的 n=512 AVX2 调用。量化和 float SSE2 函数全部 arc 为 0。此结论只针对绑定的 R 训练产物；不是正式平台画像，也不自动等于“训练质量不充分导致了多少退化”。

证据：`work/pgo-isa-coverage-extra-evidence.json` 保存六函数完整计数、反汇编和 gcov 引用；instrumented SHA `40ef2441ee8960130e6e94cef103642745bc2b689290495befa28d1e1681c150`，exec gcda SHA `df27dd81549b8dc3c3d24e2710c7f195a5adfa63cc4162b34bb76a34d69bd297`。文件哈希与之前绑定的实际 R profile 相符。本轮未执行 ELF。

当前 training generator、shell、distance.h、quantized_bound.h 与该 R proof 的对应 Git LF 内容 SHA 完全相同：分别为 `0af3ab5c…`、`e5af635d…`、`7094c089…`、`5a7b4a1f…`。当前 norm 候选没有改变这四个输入。

## 已做，不能重新当新方向

- conversation `/experiments/12`，`validation/iteration2-pgo-isolation.json`：EPYC 7763，AVX2=true、AVX512F=false，完整三维度／六 oracle 训练，105 对；默认查询有收益，但 resident30k 和 spill 有负结果。这是旧 dot-enabled 源码隔离 PGO，不是当前 R 的跨 ISA 消融。足以排除“项目从未训练过 128/512 维 AVX2”，不能把其收益移植到当前 R。
- N755 原根构建的实际 lscpu 同为 EPYC 7763；相同 dispatcher 和 corpus 支持它按 AVX2 处理长维度的源码＋硬件判断，但其 gcda 内容未导出，不能假装读到了它的维度计数。N755 同时含 INSERT 候选，不能分解为纯 ISA profile 影响。
- 最新 norm `c30d6ec369b82c8d143b2f7cd17ab3e95e88800c` 同样在 EPYC 7763（AVX2、无 AVX512）训练／测量；本轮已读取 `work/norm-maxabs-primary-raw/lscpu.txt`、root proof／summary，并再次计算实际 ELF SHA，等于 `4e8812201468c2cff237f4c22c1f8a1124e1b502a89acdfd08e4f3dcabc57c6a`。collector 的 C/EE 单 CPU 首周期 1.001022、query wall 1.036470、query CPU 1.034817；双 CPU query wall 0.937925。完整判定由独立 reader 做，以上仅说明完整 AVX2 训练并非越过 EE 主标准的充分条件。它还包含 norm 源码改变，不能反过来证明纯 AVX2 画像没有收益。
- conversation `/experiments/51`、`/experiments/52` 的匹配重建在 Xeon 8370C 与 EPYC 9V45 上，两者均有 AVX512。两轮 R2 均是 acdd，N2 均是 07da…；这些实验没有给同一 R 构造 native+低 ISA 混合 profile。
- I15 的六构建矩阵比较 O3、LTO、PGO 和扩展 spill 训练；读取其 training shell 和 README，没有 ISA 轮转。旧强制 AVX2 dot 的 135 对是另一项算法/dispatch 对照，float bound 保持 native，也不是跨 ISA profile 混合。
- 已有源码单测／ASan 显式调用 AVX2/SSE2、或禁用 AVX512 的 correctness 测试，在根 PGO 训练进程之外，不能计作根训练覆盖。未找到 SSE2 full128 根 PGO 的记录；这是已读取当前材料／相关归档／脚本范围内的未发现，非不可访问历史的绝对否定。

## 如果继续，最小独立补全方式与风险

这里仅说明如何直接证伪画像机制，未建议现在启动。必要证据应先是同一源代码的 native／较低 ISA 选择、同一实际 profile 的长循环命中和相应 release 函数变化；若主要 query CPU 退化不在这些内核、或正式构建与执行都是同一 AVX2 ISA，则没有覆盖补全的直接动机。

有条件可试的是两个 dispatcher 共享一个进程级、默认 native 的 ISA 上限，训练时只下调到硬件实际支持的 AVX2（SSE2 暂不同时加入）。默认 exact 算法、阈值、编码和 native 选择顺序不变；解析上限应缓存，不能在每行或每次内核调用中 getenv。generation 与 use 必须保留**同一份源码／控制流／开关编译输入**。不能先编译关闭 AVX512 生成 profile，再恢复不同宏来消费并忽略 mismatch；只运行独立 microkernel 测试，也未必会更新生产 exec 翻译单元对应的 profile。

最小对照可固定同一份带上限机制的 R 源码、同一 runner／flags：A 以 native 重复既有训练，B 用等量 native+AVX2 完整训练。两者训练总请求／生命周期数相同，避免把一般路径训练次数翻倍混入 ISA 覆盖效果。保留相同独立 SQL oracle、原始 profile、实际选择信息和最终 ELF；验证 AVX2 的 128/512 长循环确实有多轮反馈。最多两个最终候选构建即可作初筛，不应展开所有 ISA×线程×PGO 矩阵。本报告没有实现该上限或安排实验。

随后必须用同一 AVX2 上限测双方的默认 128 维 CPU／query／完整首周期，同时保留 native 的回归保护。AVX512 机器强制 AVX2 只能验证相同 ISA 函数与 compiler feedback 的效果，仍不等同旧型号弱 CPU 的缓存、频率、内存或正式机器。只有 native 结果没有验证低 ISA 假设；只有低 ISA 局部收益而 native/完整生命周期退步，也不能默认采用。

风险包括：混合画像稀释原 native 热度、间接调用目标反馈变化、函数布局／展开和体积增大、上限读取进入 query 初始化热路径，以及 SSE2 虽未训练但正式机可能根本不用它。若需要严格维持生产源字节不变，目前没有同等简单可靠的纯训练脚本方法；CPU 模拟器／修改 GCC 内部 CPUID 数据不是本次低成本建议。

`-fprofile-partial-training` 也不是上述 AVX2 维度缺口的直接替代：GCC13.3 仅承诺对训练时完全未执行的函数忽略反馈，已执行过的 AVX2 函数不满足此前提。它可能涉及全零 SSE2，但正式 ISA 未知且可能增大代码，不能因 SSE2 全零就默认选它。[GCC13.3 Optimize Options](https://gcc.gnu.org/onlinedocs/gcc-13.3.0/gcc/Optimize-Options.html#index-fprofile-partial-training)

## 能否解释正式与强 runner 方向相反

当前只能形成条件性假设：如果正式构建在 AVX512 主机训练、实际运行落到 AVX2/SSE2，则对应函数的反馈分布可能不合适。需要正式构建和执行两端的 ISA／实际 ELF 身份、分阶段 CPU 与内核命中证据才能建立这个链条；“1c2g／2c2g、机器很差”本身不能推出缺少 AVX512。如果正式构建和执行都为 AVX2，原训练本来就覆盖完整 128/512 AVX2，单凭本次 R 的 AVX512 画像无法解释它。

现有本地 E、正式 E 和不同 ELF／机器的比值不可相乘；正式成绩无 T/B/M 明细，不能把分数下降全归因于 query、PGO 或 ISA。本次也未测新性能、未更改仓库、未启动 CI，正式提交仍由用户决定。
