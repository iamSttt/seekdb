"""Compact report from verified norm/maxabs evidence; never runs a database."""
import hashlib,json
from pathlib import Path
w=Path(__file__).resolve().parent
source=w/'norm-maxabs-independent-analysis.json';raw=source.read_bytes();data=json.loads(raw)
assert data['status']=='verified' and data['verified_pairs']==24
screen=data['preregistered_screen'];groups={}
for label,metrics in screen['guard_metrics'].items():
    selected={};cycle='lifecycle_stage_wall_sum' if label.endswith(':wide768') else 'first_lifecycle_wall_seconds'
    cycles={row['pair_index']:row['baseline'] for row in metrics[cycle]['pairs']}
    for name,value in metrics.items():
        unit='wall_seconds' if name.endswith('_seconds') or name=='lifecycle_stage_wall_sum' else 'cpu_usec' if name.endswith('_usec') else 'bytes'
        rows=[]
        for pair in value['pairs']:
            row=dict(pair)
            if unit=='wall_seconds':row.update(baseline_ms=pair['baseline']*1000,candidate_ms=pair['candidate']*1000,
                delta_ms=pair['candidate_minus_baseline']*1000,delta_share_of_baseline_first_cycle=pair['candidate_minus_baseline']/cycles[pair['pair_index']])
            elif unit=='cpu_usec':row.update(baseline_cpu_ms=pair['baseline']/1000,candidate_cpu_ms=pair['candidate']/1000,delta_cpu_ms=pair['candidate_minus_baseline']/1000)
            rows.append(row)
        selected[name]={key:value[key] for key in ('median_candidate_over_baseline','AB_median','BA_median','candidate_faster_pairs','candidate_worse_pairs')}
        selected[name].update(unit=unit,raw_pairs=rows)
    groups[label]=selected
eligible=screen['eligible_for_one_confirmation']
result={'status':'independently_verified','screen':screen['status'],'candidate_commit':data['commit'],
    'run_id':43489727271,'artifact_id':14070890303,'artifact_bytes':3731249,'artifact_sha256':data['artifact_sha256'],
    'candidate_binary_sha256':data['candidate_binary_sha256'],'candidate_image_id':data['candidate_image_id'],
    'verified_pairs':24,'verified_root_gate_count':len(data['root_gates']),'eligible_for_one_confirmation':eligible,
    'adopted':False,'selected_runtime':'R / acddca115ab183bfc6419e27c9e3383cfd1a9046e3897e5ea516cd7bc0f29f54',
    'EE_primary':screen['EE_primary'],'R_guard_triggers':screen['R_guard_triggers'],
    'guard_trigger_count':len(screen['R_guard_triggers']),'all_negative_or_mixed_metric_summary_count':len(data['all_negative_or_mixed_metrics']),
    'guard_adverse_pair_metric_records':len(screen['all_guard_adverse_pairs']),
    'count_scope':'Overlapping metrics and derived totals are not independent regression counts; do not add these counts.',
    'groups':groups,'full_analysis':{'path':str(source),'bytes':len(raw),'sha256':hashlib.sha256(raw).hexdigest()},
    'source_equivalence_gates':data['source_equivalence_gates'],'limitations':data['limitations'],
    'formal_score':None,'formal_score_floor_proven':False,'formal_submission_performed':False,
    'recommendation':'Eligible for exactly one independent confirmation under the frozen plan; keep R pending confirmation.' if eligible else
        'The frozen screen failed; retain R and do not seek replacement favorable samples.'}
out=w/'norm-maxabs-decision.json';out.write_text(json.dumps(result,ensure_ascii=False,indent=2)+'\n',encoding='utf8')
lines=['# Norm/maxabs fusion: '+('one confirmation eligible' if eligible else 'keep R'),'',
    'The independent audit verified 24 fixed pairs and the exact 21 root gates. Screen status: `'+screen['status']+'`. No automatic adoption or formal-score claim.','',
    '| Reference | CPU | First-cycle stage sum C/reference | Query wall C/reference | Query CPU C/reference | First-cycle improving pairs |',
    '|---|---:|---:|---:|---:|---:|']
for ref in ('ee','retained'):
 for cpu in (1,2):
  m=groups[f'{ref}:{cpu}:standard10k'];keys=('first_lifecycle_wall_seconds','first_1000_queries_wall_seconds','first_1000_queries_cpu_usec')
  lines.append('| '+ref+' | '+str(cpu)+' | '+' | '.join(f"{m[key]['median_candidate_over_baseline']:.6f}" for key in keys)+f" | {m[keys[0]]['candidate_faster_pairs']}/{6 if ref=='ee' else 4} |")
lines+=['','Ratios are paired medians; above one is worse. First-cycle wall is the measured stage-timer sum, not continuously measured elapsed time. EE is the verified original-source/Docker rebuild, not the recovered official executable.','',
    'Retained-reference guard triggers: '+str(len(screen['R_guard_triggers']))+'.']
for item in screen['R_guard_triggers']:lines.append('- `'+item['group']+'`: `'+item['metric']+'`, threshold '+str(item['threshold'])+'.')
lines+=['',f"All {len(data['all_negative_or_mixed_metrics'])} negative or mixed metric summaries and {len(screen['all_guard_adverse_pairs'])} adverse guard pair/metric records remain available. These counts overlap. The companion JSON preserves absolute values, both pair orders, and all screen metrics.",'',
    'The new preregistration explicitly uses the initial sixteen spill queries. All four later cycles and the full eighty-query aggregate remain reported. There is no inherited after-launch mapping erratum in this experiment.','',
    result['recommendation'],'',
    'One runner and one seed do not prove a formal-score floor. No cross-reference ratio is multiplied and no gain compensates for a retained-reference guard failure. The source mechanism alone does not explain unrelated phase changes.']
(w/'norm-maxabs-decision.md').write_text('\n'.join(lines)+'\n',encoding='utf8')
print(json.dumps({'status':screen['status'],'eligible_for_one_confirmation':eligible,'analysis_sha256':result['full_analysis']['sha256'],
    'analysis_bytes':len(raw),'decision_sha256':hashlib.sha256(out.read_bytes()).hexdigest(),'decision_bytes':out.stat().st_size}))
