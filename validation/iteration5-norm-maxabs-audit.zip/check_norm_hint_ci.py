"""Small pure-Python/source-only CI preflight; never compile or execute DB."""
import ast
import hashlib
import json
from pathlib import Path
import re
import subprocess
import tempfile

REPO = Path('work/seekdb').resolve()
TOOLS = REPO / 'minivec/tools'
OUT = Path('work/norm-global-max-fusion-draft')
checks = []


def check(condition, name):
    if not condition:
        raise AssertionError(name)
    checks.append(name)


def sha(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def require(ok, message):
    if not ok:
        raise ValueError(message)


sources = {}
for name in ('prepare_highest_primary.py', 'summarize_highest_primary.py',
             'prepare_small_root.py', 'prepare_small_compute.py',
             'summarize_small_root.py', 'small_compute.py'):
    source = (TOOLS / name).read_text()
    sources[name] = source
    ast.parse(source)
    checks.append('AST ' + name)

tree = ast.parse(sources['prepare_highest_primary.py'])
kept = [node for node in tree.body if
        isinstance(node, ast.FunctionDef) and node.name == 'verify_root_gates' or
        isinstance(node, ast.Assign) and any(isinstance(t, ast.Name) and
             t.id in ('ROOT_GATES', 'EXPERIMENT_ID', 'PREREGISTRATION') for t in node.targets)]
namespace = dict(json=json, re=re, require=require, sha=sha)
exec(compile(ast.Module(body=kept, type_ignores=[]), '<actual verify_root_gates>', 'exec'), namespace)
verify = namespace['verify_root_gates']
expected = namespace['ROOT_GATES']
check(len(expected) == 21, 'exact 21 root gate keys')
check('global_max_hint_equivalence_normal_and_sanitized' in expected,
      'new norm gate in exact inventory')
check(namespace['EXPERIMENT_ID'] == 'norm-maxabs-fusion-highest-primary24',
      'independent experiment label')
check(namespace['PREREGISTRATION'] == 'validation/iteration5-norm-maxabs-primary24-preregistration.json',
      'new preregistration path')

shell = (TOOLS / 'ci_score.sh').read_text()
summary = re.search(r"<<'PYSUMMARY'\n(.*?)\nPYSUMMARY", shell, re.S).group(1)
summary_tree = ast.parse(summary)
report = next(node.value for node in ast.walk(summary_tree) if isinstance(node, ast.Assign)
              and any(isinstance(t, ast.Name) and t.id == 'report' for t in node.targets))
gate_dict = next(v for k, v in zip(report.keys, report.values) if ast.literal_eval(k) == 'checks')
emitted = set(ast.literal_eval(gate_dict)) | {'compound_reuse_diagnostic_and_sanitizer'}
check(emitted == expected, 'ci_score selected-feature keys equal verifier inventory')
check(shell.index('global-max-hint-$mode') < shell.index('docker build --platform'),
      'new source gate before paid root build')
check('-DMVDB_TEST_GLOBAL_MAX_HINT' in shell and
      'for mode in normal sanitized block-scale; do' in shell and
      'minivec/src/{db,exec,sql,value,flat_index}.cpp' in shell,
      'normal/sanitized/block builds use actual source with diagnostic-only macro')

with tempfile.TemporaryDirectory(dir=OUT, prefix='ci-gate-fixture-') as temporary:
    root = Path(temporary)
    def seed():
        details = {}
        for stem, marker, counts in (('cached-quantizer', 'cached_quantizer', (101, 101, 103)),
                                     ('global-max-hint', 'global_max_hint', (211, 211, 223))):
            item = {'schema_version': 1}
            for mode, count in zip(('normal', 'sanitized', 'block-scale'), counts):
                item[mode + '_checks'] = count
                item[mode + '_pass'] = True
                (root / (stem + '-' + mode + '.log')).write_text(
                    f'{marker}_checks={count}\n{marker}=PASS\n')
            (root / (stem + '-equivalence.json')).write_text(json.dumps(item))
            details[stem] = item
        gates = {'passed': True, 'checks': dict.fromkeys(expected, True),
                 'cached_quantizer_equivalence': details['cached-quantizer'],
                 'global_max_hint_equivalence': details['global-max-hint']}
        (root / 'root-gates-summary.json').write_text(json.dumps(gates))
        return gates

    def bad(name, mutate):
        gates = seed()
        mutate(gates)
        try:
            verify(root)
        except (ValueError, FileNotFoundError, KeyError):
            checks.append('reject ' + name)
        else:
            raise AssertionError('accepted ' + name)

    def save_gates(gates):
        (root / 'root-gates-summary.json').write_text(json.dumps(gates))

    def mutate_gate(key, value=None, remove=False):
        def operation(gates):
            if remove: gates['checks'].pop(key)
            else: gates['checks'][key] = value
            save_gates(gates)
        return operation

    seed()
    accepted = verify(root)
    check(set(accepted) == {'historical_cached_quantizer', 'global_max_hint'},
          'two separate source-equivalence inventories')
    check(accepted['global_max_hint']['checks_per_mode'] == 211 and
          len(accepted['global_max_hint']['file_sha256']) == 4,
          'new JSON and all three logs hashed')
    check('test-only' in accepted['historical_cached_quantizer']['scope'],
          'rejected encoder explicitly historical test scope')
    bad('missing norm root key', mutate_gate('global_max_hint_equivalence_normal_and_sanitized', remove=True))
    bad('extra root key', mutate_gate('invented', True))
    bad('false norm root key', mutate_gate('global_max_hint_equivalence_normal_and_sanitized', False))
    bad('integer truthy norm root key', mutate_gate('global_max_hint_equivalence_normal_and_sanitized', 1))
    bad('missing norm log', lambda _: (root / 'global-max-hint-normal.log').unlink())
    bad('missing norm JSON', lambda _: (root / 'global-max-hint-equivalence.json').unlink())
    bad('wrong count in log', lambda _: (root / 'global-max-hint-normal.log').write_text('global_max_hint_checks=212\nglobal_max_hint=PASS\n'))
    bad('duplicate counts', lambda _: (root / 'global-max-hint-normal.log').write_text('global_max_hint_checks=211\nglobal_max_hint_checks=211\nglobal_max_hint=PASS\n'))
    bad('duplicate PASS', lambda _: (root / 'global-max-hint-normal.log').write_text('global_max_hint_checks=211\nglobal_max_hint=PASS\nglobal_max_hint=PASS\n'))
    bad('missing block PASS', lambda _: (root / 'global-max-hint-block-scale.log').write_text('global_max_hint_checks=223\n'))
    def corrupt_details(mode, count):
        def operation(gates):
            item = gates['global_max_hint_equivalence']
            item[mode + '_checks'] = count
            (root / 'global-max-hint-equivalence.json').write_text(json.dumps(item))
            (root / ('global-max-hint-' + mode + '.log')).write_text(f'global_max_hint_checks={count}\nglobal_max_hint=PASS\n')
            save_gates(gates)
        return operation
    bad('zero norm count', corrupt_details('normal', 0))
    bad('boolean norm count', corrupt_details('normal', True))
    bad('normal/sanitizer inventory difference', corrupt_details('sanitized', 212))
    bad('JSON/root detail mismatch', lambda _: (root / 'global-max-hint-equivalence.json').write_text('{"schema_version":1}'))

# Test the actual CI embedded log parser, with fixture-only files and no shell/DB.
code = re.search(r"<<'PYMAXHINT'\n(.*?)\nPYMAXHINT", shell, re.S).group(1)
ast.parse(code)
with tempfile.TemporaryDirectory(dir=OUT, prefix='ci-parser-fixture-') as temporary:
    root = Path(temporary)
    parser_code = compile(ast.parse(code.replace("Path('protocol-results')", 'Path(FIXTURE)')),
                          '<actual PYMAXHINT fixture>', 'exec')
    def run_parser():
        exec(parser_code, {'FIXTURE': str(root)})
    def logs(normal='311', sanitized='311', block='333'):
        for mode, count in zip(('normal', 'sanitized', 'block-scale'), (normal, sanitized, block)):
            (root / ('global-max-hint-' + mode + '.log')).write_text(f'global_max_hint_checks={count}\nglobal_max_hint=PASS\n')
    logs(); run_parser()
    check(json.loads((root / 'global-max-hint-equivalence.json').read_text())['normal_checks'] == 311,
          'actual CI Python log collector happy path')
    for name, args in [('zero', ('0', '0', '333')), ('normal/san mismatch', ('311', '312', '333'))]:
        logs(*args)
        try: run_parser()
        except SystemExit: checks.append('CI embedded parser rejects ' + name)
        else: raise AssertionError(name)

collector = sources['summarize_highest_primary.py']
for fragment in ("binding['experiment_id'] == EXPERIMENT_ID", "binding['preregistration'] == preregistration",
                 "binding['source_equivalence_gates'] == source_gates", "result['completed_pairs'] == 24 and exit_code == 0"):
    check(fragment in collector, 'collector binds ' + fragment)
check(namespace['PREREGISTRATION'] in sources['prepare_small_compute.py'],
      'new preregistration included in Git-bound harness inventory')
prereg = REPO / namespace['PREREGISTRATION']
plan_status = 'pending_not_present'
if prereg.exists():
    plan = json.loads(prereg.read_bytes())
    check(plan.get('experiment_id') == namespace['EXPERIMENT_ID'], 'preregistration experiment ID')
    check(plan.get('measurement_family') == 'highest_primary24_v1' and
          plan.get('planned_pairs', {}).get('total') == 24, 'preregistration family/total')
    plan_tree = ast.parse(sources['small_compute.py'])
    plan_nodes = [n for n in plan_tree.body if isinstance(n, ast.FunctionDef) and n.name == 'highest_primary_plan']
    plan_ns = {'require': require, 'SEED': 7319}
    exec(compile(ast.Module(body=plan_nodes, type_ignores=[]), '<actual fixed plan>', 'exec'), plan_ns)
    for group in plan['groups']:
        check(group['pairs'] == plan_ns['highest_primary_plan'](group['reference'], group['db_cpu_count']),
              'preregistered exact pair/order ' + group['reference'] + str(group['db_cpu_count']))
    check(sum(len(g['pairs']) for g in plan['groups']) == 24, 'preregistered total complete 24')
    mapping = plan['screen_rules']['R_protection']['spill_query_mapping']
    check(mapping['query_before_mutations_wall_seconds']['required_request_count'] == 16 and
          mapping['query_before_mutations_cpu_usec']['start_snapshot'] == 'after_index_build' and
          mapping['query_before_mutations_cpu_usec']['end_snapshot'] == 'query_before_mutations',
          'spill guard uses initial sixteen requests and correct CPU interval')
    # Execute just the actual prepare function's pre-build preregistration gate.
    fn = next(n for n in tree.body if isinstance(n, ast.FunctionDef) and n.name == 'prepare_highest')
    cut = next(i for i, n in enumerate(fn.body) if isinstance(n, ast.Assign) and
               any(isinstance(t, ast.Name) and t.id == 'current' for t in n.targets))
    fn.body = fn.body[:cut] + [ast.Return(value=ast.Name(id='preregistration', ctx=ast.Load()))]
    prefix = ast.fix_missing_locations(ast.Module(body=[fn], type_ignores=[]))
    prefix_ns = dict(namespace, HIGHEST_PRIMARY_FAMILY='highest_primary24_v1', verify_root_gates=lambda p: {})
    exec(compile(prefix, '<actual preregistration pre-build guard>', 'exec'), prefix_ns)
    with tempfile.TemporaryDirectory(dir=OUT, prefix='prereg-fixture-') as temporary:
        test_repo = Path(temporary)
        target = test_repo / namespace['PREREGISTRATION']; target.parent.mkdir(parents=True)
        target.write_bytes(prereg.read_bytes())
        actual = prefix_ns['prepare_highest'](test_repo, None, None, None)
        check(actual['sha256'] == sha(prereg) and actual['bytes'] == prereg.stat().st_size,
              'actual prepare binds full preregistration bytes')
        for name, edit in [('experiment', lambda p: p.update(experiment_id='old-quantizer')),
                           ('family', lambda p: p.update(measurement_family='old-family')),
                           ('count', lambda p: p['planned_pairs'].update(total=20))]:
            bad_plan = json.loads(prereg.read_bytes()); edit(bad_plan)
            target.write_text(json.dumps(bad_plan))
            try: prefix_ns['prepare_highest'](test_repo, None, None, None)
            except ValueError: checks.append('pre-build guard rejects wrong preregistration ' + name)
            else: raise AssertionError('accepted wrong preregistration ' + name)
    plan_status = 'present_verified_id'

shell_proof = json.loads((OUT / 'shell-syntax-proof.json').read_bytes())
for name in ('ci_score.sh', 'ci_highest_primary.sh'):
    check(shell_proof['files'][name]['exit_code'] == 0 and
          shell_proof['files'][name]['sha256'] == sha(TOOLS / name),
          'actual separately executed sh -n ' + name)
result = {'status': 'passed' if plan_status != 'pending_not_present' else 'passed_except_preregistration_pending',
          'checks': checks, 'check_count': len(checks), 'preregistration': plan_status,
          'source_hashes': {name: sha(TOOLS / name) for name in sources},
          'shell_syntax': shell_proof,
          'database_runs': 0, 'native_compilations': 0, 'git_operations': 0,
          'scope': 'Necessary source syntax and actual Python gate negative controls only; not Linux or database validation.'}
(OUT / 'ci-preflight.json').write_text(json.dumps(result, ensure_ascii=False, indent=2) + '\n', encoding='utf8')
print(json.dumps({k: result[k] for k in ('status', 'check_count', 'preregistration')}))
