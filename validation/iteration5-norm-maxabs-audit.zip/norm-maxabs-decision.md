# Norm/maxabs fusion: keep R

The independent audit verified 24 fixed pairs and the exact 21 root gates. Screen status: `screen_rejected_R_regression_keep_R`. No automatic adoption or formal-score claim.

| Reference | CPU | First-cycle stage sum C/reference | Query wall C/reference | Query CPU C/reference | First-cycle improving pairs |
|---|---:|---:|---:|---:|---:|
| ee | 1 | 1.001022 | 1.036470 | 1.034817 | 3/6 |
| ee | 2 | 0.954313 | 0.937925 | 0.898321 | 5/6 |
| retained | 1 | 0.978531 | 0.980433 | 0.972759 | 3/4 |
| retained | 2 | 0.988992 | 0.993081 | 0.988636 | 3/4 |

Ratios are paired medians; above one is worse. First-cycle wall is the measured stage-timer sum, not continuously measured elapsed time. EE is the verified original-source/Docker rebuild, not the recovered official executable.

Retained-reference guard triggers: 4.
- `retained:1:spill_high_q16`: `query_before_mutations_wall_seconds`, threshold 1.02.
- `retained:1:spill_high_q16`: `query_before_mutations_cpu_usec`, threshold 1.02.
- `retained:1:spill_high_q16`: `first_query_wall_seconds`, threshold 1.02.
- `retained:2:standard10k`: `first_query_wall_seconds`, threshold 1.02.

All 164 negative or mixed metric summaries and 71 adverse guard pair/metric records remain available. These counts overlap. The companion JSON preserves absolute values, both pair orders, and all screen metrics.

The new preregistration explicitly uses the initial sixteen spill queries. All four later cycles and the full eighty-query aggregate remain reported. There is no inherited after-launch mapping erratum in this experiment.

The frozen screen failed; retain R and do not seek replacement favorable samples.

One runner and one seed do not prove a formal-score floor. No cross-reference ratio is multiplied and no gain compensates for a retained-reference guard failure. The source mechanism alone does not explain unrelated phase changes.
