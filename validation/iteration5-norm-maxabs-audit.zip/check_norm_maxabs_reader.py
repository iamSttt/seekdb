"""Necessary new norm-reader controls; no database/compiler execution."""
import ast,copy,json,sys,tempfile
from pathlib import Path
w=Path(__file__).resolve().parent;repo=w/'seekdb';sys.path.insert(0,str(w));sys.path.insert(0,str(repo/'minivec/tools'))
import analyze_norm_maxabs_primary_root as a
import analyze_highest_primary_root as old
from prepare_highest_primary import ROOT_GATES
checks=[]
def need(value):
 if not value:raise AssertionError('norm reader control failed')
def reject(fn):
 try:fn()
 except (ValueError,KeyError,FileNotFoundError):return
 raise AssertionError('invalid norm evidence accepted')
def check(name,fn):fn();checks.append(name)
ast.parse((w/'analyze_norm_maxabs_primary_root.py').read_text())
check('syntax',lambda:None)
check('exact_21_root_gate_inventory',lambda:need(a.GATES==ROOT_GATES and len(a.GATES)==21))
check('old_quantizer_reader_still_exact20_and_d227',lambda:need(len(old.GATES)==20 and old.CANDIDATE_COMMIT=='d22720446c1c068401633daa083b2fe564917fd1'))
check('candidate_commit_not_invented',lambda:need(a.CANDIDATE_COMMIT=='PENDING_NEW_COMMIT' or (len(a.CANDIDATE_COMMIT)==40 and a.CANDIDATE_COMMIT!=old.CANDIDATE_COMMIT)))
if a.CANDIDATE_COMMIT!='PENDING_NEW_COMMIT':
 guard=a.runtime_guard(repo,a.CANDIDATE_COMMIT)
 check('committed_three_file_scope_CRC_scalar_private_layout',lambda:need(guard['flat_index_private_section_unchanged'] and guard['db_outside_build_vector_index_unchanged'] and guard['main_exec_quantized_bound_unchanged']))
 original_blob=a.blob
 for label,path,mutate in (
   ('db_prefix','minivec/src/db.cpp',lambda raw:b'// controlled prefix mutation\n'+raw),
   ('db_suffix','minivec/src/db.cpp',lambda raw:raw+b'// controlled suffix mutation\n'),
   ('private_index_fields','minivec/src/flat_index.h',lambda raw:raw.replace(b' private:',b' private:\n  size_t controlled_extra_field;')),
   ('original_scalar_query','minivec/src/quantized_bound.h',lambda raw:raw+b'// controlled scalar helper change\n')):
  def altered(repo_arg,revision,name,path=path,mutate=mutate):
   raw=original_blob(repo_arg,revision,name)
   return mutate(raw) if revision==a.CANDIDATE_COMMIT and name==path else raw
  a.blob=altered
  try:check('reject_'+label,lambda:reject(lambda:a.runtime_guard(repo,a.CANDIDATE_COMMIT)))
  finally:a.blob=original_blob
with tempfile.TemporaryDirectory(prefix='norm-reader-controls-') as td:
 root=Path(td);gates={}
 def fixture():
  for prefix,key,marker in (('cached-quantizer','cached_quantizer_equivalence','cached_quantizer'),('global-max-hint','global_max_hint_equivalence','global_max_hint')):
   result={'schema_version':1}
   for mode in ('normal','sanitized','block-scale'):
    result[mode+'_checks']=23 if mode=='block-scale' else 19;result[mode+'_pass']=True
    (root/(prefix+'-'+mode+'.log')).write_text(f"{marker}_checks={result[mode+'_checks']}\n{marker}=PASS\n")
   (root/(prefix+'-equivalence.json')).write_text(json.dumps(result));gates[key]=result
 fixture()
 check('two_distinct_equivalence_gate_families',lambda:need(set(a.source_equivalence_gates(root,gates))=={'historical_cached_quantizer','global_max_hint'}))
 check('cached_reference_labelled_test_only',lambda:need(a.source_equivalence_gates(root,gates)['historical_cached_quantizer']['scope']=='rejected cached encoder isolated in test-only header'))
 (root/'global-max-hint-sanitized.log').unlink()
 check('missing_current_sanitizer_log_rejected',lambda:reject(lambda:a.source_equivalence_gates(root,gates)))
 fixture();(root/'global-max-hint-normal.log').write_text('global_max_hint_checks=0\nglobal_max_hint=PASS\n')
 check('zero_or_mismatched_current_count_rejected',lambda:reject(lambda:a.source_equivalence_gates(root,gates)))
 fixture();(root/'global-max-hint-block-scale.log').write_text('global_max_hint_checks=23\nglobal_max_hint=PASS\nruntime error: controlled fixture\n')
 check('sanitizer_error_not_hidden_by_pass_marker',lambda:reject(lambda:a.source_equivalence_gates(root,gates)))
 fixture();gates.pop('global_max_hint_equivalence')
 check('historical_cached_gate_cannot_replace_current_norm_gate',lambda:reject(lambda:a.source_equivalence_gates(root,gates)))
plan=a.screen.read_preregistration(repo/a.PREREG_PATH)
check('new_experiment_and_plan_pin',lambda:need(plan['experiment_id']==a.EXPERIMENT_ID and a.screen.PREREG_SHA=='929887bcaaf38758825e8f1b212ee679acc1c6cdb6ee965ce3aecc9c996603da'))
raw=json.loads((w/'highest-primary-quantizer-raw/highest-primary-root/retained-1cpu.json').read_bytes())
groups=a.screen_input(raw,'retained',1)
row=groups[('retained',1,'spill_high_q16')][0]
check('new_spill_mapping_is_first16_with_correct_names',lambda:need('query_before_mutations_wall_seconds' in row['metrics'] and 'query_before_update_wall_seconds' not in row['metrics'] and 'ingest_cpu_usec' not in row['metrics']))
bad=copy.deepcopy(raw)
next(p for p in bad['pairs'] if p['scenario']=='spill_high_q16')['baseline']['query']['query_before_mutations']['per_request_seconds']*=5
check('80_queries_cannot_replace_initial16',lambda:reject(lambda:a.screen_input(bad,'retained',1)))
record={'status':'passed','count':len(checks),'checks':checks,'new_database_runs':0,'new_compiler_runs':0,
 'source_commit_guard':'pending actual new commit' if a.CANDIDATE_COMMIT=='PENDING_NEW_COMMIT' else a.CANDIDATE_COMMIT,
 'scope':'Pure reader/schema controls. Reuses a previous raw measurement only to check field extraction; it is not a new norm-candidate result.'}
(w/'norm-maxabs-reader-preflight.json').write_text(json.dumps(record,indent=2)+'\n')
print(json.dumps(record))
