"""Record exact evidence for the completed c30 read-only audit; never run DB."""
import hashlib
import json
from pathlib import Path

w = Path(__file__).resolve().parent
names = [
    'analyze_norm_maxabs_primary_root.py', 'analyze_crc_root.py',
    'analyze_highest_compare.py', 'analyze_cursor_root.py',
    'analyze_insert_copy_root.py', 'evaluate_norm_maxabs_primary24_screen.py',
    'check_norm_maxabs_reader.py', 'norm-maxabs-reader-preflight.json',
    'norm-maxabs-source-guard.json', 'check_norm_maxabs_primary24_screen.py',
    'norm-maxabs-primary24-screen-preflight.json', 'check_norm_hint_ci.py',
    'norm-global-max-fusion-draft/ci-preflight.json',
    'norm-global-max-fusion-draft/shell-syntax-proof.json',
    'norm-maxabs-independent-analysis.json', 'norm-maxabs-decision.json',
    'norm-maxabs-decision.md', 'summarize_norm_maxabs_decision.py',
    'analyze_norm_index_policy.py', 'norm-maxabs-index-policy-audit.json',
    'seekdb/validation/iteration5-norm-maxabs-primary24-preregistration.json',
]
files = []
for name in names:
    path = w / name
    raw = path.read_bytes()
    files.append({'path': str(path), 'bytes': len(raw),
                  'sha256': hashlib.sha256(raw).hexdigest()})
analysis = json.loads((w / 'norm-maxabs-independent-analysis.json').read_bytes())
assert analysis['status'] == 'verified'
assert analysis['commit'] == 'c30d6ec369b82c8d143b2f7cd17ab3e95e88800c'
result = {
    'status': 'completed_independent_read_only_audit',
    'reader_exit_code': 0, 'reader_failures_observed': [],
    'commit': analysis['commit'], 'run_id': 43489727271,
    'artifact_id': 14070890303,
    'raw_archive': str(w / 'seekdb/validation/iteration5-norm-maxabs-raw.zip'),
    'raw_archive_sha256': 'daeb941c3ae77559bad819086ee9222c9e1c59fdc52b7da0a3bdcac977648812',
    'raw_archive_bytes': 3731249,
    'raw_extraction': str(w / 'norm-maxabs-primary-raw'),
    'actual_binary_sha256': '4e8812201468c2cff237f4c22c1f8a1124e1b502a89acdfd08e4f3dcabc57c6a',
    'raw_modified': False, 'new_database_runs': 0, 'new_builds': 0,
    'formal_submission_performed': False,
    'verified_pairs': 24, 'verified_root_gates': 21,
    'screen': 'screen_rejected_R_regression_keep_R',
    'eligible_for_independent_confirmation': False,
    'negative_or_mixed_metric_summaries': 164,
    'adverse_guard_pair_metric_records': 71,
    'negative_count_scope': 'Overlapping summaries/derived metrics, not independent experiments.',
    'files': files,
    'archive_recommendation':
        'Archive these exact files and this receipt with a fresh manifest. Keep the '
        'pinned raw ZIP separately and unchanged. Any runtime/test source copy must '
        'come from c30 Git objects, not a subsequently restored working tree. '
        'The preflight is Python/static only; actual native results are in the '
        'separately verified original CI raw artifact.',
}
out = w / 'norm-maxabs-audit-receipt.json'
out.write_text(json.dumps(result, ensure_ascii=False, indent=2) + '\n', encoding='utf8')
raw = out.read_bytes()
print(json.dumps({'output': str(out), 'bytes': len(raw),
                  'sha256': hashlib.sha256(raw).hexdigest(), 'files': len(files)}))
