"""Synthetic arithmetic/plan controls only; no DB or compiler execution."""
import copy
import hashlib
import json
from pathlib import Path
import evaluate_norm_maxabs_primary24_screen as screen

work=Path(__file__).resolve().parent
plan=screen.read_preregistration(work/'norm-maxabs-primary24-preregistration-v2.json')
checks=[]

def fixture():
    result={}
    for key,pairs in screen.expected_groups(plan).items():
        time,memory=screen.guard_metric_names(key[2])
        result[key]=[]
        for pair in pairs:
            metrics={name:{'baseline':1.0,'candidate':1.0} for name in time+memory}
            if key[0]=='ee':
                metrics['first_lifecycle_wall_seconds']['candidate']=0.97
                metrics['first_1000_queries_wall_seconds']['candidate']=0.99
            result[key].append({**copy.deepcopy(pair),'metrics':metrics})
    return result

def evaluate(groups, gates=True):
    return screen.evaluate_screen(plan,groups,verified_gate_checks_passed=gates)

def test(name, action):
    action();checks.append({'name':name,'status':'passed'})

def require(ok, message='check failed'):
    if not ok:raise AssertionError(message)

def mutate(name, change, expected):
    def run():
        groups=fixture();change(groups);expected(evaluate(groups))
    test(name,run)

def reject(name, change):
    def run():
        groups=fixture();change(groups)
        try:evaluate(groups)
        except ValueError:return
        raise AssertionError('malformed input was not rejected')
    test(name,run)

def set_ratio(groups,key,metric,ratio,indices=None):
    for i,pair in enumerate(groups[key]):
        if indices is None or i in indices:pair['metrics'][metric]['candidate']=ratio

ee1=('ee',1,'standard10k');ee2=('ee',2,'standard10k')
r1=('retained',1,'standard10k');r2=('retained',2,'standard10k')
spill=('retained',1,'spill_high_q16');wide=('retained',2,'wide768')
passes=lambda result:require(result['eligible_for_one_confirmation'] and not result['automatic_adoption'] and not result['selected_runtime_change_authorized'])
fails_ee=lambda result:require(result['status']=='screen_EE_primary_criteria_not_met_keep_R')
fails_r=lambda result:require(result['status']=='screen_rejected_R_regression_keep_R')
test('exact_24_plan_screen_only_no_adoption',lambda:passes(evaluate(fixture())))
test('unverified_gates_never_pass',lambda:require(evaluate(fixture(),False)['status']=='inconclusive_gates_not_verified_keep_R'))
mutate('EE_firstcycle_boundary_0_98_inclusive',lambda g:set_ratio(g,ee1,'first_lifecycle_wall_seconds',0.98),passes)
mutate('EE_firstcycle_above_0_98_fails',lambda g:set_ratio(g,ee1,'first_lifecycle_wall_seconds',0.98001),fails_ee)
mutate('EE_four_of_six_improvements_insufficient',lambda g:set_ratio(g,ee1,'first_lifecycle_wall_seconds',1.001,[0,1]),fails_ee)
mutate('EE_second_CPU_not_pooled_with_first',lambda g:set_ratio(g,ee2,'first_lifecycle_wall_seconds',0.995),fails_ee)
mutate('EE_query_boundary_one_inclusive',lambda g:set_ratio(g,ee1,'first_1000_queries_wall_seconds',1),passes)
mutate('EE_query_median_above_one_fails',lambda g:set_ratio(g,ee1,'first_1000_queries_wall_seconds',1.0001),fails_ee)
mutate('R_time_boundary_1_02_not_strictly_worse',lambda g:set_ratio(g,r1,'ingest_wall_seconds',1.02),passes)
mutate('R_both_orders_stable_time_regression',lambda g:set_ratio(g,r1,'ingest_wall_seconds',1.02001),fails_r)
mutate('R_only_AB_worse_not_stable',lambda g:set_ratio(g,r1,'ingest_wall_seconds',1.1,[0,2]),passes)
mutate('R_CPU_separate_guard',lambda g:set_ratio(g,r2,'complete_lifecycle_cpu_usec',1.03),fails_r)
mutate('memory_boundary_1_05_not_strictly_worse',lambda g:set_ratio(g,r1,'memory_peak_bytes',1.05),passes)
mutate('sampled_RSS_stable_regression',lambda g:set_ratio(g,r2,'max_process_rss_bytes',1.05001),fails_r)
mutate('spill_one_adverse_order_not_stable',lambda g:set_ratio(g,spill,'query_before_mutations_wall_seconds',1.2,[0]),passes)
mutate('spill_both_orders_adverse_block',lambda g:set_ratio(g,spill,'query_before_mutations_wall_seconds',1.03),fails_r)
mutate('wide_aggregate_CPU_both_orders_adverse_block',lambda g:set_ratio(g,wide,'seven_query_phases_cpu_usec',1.03),fails_r)
mutate('wide_memory_both_orders_adverse_block',lambda g:set_ratio(g,wide,'memory_peak_bytes',1.06),fails_r)
reject('missing_group',lambda g:g.pop(wide))
reject('bool_CPU_key_is_not_integer_CPU',lambda g:g.update({('ee',True,'standard10k'):g.pop(ee1)}))
reject('missing_pair',lambda g:g[ee1].pop())
reject('wrong_order',lambda g:g[ee1][0].update(order=['candidate','baseline']))
reject('duplicate_pair_index',lambda g:g[ee1][1].update(pair_index=0))
reject('missing_required_metric',lambda g:g[r1][0]['metrics'].pop('ingest_wall_seconds'))
reject('zero_denominator',lambda g:g[r1][0]['metrics']['ingest_wall_seconds'].update(baseline=0))
reject('nonfinite_metric',lambda g:g[r1][0]['metrics']['ingest_wall_seconds'].update(candidate=float('nan')))
reject('bool_is_not_numeric_measurement',lambda g:g[r1][0]['metrics']['ingest_wall_seconds'].update(candidate=True))
reject('no_invented_first_request_CPU',lambda g:g[r1][0]['metrics'].update(first_query_cpu_usec={'baseline':1,'candidate':1}))
reject('spill_startup_CPU_not_ingest_CPU',lambda g:g[spill][0]['metrics'].update(ingest_cpu_usec={'baseline':1,'candidate':1}))
reject('wide_RSS_not_measured',lambda g:g[wide][0]['metrics'].update(max_process_rss_bytes={'baseline':1,'candidate':1}))
def changed_plan():
    bad=copy.deepcopy(plan);bad['screen_rules']['EE_each_CPU_required']['median_ratio_max']=1
    try:screen.evaluate_screen(bad,fixture(),verified_gate_checks_passed=True)
    except ValueError:return
    raise AssertionError('changed frozen criterion accepted')
test('changed_frozen_rule_rejected',changed_plan)
def changed_spill_mapping():
    bad=copy.deepcopy(plan)
    bad['screen_rules']['R_protection']['spill_query_mapping']['query_before_mutations_wall_seconds']['required_request_count']=80
    try:screen.evaluate_screen(bad,fixture(),verified_gate_checks_passed=True)
    except ValueError:return
    raise AssertionError('wrong spill initial-query mapping accepted')
test('spill_mapping_cannot_expand_16_to_80',changed_spill_mapping)
report={'status':'passed','check_count':len(checks),'checks':checks,'database_runs':0,'compiler_runs':0,
        'actual_experiment_result_verified':False,'scope':'Synthetic arithmetic and schema controls; no measured candidate benefit.',
        'preregistration_sha256':screen.PREREG_SHA,
        'test_timing':'Synthetic numerical checks only; no norm artifact or measured result was consumed',
        'module_sha256':hashlib.sha256((work/'evaluate_norm_maxabs_primary24_screen.py').read_bytes()).hexdigest(),
        'test_script_sha256':hashlib.sha256(Path(__file__).read_bytes()).hexdigest()}
output=work/'norm-maxabs-primary24-screen-preflight.json'
if output.exists():raise FileExistsError('refuse overwrite')
output.write_text(json.dumps(report,indent=2)+'\n',encoding='utf8')
print(json.dumps({'status':report['status'],'checks':len(checks),'database_runs':0,'compiler_runs':0,'module_sha256':report['module_sha256']},indent=2))
