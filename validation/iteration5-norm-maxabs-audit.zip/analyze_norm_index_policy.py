"""Read-only index phase and observed query-policy audit of verified c30 raw."""
import hashlib,json,math,re
from pathlib import Path
from statistics import median
import analyze_crc_root as core
w=Path(__file__).resolve().parent;root=w/'norm-maxabs-primary-raw/highest-primary-root'
analysis=w/'norm-maxabs-independent-analysis.json';verified=json.loads(analysis.read_bytes())
assert verified['status']=='verified' and verified['commit']=='c30d6ec369b82c8d143b2f7cd17ab3e95e88800c'
manifest={p['path']:p for p in core.read(root/'hashes.json')['artifacts']}
def source(name):
 p=root/name;item=manifest[name];assert p.stat().st_size==item['bytes'] and core.sha(p)==item['sha256'];return core.read(p)
def policy(run):
 assert run['effective_environment']=={} and run['thread_policy_observations']['stderr_complete']
 sessions=[]
 for line in run['thread_policy_observations']['fanout_log_lines']:
  if 'median of 200 handshakes' in line:
   sessions.append({'wake_us':float(re.search(r'wake_us=([0-9.]+)',line).group(1)),'decisions':[]})
  else:
   m=re.fullmatch(r'mvdb: fanout rows=10000 scan=100.0us wake=([0-9.]+)us predicted_gain=([-0-9.]+)us -> ([12]) threads?',line)
   assert m and sessions and float(m.group(1))==sessions[-1]['wake_us']
   sessions[-1]['decisions'].append(int(m.group(3)))
 assert len(sessions)==2
 for p in sessions:
  assert len(p['decisions'])==4 and len(set(p['decisions']))==1
  p['unfiltered_selected_threads']=p.pop('decisions')[0]
 return sessions
def cpu_interval(run,start,end):
 phases={p['phase']:p for p in run['adapter']['phase_cgroups']}
 b,c=[core.counters(phases[p]['cpu.stat']) for p in (start,end)]
 return {name:c[name]-b[name] for name in ('usage_usec','user_usec','system_usec')}
def aggregate(rows,name):
 b=[r['baseline'][name] for r in rows];c=[r['candidate'][name] for r in rows]
 ratios=[y/x for x,y in zip(b,c)];assert all(math.isfinite(x) and x>0 for x in ratios)
 return {'median_candidate_over_baseline':median(ratios),'candidate_worse_pairs':sum(y>x for x,y in zip(b,c)),
  'candidate_faster_pairs':sum(y<x for x,y in zip(b,c)),'baseline_absolute':b,'candidate_absolute':c,
  'raw_ratios':ratios,'median_baseline_absolute':median(b),'median_candidate_absolute':median(c)}
index_groups={};policy_groups={}
for reference in ('ee','retained'):
 for count in (1,2):
  data=source(f'{reference}-{count}cpu.json');label=f'{reference}:{count}'
  policy_rows=[]
  for pair in data['pairs']:
   scenario=pair['scenario']
   if scenario=='wide768':continue
   row={k:pair[k] for k in ('pair_index','order','scenario')}
   for role in ('baseline','candidate'):
    run=pair[role];phase=run['phase_seconds'];cp=cpu_interval(run,'after_ingest','after_index_build')
    first=core.lifecycle_timings(run)['first_lifetime_no_restart']
    row[role]={'index_wall_ms':phase['index_build']*1000,'index_cpu_ms':cp['usage_usec']/1000,
      'index_user_ms':cp['user_usec']/1000,'index_system_ms':cp['system_usec']/1000,
      'first_cycle_ms':first*1000,'index_share_of_first_cycle':phase['index_build']/first}
   row['index_wall_delta_ms']=row['candidate']['index_wall_ms']-row['baseline']['index_wall_ms']
   row['index_delta_share_of_baseline_cycle']=row['index_wall_delta_ms']/row['baseline']['first_cycle_ms']
   index_groups.setdefault(label+':'+scenario,[]).append(row)
   if scenario!='standard10k':continue
   trace={k:pair[k] for k in ('pair_index','order')}
   for role in ('baseline','candidate'):
    run=pair[role];sessions=policy(run);observations=[]
    for i,name in enumerate(('query_before_update','query_after_restart')):
     samples=run['query'][name]['per_request_seconds'];assert len(samples)==1000
     start='after_index_build' if i==0 else 'after_restart';cp=cpu_interval(run,start,name)
     observations.append({'phase':name,'policy':sessions[i],'query_wall_ms':math.fsum(samples)*1000,
       'first_query_wall_ms':samples[0]*1000,'tail999_wall_ms':math.fsum(samples[1:])*1000,
       'phase_cpu_ms':cp['usage_usec']/1000,'phase_user_ms':cp['user_usec']/1000,'phase_system_ms':cp['system_usec']/1000,
       'first_query_cpu_ms':None,'tail_query_cpu_ms':None,
       'cpu_scope':'aggregate query phase' if i==0 else 'restart verification plus query phase'})
    trace[role]=observations
   trace['same_logged_policy_by_phase']=[trace['baseline'][i]['policy']['unfiltered_selected_threads']==trace['candidate'][i]['policy']['unfiltered_selected_threads'] for i in (0,1)]
   policy_rows.append(trace)
  policy_groups[label]={'raw_pairs':policy_rows,
    'first_phase_same_policy_pairs':sum(p['same_logged_policy_by_phase'][0] for p in policy_rows),
    'restart_phase_same_policy_pairs':sum(p['same_logged_policy_by_phase'][1] for p in policy_rows),
    'observed_policy_pairs':{phase:[[p['baseline'][i]['policy']['unfiltered_selected_threads'],p['candidate'][i]['policy']['unfiltered_selected_threads']] for p in policy_rows] for i,phase in enumerate(('first','restart'))}}
summaries={label:{'raw_pairs':rows,'metrics':{name:aggregate(rows,name) for name in ('index_wall_ms','index_cpu_ms','first_cycle_ms','index_share_of_first_cycle')},
  'median_index_delta_share_of_baseline_cycle':median(r['index_delta_share_of_baseline_cycle'] for r in rows)} for label,rows in index_groups.items()}
result={'status':'descriptive_analysis_of_verified_c30_artifact','analysis_sha256':core.sha(analysis),
 'index_phase':summaries,'default_query_policy':policy_groups,
 'limitations':['All pairs retained; these descriptions do not replace the preregistered screen.',
 'Index wall is the CREATE INDEX request timer. Index CPU is after_ingest to after_index_build cgroup delta, including work between the snapshots; it is not isolated max-scan CPU.',
 'The diagnostic unit proves a full norm traversal and removal of a max traversal in admitted fixtures. It does not measure per-operation work in these benchmark processes.',
 'Four early eligible unfiltered fanout decisions are logged per startup. Their identical values describe the cached policy, not a trace of every request. Filtered queries remain serial under the unchanged source policy.',
 'First and tail query CPU were not sampled. Restart-phase CPU includes recovery verification.',
 'Unchanged observed fanout does not establish that unrelated ingest/query changes were caused by max fusion. Compiler/layout effects and shared-host variation remain unseparated.',
 'No distinct index_build timer exists for wide projection; none is fabricated. Spill index statistics are reported even though its disk path does not use the new resident hint.'],
 'new_database_runs':0,'new_builds':0,'formal_submission':False}
out=w/'norm-maxabs-index-policy-audit.json';out.write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps({'output':str(out),'bytes':out.stat().st_size,'sha256':core.sha(out)}))
for label,value in summaries.items():
 print(label,{key:(metric['median_candidate_over_baseline'],metric['candidate_worse_pairs'],metric['median_baseline_absolute'],metric['median_candidate_absolute']) for key,metric in value['metrics'].items()},'delta_cycle_share',value['median_index_delta_share_of_baseline_cycle'])
for label,value in policy_groups.items():print('POLICY',label,value['observed_policy_pairs'])
