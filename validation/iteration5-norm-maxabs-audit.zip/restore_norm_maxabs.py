"""Restore the retained runtime after the failed independent norm screen."""
from pathlib import Path
import hashlib,json,subprocess

repo=Path(__file__).resolve().parent/'seekdb'
git=['git','-c','safe.directory='+repo.as_posix(),'-C',str(repo)]
reference='be8867544495ea37672113a7a6ee4585e5baf9ed'
candidate='c30d6ec369b82c8d143b2f7cd17ab3e95e88800c'
names=('minivec/src/db.cpp','minivec/src/flat_index.cpp','minivec/src/flat_index.h',
       'minivec/tools/ci_score.sh','minivec/tools/prepare_highest_primary.py',
       'minivec/tools/prepare_small_compute.py','minivec/tools/summarize_highest_primary.py')
records={}
for name in names:
    data=subprocess.check_output(git+['show',reference+':'+name])
    (repo/name).write_bytes(data)
    records[name]=hashlib.sha256(data).hexdigest()
name='minivec/tests/test_global_max_hint.cpp'
target=(repo/name).resolve()
assert target.is_relative_to(repo.resolve())
old=subprocess.check_output(git+['show',candidate+':'+name])
assert target.read_bytes()==old
saved=repo.parent/'norm-global-max-fusion-draft/rejected-test_global_max_hint.cpp'
saved.write_bytes(old)
target.unlink()
proof={'status':'rejected_norm_runtime_and_active_CI_restored','reference':reference,
       'restored_files_sha256':records,'test_preserved_at_commit':candidate,
       'test_sha256':hashlib.sha256(old).hexdigest(),
       'new_database_runs':0,'formal_submission':False}
(repo.parent/'norm-maxabs-rollback.json').write_text(json.dumps(proof,indent=2)+'\n',encoding='utf8')
print(json.dumps(proof))
