"""Work-only norm rejection archive/preview; preserve all existing material."""
import copy
import hashlib
import importlib.util
import io
import json
from pathlib import Path
import subprocess
import zipfile

BASE='e5df72b69cd85447df0a0f715b453ab8978dac98d38fa6fa310c43884a38d688'
RAW_SHA='daeb941c3ae77559bad819086ee9222c9e1c59fdc52b7da0a3bdcac977648812'
ANALYSIS_SHA='108ae0037e227e6236186a0ffa9b259a6e722c2fe68a18af933a8b1dcb1bff4e'
DECISION_SHA='01e72c3bb7231d6b122c77c1951acb0fb91bc4ca5c2a8890944f892d2ae7c9a3'
RECEIPT_SHA='785bd75adc89327507e51751f91ace4e3e68b14025f67b646be3d572b9c65dae'
CANDIDATE='c30d6ec369b82c8d143b2f7cd17ab3e95e88800c'
RAW_DEST='validation/iteration5-norm-maxabs-raw.zip'
AUDIT_DEST='validation/iteration5-norm-maxabs-audit.zip'

def need(ok,message):
    if not ok:raise ValueError(message)

def sha(data):return hashlib.sha256(data).hexdigest()

def encode(value):return (json.dumps(value,ensure_ascii=False,separators=(',',':'),allow_nan=False)+'\n').encode('utf8')

def pointers(value):
    if isinstance(value,dict):return [v for k,v in value.items() if k=='pointer' or k.endswith('_pointer')]+[p for v in value.values() for p in pointers(v)]
    if isinstance(value,list):return [p for v in value for p in pointers(v)]
    return []

def main():
    work=Path(__file__).resolve().parent;repo=(work/'seekdb').resolve()
    prior=(repo/'conversation.json').read_bytes()
    need(prior==(repo/'agent/conversation.json').read_bytes() and len(prior)==129434 and sha(prior)==BASE,'material drift')
    old=json.loads(prior);need(encode(old)==prior and len(old['messages'])==138 and len(old['experiments'])==56,'inventory differs')
    users=[m for m in old['messages'] if m['role']=='user'];need(len(users)==46,'user count differs')
    raw=(repo/RAW_DEST).read_bytes();need(len(raw)==3731249 and sha(raw)==RAW_SHA,'raw differs')
    receipt_raw=(work/'norm-maxabs-audit-receipt.json').read_bytes();need(sha(receipt_raw)==RECEIPT_SHA,'receipt differs')
    receipt=json.loads(receipt_raw);need(len(receipt['files'])==21,'receipt file inventory differs')
    files={'norm-maxabs-audit-receipt.json':receipt_raw}
    for entry in receipt['files']:
        path=Path(entry['path']).resolve();need(path.is_relative_to(work),'receipt path outside work')
        data=path.read_bytes();need(len(data)==entry['bytes'] and sha(data)==entry['sha256'],'receipt input changed: '+path.name)
        files[path.relative_to(work).as_posix()]=data
    for name in ['norm-maxabs-rollback.json','restore_norm_maxabs.py','norm-maxabs-staged-rollback-proof.json','verify_norm_rollback.py','record_norm_maxabs_audit_receipt.py',Path(__file__).name]:
        files[name]=(work/name).read_bytes()
    need(sha(files['norm-maxabs-staged-rollback-proof.json'])=='d67b4ad4992c398a312a0faedc401186b0c5bda51837361a61df8ff61235ef41','staged rollback proof differs')
    for name in ['pgo-isa-coverage-current-audit.md','pgo-isa-coverage-extra-evidence.json']:
        files['read_only_next_direction/'+name]=(work/name).read_bytes()
    files['read_only_next_direction/README.txt']=b'Read-only follow-up screening; not part of norm performance measurements. No implementation, build, or new CI is claimed. Mixed ISA has insufficient evidence for immediate work; complete-dimensional AVX2 training already existed and is not a new direction or proven cause of formal score decline.\n'
    need(sha(files['norm-maxabs-independent-analysis.json'])==ANALYSIS_SHA and sha(files['norm-maxabs-decision.json'])==DECISION_SHA,'verified result differs')
    analysis=json.loads(files['norm-maxabs-independent-analysis.json']);decision=json.loads(files['norm-maxabs-decision.json'])
    need(analysis['status']=='verified' and analysis['verified_pairs']==24 and analysis['commit']==CANDIDATE
         and analysis['artifact_sha256']==RAW_SHA and len(analysis['root_gates'])==21 and all(analysis['root_gates'].values()),'actual gate/result differs')
    need(analysis['candidate_binary_sha256']=='4e8812201468c2cff237f4c22c1f8a1124e1b502a89acdfd08e4f3dcabc57c6a','actual ELF differs')
    need(decision['screen']=='screen_rejected_R_regression_keep_R' and decision['guard_trigger_count']==4
         and decision['all_negative_or_mixed_metric_summary_count']==164 and decision['guard_adverse_pair_metric_records']==71
         and not decision['eligible_for_one_confirmation'] and not decision['adopted'],'rejection differs')
    need(analysis['source_equivalence_gates']['global_max_hint']['checks_per_mode']==10158,'hint checks differ')
    with zipfile.ZipFile(io.BytesIO(raw)) as zf:
        names=[n for n in zf.namelist() if n.endswith('global-max-hint-block-scale.log')]
        need(len(names)==1 and '10199' in zf.read(names[0]).decode('utf8'),'block-scale checks differ')
    rollback=json.loads(files['norm-maxabs-rollback.json'])
    need(rollback['status']=='rejected_norm_runtime_and_active_CI_restored' and rollback['new_database_runs']==0
         and rollback['test_preserved_at_commit']==CANDIDATE,'rollback proof differs')
    git=['git','-c','safe.directory='+repo.as_posix()]
    binding={'status':'verified_immutable_Git_blobs','git_mutations':0,'worktree_source_reads':0,'candidate_commit':CANDIDATE,
             'restoration_reference':rollback['reference'],'files':{}}
    def add_git(commit,relative,prefix,expected=None):
        data=subprocess.check_output(git+['show',commit+':'+relative],cwd=repo)
        oid=subprocess.check_output(git+['rev-parse',commit+':'+relative],cwd=repo,text=True).strip()
        need(hashlib.sha1(b'blob '+str(len(data)).encode()+b'\0'+data).hexdigest()==oid,'Git blob OID mismatch')
        if expected:need(sha(data)==expected,'Git data/rollback hash differs: '+relative)
        name=prefix+'/'+relative;files[name]=data
        binding['files'][name]={'commit':commit,'git_blob':oid,'bytes':len(data),'sha256':sha(data)}
    for relative,digest in rollback['restored_files_sha256'].items():
        add_git(rollback['reference'],relative,'restored-source-and-CI',digest)
    for relative in ['minivec/src/db.cpp','minivec/src/flat_index.cpp','minivec/src/flat_index.h','minivec/tools/ci_score.sh']:
        add_git(CANDIDATE,relative,'historical-norm-candidate')
    add_git(CANDIDATE,'minivec/tests/test_global_max_hint.cpp','historical-norm-candidate',rollback['test_sha256'])
    files['immutable-source-binding.json']=encode(binding)
    manifest={'schema':'norm-maxabs-rejection-audit-v1','actual_raw':{'path':RAW_DEST,'bytes':len(raw),'sha256':RAW_SHA,
        'run_id':43489727271,'artifact_id':14070890303},'candidate':{'commit':CANDIDATE,'binary_sha256':analysis['candidate_binary_sha256'],
        'image_id':analysis['candidate_image_id']},'result':{'verified_pairs':24,'root_gate_count':21,'guard_triggers':4,
        'negative_or_mixed_summaries':164,'adverse_guard_pair_metric_records':71,'counts_overlap':True,'default_adopted':False},
        'material_before':{'bytes':len(prior),'sha256':BASE},
        'rollback_scope':'The original c30 test and source are archived from immutable Git. Restored production and active CI files bind be886 Git blobs. The c30 21 gates do not claim a fresh run after rollback.',
        'files':{name:{'bytes':len(data),'sha256':sha(data)} for name,data in sorted(files.items())}}
    buffer=io.BytesIO()
    with zipfile.ZipFile(buffer,'w',zipfile.ZIP_DEFLATED,compresslevel=9) as zf:
        for name,data in sorted({**files,'manifest.json':encode(manifest)}.items()):
            info=zipfile.ZipInfo(name,date_time=(2026,11,14,0,0,0));info.external_attr=0o100644<<16
            zf.writestr(info,data,compress_type=zipfile.ZIP_DEFLATED,compresslevel=9)
    audit=buffer.getvalue();new=copy.deepcopy(old);experiment=new['experiments'][55]
    need(experiment['id']=='norm-maxabs-fusion-highest-primary24','experiment differs')
    experiment.update(status='measured_rejected_retained_runtime_CI_restored',new_pgo_builds_executed=1,database_pairs_executed=24,
        result_message='assistant-norm-maxabs-rejected',root_gate_groups=21,guard_trigger_entries=4,
        negative_or_mixed_metric_summaries=164,adverse_guard_pair_metric_records=71)
    experiment['artifacts'] += [{'path':RAW_DEST,'sha256':RAW_SHA},{'path':AUDIT_DEST,'sha256':sha(audit)}]
    new['messages'].append({'id':'assistant-norm-maxabs-rejected','role':'assistant','content':
        'assistant实测c30：新根PGO1次；21正确性门禁通过，24对测量核验有效，但性能筛选失败。hint normal/san各10158，block10199。C/EE首周期阶段和1/2CPU=1.001022/0.954313，查询=1.036470/0.937925，EE1未达门槛。R默认首周期0.978531/0.988992虽改善，但spill首16查询wall/CPU/首条及R2首条共4guard触发。164混合负面摘要/71负面guard对子全保留，重叠不相加。拒绝且不确认；三生产文件及专用CI回退R，测试仅历史与归档。43个生产源码/构建输入与R相同，未重建R。21门禁属于本轮c30，不冒充回退后新测试；无正式提交或分数承诺。'})
    need(new['messages'][:138]==old['messages'] and new['experiments'][:55]==old['experiments'][:55],'old record changed')
    need([m for m in new['messages'] if m['role']=='user']==users,'user changed')
    for key in old:
        if key not in ('messages','experiments'):need(new[key]==old[key],'root field changed: '+key)
    spec=importlib.util.spec_from_file_location('norm_rejection_checker',repo/'minivec/tools/validate_iteration_material.py')
    checker=importlib.util.module_from_spec(spec);spec.loader.exec_module(checker)
    checker.validate(repo);checker.check_structure(new,new)
    for pointer in pointers(old):need(encode(checker.resolve_pointer(new,pointer))==encode(checker.resolve_pointer(old,pointer)),'old pointer changed')
    material=encode(new);need(len(material)<=131072,'material exceeds limit')
    summary={'status':'work_preview_not_applied','source_bytes':len(prior),'source_sha256':BASE,'preview_bytes':len(material),
        'preview_sha256':sha(material),'remaining_bytes':131072-len(material),'messages':len(new['messages']),'experiments':56,'users':46,
        'all_original_message_objects_preserved':138,'all_old_results_and_failures_preserved':True,'all_users_and_manifest_unchanged':True,
        'selected_runtime_unchanged':True,'old_pointer_targets_unchanged':True,'compaction_performed':False,
        'new_database_runs':0,'new_builds':0,'repository_writes':0,'git_mutations':0,'prospective_full_repository_validation_run':False,
        'copy_recommendation':[{'source':'iteration5-norm-maxabs-audit-v2.zip','target':AUDIT_DEST,'bytes':len(audit),'sha256':sha(audit)},
            {'source':'norm-rejection-material-preview-v2.json','targets':['conversation.json','agent/conversation.json'],'bytes':len(material),'sha256':sha(material)}]}
    for name,data in [('iteration5-norm-maxabs-audit-v2.zip',audit),('norm-rejection-material-preview-v2.json',material),('norm-rejection-material-summary-v2.json',encode(summary))]:
        target=work/name;need(not target.exists(),'refuse overwrite');target.write_bytes(data)
    print(json.dumps({k:summary[k] for k in ('status','preview_bytes','remaining_bytes','preview_sha256')},indent=2))

if __name__=='__main__':main()
