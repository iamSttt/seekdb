"""Independent read-only audit of EE-root versus imported retained/CRC evidence.

Runs pure Python Git/input verification only. Never launches a database, compiler,
Docker, submission client, or other measured process.
"""
import argparse
import base64
import hashlib
import io
import json
import math
from pathlib import Path
import re
from statistics import median
import zipfile

import analyze_crc_root as core

EE = 'ee299adb296a2922d01982aa6c5707d37e767b41'
EE_TREE = '18e18607350d36f5e7b701512d68afdd99df0628'
RETAINED = core.BASE
CRC = '780be2c8954ce5706f44abba5681d7326e41a27e'
R_SHA = core.BASE_BINARY
C_SHA = '8bf702f8b87df81f886df9cff12d72ec27e5a600e367fad0b97de19526607f20'
EE_ARCHIVE = 'validation/iteration5-ee299-root-source.zip'
EE_ARCHIVE_SHA = 'ffe5ea77bd0c102b0f3658fa6c5c46a4834c77acb2a2a9365b96b3aea5ca52e4'
CRC_ARCHIVE = 'validation/iteration5-crc-root-raw.zip'
CRC_ARCHIVE_SHA = '70a0383fc86708ab680315fd9b98d5573d8dedc22f0bf70ea055e6abd7ab11b8'
RECOVERY_ARTIFACT_SHA = 'cb6a5801cf2195cfcb0aafe7067143c825c8420974ead2c9e81ab6e6c2deb599'
RECOVERY_COMMIT = '95afba3993cb21cdce32acf2502312262b8ae9ac'
RECOVERABLE_SOURCE = 'ee-context/.dockerignore'
INPUTS = {'minivec/tools/ci_highest_compare.sh', 'minivec/tools/prepare_highest_compare.py',
    'minivec/tools/summarize_highest_compare.py', 'minivec/tools/prepare_small_compute.py',
    'minivec/tools/summarize_small_root.py', 'minivec/tools/small_compute.py',
    'minivec/tools/benchmark_iteration.py', 'minivec/tools/benchmark_index_delta.py',
    'minivec/tools/benchmark_write_query.py', 'minivec/tools/benchmark_projection.py',
    'minivec/tools/cgroup_exec.c', 'minivec/tests/json_protocol.py', 'minivec/tests/topk_bounds.py',
    EE_ARCHIVE, CRC_ARCHIVE}
CHECKS = {'complete_git_bound_inputs', 'original_ee_git_objects_and_context',
    'ee_actual_image_public_json_topk', 'prior_program_bytes_and_proofs',
    'all_40_pairs_correct_identity_exact_resource', 'same_runner_affinity_and_workloads'}
require, sha, read, digest, blob, git = core.require, core.sha, core.read, core.digest, core.blob, core.git


def git_oid(kind, raw):
    return hashlib.sha1(kind.encode() + b' ' + str(len(raw)).encode() + b'\0' + raw).hexdigest()


def git_tree(raw):
    entries = {}; offset = 0
    while offset < len(raw):
        zero = raw.index(b'\0', offset)
        mode, name = raw[offset:zero].split(b' ', 1)
        name = name.decode('utf8'); core.safe_name(name)
        require('/' not in name and name not in entries and zero + 21 <= len(raw), 'invalid/truncated Git tree member')
        entries[name] = (mode.decode(), raw[zero + 1:zero + 21].hex())
        offset = zero + 21
    return entries


def manifest_with_exact_source_recovery(root, repo, commit, artifact_sha):
    """One fixed artifact lost one redundant hidden source member on upload.

    Recover that source only in memory. Every output, binary, log and other input
    remains required in the actual archive. Later EE object verification binds
    these bytes to the original commit/tree/blob rather than trusting this map.
    """
    entries = read(root / 'hashes.json')['artifacts']; names = [x['path'] for x in entries]
    require(len(names) == len(set(names)), 'duplicate artifact manifest entry')
    for name in names: core.safe_name(name)
    actual = {p.relative_to(root).as_posix() for p in root.rglob('*') if p.is_file()} - {'hashes.json'}
    missing = set(names) - actual
    require(not actual - set(names), 'extra unmanifested artifact member')
    virtual, recovery = {}, []
    if missing:
        require(missing == {RECOVERABLE_SOURCE} and artifact_sha == RECOVERY_ARTIFACT_SHA and commit == RECOVERY_COMMIT,
                'unexpected missing artifact member; exact recovery exception does not apply')
        raw_archive = blob(repo, commit, EE_ARCHIVE)
        require(len(raw_archive) == 232726 and digest(raw_archive) == EE_ARCHIVE_SHA, 'recovery archive is not the pinned Git source')
        with zipfile.ZipFile(io.BytesIO(raw_archive)) as archive:
            value = archive.read('context/.dockerignore')
        virtual[RECOVERABLE_SOURCE] = value
        recovery.append({'missing_raw_artifact_member': RECOVERABLE_SOURCE, 'bytes': len(value), 'sha256': digest(value),
            'recovery_kind': 'read_only_in_memory_source_bytes', 'source_git_commit': commit,
            'source_git_path': EE_ARCHIVE, 'source_archive_sha256': EE_ARCHIVE_SHA,
            'source_archive_member': 'context/.dockerignore', 'original_source_commit': EE,
            'original_git_blob': git_oid('blob', value),
            'scope': 'Raw Actions artifact does not contain this hidden source file. Bytes come from the immutable source archive and are additionally bound to EE commit/tree/blob below. No raw archive/extraction changes and no reconstructed output/performance evidence.'})
    for entry in entries:
        path = entry['path']; raw = virtual[path] if path in virtual else (root / path).read_bytes()
        require(len(raw) == entry['bytes'] and digest(raw) == entry['sha256'], 'artifact member bytes/hash differ: ' + path)
    return virtual, {'raw_source_archive_complete': not missing, 'manifest_members': len(entries),
                     'physical_manifest_members': len(actual), 'missing_raw_members': sorted(missing), 'source_recovery': recovery}


def read_source(root, path, virtual):
    if path in virtual:
        require(path == RECOVERABLE_SOURCE and not (root / path).exists(), 'invalid virtual source substitution')
        return virtual[path]
    return (root / path).read_bytes()


def original_ee(root, repo, commit, prep, virtual=None):
    virtual = {} if virtual is None else virtual
    raw_archive = blob(repo, commit, EE_ARCHIVE)
    require(len(raw_archive) == 232726 and digest(raw_archive) == EE_ARCHIVE_SHA, 'pinned EE archive differs')
    manifest_raw = (root / 'ee-source-manifest.json').read_bytes()
    manifest = json.loads(manifest_raw)
    require(manifest['source_commit'] == EE and manifest['full_tree'] == EE_TREE, 'EE source identity differs')
    raw_commit = base64.b64decode(manifest['git_commit_raw_base64'], validate=True)
    require(git_oid('commit', raw_commit) == EE and raw_commit.splitlines()[0] == ('tree ' + EE_TREE).encode(), 'EE commit object does not bind tree')
    trees = {}
    for key, encoded in manifest['git_tree_objects_base64'].items():
        raw = base64.b64decode(encoded, validate=True)
        require(git_oid('tree', raw) == key, 'EE tree object hash differs')
        trees[key] = git_tree(raw)
    top = trees[EE_TREE]; mini = trees[top['minivec'][1]]
    expected = {'Dockerfile', '.dockerignore', 'minivec/Makefile'}
    for name in ('src', 'third_party'):
        subtree = trees[mini[name][1]]
        require(all(mode == '100644' for mode, _ in subtree.values()), 'unexpected nested/nonregular EE source')
        expected.update('minivec/' + name + '/' + path for path in subtree)
    require(len(expected) == 24 and 'minivec/src/vector.cpp' in expected and set(manifest['files']) == expected,
            'complete original EE wildcard input inventory differs')
    virtual_inputs = {name.removeprefix('ee-context/') for name in virtual}
    require(not virtual or set(virtual) == {RECOVERABLE_SOURCE}, 'unapproved virtual source inventory')
    require(expected == {p.relative_to(root / 'ee-context').as_posix() for p in (root / 'ee-context').rglob('*') if p.is_file()} | virtual_inputs,
            'EE actual build context inventory differs')
    hashes = {}
    with zipfile.ZipFile(io.BytesIO(raw_archive)) as archived:
        names = archived.namelist()
        require(len(names) == len(set(names)) and set(names) == {'manifest.json'} | {'context/' + p for p in expected}, 'EE source ZIP inventory differs')
        require(archived.read('manifest.json') == manifest_raw, 'EE artifact manifest differs from pinned Git archive')
        for path in sorted(expected):
            cursor = top; parts = path.split('/')
            for component in parts[:-1]:
                mode, key = cursor[component]; require(mode == '40000', 'EE source ancestor is not a tree'); cursor = trees[key]
            mode, oid = cursor[parts[-1]]; raw = read_source(root, 'ee-context/' + path, virtual); entry = manifest['files'][path]
            require(mode == entry['mode'] == '100644' and git_oid('blob', raw) == oid == entry['git_blob'] and
                    len(raw) == entry['bytes'] and digest(raw) == entry['sha256'] and archived.read('context/' + path) == raw,
                    'EE source blob/context mismatch: ' + path)
            hashes[path] = digest(raw)
    require(prep['ee_source_commit'] == EE and prep['ee_source_tree'] == EE_TREE and
            prep['ee_source_manifest_sha256'] == digest(manifest_raw) and prep['ee_source_sha256'] == hashes and
            prep['ee_archive_sha256'] == EE_ARCHIVE_SHA, 'EE preparation source binding differs')
    docker = (root / 'ee-context/Dockerfile').read_text()
    require(core.COMPILER in docker and 'src/*.cpp -o /minivec' in docker and
            'ENABLE_PGO' not in docker and 'FEATURE_FLAGS' not in docker and '-fprofile-' not in docker,
            'original EE build policy differs')
    return {'source_commit': EE, 'tree': EE_TREE, 'verified_context_files': len(expected), 'source_sha256': hashes,
            'manifest_sha256': digest(manifest_raw), 'archive_sha256': EE_ARCHIVE_SHA,
            'includes_original_vector_cpp': True, 'official_executable_retrieved': False}


def imported_programs(root, repo, commit, prep):
    raw = blob(repo, commit, CRC_ARCHIVE)
    require(len(raw) == 3020045 and digest(raw) == CRC_ARCHIVE_SHA == prep['crc_archive_sha256'], 'pinned CRC source artifact differs')
    with zipfile.ZipFile(io.BytesIO(raw)) as archive:
        prior = json.loads(archive.read('verification-summary.json'))
        require(prior['passed'] is True and set(prior['checks']) == core.GATES | {'actual_root_small_compute_20_pairs', 'actual_crc_old_new_18_checks'} and
                all(x is True for x in prior['checks'].values()), 'prior CRC root gate inventory differs')
        prefix = 'small-compute-root/programs/'
        original_ids = json.loads(archive.read(prefix + 'identities.json'))
        for label, role, revision, expected in (('retained', 'baseline', RETAINED, R_SHA), ('crc', 'candidate', CRC, C_SHA)):
            program = root / 'programs' / label; proof = read(program / 'proof.json'); item = original_ids[role]
            original = archive.read(prefix + item['binary']); original_proof = archive.read(prefix + item['evidence_file'])
            original_data = json.loads(original_proof)
            require(proof == prep['imported'][label] and proof['status'] == 'verified' and proof['source_commit'] == revision and
                    proof['kind'] == 'imported_historical_pgo_bytes' and proof['new_pgo_builds'] == 0 and
                    proof['official_binary_identity_known'] is False and proof['archive_sha256'] == CRC_ARCHIVE_SHA,
                    'historical import scope differs')
            require(digest(original) == expected == sha(program / 'minivec') == proof['binary_sha256'] == item['binary_sha256'] and
                    original == (program / 'minivec').read_bytes(), 'imported actual program bytes differ')
            require(original_proof == (program / 'original-proof.json').read_bytes() and digest(original_proof) ==
                    proof['original_proof_sha256'] == item['evidence_sha256'], 'imported original proof differs')
            require(item['source_commit'] == original_data['source_commit'] == revision and item['environment'] == {} and
                    original_data['binary_sha256'] == expected and original_data['feature_flags'] == core.FLAGS, 'original executable source/features differ')
            source = original_data['source_and_training_sha256'] if label == 'retained' else original_data['root_input_sha256']
            require(proof['historical_source_sha256'] == source, 'imported source manifest changed')
            for path, h in source.items(): require(digest(blob(repo, revision, path)) == h, 'imported historical source not bound to Git: ' + path)
            if label == 'crc':
                require(prior['runtime_commit'] == revision and prior['image_binary_sha256'] == expected and
                        prior['image_id'] == original_data['image_id'] == proof['historical_image_id'], 'CRC image identity differs')
    return {'retained': {'source_commit': RETAINED, 'binary_sha256': R_SHA},
            'crc': {'source_commit': CRC, 'binary_sha256': C_SHA}, 'archive_sha256': CRC_ARCHIVE_SHA,
            'new_pgo_builds': 0, 'scope': 'Exact program bytes from pinned previously audited artifact, not a new compilation or known official executable.'}


def image_gates(root, repo, commit, prep, binding):
    ee = binding['ee']; image = (root / 'ee-image-id.txt').read_text().strip()
    require(re.fullmatch(r'sha256:[0-9a-f]{64}', image) and ee['image_id'] == image, 'EE image ID differs')
    inspect = read(root / 'ee-image-inspect.json')
    require(len(inspect) == 1 and inspect[0]['Id'] == image and inspect[0]['Config']['Entrypoint'] == ['/minivec', '--data', '/data'], 'EE image inspection differs')
    require(read(root / 'programs/ee/proof.json') == ee and ee['status'] == 'verified' and ee['source_commit'] == EE and ee['source_tree'] == EE_TREE and
            ee['kind'] == 'one_original_root_docker_rebuild_without_pgo' and ee['new_non_pgo_builds'] == 1 and ee['new_pgo_builds'] == 0 and
            ee['official_binary_identity_known'] is False, 'EE rebuilt program scope differs')
    require(sha(root / 'programs/ee/minivec') == ee['binary_sha256'] == (root / 'ee-binary-sha256.txt').read_text().split()[0] and
            ee['source_archive_sha256'] == EE_ARCHIVE_SHA and ee['source_manifest_sha256'] == prep['ee_source_manifest_sha256'] and
            ee['source_sha256'] == prep['ee_source_sha256'] and ee['prepare_proof_sha256'] == sha(root / 'prepare-proof.json'), 'EE extracted binary/source proof differs')
    cases = {x['id'] for x in json.loads(blob(repo, commit, 'mysqltest/manifest.json'))['cases']}
    require(len(cases) == 20, 'current public case inventory differs')
    for name, expected in (('ee-image-handshake', {'handshake'}), ('ee-image-public', cases)):
        data = read(root / name / 'result.json')
        require(data['passed'] is True and len(data['cases']) == len(expected) and {x['id'] for x in data['cases']} == expected and
                all(x['status'] == 'PASS' for x in data['cases']), 'EE current public/handshake gate incomplete')
    tests = ['typed_rows', 'row_encoding_reuse', 'transactions_and_invalid_input', 'crash_recovery',
             'mode_switch', 'fragmented_jsonl', 'parallel_insert_errors', 'legacy_mode']
    lines = (root / 'ee-json.log').read_text().splitlines()
    require([line for line in lines if line.startswith('PASS ')] == ['PASS ' + x for x in tests], 'EE current JSON gate incomplete')
    for name in ('ee-topk.log', 'ee-topk-parallel.log'):
        require((root / name).read_text().strip() == 'PASS JSONL TopK against exact float32 oracle, including ties, filters and rollback', 'EE current TopK gate incomplete')
    log = (root / 'ee-docker-build.log').read_text()
    require(core.COMPILER in log and 'src/*.cpp -o /minivec' in log, 'original EE build log incomplete')
    return ee


def pair_summary(rows):
    ratios = [r['baseline_over_candidate'] for r in rows if r['baseline_over_candidate'] is not None]
    return {'raw_pairs': rows, 'median_baseline_over_candidate': median(ratios) if len(ratios) == len(rows) else None,
            'candidate_larger_pairs': sum(r['candidate_larger'] for r in rows)}


def combined_metrics(run):
    result = core.lifecycle_timings(run)
    if 'query' in run:
        queries = math.fsum(math.fsum(p['per_request_seconds']) for label, p in run['query'].items() if label != 'query_after_restart')
    else: queries = math.fsum(p['wall_seconds'] for p in run['phases'].values())
    result['first_lifetime_query_total'] = queries
    result['first_lifetime_nonquery_total'] = result['first_lifetime_no_restart'] - queries
    for cycle in run.get('write_cycles', []):
        expected = cycle['write_and_commit_seconds'] + cycle['query_seconds']
        require(math.isclose(expected, cycle['cycle_seconds'], rel_tol=1e-12, abs_tol=1e-12), 'write-query cycle arithmetic differs')
        result['write_query_cycle_' + str(cycle['cycle'])] = expected
    return result


def resource_metrics(run):
    resource = run['cgroup']['resource_delta']; devices = resource['io_stat_delta']
    return {'whole_cgroup_cpu_usec': resource['cpu_stat_delta']['usage_usec'],
            'whole_cgroup_memory_peak_bytes': resource['memory_peak_bytes'],
            'whole_cgroup_device_read_bytes': sum(item.get('rbytes', 0) for item in devices.values()),
            'whole_cgroup_device_write_bytes': sum(item.get('wbytes', 0) for item in devices.values())}


def summarize_extra(data):
    groups = {}
    for pair in data['pairs']:
        b = combined_metrics(pair['baseline']) | resource_metrics(pair['baseline'])
        c = combined_metrics(pair['candidate']) | resource_metrics(pair['candidate'])
        require(set(b) == set(c), 'extra metric inventory differs')
        for metric in b:
            require(math.isfinite(b[metric]) and math.isfinite(c[metric]) and min(b[metric], c[metric]) >= 0, 'invalid extra metric')
            rows = groups.setdefault(pair['scenario'], {}).setdefault(metric, [])
            rows.append({'pair_index': pair['pair_index'], 'order': pair['order'], 'baseline': b[metric], 'candidate': c[metric],
                'baseline_over_candidate': b[metric] / c[metric] if c[metric] else None,
                'candidate_minus_baseline': c[metric] - b[metric], 'candidate_larger': c[metric] > b[metric]})
    return {name: {metric: pair_summary(rows) for metric, rows in metrics.items()} for name, metrics in groups.items()}


def audit(args):
    root, repo, commit = args.input.resolve(), args.repo.resolve(), args.commit
    files = core.verify_archive(root, args.archive.resolve(), args.artifact_sha256, args.artifact_bytes)
    virtual, artifact_completeness = manifest_with_exact_source_recovery(root, repo, commit, args.artifact_sha256)
    summary, prep, binding = [read(root / name) for name in ('summary.json', 'prepare-proof.json', 'binding-proof.json')]
    require(summary['status'] == 'passed' and summary['exit_code'] == 0 and summary['expected_pairs'] == summary['completed_pairs'] == 40 and
            set(summary['checks']) == CHECKS and all(v is True for v in summary['checks'].values()), 'highest comparison gate incomplete')
    require(summary['kind'] == 'independent_highest_source_comparison' and summary['new_pgo_builds'] == 0 and
            summary['formal_submission'] is False and summary['official_score'] is None and summary['official_binary_identity_known'] is False and
            summary['automatic_adoption'] is False, 'comparison scope differs')
    require(prep['status'] == binding['status'] == 'verified' and prep['harness_commit'] == summary['harness_commit'] == commit and
            prep['new_pgo_builds'] == 0 and prep['official_binary_identity_known'] is False and
            binding['prepare_proof_sha256'] == sha(root / 'prepare-proof.json'), 'preparation/binding identity differs')
    paths = INPUTS | set(git(repo, 'ls-tree', '-r', '--name-only', commit, '--', 'protocol_check', 'mysqltest').decode().splitlines())
    require(set(prep['git_input_sha256']) == paths, 'complete new harness Git inventory differs')
    for path, h in prep['git_input_sha256'].items(): require(digest(blob(repo, commit, path)) == h, 'harness input differs from fixed Git: ' + path)
    original = original_ee(root, repo, commit, prep, virtual)
    imported = imported_programs(root, repo, commit, prep)
    ee = image_gates(root, repo, commit, prep, binding)
    require(summary['ee_image_id'] == ee['image_id'] and summary['binary_sha256'] == {'ee': ee['binary_sha256'], 'retained': R_SHA, 'crc': C_SHA}, 'summary program identities differ')
    local = core.reproduce_workloads(repo, commit)
    expected_workloads, workload_proof = core.workload_reference(repo, commit, read(root / 'ee-vs-retained/measurements-1cpu.json'), local)
    reports, concise, negatives, hosts, masks = {}, [], [], [], {}
    tasksets = []
    for label, revision, binary_sha in (('retained', RETAINED, R_SHA), ('crc', CRC, C_SHA)):
        directory = root / ('ee-vs-' + label); ids_path = directory / 'identities.json'; ids = read(ids_path)
        require(set(ids) == {'baseline', 'candidate'} and sha(ids_path) == binding['comparison_identity_sha256'][label], 'comparison identity file differs')
        for role, program, source, expected in (('baseline', 'ee', EE, ee['binary_sha256']), ('candidate', label, revision, binary_sha)):
            item = ids[role]
            require(item['binary'] == '../programs/' + program + '/minivec' and item['evidence_file'] == '../programs/' + program + '/proof.json', 'identity paths differ')
            require(item['binary_sha256'] == expected and item['source_commit'] == source and item['environment'] == {} and
                    item['evidence_sha256'] == sha(root / 'programs' / program / 'proof.json') and
                    item['evidence_binary_pointer'] == ['binary_sha256'] and item['evidence_commit_pointer'] == ['source_commit'], 'identity values differ')
        reports[label] = {}
        compared = summary['comparisons']['ee_vs_' + label]
        require(compared['completed_pairs'] == 20 and set(compared['measurements']) == {'1cpu', '2cpu'}, 'direct comparison not 20 pairs')
        for count, cases in ((1, core.CASES), (2, core.PROTECTION)):
            path = directory / f'measurements-{count}cpu.json'; data = read(path)
            require(compared['measurements'][str(count) + 'cpu'] == {'sha256': sha(path), 'pairs': 2 * len(cases)}, 'individual measurement binding differs')
            report = core.verify_measurements(data, count, cases, directory, ids,
                                             {'harness_file_sha256': prep['git_input_sha256']}, expected_workloads)
            report['extra_summary'] = summarize_extra(data); reports[label][str(count)] = report
            hosts.append(data['host']); tasksets.append(data['taskset'])
            require(re.fullmatch('[0-9a-f]{64}', data['taskset']['sha256']) is not None, 'taskset identity absent')
            if count in masks: require(masks[count] == data['db_cpus'], 'comparison CPU masks differ')
            masks[count] = data['db_cpus']
            for scenario, metrics in report['extra_summary'].items():
                names = ('first_lifetime_no_restart', 'first_lifetime_query_total', 'restart_inclusive_excluding_verification',
                         'whole_cgroup_cpu_usec', 'whole_cgroup_memory_peak_bytes', 'whole_cgroup_device_read_bytes', 'whole_cgroup_device_write_bytes')
                concise.append({'comparison': 'EE_vs_' + label, 'cpu_count': count, 'scenario': scenario,
                    'metrics': {name: {'baseline_over_candidate': metrics[name]['median_baseline_over_candidate'],
                        'candidate_larger_pairs': metrics[name]['candidate_larger_pairs'],
                        'raw_baseline': [x['baseline'] for x in metrics[name]['raw_pairs']],
                        'raw_candidate': [x['candidate'] for x in metrics[name]['raw_pairs']]} for name in names if name in metrics}})
                for metric, entry in metrics.items():
                    if entry['candidate_larger_pairs']:
                        negatives.append({'comparison': 'EE_vs_' + label, 'cpu_count': count, 'scenario': scenario,
                                          'metric': metric, **entry})
            for scenario, phases in report['summary'].items():
                for phase, entry in phases.items():
                    if entry['candidate_slower_pairs']:
                        negatives.append({'comparison': 'EE_vs_' + label, 'cpu_count': count, 'scenario': scenario,
                                          'raw_timing_phase': phase, **entry})
    require(len(hosts) == 4 and all(h == hosts[0] for h in hosts) and all(t == tasksets[0] for t in tasksets), 'runner/taskset identity differs')
    require(set(summary['comparisons']) == {'ee_vs_retained', 'ee_vs_crc'} and len(concise) == 20, 'comparison matrix incomplete')
    return {'status': 'verified', 'verified_pairs': 40, 'harness_commit': commit, 'artifact_sha256': args.artifact_sha256,
        'artifact_files': files, 'artifact_completeness': artifact_completeness,
        'artifact_limitations': ['The raw artifact omits ee-context/.dockerignore. This one redundant source input is checked from its immutable Git source ZIP using the same manifest SHA and original EE Git object chain; the raw artifact is not claimed complete.'] if virtual else [],
        'git_input_count': len(paths), 'ee_source_audit': original, 'imported_programs': imported,
        'ee_image_id': ee['image_id'], 'binary_sha256': summary['binary_sha256'], 'workload_identity_audit': workload_proof,
        'ratio_direction': 'EE rebuilt baseline / paired candidate; timing/CPU/memory ratios above one favor candidate. Zero candidate IO has no ratio.',
        'compact_comparisons': concise, 'measurements': reports, 'all_negative_or_mixed_metrics': negatives,
        'host': hosts[0], 'actual_cpu_model': (root / 'lscpu.txt').read_text(), 'official_score': None,
        'score_floor_proven': False, 'automatic_adoption': False,
        'limitations': ['EE executable is newly built from original byte-verified root Docker inputs; the historical official executable is unknown.',
            'Each direct EE/R and EE/C contrast uses its own same-run EE baseline. No ratios are multiplied or inferred across CPU counts, prior runs or mixed-mode workloads.',
            'Two AB/BA pairs at one seed per scenario are a screen; no confidence interval or formal score conversion.',
            'First lifetime is the sum of measured startup/request/first-shutdown timers. Restart-inclusive totals are separate. Neither is elapsed wall time including driver oracle work and snapshots.',
            'Whole-cgroup CPU, peak memory and IO include restart verification and launcher; they are not first-lifetime-only T/B/M. Device IO uses shared page cache and filesystem.',
            'Exact 1/2 logical CPUs, quota, 2 GiB and swap0 are local diagnostic settings, not a verified official envelope.',
            'All negative paired phases remain visible. Success validates evidence/correctness, not superiority or automatic submission.',
            'Git-verified workload generation runs in Python only. Four full hashes reproduce locally; 30k/60k float-oracle hashes may differ between Windows and Linux and must match across all current Linux groups.',
            'Raw protocol responses are not all archived; the Git-bound executed harness checked independent oracles and equivalent response digests. No local DB run or absent raw response reconstruction is claimed.']}


def main():
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument('--input', type=Path, required=True); p.add_argument('--archive', type=Path, required=True)
    p.add_argument('--repo', type=Path, default=Path(__file__).resolve().parent / 'seekdb')
    p.add_argument('--commit', required=True); p.add_argument('--artifact-sha256', required=True)
    p.add_argument('--artifact-bytes', type=int, required=True); p.add_argument('--output', type=Path, required=True)
    args = p.parse_args(); require(not args.output.exists(), 'refuse overwrite')
    require(not args.output.resolve().is_relative_to(args.input.resolve()), 'analysis must be outside raw evidence tree')
    require(re.fullmatch('[0-9a-f]{40}', args.commit) and re.fullmatch('[0-9a-f]{64}', args.artifact_sha256), 'full expected identities required')
    result = audit(args)
    args.output.write_text(json.dumps(result, ensure_ascii=False, indent=2, allow_nan=False) + '\n', encoding='utf8')
    print(json.dumps({'status': result['status'], 'verified_pairs': result['verified_pairs'],
        'negative_or_mixed_metrics': len(result['all_negative_or_mixed_metrics']), 'output': str(args.output)}))


if __name__ == '__main__': main()
