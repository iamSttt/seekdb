"""Controlled local checks for added plans, affinity parsing and fail-closed identity collection."""
import copy
import json
import tempfile
from pathlib import Path
from types import SimpleNamespace
from unittest.mock import patch
import small_compute as s
import summarize_small_root as r

checks=[]
def check(name, fn):
    fn();checks.append(name)
def reject(fn):
    try:fn()
    except (ValueError,KeyError):return
    raise AssertionError('invalid fixture accepted')

check('original_12_plan_preserved',lambda:s.require(len(s.plan())==12 and s.plan()[0]['scenario']=='standard10k','plan differs'))
check('exact_8_protection_ABBA',lambda:s.check_plan(s.plan(s.PROTECTION_CASES),s.PROTECTION_CASES))
check('missing_protection_pair_rejected',lambda:reject(lambda:s.check_plan(s.plan(s.PROTECTION_CASES)[:-1],s.PROTECTION_CASES)))
check('full_plan_not_accepted_as_protection',lambda:reject(lambda:s.check_plan(s.plan(),s.PROTECTION_CASES)))
check('linux_range_equals_taskset_list',lambda:s.require(s.cpu_set('0-1')==s.cpu_set('0,1')=={0,1},'affinity differs'))
check('noncontiguous_affinity',lambda:s.require(s.select_cpus([4,7,9],2)==[4,7],'CPU selection differs'))
check('explicit_start_affinity',lambda:s.require(s.select_cpus([4,7,9],2,7)==[7,9],'CPU selection differs'))
for name,value in [('empty',''),('descending','2-1'),('duplicated','0,0'),('overlapping','0-2,2'),('negative','-1'),('oversized','0-99999999')]:
    check('invalid_cpu_'+name,lambda value=value:reject(lambda:s.cpu_set(value)))
check('too_few_allowed_cpus',lambda:reject(lambda:s.select_cpus([2],2)))

def fixture(count):
    cases=s.CASES if count==1 else s.PROTECTION_CASES
    ids={role:{'binary_sha256':('a' if role=='baseline' else 'b')*64,'source_commit':('a' if role=='baseline' else 'b')*40,
               'evidence_sha256':('c' if role=='baseline' else 'd')*64,'environment':{},'binary':'/fixture/'+role} for role in ('baseline','candidate')}
    pairs=s.plan(cases)
    for pair in pairs:
        pair['all_responses_identical']=True
        for role in pair['order']:
            ready={'pid':100,'members':[100],'driver_pid':101,'actual_exe':ids[role]['binary'],
                   'cpus_allowed_list':'4' if count==1 else '4-5'}
            phase={'native_tasks':[{'main':True,'cpus_allowed_list':ready['cpus_allowed_list']}]}
            nphase=14 if pair['scenario']=='wide768' else 15 if pair['scenario'].startswith('spill_') else 7
            pair[role]={'declared_environment':{},'cgroup':{'timeout':False,'oom_events_delta':{'oom':0,'oom_kill':0},
                'before':{'cpu.max':f'{count*100000} 100000'},'after':{'cgroup.procs':'','cpu.max':f'{count*100000} 100000'}},
                'adapter':{'ready_memberships':[copy.deepcopy(ready) for _ in range(1 if pair['scenario']=='wide768' else 2)],
                           'phase_cgroups':[copy.deepcopy(phase) for _ in range(nphase)]}}
    data={'status':'passed','expected_pairs':len(pairs),'completed_pairs':len(pairs),'pairs':pairs,
        'comparison_kind':'whole_version_diagnostic','identity_record_sha256':'e'*64,'db_cpu_count':count,
        'db_cpus':[4] if count==1 else [4,5],'protection_only':count==2,'identities':ids,
        'requested_limits':{'cpu_quota_us':count*100000,'cpu_period_us':100000}}
    return data,ids,cases

for count in (1,2):
    data,ids,cases=fixture(count)
    check(f'valid_{count}cpu_collection',lambda data=data,ids=ids,cases=cases,count=count:r.verify_measurement(data,count,cases,'e'*64,ids))
    mutations={
        'incomplete':lambda d:d.update(completed_pairs=0),
        'wrong_identity':lambda d:d.update(identity_record_sha256='f'*64),
        'wrong_actual_affinity':lambda d:d['pairs'][0]['candidate']['adapter']['ready_memberships'][0].update(cpus_allowed_list='9'),
        'driver_inside_group':lambda d:d['pairs'][0]['candidate']['adapter']['ready_memberships'][0].update(members=[100,101]),
        'wrong_actual_quota':lambda d:d['pairs'][0]['baseline']['cgroup']['before'].update({'cpu.max':'max 100000'}),
        'timeout':lambda d:d['pairs'][0]['candidate']['cgroup'].update(timeout=True),
        'oom':lambda d:d['pairs'][0]['candidate']['cgroup']['oom_events_delta'].update(oom_kill=1),
        'live_process':lambda d:d['pairs'][0]['candidate']['cgroup']['after'].update({'cgroup.procs':'100'}),
        'different_response':lambda d:d['pairs'][0].update(all_responses_identical=False),
        'wrong_executable':lambda d:d['pairs'][0]['candidate']['adapter']['ready_memberships'][0].update(actual_exe='/wrong'),
        'missing_ready':lambda d:d['pairs'][0]['candidate']['adapter'].update(ready_memberships=[]),
        'missing_phase':lambda d:d['pairs'][0]['candidate']['adapter'].update(phase_cgroups=[]),
        'worker_wrong_affinity':lambda d:d['pairs'][0]['candidate']['adapter']['phase_cgroups'][0]['native_tasks'].append({'main':False,'cpus_allowed_list':'9'}),
        'telemetry_error':lambda d:d['pairs'][0]['candidate']['adapter']['phase_cgroups'][0].update(task_read_errors=['failed']),
        'request_timeout':lambda d:d['pairs'][0]['candidate']['cgroup'].update(request_timeout_observed=True),
    }
    for name,mutate in mutations.items():
        bad=copy.deepcopy(data);mutate(bad)
        check(f'{count}cpu_{name}_rejected',lambda bad=bad,ids=ids,cases=cases,count=count:reject(lambda:r.verify_measurement(bad,count,cases,'e'*64,ids)))

with tempfile.TemporaryDirectory() as td:
    out=Path(td)/'small';out.mkdir();reports=Path(td)/'reports';reports.mkdir()
    gate={'passed':True,'checks':{'gate':True},'limitations':['No new paired performance measurement.']}
    (reports/'root-gates-summary.json').write_text(json.dumps(gate))
    result=r.collect(out,reports,'sha256:'+'a'*64,Path(td)/'missing-binary',1)
    final=json.loads((reports/'verification-summary.json').read_bytes())
    check('missing_proof_preserves_failure',lambda:s.require(result['status']=='failed_or_incomplete' and final['passed'] is False,'failure hidden'))
    check('failure_has_manifest',lambda:s.require((out/'hashes.json').exists(),'failure artifact manifest absent'))

Path(__file__).with_name('static-validation.json').write_text(json.dumps({'status':'passed','controlled_checks':checks,'count':len(checks),
    'linux_database_runs':0,'scope':'Controlled pure-Python fixtures only; no performance or Linux process/cgroup claim.'},indent=2)+'\n')
print(json.dumps({'status':'passed','controlled_checks':len(checks),'linux_database_runs':0}))
