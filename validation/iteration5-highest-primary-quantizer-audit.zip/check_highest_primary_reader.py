"""Reader-only schema and negative controls; zero database executions."""
import ast,copy,json,shutil,sys,tempfile
from pathlib import Path
w=Path(__file__).resolve().parent;repo=w/'seekdb';sys.path.insert(0,str(w));sys.path.insert(0,str(repo/'minivec/tools'))
import analyze_highest_primary_root as a
import small_compute as s
import summarize_highest_primary as collector
checks=[]; all_groups={}
def need(ok):
 if not ok:raise AssertionError('reader control failed')
def reject(fn):
 try:fn()
 except (ValueError,KeyError,FileNotFoundError):return
 raise AssertionError('invalid evidence accepted')
def check(name,fn):fn();checks.append(name)
ast.parse((w/'analyze_highest_primary_root.py').read_text())
check('syntax',lambda:None)
check('committed_only_quantizer_runtime_delta',lambda:need(len(a.runtime_guard(repo,a.CANDIDATE_COMMIT)['changed_runtime_files'])==2))
check('reject_previous_cursor_runtime',lambda:reject(lambda:a.runtime_guard(repo,'ba45b120040cc782498d5f0871a24769e126e93f')))
prior=w/'performance/insert-copy-7554753/insert-copy-root'
with tempfile.TemporaryDirectory(prefix='highest-primary-reader-control-') as td:
 out=Path(td); programs=out/'programs';programs.mkdir();shutil.copyfile(prior/'cgroup_exec',out/'cgroup_exec')
 for reference in ('ee','retained'):
  rawids=(prior/'programs/retained-identities.json').read_bytes()
  (programs/(reference+'-identities.json')).write_bytes(rawids)
  ids=json.loads(rawids);proof=json.loads((prior/'programs/root-proof.json').read_bytes())
  for count in (1,2):
   original=json.loads((prior/f'retained-{count}cpu.json').read_bytes());fixed=a.plan(reference,count);data=copy.deepcopy(original)
   data['pairs']=[]
   for entry in fixed:
    pair=copy.deepcopy(next(p for p in original['pairs'] if p['scenario']==entry['scenario'] and p['pair_index']==entry['pair_index']))
    pair.update(entry)
    for role in ('baseline','candidate'):
     pair[role]['effective_environment']={}
     for ready in pair[role]['adapter']['ready_memberships']:ready['runtime_environment']={}
    data['pairs'].append(pair)
   cases=tuple(dict.fromkeys(p['scenario'] for p in fixed));workloads={p['scenario']:p for p in original['workloads']}
   data.update(plan=fixed,pairs=data['pairs'],expected_pairs=6,completed_pairs=6,
     measurement_family=a.FAMILY,highest_primary_reference=reference,insert_copy_reference=None,
     insert_thread_control=False,matched_insert_roots=False,workloads=[workloads[n] for n in cases],
     summary=s.summary(data['pairs']))
   def verify(value):return a.verify_highest_measurements(value,count,cases,programs,ids,proof,workloads,reference)
   check(f'{reference}_{count}_constructed_schema',lambda:need(verify(data)['verified_pairs']==6))
   independent=a.extra_summary(data)['standard10k'];claimed=collector.paired_standard(data)
   check(f'{reference}_{count}_metric_arithmetic',lambda:a.collector_default(independent,claimed))
   groups=a.screen_input(data,reference,count)
   all_groups.update(groups)
   check(f'{reference}_{count}_screen_metric_boundaries',lambda:need(sum(map(len,groups.values()))==6))
   if 'spill_high_q16' in cases:
    row=groups[(reference,count,'spill_high_q16')][0]
    raw=next(p for p in data['pairs'] if p['scenario']=='spill_high_q16')['baseline']
    check('spill_guard_initial16_not_all80',lambda:need(row['metrics']['query_before_update_wall_seconds']['baseline']==raw['phase_seconds']['query_before_mutations'] and
         row['metrics']['query_before_update_wall_seconds']['baseline']<a.metrics(raw,'spill_high_q16')['first_lifetime_query_total'] and 'ingest_cpu_usec' not in row['metrics']))
   if 'wide768' in cases:
    row=groups[(reference,count,'wide768')][0]
    check('wide_no_fabricated_RSS_or_first_request_CPU',lambda:need('max_process_rss_bytes' not in row['metrics'] and 'first_query_cpu_usec' not in row['metrics']))
   for name,mutate in (
      ('missing_pair',lambda x:x['pairs'].pop()),
      ('wrong_family',lambda x:x.update(measurement_family='insert_copy24')),
      ('wrong_declared_plan',lambda x:x['plan'][0].update(seed=0)),
      ('missing_actual_environment',lambda x:x['pairs'][0]['candidate']['adapter']['ready_memberships'][0].pop('runtime_environment')),
      ('incorrect_summary',lambda x:x['summary']['standard10k']['ingest'].update(candidate_slower_pairs=999)),
      ('nonexact_transport',lambda x:x['pairs'][0]['candidate']['adapter'].update(completed_request_modes={'ann':1}))):
    bad=copy.deepcopy(data);mutate(bad)
    check(f'{reference}_{count}_reject_{name}',lambda bad=bad:reject(lambda:verify(bad)))
 gate={'schema_version':1,'normal_checks':123,'sanitized_checks':123,'block-scale_checks':124,
       'normal_pass':True,'sanitized_pass':True,'block-scale_pass':True}
 def gatefiles():
  (out/'cached-quantizer-equivalence.json').write_text(json.dumps(gate))
  for mode in ('normal','sanitized','block-scale'):
   (out/f'cached-quantizer-{mode}.log').write_text(f"cached_quantizer_checks={gate[mode+'_checks']}\ncached_quantizer=PASS\n")
 gatefiles()
 check('three_quantizer_logs',lambda:need(a.quantizer_gate(out,{'cached_quantizer_equivalence':gate})['checks_per_mode']==123))
 (out/'cached-quantizer-sanitized.log').write_text('cached_quantizer_checks=123\ncached_quantizer=PASS\nruntime error: test fixture\n')
 check('reject_sanitizer_error_even_with_pass',lambda:reject(lambda:a.quantizer_gate(out,{'cached_quantizer_equivalence':gate})))
 gatefiles();(out/'cached-quantizer-block-scale.log').unlink()
 check('reject_missing_block_scale_log',lambda:reject(lambda:a.quantizer_gate(out,{'cached_quantizer_equivalence':gate})))
 check('missing_current_raw_not_accepted',lambda:reject(lambda:a.core.verify_archive(out,out/'missing.zip','0'*64,1)))
 plan=json.loads(a.blob(repo,a.CANDIDATE_COMMIT,a.PREREG_PATH))
 erratum=a.screen.read_mapping_erratum(w/'highest-primary24-spill-field-erratum.json')
 evaluated=a.screen.evaluate_screen(plan,all_groups,verified_gate_checks_passed=False,mapping_erratum=erratum)
 check('frozen_plan_erratum_and_rule_interface',lambda:need(evaluated['numerical_pairs']==24 and evaluated['status']=='inconclusive_gates_not_verified_keep_R'))
 wrong=copy.deepcopy(erratum);wrong['mapping']['query_before_update_wall_seconds']['required_request_count']=80
 check('reject_mutated_erratum',lambda:reject(lambda:a.screen.evaluate_screen(plan,all_groups,verified_gate_checks_passed=False,mapping_erratum=wrong)))
result={'status':'passed','checks':checks,'count':len(checks),'new_database_runs':0,'new_builds':0,
 'scope':'Git source guard, controlled copies of historical schema with fixture-only family/env fields, independent metric arithmetic and missing/error evidence rejection. No current performance result or current gate pass is claimed.'}
(w/'highest-primary-reader-preflight.json').write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps(result))
