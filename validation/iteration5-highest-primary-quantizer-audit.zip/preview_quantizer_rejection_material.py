"""Work-only verified rejection, audit archive and reversible metadata compaction."""
import copy
import hashlib
import importlib.util
import io
import json
from pathlib import Path
import zipfile

BASE='d3f6f03786e145cc189a4d53066674f4301d44b5b9be8d065113c4b7814321d7'
RAW_SHA='87c591326887ba37d52ad6328330a0eac8783450a47b84ad85b3fdc12c0c1fc4'
ANALYSIS_SHA='b0c94fa978ab07b16c98b5c24dd7d7b13f47263fe31ba3faca48f92cc53d9d2a'
DECISION_SHA='8e45e7a99aebeb812e9f66c8ad59c0dff35ac6de6cc7c7e06c7e332c688ce589'
RAW_DEST='validation/iteration5-highest-primary-quantizer-raw.zip'
AUDIT_DEST='validation/iteration5-highest-primary-quantizer-audit.zip'
PRIOR_DEST='validation/iteration5-pre-quantizer-result-material.json'
ARCHIVE_KEY='iteration5_pre_quantizer_result'

def need(ok,message):
    if not ok:raise ValueError(message)

def sha(data):return hashlib.sha256(data).hexdigest()

def encode(value):
    return (json.dumps(value,ensure_ascii=False,separators=(',',':'),allow_nan=False)+'\n').encode('utf8')

def pointers(value):
    if isinstance(value,dict):
        return [v for k,v in value.items() if k=='pointer' or k.endswith('_pointer')]+[p for v in value.values() for p in pointers(v)]
    if isinstance(value,list):return [p for v in value for p in pointers(v)]
    return []

def main():
    work=Path(__file__).resolve().parent;repo=work/'seekdb'
    prior=(repo/'conversation.json').read_bytes()
    need(prior==(repo/'agent/conversation.json').read_bytes() and len(prior)==129767 and sha(prior)==BASE,'material drift')
    old=json.loads(prior);need(encode(old)==prior and len(old['messages'])==136 and len(old['experiments'])==55,'inventory differs')
    users=[m for m in old['messages'] if m['role']=='user'];need(len(users)==46,'user inventory differs')
    raw=(repo/RAW_DEST).read_bytes();need(len(raw)==3741425 and sha(raw)==RAW_SHA,'raw artifact differs')
    receipt_raw=(work/'highest-primary-quantizer-audit-receipt.json').read_bytes();receipt=json.loads(receipt_raw)
    need(receipt['status']=='completed_independent_read_only_audit' and receipt['reader_exit_code']==0
         and receipt['raw_archive_sha256']==RAW_SHA and receipt['verified_pairs']==24 and len(receipt['files'])==17,'audit receipt differs')
    files={'highest-primary-quantizer-audit-receipt.json':receipt_raw}
    for entry in receipt['files']:
        path=Path(entry['path']).resolve();need(path.is_relative_to(work),'receipt input outside work')
        data=path.read_bytes();need(len(data)==entry['bytes'] and sha(data)==entry['sha256'],'receipt input drift: '+path.name)
        files[path.relative_to(work).as_posix()]=data
    for name in ['inspect_cached_quantizer_codegen.py','cached-quantizer-draft/retained-codegen-reader-check.json',
                 'cached-quantizer-rollback.json','restore_scalar_quantizer.py',Path(__file__).name]:
        files[name]=(work/name).read_bytes()
    for path in sorted((work/'cached-quantizer-draft').glob('actual-codegen-d227204*')):
        files[path.relative_to(work).as_posix()]=path.read_bytes()
    rollback=json.loads(files['cached-quantizer-rollback.json'])
    need(rollback['status']=='retained_scalar_runtime_restored' and rollback['new_database_runs']==0,'rollback proof differs')
    for relative,digest in rollback['restored_files_sha256'].items():
        data=(repo/relative).read_bytes();need(sha(data)==digest,'restored source drift: '+relative)
        files['restored-source/'+relative]=data
    need(all('cached_quantizer_candidate.h' not in p.read_text('utf8') for p in (repo/'minivec/src').glob('*') if p.is_file()),'production includes rejected helper')
    files['historical-tests/cached_quantizer_candidate.h']=(repo/'minivec/tests/cached_quantizer_candidate.h').read_bytes()
    files['original-preregistration.json']=(repo/'validation/iteration5-highest-primary24-preregistration.json').read_bytes()
    need(sha(files['highest-primary-quantizer-independent-analysis.json'])==ANALYSIS_SHA
         and sha(files['highest-primary-quantizer-decision.json'])==DECISION_SHA,'verified result differs')
    analysis=json.loads(files['highest-primary-quantizer-independent-analysis.json'])
    decision=json.loads(files['highest-primary-quantizer-decision.json'])
    need(analysis['status']=='verified' and analysis['verified_pairs']==24 and analysis['artifact_sha256']==RAW_SHA
         and all(analysis['root_gates'].values()) and len(analysis['root_gates'])==20,'root gates/result differs')
    need(decision['decision']=='screen_rejected_R_regression_keep_R' and decision['guard_trigger_count']==6
         and decision['all_negative_or_mixed_metric_summary_count']==163 and decision['guard_adverse_pair_metric_records']==80
         and not decision['eligible_for_one_confirmation'] and not decision['adopted'],'rejection differs')
    need(analysis['candidate_binary_sha256']=='a3e43064f079ef2e686bf0f6a13fdca0c7de77e2ccdcb4788cda566670a60f89','ELF differs')
    need(analysis['quantizer_gate']['checks_per_mode']==1967150,'quantizer counts differ')
    with zipfile.ZipFile(io.BytesIO(raw)) as zf:
        logs=[name for name in zf.namelist() if name.endswith('/cached-quantizer-block-scale.log') or name=='cached-quantizer-block-scale.log']
        need(len(logs)==1 and '1967149' in zf.read(logs[0]).decode('utf8'),'block-scale check count differs')
    manifest={'schema':'highest-primary-quantizer-rejection-audit-v1',
        'actual_raw':{'path':RAW_DEST,'bytes':len(raw),'sha256':RAW_SHA,'run_id':43484633651,'artifact_id':14068250504},
        'candidate':{'commit':analysis['commit'],'binary_sha256':analysis['candidate_binary_sha256'],'image_id':analysis['candidate_image_id']},
        'result':{'verified_pairs':24,'root_gate_count':20,'guard_triggers':6,'negative_or_mixed_summaries':163,'adverse_guard_pair_metric_records':80,'counts_overlap':True,'default_adopted':False},
        'prior_material':{'path':PRIOR_DEST,'bytes':len(prior),'sha256':BASE},
        'rollback_scope':'The two production quantizer files match the recorded retained-R source hashes. Rejected encoder is preserved only in a test header. No new DB/compiler run is claimed by this archive generator.',
        'files':{name:{'bytes':len(data),'sha256':sha(data)} for name,data in sorted(files.items())}}
    buffer=io.BytesIO()
    with zipfile.ZipFile(buffer,'w',zipfile.ZIP_DEFLATED,compresslevel=9) as zf:
        for name,data in sorted({**files,'manifest.json':encode(manifest)}.items()):
            info=zipfile.ZipInfo(name,date_time=(2026,11,14,0,0,0));info.external_attr=0o100644<<16
            zf.writestr(info,data,compress_type=zipfile.ZIP_DEFLATED,compresslevel=9)
    audit=buffer.getvalue();new=copy.deepcopy(old);locations=[]
    for section in ('messages','experiments'):
        for index,item in enumerate(new[section]):
            if section=='messages' and item['role']=='user':continue
            if 'archived_original' in item:
                locations.append('/'+section+'/'+str(index));del item['archived_original']
    need(len(locations)==41 and ARCHIVE_KEY not in new['provenance'],'metadata inventory differs')
    new['provenance'][ARCHIVE_KEY]={'path':PRIOR_DEST,'sha256':BASE,'bytes':len(prior),
        'scope':'Exact prior JSON. Only repeated archived_original reference metadata moves to the listed source_locations; original reference chains are retained there. No message content, user, result, failure or decision is compacted.',
        'metadata_groups':[{'fields':['archived_original'],'source_locations':locations}]}
    experiment=new['experiments'][54]
    need(experiment['id']=='flat-quant-reciprocal-highest-primary24','experiment differs')
    experiment.update(status='measured_rejected_retained_quantizer_restored',new_pgo_builds_executed=1,database_pairs_executed=24,
        result_message='assistant-highest-primary-quantizer-rejected',root_gate_groups=20,guard_trigger_entries=6,
        negative_or_mixed_metric_summaries=163,adverse_guard_pair_metric_records=80)
    experiment['artifacts'] += [{'path':RAW_DEST,'sha256':RAW_SHA},{'path':AUDIT_DEST,'sha256':sha(audit)}]
    new['messages'].append({'id':'assistant-highest-primary-quantizer-rejected','role':'assistant','content':
        'assistant实测：新根PGO1次、20门禁/24对通过；量化normal/san各1967150检查，block1967149。C/EE首周期阶段和1/2CPU=0.870993/0.933569，但2CPU仅4/6更快，未达预登记。R1CPU首周期1.321218、写入1.5253；查询wall/CPU亦4/4负但未单独触发2%门槛，spill另4项，合计6guard。全部163负面/混合摘要、80负面guard对子保留，计数重叠不可相加。拒绝且不追加确认；生产量化恢复R，候选仅留测试头。静态ELF机制成立不证明整体收益；不推断正式分或提交。'})
    need([m for m in new['messages'] if m['role']=='user']==users,'user object changed')
    need(all(new['messages'][i]['content']==m['content'] and new['messages'][i]['role']==m['role'] and new['messages'][i]['id']==m['id'] for i,m in enumerate(old['messages'])),'old message content/role/id changed')
    for key in old:
        if key not in ('messages','experiments','provenance'):need(new[key]==old[key],'root result changed: '+key)
    need({k:v for k,v in new['provenance'].items() if k!=ARCHIVE_KEY}==old['provenance'],'old provenance changed')
    restored=copy.deepcopy(new);restored['messages']=restored['messages'][:136];restored['experiments'][54]=copy.deepcopy(old['experiments'][54])
    for location in locations:
        _,section,index=location.split('/');restored[section][int(index)]['archived_original']=copy.deepcopy(old[section][int(index)]['archived_original'])
    del restored['provenance'][ARCHIVE_KEY];need(restored==old,'compaction cannot restore all original values')
    spec=importlib.util.spec_from_file_location('quant_rejection_checker',repo/'minivec/tools/validate_iteration_material.py')
    checker=importlib.util.module_from_spec(spec);spec.loader.exec_module(checker)
    checker.validate(repo);checker.check_structure(new,new)
    for pointer in pointers(old):need(encode(checker.resolve_pointer(new,pointer))==encode(checker.resolve_pointer(old,pointer)),'pointer target changed')
    material=encode(new);need(len(material)<=131072,'material overflow')
    summary={'status':'preview_only_not_applied','repository_writes':0,'git_commands':0,'new_database_runs':0,
        'source_bytes':len(prior),'source_sha256':BASE,'preview_bytes':len(material),'preview_sha256':sha(material),'remaining_bytes':131072-len(material),
        'all_original_message_contents_preserved':136,'all_original_user_objects_preserved':46,'messages':len(new['messages']),'experiments':55,
        'metadata_only_compaction':True,'archived_reference_count':len(locations),'all_original_values_restorable':True,
        'selected_runtime_and_formal_scores_unchanged':True,'all_old_pointer_targets_unchanged':True,
        'next_candidate_records_added':0,'prospective_full_repository_validation_run':False,
        'copy_recommendation':[{'source':'iteration5-pre-quantizer-result-material.json','target':PRIOR_DEST,'bytes':len(prior),'sha256':BASE},
            {'source':'iteration5-highest-primary-quantizer-audit.zip','target':AUDIT_DEST,'bytes':len(audit),'sha256':sha(audit)},
            {'source':'quantizer-rejection-material-preview.json','targets':['conversation.json','agent/conversation.json'],'bytes':len(material),'sha256':sha(material)}]}
    for name,data in [('iteration5-pre-quantizer-result-material.json',prior),('iteration5-highest-primary-quantizer-audit.zip',audit),
                      ('quantizer-rejection-material-preview.json',material),('quantizer-rejection-material-summary.json',encode(summary))]:
        target=work/name;need(not target.exists(),'refuse overwrite');target.write_bytes(data)
    print(json.dumps({k:summary[k] for k in ('status','preview_bytes','remaining_bytes','preview_sha256')},indent=2))

if __name__=='__main__':main()
