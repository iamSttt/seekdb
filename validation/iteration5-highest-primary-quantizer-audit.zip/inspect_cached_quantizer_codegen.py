"""Offline ELF inspection only; instruction patterns do not establish speedup."""
import argparse
from bisect import bisect_right
import hashlib
import json
from pathlib import Path
import sys

sys.path.insert(0, str(Path(__file__).resolve().parent / 'elf-inspection-deps'))
from capstone import Cs, CS_ARCH_X86, CS_MODE_64, CS_GRP_CALL, CS_GRP_JUMP
from capstone.x86_const import X86_OP_IMM, X86_OP_MEM, X86_REG_RIP
from elftools.elf.elffile import ELFFile
from elftools.dwarf.callframe import FDE


def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def inspect(binary, expected, symbols=None):
    if sha(binary) != expected:
        raise ValueError('Actual executable hash differs from independently verified identity')
    with binary.open('rb') as source:
        elf = ELFFile(source)
        text = elf.get_section_by_name('.text')
        text_base, text_bytes = text['sh_addr'], text.data()
        loads = [seg for seg in elf.iter_segments() if seg['p_type'] == 'PT_LOAD']
        def read(address, length):
            for seg in loads:
                if seg['p_vaddr'] <= address and address + length <= seg['p_vaddr'] + seg['p_filesz']:
                    source.seek(seg['p_offset'] + address - seg['p_vaddr'])
                    return source.read(length)
            raise ValueError('Unmapped code range')
        names = {}
        if symbols:
            with symbols.open('rb') as sf:
                named = ELFFile(sf)
                if named.get_section_by_name('.text').data() != text_bytes:
                    raise ValueError('Symbol-bearing executable has different actual .text bytes')
                for sym in named.get_section_by_name('.symtab').iter_symbols():
                    if sym['st_size']:
                        names.setdefault(sym['st_value'], []).append(sym.name)
        ranges = sorted(set((entry['initial_location'], entry['address_range'])
            for entry in elf.get_dwarf_info().EH_CFI_entries() if isinstance(entry, FDE)))
        starts = [a for a, _ in ranges]
        def owner(address):
            i = bisect_right(starts, address) - 1
            return starts[i] if i >= 0 and address < starts[i] + ranges[i][1] else None
        anchors = {}
        for section in elf.iter_sections():
            if not section['sh_addr'] or section.name.startswith('.debug'):
                continue
            raw = section.data()
            for phrase in (b'flat vector index build failed\0', b'incomplete flat vector index build\0'):
                pos = raw.find(phrase)
                while pos >= 0:
                    anchors[section['sh_addr'] + pos] = phrase[:-1].decode()
                    pos = raw.find(phrase, pos + 1)
        md = Cs(CS_ARCH_X86, CS_MODE_64)
        md.detail = True
        decoded = {}
        graph = {}
        for address, length in ranges:
            if not (text_base <= address and address + length <= text_base + len(text_bytes)):
                continue
            ins = list(md.disasm(read(address, length), address))
            if sum(i.size for i in ins) != length:
                continue
            refs, calls, backedges = [], [], []
            for instruction in ins:
                for operand in instruction.operands:
                    target = None
                    if operand.type == X86_OP_IMM:
                        target = operand.imm
                    elif operand.type == X86_OP_MEM and operand.mem.base == X86_REG_RIP:
                        target = instruction.address + instruction.size + operand.mem.disp
                    if target in anchors:
                        refs.append({'address': hex(instruction.address), 'literal': anchors[target]})
                    if operand.type != X86_OP_IMM:
                        continue
                    target_owner = owner(target)
                    if instruction.group(CS_GRP_CALL) and target_owner is not None:
                        calls.append(target_owner)
                    if instruction.group(CS_GRP_JUMP):
                        if address <= target <= instruction.address:
                            backedges.append((target, instruction.address))
                        elif target_owner is not None and target_owner != address:
                            # Conditional branches and interior continuation
                            # jumps connect hot/cold fragments. Ignore tail
                            # calls that simply jump to another function start.
                            if instruction.mnemonic != 'jmp' or target != target_owner:
                                graph.setdefault(address, set()).add(target_owner)
                                graph.setdefault(target_owner, set()).add(address)
            counts = {op: sum(i.mnemonic == op for i in ins) for op in ('stmxcsr', 'divsd', 'mulsd', 'cvtss2sd')}
            decoded[address] = (length, ins, refs, calls, backedges, counts)
        located = {a for a, data in decoded.items() if data[2]}
        pending = list(located)
        while pending:
            for neighbor in graph.get(pending.pop(), ()):
                if neighbor not in located:
                    located.add(neighbor); pending.append(neighbor)
        direct = {target for a in located if a in decoded for target in decoded[a][3]}
        candidates = located | {a for a, data in decoded.items()
            if data[5]['stmxcsr'] and (data[5]['divsd'] or data[5]['mulsd'])}
        reports = []
        for address in sorted(candidates):
            if address not in decoded:
                continue
            length, ins, refs, calls, backedges, counts = decoded[address]
            focus = []
            for index, instruction in enumerate(ins):
                if instruction.mnemonic not in ('stmxcsr', 'divsd', 'mulsd'):
                    continue
                enclosing = [(lo, hi) for lo, hi in backedges if lo <= instruction.address <= hi]
                focus.append({'operation': instruction.mnemonic, 'address': hex(instruction.address),
                    'enclosing_backward_branch_ranges': [[hex(lo), hex(hi)] for lo, hi in sorted(enclosing, key=lambda x: x[1]-x[0])],
                    'context': [hex(i.address) + ' ' + i.mnemonic + ' ' + i.op_str
                                for i in ins[max(0, index-8):index+10]]})
            reports.append({'address': hex(address), 'bytes': length, 'names': names.get(address, []),
                'anchored_flat_finish_component': address in located,
                'direct_call_from_anchored_component': address in direct,
                'literal_references': refs, 'instruction_counts': counts, 'focus': focus})
        return {'status': 'offline_candidates_for_manual_loop_review', 'binary_sha256': expected,
            'symbol_binary_sha256': sha(symbols) if symbols else None, 'runtime_executions': 0,
            'functions': reports, 'limitations': [
                'Stripped function roles are inferred from unique error-literal references, hot/cold branches and direct calls; review the complete control flow before attributing a loop.',
                'An enclosing backward branch is a static loop candidate, not an executed coordinate count. No dynamic instruction or timing measurement is made.',
                'Fewer inner-loop divsd/stmxcsr operations can explain a mechanism only; CPU, lifecycle, memory and protected workloads decide adoption.']}


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--binary', type=Path, required=True)
    parser.add_argument('--expected-sha256', required=True)
    parser.add_argument('--symbols', type=Path)
    parser.add_argument('--output', type=Path, required=True)
    args = parser.parse_args()
    report = inspect(args.binary, args.expected_sha256, args.symbols)
    args.output.write_text(json.dumps(report, indent=2) + '\n', encoding='utf-8')
    print(json.dumps({'status': report['status'], 'candidate_functions': len(report['functions'])}))


if __name__ == '__main__':
    main()
