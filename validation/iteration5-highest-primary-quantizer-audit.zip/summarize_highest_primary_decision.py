"""Summarize the independently verified frozen screen; no DB or source changes."""
import hashlib,json
from pathlib import Path
w=Path(__file__).resolve().parent
source=w/'highest-primary-quantizer-independent-analysis.json'
raw=source.read_bytes();data=json.loads(raw);screen=data['preregistered_screen']
assert data['status']=='verified' and data['verified_pairs']==24
groups={}
for label,metrics in screen['guard_metrics'].items():
    selected={}
    cycle_name='lifecycle_stage_wall_sum' if label.endswith(':wide768') else 'first_lifecycle_wall_seconds'
    cycles={row['pair_index']:row['baseline'] for row in metrics[cycle_name]['pairs']}
    for name,value in metrics.items():
        kind='wall_seconds' if name.endswith('_seconds') or name=='lifecycle_stage_wall_sum' else 'cpu_usec' if name.endswith('_usec') else 'bytes'
        records=[]
        for pair in value['pairs']:
            row=dict(pair)
            if kind=='wall_seconds':
                row.update(baseline_ms=pair['baseline']*1000,candidate_ms=pair['candidate']*1000,
                    delta_ms=pair['candidate_minus_baseline']*1000,
                    delta_share_of_baseline_first_cycle=pair['candidate_minus_baseline']/cycles[pair['pair_index']])
            elif kind=='cpu_usec':
                row.update(baseline_cpu_ms=pair['baseline']/1000,candidate_cpu_ms=pair['candidate']/1000,
                    delta_cpu_ms=pair['candidate_minus_baseline']/1000)
            records.append(row)
        selected[name]={key:value[key] for key in ('median_candidate_over_baseline','AB_median','BA_median','candidate_faster_pairs','candidate_worse_pairs')}
        selected[name].update(unit=kind,raw_pairs=records)
    groups[label]=selected
result={'status':'independently_verified_screen_rejected_keep_R','candidate_commit':data['commit'],
    'run_id':43484633651,'artifact_id':14068250504,'artifact_bytes':3741425,
    'artifact_sha256':data['artifact_sha256'],'candidate_binary_sha256':data['candidate_binary_sha256'],
    'candidate_image_id':data['candidate_image_id'],'verified_pairs':24,'verified_root_gate_count':len(data['root_gates']),
    'decision':screen['status'],'eligible_for_one_confirmation':screen['eligible_for_one_confirmation'],
    'adopted':False,'selected_runtime':'R / acddca115ab183bfc6419e27c9e3383cfd1a9046e3897e5ea516cd7bc0f29f54',
    'EE_primary':screen['EE_primary'],'R_guard_triggers':screen['R_guard_triggers'],
    'guard_trigger_count':len(screen['R_guard_triggers']),
    'all_negative_or_mixed_metric_summary_count':len(data['all_negative_or_mixed_metrics']),
    'guard_adverse_pair_metric_records':len(screen['all_guard_adverse_pairs']),
    'count_scope':'Counts contain overlapping metrics/derived totals and repeated observations of a pair; do not add them or call them independent regressions.',
    'groups':groups,'full_analysis':{'path':str(source),'bytes':len(raw),'sha256':hashlib.sha256(raw).hexdigest()},
    'limitations':data['limitations'],
    'formal_score':None,'formal_score_floor_proven':False,'formal_submission_performed':False,
    'recommendation':'Reject the default candidate and retain R. Do not enter a confirmation run merely to seek a favorable result; the frozen necessary criteria failed.'}
target=w/'highest-primary-quantizer-decision.json';target.write_text(json.dumps(result,ensure_ascii=False,indent=2)+'\n',encoding='utf8')
lines=['# Cached row quantizer: keep R','',
 'Independent audit passed all 24 fixed pairs and the complete 20-gate current root inventory. The measured candidate ELF is `'+data['candidate_binary_sha256']+'`. The original raw archive was not modified.','',
 'The frozen screen rejected the candidate. Six retained-reference guards triggered, and the EE 2-CPU arm improved only four of six first cycles, below the required five. No independent confirmation is warranted under this plan.','',
 '| Paired reference | CPU | First-cycle stage sum C/reference | Query wall C/reference | Query CPU C/reference | First-cycle improving pairs |',
 '|---|---:|---:|---:|---:|---:|']
for ref in ('ee','retained'):
 for cpu in (1,2):
  m=groups[f'{ref}:{cpu}:standard10k']
  names=('first_lifecycle_wall_seconds','first_1000_queries_wall_seconds','first_1000_queries_cpu_usec')
  lines.append('| '+ref+' | '+str(cpu)+' | '+' | '.join(f"{m[name]['median_candidate_over_baseline']:.6f}" for name in names)+f" | {m[names[0]]['candidate_faster_pairs']}/{6 if ref=='ee' else 4} |")
lines += ['', 'Ratios are paired medians, with values above one worse. First-cycle wall is a sum of stage timers, not continuously measured elapsed time including oracle/telemetry gaps. EE is the prior original-source/Docker rebuild, not the recovered formal evaluation binary.','',
 'Retained 1-CPU default: first-cycle stage sum and ingest wall exceed 1.02 in the overall, AB-only and BA-only medians. Query wall and query CPU are also worse in all four pairs, though their BA medians do not exceed the separate 2% guard threshold.','',
 'Retained 1-CPU spill: both orders regress beyond 2% in first-cycle stage sum, initial 16-query wall, initial query CPU, and ingest wall. The after-launch/before-viewing-results field mapping clarification is separately bound; all four mutation/query cycles and the full eighty-query aggregate remain in the full analysis. Wide 2-CPU protection triggers no preregistered guard.','',
 'All '+str(len(data['all_negative_or_mixed_metrics']))+' negative or mixed metric summaries and all '+str(len(screen['all_guard_adverse_pairs']))+' adverse guard pair/metric records remain available. These counts overlap; they are not counts of independent regressions. Absolute values, both pair orders and every screen metric are preserved in the companion JSON.','',
 'One CPU-limited runner (AMD EPYC 9V74), one seed, no formal score inference. Improvements in one reference or scenario cannot offset retained-reference failures. The source change alone does not establish why unrelated phases changed.']
(w/'highest-primary-quantizer-decision.md').write_text('\n'.join(lines)+'\n',encoding='utf8')
print(json.dumps({'status':result['status'],'analysis_bytes':len(raw),'analysis_sha256':result['full_analysis']['sha256'],
    'decision_path':str(target),'decision_sha256':hashlib.sha256(target.read_bytes()).hexdigest()}))
