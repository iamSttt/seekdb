"""Restore retained runtime and isolate the rejected encoder in test-only code."""
from pathlib import Path
import hashlib,json,subprocess

repo=Path(__file__).resolve().parent/'seekdb'
git=['git','-c','safe.directory='+repo.as_posix(),'-C',str(repo)]
reference='33a52a7dd4426af059ec2334b7c93a07c38c93c9'
current=(repo/'minivec/src/quantized_bound.h').read_text(encoding='utf8')
start=current.index('// Row-sized index build operation.')
end=current.index('// Exact integer distance',start)
historical=('#pragma once\n// Rejected d227204 build encoder, retained only for historical regression.\n'
            '// Production translation units do not include this file.\n'
            '#include "quantized_bound.h"\nnamespace mvdb {\n'+current[start:end]+'} // namespace mvdb\n')
target=repo/'minivec/tests/cached_quantizer_candidate.h'
assert not target.exists()
test=repo/'minivec/tests/test_cached_quantizer.cpp'
raw=test.read_text(encoding='utf8')
assert raw.count('#include "quantized_bound.h"')==1
raw=raw.replace('#include "quantized_bound.h"','#include "cached_quantizer_candidate.h"',1)
target.write_text(historical,encoding='utf8',newline='\n')
test.write_text(raw,encoding='utf8',newline='\n')
records={}
for name in ('minivec/src/quantized_bound.h','minivec/src/flat_index.cpp'):
    data=subprocess.check_output(git+['show',reference+':'+name])
    (repo/name).write_bytes(data)
    records[name]=hashlib.sha256(data).hexdigest()
proof={'status':'retained_scalar_runtime_restored','reference':reference,
       'restored_files_sha256':records,'rejected_encoder':'test-only header; no production include',
       'new_database_runs':0}
(repo.parent/'cached-quantizer-rollback.json').write_text(json.dumps(proof,indent=2)+'\n',encoding='utf8')
print(json.dumps(proof))
