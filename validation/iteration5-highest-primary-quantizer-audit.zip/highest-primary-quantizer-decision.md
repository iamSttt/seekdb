# Cached row quantizer: keep R

Independent audit passed all 24 fixed pairs and the complete 20-gate current root inventory. The measured candidate ELF is `a3e43064f079ef2e686bf0f6a13fdca0c7de77e2ccdcb4788cda566670a60f89`. The original raw archive was not modified.

The frozen screen rejected the candidate. Six retained-reference guards triggered, and the EE 2-CPU arm improved only four of six first cycles, below the required five. No independent confirmation is warranted under this plan.

| Paired reference | CPU | First-cycle stage sum C/reference | Query wall C/reference | Query CPU C/reference | First-cycle improving pairs |
|---|---:|---:|---:|---:|---:|
| ee | 1 | 0.870993 | 0.999393 | 0.996319 | 6/6 |
| ee | 2 | 0.933569 | 0.992883 | 0.994303 | 4/6 |
| retained | 1 | 1.321218 | 1.034250 | 1.030889 | 1/4 |
| retained | 2 | 0.991921 | 1.000973 | 1.003662 | 2/4 |

Ratios are paired medians, with values above one worse. First-cycle wall is a sum of stage timers, not continuously measured elapsed time including oracle/telemetry gaps. EE is the prior original-source/Docker rebuild, not the recovered formal evaluation binary.

Retained 1-CPU default: first-cycle stage sum and ingest wall exceed 1.02 in the overall, AB-only and BA-only medians. Query wall and query CPU are also worse in all four pairs, though their BA medians do not exceed the separate 2% guard threshold.

Retained 1-CPU spill: both orders regress beyond 2% in first-cycle stage sum, initial 16-query wall, initial query CPU, and ingest wall. The after-launch/before-viewing-results field mapping clarification is separately bound; all four mutation/query cycles and the full eighty-query aggregate remain in the full analysis. Wide 2-CPU protection triggers no preregistered guard.

All 163 negative or mixed metric summaries and all 80 adverse guard pair/metric records remain available. These counts overlap; they are not counts of independent regressions. Absolute values, both pair orders and every screen metric are preserved in the companion JSON.

One CPU-limited runner (AMD EPYC 9V74), one seed, no formal score inference. Improvements in one reference or scenario cannot offset retained-reference failures. The source change alone does not establish why unrelated phases changed.
