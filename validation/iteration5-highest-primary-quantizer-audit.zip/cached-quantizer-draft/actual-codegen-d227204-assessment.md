# 实际根 ELF：行级量化缓存生成代码核对

结论：静态生成代码与本次候选机制相符。正常尺度的 finish 坐标循环已用乘法取代逐坐标除法，FP 环境检查与倒数计算移到每行的循环外层。没有执行 ELF，没有动态指令计数或新的性能测试；此结论不决定采用。

候选实际 ELF SHA256：`a3e43064f079ef2e686bf0f6a13fdca0c7de77e2ccdcb4788cda566670a60f89`，文件为 `work/highest-primary-quantizer-raw/highest-primary-root/programs/actual-image-minivec`。读取前已校验该哈希。

参考 R 实际 ELF SHA256：`acddca115ab183bfc6419e27c9e3383cfd1a9046e3897e5ea516cd7bc0f29f54`。此前符号映射使用 `.text` 完全相同的 unstripped 文件；候选已 stripped，以唯一 finish 错误字符串引用和热／冷跳转连通关系定位，并完整查看两个片段的控制流。

| 位置 | R/acdd | 候选 a3e43064 |
|---|---|---|
| 正常坐标循环 | `0x43c9d1` 加载坐标，正／负路径回到下一坐标；`stmxcsr@0x43c9e1`、`divsd@0x43ca1b` 在循环内 | `0x43c950` 加载坐标，`0x43c9a2`／`0x43ca1c` 返回该地址；只有 `mulsd@0x43c967`，循环内没有 `stmxcsr`、`divsd` 或 FMA |
| 行循环 | 原逐坐标 scalar 检查 | `0x43c8c8` 取行指针；`stmxcsr@0x43c8ef`、环境位掩码 `0xe040`、power-of-two 条件在每行；`divsd@0x43c936` 计算 `1/step`，随后进入坐标循环 |
| 行推进 | 独立 row 与 coordinate 计数 | `0x43c9a8` 增加 code 偏移、`0x43c9ab` 增加 row，`0x43c9b6` 返回 `0x43c8c8`；因此是每行倒数，而非整 build 只算一次 |
| 尺度边界 | 全部原逐值除法 | ELF 数据常量 `0x0010000000000000` = `2^-1022`、`0x7fd0000000000000` = `2^1022`，在倒数之前比较；越界进入冷路径 `0x4176b2` |
| 边界回退 | 原除法 | 冷坐标循环 `0x4176db`→`0x41775f`，保留 `divsd@0x4176fe`，不用先计算不安全倒数；FP 环境检查仍在进入每行时执行 |

正常热循环先以 `ucomiss` 拒绝非有限 float，转换 double 后乘以倒数；随后以 `ucomisd` 拒绝非有限 scaled，并比较 `-127` 与 `127`，然后才按符号加／减 `0.5`、`cvttsd2si` 和写入一个 code。冷除法路径同样保留这些检查和失败出口。空维度、失败清理、全局 max 扫描及 quantization_step 仍有其各自路径，不把它们计算为坐标循环内的重复除法。

原始自动候选发现结果见 `actual-codegen-d227204.json`；完整两个版本 finish 热／冷片段反汇编与相关 double 常量见 `actual-codegen-d227204-detail.json`。机器可读结论见 `actual-codegen-d227204-assessment.json`。

局限：静态 CFG 显示指令位置与分支条件，不显示正式平台所走路径、指令次数、CPU 周期、缓存行为或分数；R 和候选是各自实际构建产物，此核对也不隔离其他布局／PGO 差异。采用仍以本轮冻结的同机 EE/R 配对指标、正确性和保护场景决定。
