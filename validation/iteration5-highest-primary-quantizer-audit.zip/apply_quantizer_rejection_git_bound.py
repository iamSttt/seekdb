"""Bind restored evidence to immutable Git blobs, then apply reviewed material."""
import hashlib
import importlib.util
import io
import json
from pathlib import Path
import subprocess
import zipfile

work=Path(__file__).resolve().parent;repo=(work/'seekdb').resolve()
sha=lambda b:hashlib.sha256(b).hexdigest()
encode=lambda v:(json.dumps(v,ensure_ascii=False,separators=(',',':'),allow_nan=False)+'\n').encode('utf8')
old_material=(repo/'conversation.json').read_bytes()
assert old_material==(repo/'agent/conversation.json').read_bytes()
assert sha(old_material)=='d3f6f03786e145cc189a4d53066674f4301d44b5b9be8d065113c4b7814321d7'
prior=(work/'iteration5-pre-quantizer-result-material.json').read_bytes();assert prior==old_material
old_audit=(work/'iteration5-highest-primary-quantizer-audit.zip').read_bytes()
assert sha(old_audit)=='155e21b616de8dbdff7246da8a066526934fe9142e518251ede147fcb2d03c14'
with zipfile.ZipFile(io.BytesIO(old_audit)) as zf:
    parts={name:zf.read(name) for name in zf.namelist()}
manifest=json.loads(parts.pop('manifest.json'))
assert set(parts)==set(manifest['files'])
for name,data in parts.items():
    assert len(data)==manifest['files'][name]['bytes'] and sha(data)==manifest['files'][name]['sha256']
commit='320315b7ec13722b95f696852179cd24bdc952a9'
git=['git','-c','safe.directory='+repo.as_posix()]
binding={'status':'verified_exact_Git_blob_bytes','source_commit':commit,'git_mutations':0,'worktree_source_reads':0,'files':{}}
rollback=json.loads(parts['cached-quantizer-rollback.json'])
for relative,expected_sha in rollback['restored_files_sha256'].items():
    data=subprocess.check_output(git+['show',commit+':'+relative],cwd=repo)
    oid=subprocess.check_output(git+['rev-parse',commit+':'+relative],cwd=repo,text=True).strip()
    assert hashlib.sha1(b'blob '+str(len(data)).encode()+b'\0'+data).hexdigest()==oid
    assert sha(data)==expected_sha and data==parts['restored-source/'+relative]
    parts['restored-source/'+relative]=data
    binding['files'][relative]={'git_blob':oid,'bytes':len(data),'sha256':sha(data),'matches_rollback_proof':True}
parts['restored-source-git-binding.json']=encode(binding)
parts[Path(__file__).name]=Path(__file__).read_bytes()
manifest['restored_source_binding']={'file':'restored-source-git-binding.json','source_commit':commit,
    'scope':'Restored source entries are exact immutable Git blob bytes, not a concurrent worktree snapshot.'}
manifest['files']={name:{'bytes':len(data),'sha256':sha(data)} for name,data in sorted(parts.items())}
out=io.BytesIO()
with zipfile.ZipFile(out,'w',zipfile.ZIP_DEFLATED,compresslevel=9) as zf:
    for name,data in sorted({**parts,'manifest.json':encode(manifest)}.items()):
        info=zipfile.ZipInfo(name,date_time=(2026,11,14,0,0,0));info.external_attr=0o100644<<16
        zf.writestr(info,data,compress_type=zipfile.ZIP_DEFLATED,compresslevel=9)
audit=out.getvalue()
preview=(work/'quantizer-rejection-material-preview.json').read_bytes()
assert sha(preview)=='1b62c2870b31f7b09c413a6da1cfa99a978047feccc5597a28f7b1f550363ba0'
material=json.loads(preview);artifact=material['experiments'][54]['artifacts'][-1]
assert artifact['path']=='validation/iteration5-highest-primary-quantizer-audit.zip' and artifact['sha256']==sha(old_audit)
artifact['sha256']=sha(audit);data=encode(material)
assert len(data)==128201 and material['selected_runtime']==json.loads(old_material)['selected_runtime']
assert [m['content'] for m in material['messages'][:136]]==[m['content'] for m in json.loads(old_material)['messages']]
assert [m for m in material['messages'] if m['role']=='user']==[m for m in json.loads(old_material)['messages'] if m['role']=='user']
for name,content in [('iteration5-highest-primary-quantizer-audit-git-bound.zip',audit),
                     ('quantizer-rejection-material-git-bound.json',data)]:
    target=work/name;assert not target.exists();target.write_bytes(content)
for relative,content in [('validation/iteration5-pre-quantizer-result-material.json',prior),
                         ('validation/iteration5-highest-primary-quantizer-audit.zip',audit)]:
    target=repo/relative;assert not target.exists() or target.read_bytes()==content;target.write_bytes(content)
for relative in ('conversation.json','agent/conversation.json'):(repo/relative).write_bytes(data)
spec=importlib.util.spec_from_file_location('quantizer_applied_validator',repo/'minivec/tools/validate_iteration_material.py')
checker=importlib.util.module_from_spec(spec);spec.loader.exec_module(checker)
result=checker.validate(repo)
result.update(archive_bytes=len(audit),archive_sha256=sha(audit),prior_material_sha256=sha(prior),
              immutable_restored_source_commit=commit,source_and_CI_writes=0,git_mutations=0)
(work/'quantizer-rejection-material-applied.json').write_text(json.dumps(result,indent=2)+'\n',encoding='utf8')
print(json.dumps(result,indent=2))
