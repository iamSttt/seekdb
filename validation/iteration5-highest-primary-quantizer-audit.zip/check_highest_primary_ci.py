"""Pure-Python controlled plan/gate checks. Does not execute any database."""
import ast, copy, json, os, subprocess, sys, tempfile
from pathlib import Path
w=Path(__file__).resolve().parent;t=w/'seekdb/minivec/tools';sys.path.insert(0,str(t))
import small_compute as s
from summarize_small_root import verify_measurement
import summarize_highest_primary as collector
from prepare_highest_primary import ROOT_GATES,verify_root_gates
checks=[]
def need(ok):
 if not ok:raise AssertionError('controlled check failed')
def reject(fn):
 try:fn()
 except (ValueError,KeyError):return
 raise AssertionError('invalid fixture accepted')
def check(name,fn):fn();checks.append(name)
for name in ('prepare_highest_primary.py','summarize_highest_primary.py','small_compute.py','summarize_small_root.py','prepare_small_compute.py'):
 ast.parse((t/name).read_text(encoding='utf8'),filename=name)
check('python_syntax_five_files',lambda:None)
check('fixed_24_matrix',lambda:need(sum(len(s.highest_primary_plan(r,c)) for r in ('ee','retained') for c in (1,2))==24))
check('old_20_matrix_unchanged',lambda:need(len(s.plan())==12 and len(s.plan(s.PROTECTION_CASES))==8))
check('old_insert_24_matrix_unchanged',lambda:need([len(s.insert_copy_plan(r,c)) for r in ('ee','retained') for c in (1,2)]==[4,4,8,8]))
for reference in ('ee','retained'):
 for count in (1,2):
  raw=json.loads((w/f'performance/insert-copy-7554753/insert-copy-root/retained-{count}cpu.json').read_bytes())
  data=copy.deepcopy(raw);fixed=s.highest_primary_plan(reference,count);data['pairs']=[]
  for item in fixed:
   pair=copy.deepcopy(next(p for p in raw['pairs'] if p['scenario']==item['scenario'] and p['pair_index']==item['pair_index']))
   pair.update(item)
   for role in ('baseline','candidate'):
    pair[role]['effective_environment']={}
    for ready in pair[role]['adapter']['ready_memberships']:ready['runtime_environment']={}
   data['pairs'].append(pair)
  cases=tuple(dict.fromkeys(p['scenario'] for p in fixed))
  data.update(measurement_family=s.HIGHEST_PRIMARY_FAMILY,highest_primary_reference=reference,
      insert_copy_reference=None,matched_insert_roots=False,insert_thread_control=False,
      protection_only=False,plan=fixed,expected_pairs=6,completed_pairs=6)
  def verify(value):verify_measurement(value,count,cases,value['identity_record_sha256'],value['identities'],highest_reference=reference)
  check(f'{reference}_{count}_controlled_inventory',lambda:verify(data))
  check(f'{reference}_{count}_default_metric_count',lambda:need(len(collector.paired_standard(data)['metrics']['ingest_cpu_usec']['raw_pairs'])==(6 if reference=='ee' else 4)))
  for name,mutate in (
   ('wrong_family',lambda x:x.update(measurement_family='insert_copy24')),
   ('missing_pair',lambda x:x['pairs'].pop()),
   ('declared_plan',lambda x:x['plan'][0].update(seed=42)),
   ('old_insert_family',lambda x:x.update(insert_copy_reference=reference)),
   ('actual_environment',lambda x:x['pairs'][0]['candidate']['adapter']['ready_memberships'][0].update(runtime_environment={'MVDB_QUERY_THREADS':'1'})),
   ('memory',lambda x:x['pairs'][0]['candidate']['cgroup']['before'].update({'memory.max':'max'}))):
   bad=copy.deepcopy(data);mutate(bad)
   check(f'{reference}_{count}_reject_{name}',lambda bad=bad:reject(lambda:verify(bad)))
  check(f'{reference}_{count}_old_reader_rejects_new_family',lambda:reject(lambda:verify_measurement(data,count,cases,data['identity_record_sha256'],data['identities'],insert_reference=reference)))
with tempfile.TemporaryDirectory(prefix='highest-primary-preflight-') as td:
 out=Path(td)
 for reference in ('ee','retained'):
  for count in (1,2):
   dest=out/f'{reference}{count}.json'
   command=[sys.executable,str(t/'small_compute.py'),'--tools',str(t),'--output',str(dest),'--plan-only',
      '--highest-primary-reference',reference,'--db-cpu-count',str(count),'--allow-version-contrast',
      '--query-mode','exact','--memory-max','2147483648','--swap-max','0','--cpu-quota-us',str(count*100000)]
   run=subprocess.run(command,capture_output=True,text=True)
   check(f'{reference}_{count}_plan_cli',lambda:need(run.returncode==0 and json.loads(dest.read_bytes())['expected_pairs']==6))
 command=[sys.executable,str(t/'small_compute.py'),'--tools',str(t),'--output',str(out/'rejected.json'),'--plan-only',
    '--highest-primary-reference','ee','--allow-version-contrast','--query-mode','exact','--memory-max','2147483648','--swap-max','0']
 for name,extra in (('mixed',['--matched-insert-roots']),('ann',['--query-mode','mixed']),('cap',['--memory-max','max']),('quota',['--cpu-quota-us','200000'])):
  run=subprocess.run(command+extra,capture_output=True,text=True)
  check('cli_reject_'+name,lambda:need(run.returncode!=0 and not (out/'rejected.json').exists()))
 details={'schema_version':1,'normal_checks':123,'sanitized_checks':123,'block-scale_checks':124,
          'normal_pass':True,'sanitized_pass':True,'block-scale_pass':True}
 root={'passed':True,'checks':{k:True for k in ROOT_GATES},'cached_quantizer_equivalence':details,'limitations':[]}
 def write_gate():
  (out/'root-gates-summary.json').write_text(json.dumps(root))
  (out/'cached-quantizer-equivalence.json').write_text(json.dumps(details))
  for mode in ('normal','sanitized','block-scale'):
   (out/f'cached-quantizer-{mode}.log').write_text(f"cached_quantizer_checks={details[mode+'_checks']}\ncached_quantizer=PASS\n")
 write_gate()
 check('root_20_and_three_quantizer_modes',lambda:need(verify_root_gates(out)['checks_per_mode']==123))
 (out/'cached-quantizer-normal.log').write_text('cached_quantizer_checks=123\n')
 check('reject_missing_quantizer_marker',lambda:reject(lambda:verify_root_gates(out)))
 write_gate();root['checks'].pop(next(iter(ROOT_GATES)));(out/'root-gates-summary.json').write_text(json.dumps(root))
 check('reject_missing_root_gate',lambda:reject(lambda:verify_root_gates(out)))
 failed=out/'failed';failed.mkdir()
 result=collector.collect(failed,out,'sha256:'+'0'*64,out/'missing-program',7)
 check('collector_nonzero_missing_evidence_fail_closed',lambda:need(result['status']=='failed_or_incomplete' and result['completed_pairs']==0 and result['automatic_adoption'] is False))
sh=Path(r'C:\Users\Lenovo\.cache\codex-runtimes\codex-primary-runtime\dependencies\native\git\usr\bin\sh.exe')
for name in ('ci_highest_primary.sh','ci_score.sh'):
 result=subprocess.run([str(sh),'-n',str(t/name)],capture_output=True,text=True)
 check('shell_syntax_'+name,lambda:need(result.returncode==0))
workflow=(w/'seekdb/.github/workflows/minivec-score.yml').read_text()
job=None;seen=0
for line in workflow.splitlines():
 if line.startswith('  ') and not line.startswith('   ') and line.endswith(':'):job=line.strip()[:-1]
 if line.startswith('    if: ${{'):
  need(('inputs.highest_primary ||' if job=='validate' else "!inputs.highest_primary && !contains(github.event.head_commit.message, '[highest-primary]') &&") in line);seen+=1
check('workflow_marker_excludes_other_jobs',lambda:need(seen>=20))
record={'status':'passed','count':len(checks),'checks':checks,'new_database_runs':0,'new_pgo_builds':0,
 'scope':'Python AST and shell syntax, fixed plan-only CLI, controlled copies of historical telemetry with explicit fixture-only environment fields, and fail-closed gate readers. Not a fresh performance result.'}
(w/'highest-primary-ci-preflight.json').write_text(json.dumps(record,indent=2)+'\n')
print(json.dumps(record))
