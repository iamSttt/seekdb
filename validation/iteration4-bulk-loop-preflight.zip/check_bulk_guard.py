#!/usr/bin/env python3
"""Synthetic parser/build-plan tests only, never database performance."""
from copy import deepcopy
import importlib.util
import json
from pathlib import Path
import shutil
import sys
import tempfile
import contextlib
import io

HERE = Path(__file__).resolve().parent
TOOLS = HERE / 'seekdb/minivec/tools'
sys.path.insert(0, str(TOOLS))
import benchmark_bulk_guard as bench
import bulk_guard_proof as bulk
import ablation_build as build
from types import SimpleNamespace
proof = SimpleNamespace(**{name:getattr(build,name) for name in ('sha','save','read','COMMON')},
    FLAGS=bulk.FLAGS, BASELINE=bulk.BASELINE, verify_results=bulk.verify_results,
    initialize=lambda out,scratch,revision: build.initialize(out,scratch,bulk.BASELINE,revision,bulk.FLAGS,bench.make_plan()),
    verify_builds=lambda out,scratch: build.verify_builds(out,scratch,bulk.FLAGS))
spec = importlib.util.spec_from_file_location('fixture120', HERE / 'check_retained_final_analyzer.py')
old = importlib.util.module_from_spec(spec); spec.loader.exec_module(old)


def write(path, data):
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_bytes(data if isinstance(data, bytes) else data.encode())


def lifecycle(name, role, threads):
    plan = 'spill_filters' if name.startswith('spill_') else 'standard' if name == 'standard10k' else 'boundaries'
    run = old.lifecycle(name, plan, 64 if name.startswith('spill_') else 1000, 1 if role == 'baseline' else .99)
    lines = 'minivec ready data=/synthetic\n'
    if threads == 2: lines += ('mvdb: fanout -> 2 threads (forced)\n' * 4)
    lines *= 2
    run['stderr'] = {'total_bytes': len(lines), 'tail_source_bytes': len(lines), 'truncated': False, 'tail_utf8': lines}
    for snapshot in run['resource_snapshots']:
        restarted = snapshot['phase'] in ('after_restart', 'query_after_restart', 'before_final_shutdown')
        ident = 200 if restarted else 100
        after = snapshot['phase'] not in ('after_index_build', 'after_restart', 'after_ingest')
        snapshot['native_tasks'] = [{'tid': ident, 'main': True, 'cpu_ticks': 10}]
        if threads == 2: snapshot['native_tasks'].append({'tid': ident + 1, 'main': False, 'cpu_ticks': 20 if after else 0})
        snapshot['clock_ticks_per_second'] = 100
    run['policy_evidence'] = bench.repeat.observed_policy(run, threads)
    return run


def make_fixture(out, scratch):
    for role in ('baseline', 'candidate'):
        root = scratch / role
        write(root / 'Dockerfile', (HERE / 'seekdb/Dockerfile').read_bytes())
        write(root / '.dockerignore', b'synthetic ignore\n')
        write(root / 'minivec/src/db.cpp', b'// synthetic source fixture, not compiled\n')
        write(root / 'minivec/third_party/json.hpp', b'// synthetic thirdparty fixture\n')
        for name in ('train.cpp', 'run-training.sh'): write(root / 'minivec/tools/pgo' / name, (TOOLS / 'pgo' / name).read_bytes())
        if role == 'candidate':
            for name in ('benchmark_bulk_guard.py', 'bulk_guard_proof.py', 'benchmark_bulk_typed.py', 'ablation_build.py', 'bulk_typed_proof.py', 'benchmark_regression_ablation.py', 'regression_ablation_proof.py', 'benchmark_iteration.py', 'benchmark_report_matrix.py', 'benchmark_projection.py', 'benchmark_filter_repeat.py'):
                write(root / 'minivec/tools' / name, (TOOLS / name).read_bytes())
    (out / 'build-input').mkdir(parents=True)
    write(out / 'lscpu.txt', 'synthetic host, no measurement\n')
    write(out / 'stage.txt', 'complete\n')
    proof.initialize(out, scratch, 'b' * 40)
    inputs = proof.read(out / 'build-input.json')
    for role, flags in proof.FLAGS.items():
        target = out / (role + '-pgo'); training = target / 'training'
        src = scratch / ('baseline' if role == 'baseline' else 'candidate')
        shutil.copytree(src / 'minivec/src', target / 'built-source')
        shutil.copytree(src / 'minivec/third_party', target / 'built-third-party')
        for name in ('train.cpp', 'run-training.sh'): write(training / name, (src / 'minivec/tools/pgo' / name).read_bytes())
        write(target / 'minivec', ('synthetic runtime ' + role).encode())
        write(target / 'binary-sha256.txt', proof.sha(target / 'minivec') + '  ' + str(target) + '/minivec\n')
        write(training / 'instrumented-minivec', ('synthetic instrumented ' + role).encode())
        write(training / 'instrumented-binary-sha256.txt', proof.sha(training / 'instrumented-minivec') + '  /minivec\n')
        write(training / 'unstripped-minivec', b'synthetic unstripped bytes')
        write(training / 'symbols.txt', b'synthetic symbol data')
        write(training / 'sections.txt', b'synthetic section data')
        write(training / 'effective-flags.txt', proof.COMMON + ' ' + ' '.join(flags) + '\n')
        write(training / 'profile-data/minivec-db.gcda', b'synthetic gcda, not a measured profile')
        write(training / 'profile-sha256.txt', proof.sha(training / 'profile-data/minivec-db.gcda') + '  /pgo/minivec-db.gcda\n')
        write(training / 'corpus/phase.jsonl', b'{"synthetic":true}\n')
        write(training / 'corpus-sha256.txt', proof.sha(training / 'corpus/phase.jsonl') + '  /training/corpus/phase.jsonl\n')
        oracle = []
        for threads in (1, 2):
            for phase in (0, 1, 2):
                name = f'responses-{threads}-{phase}.jsonl'; write(training / name, b'{"synthetic":true}\n')
                oracle.append({'actual_file': name, 'status': 'passed', 'responses': 1})
        write(training / 'verification.jsonl', ''.join(json.dumps(v) + '\n' for v in oracle))
        proof.save(target / 'image.json', [{'Id': 'sha256:' + proof.sha(target / 'minivec')}])
    proof.verify_builds(out, scratch)
    first_context = (out / 'context.json').read_bytes(); proof.verify_builds(out, scratch)
    assert (out / 'context.json').read_bytes() == first_context, 'postmeasurement verify would mutate context hash'
    context = proof.read(out / 'context.json')
    checks = []
    for role in proof.FLAGS:
        for name in ('json_protocol', 'utf8_atomicity', 'topk_serial', 'topk_parallel'):
            checks.append({'role': role, 'test': name, 'returncode': 0, 'binary_sha256': context['profile_source_proof'][role]['binary_sha256']})
        proof.save(out / (role + '-utf8.json'), {'status': 'passed', 'checks': [{'status': 'passed', 'malformed_hex': raw, 'projected_vector_dimension': dim, 'path': path}
            for raw in ('ff', 'c080', 'eda080', 'e4b8', 'f4908080', '80') for dim in (None, 127, 128) for path in ('ORDER BY id LIMIT 10', 'unbounded', 'ORDER BY id LIMIT 4096')]})
    proof.save(out / 'correctness.json', {'status': 'passed', 'checks': checks})
    units = sorted(bulk.UNIT_CASES)
    write(out / 'unit/passed.tsv', ''.join('\t'.join(v) + '\n' for v in units))
    for role, mode, test in units:
        label = '-'.join((role,mode,test))
        flags=['-std=c++17','-pthread','-Isrc',*bulk.FLAGS['baseline'],'-DMVDB_JSON_RESPONSE_DIAGNOSTICS']
        if role == 'bulk': flags += ['-DMVDB_TYPED_BULK_VECTOR_ONLY']
        flags += ['-O2'] if mode == 'normal' else ['-O1','-g','-fno-omit-frame-pointer','-fsanitize=address,undefined','-fno-pie','-no-pie']
        write(out / 'unit' / (label+'-flags.txt'), '\n'.join(flags)+'\n')
        write(out / 'unit' / (label+'.log'), 'PASS bulk typed admission boundaries bulk='+str(int(role=='bulk'))+'\n')
    data = {'status': 'passed', 'binary_unchanged': True, 'baseline_commit': proof.BASELINE, 'candidate_commit': context['candidate_commit'],
        'build_context_sha256': proof.sha(out / 'context.json'), 'plan': bench.make_plan(), 'pairs': [], 'workloads': [],
        'environment_before_overrides': {}, 'host': {'affinity': [0, 1]},
        'binaries': {r: {'path': str(out / (r + '-pgo/minivec')), 'sha256': context['profile_source_proof'][r]['binary_sha256']} for r in proof.FLAGS},
        'driver_sha256': inputs['snapshot_files']['candidate']['minivec/tools/benchmark_bulk_guard.py'],
        'harness_sha256': {n: inputs['snapshot_files']['candidate']['minivec/tools/' + n] for n in ('benchmark_iteration.py', 'benchmark_report_matrix.py', 'benchmark_projection.py', 'benchmark_filter_repeat.py', 'benchmark_regression_ablation.py')}}
    corpora = {}
    for name in bench.CASES:
        for seed in bench.SEEDS:
            item = {'scenario': name, 'seed': seed}
            if name in bench.PROJECTED:
                path = out / 'measurements.inputs' / f'{name}-{seed}.jsonl'; write(path, b'{"synthetic":true}\n')
                rows, dim, width = bench.projection.CASES[name]
                item.update(input_path=str(path), input_bytes=path.stat().st_size, input_sha256=proof.sha(path), rows=rows, dimension=dim, string_codepoints=width)
                corpora[(name, seed)] = item['input_sha256']
            else:
                rows, dim = (bench.base.FULL_CASES[name] if name in bench.ITERATION else bench.matrix.CASES[name])[:2]
                item.update(rows=rows, dimension=dim, queries=1000 if name in bench.ITERATION else 64, workload_sha256='f' * 64)
                corpora[(name, seed)] = item['workload_sha256']
            data['workloads'].append(item)
    for planned in data['plan']:
        name = planned['scenario']; role = 'baseline' if planned['contrast'] == 'aa' else planned['contrast']
        pair = {**planned, 'workload_sha256': corpora[(name, planned['seed'])],
            'binary_sha256': {side: data['binaries'][actual]['sha256'] for side, actual in (('baseline', 'baseline'), ('candidate', role))},
            'binary_paths': {'baseline': str(out / 'baseline-pgo/minivec'), 'candidate': str(out / (role + '-pgo/minivec'))},
            'query_environment': {'MVDB_QUERY_THREADS': str(planned['query_threads'])}}
        for side, actual in (('baseline', 'baseline'), ('candidate', role)):
            if name in bench.PROJECTED:
                run = old.projection('many16' if name in ('many64','many127') else name, 1 if actual == 'baseline' else .99)
                run['policy_evidence'] = {'requested_query_threads': 1, 'no_query_fanout_diagnostics': True, 'task_snapshots': [{}] * 14}
                pair[side] = run
            else: pair[side] = lifecycle(name, actual, planned['query_threads'])
        pair['all_responses_identical_and_independently_verified' if name in bench.PROJECTED else 'all_responses_identical'] = True
        data['pairs'].append(pair)
    data['summary'] = bench.summarize(data['pairs']); proof.save(out / 'measurements.json', data)
    return data



def main():
    cases=[]
    import re
    shell=(TOOLS/'ci_bulk_guard_confirmation.sh').read_text()
    assert re.search(r"^compiler='([^']+)'$",shell,re.M)[1]==build.COMPILER
    assert re.search(r'^baseline=([a-f0-9]+)$',shell,re.M)[1]==bulk.BASELINE
    cases.append({'case':'shell_compiler_digest_and_baseline_exact_unchanged','result':'passed'})
    with tempfile.TemporaryDirectory(prefix='guard192-fixture-',dir=HERE) as temporary:
        root=Path(temporary);out,scratch=root/'out',root/'scratch'
        data=make_fixture(out,scratch)
        summary=bulk.verify_results(out)
        assert summary['verified_total_pairs']==192 and summary['per_candidate_pairs']==150 and summary['identical_baseline_aa_pairs']==42
        for name in bench.CASES:
            assert sum(p['scenario']==name and p['contrast']=='bulk' for p in data['pairs'])==15
        assert all(sum(p['scenario']==name and p['contrast']=='aa' for p in data['pairs'])==6 for name in bench.TARGETS)
        cases.append({'case':'complete192_150candidate42AA_all10x15_and7x6','result':'accepted synthetic only'})
        for name,mutate in [
            ('missing_protection_pair',lambda d:d['pairs'].pop()),
            ('duplicate_identity',lambda d:d['pairs'].__setitem__(1,deepcopy(d['pairs'][0]))),
            ('changed_aa_program',lambda d:next(p for p in d['pairs'] if p['contrast']=='aa')['binary_paths'].__setitem__('candidate','/wrong')),
            ('changed_candidate_binary',lambda d:d['pairs'][0]['binary_sha256'].__setitem__('candidate','0'*64)),
            ('wrong_projection_abba',lambda d:next(p for p in d['pairs'] if p['scenario']=='many127')['order'].reverse()),
            ('missing_projection_oracle',lambda d:next(p for p in d['pairs'] if p['scenario']=='many64')['candidate']['phases']['wide_all'].__setitem__('independent_oracle','')),
        ]:
            broken=deepcopy(data);mutate(broken)
            try:broken['summary']=bench.summarize(broken['pairs'])
            except (KeyError,ValueError):pass
            proof.save(out/'measurements.json',broken)
            try:bulk.verify_results(out)
            except (KeyError,ValueError):cases.append({'case':name,'result':'rejected'})
            else:raise AssertionError(name)
        proof.save(out/'measurements.json',data)
        with contextlib.redirect_stdout(io.StringIO()):bulk.collect(out,0)
        assert proof.read(out/'summary.json')['identical_baseline_aa_pairs']==42
        assert proof.read(out/'summary.json')['verified_total_pairs']==192
        manifest=proof.read(out/'hashes.json')['artifacts']
        assert all(proof.sha(out/r['path'])==r['sha256'] for r in manifest)
        cases.append({'case':'collector192_no_identity_shadow_full_manifest','result':'passed'})
        broken=deepcopy(data);broken['pairs'].pop();proof.save(out/'measurements.json',broken)
        try:
            with contextlib.redirect_stdout(io.StringIO()):bulk.collect(out,0)
        except ValueError:cases.append({'case':'collector_zero_exit_missing_raw_rejected','result':'passed'})
        else:raise AssertionError('collector false success')
        with contextlib.redirect_stdout(io.StringIO()):bulk.collect(out,17)
        assert proof.read(out/'run-status.json')['exit_code']==17
        cases.append({'case':'collector_failure_preserved','result':'passed'})
        import benchmark_bulk_typed as previous
        assert len(previous.make_plan())==84 and len(bench.make_plan())==192
        cases.append({'case':'prior84_protocol_unmodified','result':'passed'})
    report={'status':'passed','scope':'new192 synthetic scheduling/proof tests only; no Linux compile or performance results',
       'files_sha256':{name:proof.sha(TOOLS/name) for name in ('benchmark_bulk_guard.py','bulk_guard_proof.py','ci_bulk_guard_confirmation.sh')},'cases':cases}
    proof.save(HERE/'bulk-guard-harness-static-validation.json',report)
    print(json.dumps({'status':'passed','cases':len(cases)}))

if __name__=='__main__':main()
