"""Read-only scope review and preflight archive; reuses unchanged192 evidence."""
import hashlib,json,subprocess,zipfile
from pathlib import Path

HERE=Path(__file__).resolve().parent;REPO=HERE/'seekdb'
PARENT='85cded31d28192f30b4177ed226384ec8d0ffd95'
git=['git','-c','safe.directory='+REPO.as_posix(),'-C',str(REPO)]
def digest(value):return hashlib.sha256(value).hexdigest()
def encoded(value):return (json.dumps(value,indent=2,ensure_ascii=False)+'\n').encode()

runtime=['Dockerfile','minivec/Makefile','.github/workflows/minivec-score.yml',
 'minivec/src/json_response_diagnostics.h','minivec/tests/test_bulk_typed_response.cpp','minivec/tests/test_typed_response.py',
 'minivec/tests/json_protocol.py','minivec/tests/topk_bounds.py','protocol_check/_transport.py']
runtime+=['minivec/tools/'+n for n in ('benchmark_bulk_guard.py','bulk_guard_proof.py','ci_bulk_guard_confirmation.sh','ablation_build.py',
 'benchmark_regression_ablation.py','regression_ablation_proof.py','benchmark_iteration.py','benchmark_report_matrix.py',
 'benchmark_projection.py','benchmark_filter_repeat.py','pgo/train.cpp','pgo/run-training.sh','ci_score.sh')]
unchanged=subprocess.check_output(git+['diff','--name-only',PARENT,'--',*runtime]).decode().splitlines()
assert not unchanged,unchanged
subprocess.run(git+['diff','--check','--','minivec/src/exec.cpp'],check=True,capture_output=True)
old=subprocess.check_output(git+['show',PARENT+':minivec/src/exec.cpp'])
new=(REPO/'minivec/src/exec.cpp').read_bytes()

def bulk_off(data):
    text=data.decode().replace('\r\n','\n')
    anchor='#ifdef MVDB_TYPED_BULK_VECTOR_ONLY'
    assert text.count(anchor)==1
    before,tail=text.split(anchor,1)
    candidate,after=tail.split('#else',1)
    retained,rest=after.split('#endif',1)
    return (before+retained+rest).split()
assert bulk_off(old)==bulk_off(new),'macro-off token stream changed'
diff=subprocess.check_output(git+['diff',PARENT,'--','minivec/src/exec.cpp'])
assert diff.count(b'@@')==2,'expected one local hunk'
proof=json.loads((HERE/'bulk-guard-harness-static-validation.json').read_bytes())
assert proof['status']=='passed' and len(proof['cases'])==12
for name,sha in proof['files_sha256'].items():assert digest((REPO/'minivec/tools'/name).read_bytes())==sha,name
cpp=json.loads((HERE/'bulk-loop-cpp-static-validation.json').read_bytes())
assert digest(new)==cpp['owned_source_sha256'] and cpp['source_parent']==PARENT
assert cpp['checks']['bulk_disabled_normalized_source_identical_to_85cded3']
review={'status':'static_scope_review_passed','source_parent':PARENT,'new_exec_working_file_sha256':digest(new),
 'original_exec_git_blob_sha256':digest(old),'new_source_diff_sha256':digest(diff),
 'harness_tests_reused_not_rerun':12,'harness_evidence_sha256':digest((HERE/'bulk-guard-harness-static-validation.json').read_bytes()),
 'unchanged_runtime_dependency_git_hashes':{n:digest(subprocess.check_output(git+['show',PARENT+':'+n])) for n in runtime},
 'review':['Only the bulk-enabled any_of predicate becomes an explicit for loop; false becomes continue, true sets the result and breaks.',
 'Nonvector/distance columns are skipped before schema dimension access; >=128 preserves old early acceptance; <16 skips; LIMIT then WHERE then live-key checks remain ordered.',
 'Macro-off token stream is identical after selecting the original preprocessor branch. Tests, diagnostic header, defaults, training, all192 tools and workflow are unchanged from the parent.',
 'This is not Linux compilation, assembly verification or performance evidence. Removing the outlined calls is a hypothesis; it does not establish the cause of prior regressions.']}
(HERE/'bulk-loop-preflight-review.json').write_bytes(encoded(review))
entries={'README.md':b'''# Bulk loop preflight only

Parent85cded31d28192f30b4177ed226384ec8d0ffd95; production bulk remains OFF.
Only the bulk-enabled any_of is replaced by an explicit loop. Thresholds,
short-circuit order and selected-vector semantics are unchanged. The macro-off
expression is preserved. The existing three source-gate modes will test the
candidate on Linux; no new test mirrors this implementation.

The prior12 harness checks are REUSED, NOT RERUN: their three tool byte hashes
still match exactly, and all benchmark/helper/training/test/default/workflow
dependencies are unchanged against the fixed parent Git blobs. This archive
includes the prior proof plus new source-only checks, scope review and full
source diff. It does not claim local Linux compilation, sanitizer execution,
elimination of assembly calls or a speedup. The next unchanged192 experiment
and actual generated code must establish those facts. No defaults are enabled.

working-tree/ contains the exact local candidate exec bytes (CRLF preserved).
parent/ is the immutable source snapshot, not a full Git checkout. The source
hash distinction is explicit because Git can normalize working-file line ends.
archive-manifest.json hashes every other member. No prior analysis ZIP was
modified by creating this separate archive.
''',
 'bulk-loop-cpp-static-validation.json':(HERE/'bulk-loop-cpp-static-validation.json').read_bytes(),
 'bulk-loop-preflight-review.json':encoded(review),'bulk-loop.patch':diff,
 'bulk-guard-harness-static-validation.json':(HERE/'bulk-guard-harness-static-validation.json').read_bytes(),
 'check_bulk_guard.py':(HERE/'check_bulk_guard.py').read_bytes(),
 'package_bulk_loop_preflight.py':Path(__file__).read_bytes(),
 'working-tree/minivec/src/exec.cpp':new,'parent/minivec/src/exec.cpp':old}
for name in runtime:entries['parent/'+name]=subprocess.check_output(git+['show',PARENT+':'+name])
entries['archive-manifest.json']=encoded({'source_parent':PARENT,'scope':'Every member except this manifest',
 'files':[{'path':n,'bytes':len(v),'sha256':digest(v)} for n,v in sorted(entries.items())]})
target=REPO/'validation/iteration4-bulk-loop-preflight.zip';assert not target.exists()
with zipfile.ZipFile(target,'x',compression=zipfile.ZIP_DEFLATED,compresslevel=9) as z:
    for name,data in sorted(entries.items()):
        info=zipfile.ZipInfo(name,(2026,11,13,0,0,0));info.compress_type=zipfile.ZIP_DEFLATED;z.writestr(info,data,compresslevel=9)
with zipfile.ZipFile(target) as z:
    manifest=json.loads(z.read('archive-manifest.json'))
    assert set(z.namelist())=={r['path'] for r in manifest['files']}|{'archive-manifest.json'}
    for row in manifest['files']:assert digest(z.read(row['path']))==row['sha256']
report={'status':'preflight_archived','path':target.relative_to(REPO).as_posix(),'bytes':target.stat().st_size,'sha256':digest(target.read_bytes()),
 'members':len(entries),'harness_tests_reused_not_rerun':12,'local_linux_execution':False}
(HERE/'bulk-loop-preflight-package-validation.json').write_bytes(encoded(report));print(json.dumps(report))
