# Bulk loop preflight only

Parent85cded31d28192f30b4177ed226384ec8d0ffd95; production bulk remains OFF.
Only the bulk-enabled any_of is replaced by an explicit loop. Thresholds,
short-circuit order and selected-vector semantics are unchanged. The macro-off
expression is preserved. The existing three source-gate modes will test the
candidate on Linux; no new test mirrors this implementation.

The prior12 harness checks are REUSED, NOT RERUN: their three tool byte hashes
still match exactly, and all benchmark/helper/training/test/default/workflow
dependencies are unchanged against the fixed parent Git blobs. This archive
includes the prior proof plus new source-only checks, scope review and full
source diff. It does not claim local Linux compilation, sanitizer execution,
elimination of assembly calls or a speedup. The next unchanged192 experiment
and actual generated code must establish those facts. No defaults are enabled.

working-tree/ contains the exact local candidate exec bytes (CRLF preserved).
parent/ is the immutable source snapshot, not a full Git checkout. The source
hash distinction is explicit because Git can normalize working-file line ends.
archive-manifest.json hashes every other member. No prior analysis ZIP was
modified by creating this separate archive.
