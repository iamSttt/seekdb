"""Narrow reader controls only. Constructed reports are never DB evidence."""
import ast,copy,json,sys,tempfile
from pathlib import Path
sys.dont_write_bytecode=True
import analyze_cursor_root as r
W=Path(__file__).resolve().parent;repo=W/'seekdb';checks=[]
def check(name,fn):fn();checks.append({'name':name,'status':'passed'})
def need(value):
    if not value:raise AssertionError('preflight failed')
def reject(name,fn):
    try:fn()
    except (ValueError,KeyError,FileNotFoundError):checks.append({'name':name,'status':'passed','expected_rejection':True})
    else:raise AssertionError('bad evidence accepted')
check('reader_syntax',lambda:ast.parse((W/'analyze_cursor_root.py').read_text(encoding='utf8')))
check('current18_plus_cursor_not_old17',lambda:need(len(r.GATES)==19 and r.CURSOR_GATE in r.GATES and 'insert_owned_copy_normal_and_sanitized' in r.GATES))
check('reviewed_local_main_bytes',lambda:need(r.sha(repo/'minivec/src/main.cpp')==r.MAIN_SHA))
raw=(repo/'minivec/tests/test_jsonl_cursor.py').read_bytes();tree=ast.parse(raw)
cases=ast.literal_eval(next(n.value for n in tree.body if isinstance(n,ast.Assign) and any(isinstance(t,ast.Name) and t.id=='EXPECTED_CASES' for t in n.targets)))
check('current_cursor16_source_inventory',lambda:need(cases==r.CASES))
# Evaluate only the two pure framing functions; no launch/run_case/main/import.
nodes=[n for n in tree.body if isinstance(n,ast.FunctionDef) and n.name in ('framing_model','mechanism_model')]
namespace={'require':r.require,'MODEL_SCOPE':r.MODEL_SCOPE}
exec(compile(ast.Module(body=nodes,type_ignores=[]),'<pure-framing-model>','exec'),namespace)
model=namespace['mechanism_model']()
check('pure_model_scope',lambda:need(model['scope']==r.MODEL_SCOPE and model['not_a_performance_measurement'] is True))
fixture={'status':'passed','binary_sha256':'a'*64,'checks':[],
 'scope':'actual binary protocol/persistence correctness',
 'fragmentation_scope':'writer chunks; kernel read boundaries are not controlled or measured','mechanism_model':model}
for name in r.CASES:
    c={'name':name,'status':'passed'}
    if name.startswith('fragment_writer_'):c.update(writer_chunk_bytes=int(name.rsplit('_',1)[1]),payload_bytes=500,tail_waited_for_newline=True)
    elif name.startswith('large_'):
        _,size,_,chunk=name.split('_');c.update(writer_chunk_bytes=int(chunk),payload_bytes=int(size[:-1])*1024+100,kind='valid INSERT with block-comment padding')
    elif name=='vector_insert_writer_65536':c.update(writer_chunk_bytes=65536,payload_bytes=160000,rows=100,dimension=128)
    elif name=='crlf_split':c['split_between_cr_and_lf']=True
    elif name.startswith('eof_'):c.update(restart_checked_persistent_rows=True,tail_executed=False)
    elif name=='duplicate_keys_no_execute':c.update(duplicate_spellings=['literal','escaped-equivalent'],mutations=0)
    elif name=='malformed_frame_no_execute':c.update(invalid_shapes=['missing_brace','trailing_garbage','empty_frame'],mutations=0)
    elif name=='shutdown_same_write_discards_tail':c.update(single_writer_send_bytes=200,restart_checked_persistent_rows=True,read_coalescing_not_assumed=True)
    elif name=='escaped_newline':c.update(writer_chunk_bytes=1,physical_newlines=1)
    fixture['checks'].append(c)
with tempfile.TemporaryDirectory(prefix='cursor-reader-schema-') as td:
    root=Path(td);output=root/'image-binary-jsonl-cursor.json'
    (root/'image-binary-jsonl-cursor.log').write_text('\n'.join('PASS '+x for x in cases)+'\n')
    old=r.blob
    # Only this schema-control invocation substitutes local test source for a
    # Git fetch. The production reader remains unchanged and Git-bound.
    r.blob=lambda repo,commit,path:raw if path=='minivec/tests/test_jsonl_cursor.py' else old(repo,commit,path)
    try:
        output.write_text(json.dumps(fixture))
        check('constructed_schema_accepts_complete_inventory',lambda:r.cursor_gate(root,repo,'schema_fixture','a'*64))
        for name,change in (
          ('missing_case',lambda v:v['checks'].pop()),
          ('wrong_actual_ELF',lambda v:v.update(binary_sha256='b'*64)),
          ('EOF_tail_executed',lambda v:v['checks'][10].update(tail_executed=True)),
          ('model_claims_actual_performance',lambda v:v['mechanism_model'].update(not_a_performance_measurement=False))):
            bad=copy.deepcopy(fixture);change(bad);output.write_text(json.dumps(bad))
            reject(name,lambda:r.cursor_gate(root,repo,'schema_fixture','a'*64))
    finally:r.blob=old
result={'status':'passed','check_count':len(checks),'checks':checks,'database_runs':0,'compiler_runs':0,
 'reader_sha256':r.sha(W/'analyze_cursor_root.py'),'actual_cursor_root_verified':False,
 'scope':'Syntax, local pending-source pin, pure model, and constructed schema rejection controls only. No Git-committed candidate or actual new gate/performance result is claimed.'}
(W/'cursor-root-reader-preflight.json').write_text(json.dumps(result,indent=2)+'\n',encoding='utf8')
print(json.dumps({k:result[k] for k in ('status','check_count','database_runs','reader_sha256')}))
