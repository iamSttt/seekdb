"""Dispatch the one predeclared unchanged matched-root replication; no credentials logged."""
import datetime
import json
import os
from pathlib import Path
import subprocess
import urllib.request

HEAD = '6d2c4331d82073cc166c32c29f59dcf6cfaf31da'
BRANCH = 'codex/round2-optimize-20261112'
REPO = 'https://api.github.com/repos/iamSttt/seekdb'
OUT = Path(__file__).with_name('matched-repeat-dispatch.json')
if OUT.exists():
    raise SystemExit('Existing dispatch receipt; refuse a second request.')
result = subprocess.run(['git', 'credential', 'fill'],
    input='protocol=https\nhost=github.com\n\n', text=True, capture_output=True,
    check=True, timeout=30,
    env=dict(os.environ, GIT_TERMINAL_PROMPT='0', GCM_INTERACTIVE='Never'))
fields = dict(line.split('=', 1) for line in result.stdout.splitlines() if '=' in line)
headers = {'Authorization': 'Bearer ' + fields['password'],
           'User-Agent': 'MiniVectorDB-matched-repeat',
           'Accept': 'application/vnd.github+json',
           'X-GitHub-Api-Version': '2022-11-28'}
with urllib.request.urlopen(urllib.request.Request(REPO + '/git/ref/heads/' + BRANCH, headers=headers), timeout=40) as response:
    ref = json.load(response)
if ref['object']['sha'] != HEAD:
    raise SystemExit('Remote branch drift; no workflow dispatched.')
receipt = {'status': 'request_about_to_send_no_automatic_retry', 'head_sha': HEAD,
           'branch': BRANCH, 'planned_pairs': 8, 'planned_pgo_builds': 2,
           'utc': datetime.datetime.now(datetime.timezone.utc).isoformat(),
           'policy': 'One independent unchanged replication; preserve every result and hardware identity. No formal submission.'}
OUT.write_text(json.dumps(receipt, indent=2) + '\n', encoding='utf8')
data = json.dumps({'ref': BRANCH, 'inputs': {'matched_insert_roots': True}}).encode()
request = urllib.request.Request(REPO + '/actions/workflows/minivec-score.yml/dispatches',
    data=data, headers={**headers, 'Content-Type': 'application/json'}, method='POST')
with urllib.request.urlopen(request, timeout=40) as response:
    receipt.update(status='accepted', http_status=response.status)
OUT.write_text(json.dumps(receipt, indent=2) + '\n', encoding='utf8')
print(json.dumps(receipt))
