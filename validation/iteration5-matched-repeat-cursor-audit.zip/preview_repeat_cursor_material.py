"""Archive verified matched repeat plus unmeasured cursor preparation; work only."""
import copy
import hashlib
import importlib.util
import io
import json
from pathlib import Path
import zipfile

BASE = '6c45112651ab71b9a56b7ba93a7ca2a5617d386ee2b2e6e0995d0c17fa3917cf'
RAW_SHA = '350152ce7cac1abb29a7ac48e4138bd168c5e493089f42067080db9e3bf0181f'
ANALYSIS_SHA = '32986509633832b7a627a2fd4756a68617eae09a7d38f921294a307827b1ad3f'
DECISION_SHA = '8ecf3d5076e94fbdbb9d1be15ff053f93468fcce69c2f83563e248913708bc6e'
COMPACT_SHA = 'f0b4b0699c7eb4d2164b6545b77877ce73d3c60efe69dab7d386762e4698794b'
PLAN_SHA = '2bfdc2ea58909f381974589632f44e8b448ef15b368ce097223d68c45acb9346'
R_SHA = 'acddca115ab183bfc6419e27c9e3383cfd1a9046e3897e5ea516cd7bc0f29f54'
N_SHA = '07daffba3ef448636e335292e894b6af005a18d0c02307495b371435b6d9a548'
RAW_DEST = 'validation/iteration5-matched-insert-repeat-raw.zip'
AUDIT_DEST = 'validation/iteration5-matched-repeat-cursor-audit.zip'

def need(ok, message):
    if not ok:
        raise ValueError(message)

def sha(data):
    return hashlib.sha256(data).hexdigest()

def encode(value):
    return (json.dumps(value, ensure_ascii=False, separators=(',', ':'), allow_nan=False) + '\n').encode('utf8')

def pointers(value):
    if isinstance(value, dict):
        return [child for key, child in value.items() if key == 'pointer' or key.endswith('_pointer')] + [p for child in value.values() for p in pointers(child)]
    if isinstance(value, list):
        return [p for child in value for p in pointers(child)]
    return []

def main():
    work = Path(__file__).resolve().parent
    repo = work / 'seekdb'
    raw = (repo / 'conversation.json').read_bytes()
    need(raw == (repo / 'agent/conversation.json').read_bytes() and len(raw) == 126792 and sha(raw) == BASE, 'material drift')
    old = json.loads(raw)
    need(encode(old) == raw and len(old['messages']) == 129 and len(old['experiments']) == 53, 'inventory drift')
    users = [m for m in old['messages'] if m['role'] == 'user']
    need(len(users) == 45, 'user inventory drift')
    actual_raw = (work / 'performance/matched-insert-repeat-6d2c433.zip').read_bytes()
    need(len(actual_raw) == 2670993 and sha(actual_raw) == RAW_SHA, 'repeat raw differs')
    files = {}
    names = [
        'analyze_matched_insert_roots.py', 'check_matched_insert_reader.py', 'matched-insert-reader-preflight.json',
        'matched-repeat-reader-plan.json', 'matched-insert-repeat-independent-analysis.json',
        'matched-insert-repeat-decision.json', 'matched-insert-repeat-compact-decision.json',
        'summarize_matched_insert_repeat.py', 'dispatch_matched_repeat.py', 'matched-repeat-dispatch.json',
        'jsonl-cursor-screen-plan.json', 'connect_cursor_ci.py', 'analyze_cursor_root.py',
        'check_cursor_root_reader.py', 'cursor-root-reader-extension-plan.json', 'cursor-root-reader-preflight.json',
        Path(__file__).name,
    ]
    names += [p.relative_to(work).as_posix() for p in sorted((work / 'jsonl-cursor-draft').rglob('*')) if p.is_file()]
    for name in names:
        files[name] = (work / name).read_bytes()
    for relative in ['minivec/src/main.cpp', 'minivec/tests/test_jsonl_cursor.py', 'minivec/tools/ci_score.sh',
                     'minivec/tools/summarize_small_root.py', 'minivec/tools/prepare_small_compute.py']:
        files['prepared-working-inputs/' + relative] = (repo / relative).read_bytes()
    for name, digest in [('matched-insert-repeat-independent-analysis.json', ANALYSIS_SHA),
                         ('matched-insert-repeat-decision.json', DECISION_SHA),
                         ('matched-insert-repeat-compact-decision.json', COMPACT_SHA), ('jsonl-cursor-screen-plan.json', PLAN_SHA)]:
        need(sha(files[name]) == digest, 'evidence differs: ' + name)
    analysis = json.loads(files['matched-insert-repeat-independent-analysis.json'])
    decision = json.loads(files['matched-insert-repeat-compact-decision.json'])
    plan = json.loads(files['jsonl-cursor-screen-plan.json'])
    static = json.loads(files['jsonl-cursor-draft/static-preflight.json'])
    need(analysis['status'] == 'verified' and analysis['verified_pairs'] == 8 and analysis['new_root_pgo_builds'] == 2
         and analysis['artifact_sha256'] == RAW_SHA and len(analysis['all_negative_or_mixed_metrics']) == 60, 'repeat result differs')
    need(decision['analysis_sha256'] == ANALYSIS_SHA and decision['raw_sha256'] == RAW_SHA
         and decision['decision'] == 'end_default_INSERT_adoption_path_keep_R' and decision['negative_metric_entries'] == 60
         and decision['run_id'] == 43475743893 and decision['artifact_id'] == 14062767408, 'repeat decision differs')
    need(decision['programs']['r2']['binary_sha256'] == R_SHA and decision['programs']['n2']['binary_sha256'] == N_SHA,
         'repeat actual identities differ')
    need(decision['all_negative_evidence']['sha256'] == ANALYSIS_SHA and decision['all_negative_evidence']['count'] == 60
         and len(decision['all_negative_evidence']['entries']) == 60, 'negative evidence incomplete')
    for cpu in ('1', '2'):
        need(decision['measurements'][cpu]['same_unfiltered_policy_all_pairs'] == 2, 'policy differs')
    second = decision['measurements']['2']['metrics']
    need(second['ingest_system_usec']['candidate_larger_pairs'] == 4 and second['ingest_cpu_usec']['candidate_larger_pairs'] == 3
         and second['query_before_update/first']['candidate_larger_pairs'] == 4, 'adverse counts differ')
    need(plan['status'] == 'planned_unmeasured' and plan['database_pairs_executed'] == 0
         and plan['new_pgo_builds_executed'] == 0 and plan['default_adopted'] is False, 'cursor is no longer an unmeasured plan')
    need(static['database_executions'] == 0 and static['compiled_database_tests'] == 0 and len(static['expected_actual_cases']) == 16,
         'cursor static scope differs')
    need(sha(files['prepared-working-inputs/minivec/src/main.cpp']) == static['main_sha256']
         and sha(files['prepared-working-inputs/minivec/tests/test_jsonl_cursor.py']) == static['test_sha256'], 'cursor preparation source drift')
    for name, digest in static['retained_db_exec_sha256'].items():
        need(sha((repo / 'minivec/src' / name).read_bytes()) == digest, 'retained runtime drift: ' + name)
    manifest = {
        'schema': 'matched-repeat-and-cursor-preparation-v1',
        'source_material': {'bytes': len(raw), 'sha256': BASE},
        'actual_repeat': {'run_id': decision['run_id'], 'job_id': decision['job_id'], 'artifact_id': decision['artifact_id'],
                         'harness_commit': analysis['harness_commit'], 'path': RAW_DEST, 'bytes': len(actual_raw), 'sha256': RAW_SHA,
                         'verified_pairs': 8, 'new_root_pgo_builds': 2, 'negative_or_mixed_metrics': 60,
                         'decision': decision['decision'], 'source_sanitizers_rerun': False},
        'cursor_preparation': {'plan_file': 'jsonl-cursor-screen-plan.json', 'plan_sha256': PLAN_SHA,
                               'planned_new_pgo_builds': 1, 'planned_pairs': 20, 'executed_database_pairs': 0,
                               'executed_new_pgo_builds': 0, 'default_adopted': False,
                               'scope': 'Uncommitted prepared working inputs and static/model evidence, not Linux runtime or actual-root gate results.'},
        'files': {name:{'bytes':len(data), 'sha256':sha(data)} for name,data in sorted(files.items())},
    }
    target = io.BytesIO()
    with zipfile.ZipFile(target, 'w', compression=zipfile.ZIP_DEFLATED, compresslevel=9) as zf:
        for name, data in sorted({**files, 'manifest.json': encode(manifest)}.items()):
            info = zipfile.ZipInfo(name, date_time=(2026, 11, 14, 0, 0, 0))
            info.external_attr = 0o100644 << 16
            zf.writestr(info, data, compress_type=zipfile.ZIP_DEFLATED, compresslevel=9)
    audit = target.getvalue()
    new = copy.deepcopy(old)
    exp = new['experiments'][52]
    need(exp['id'] == 'matched-root-single-repeat' and exp['status'] == 'running_no_verified_results', 'repeat experiment drift')
    exp.pop('new_pgo_builds_verified')
    exp.pop('database_pairs_verified')
    exp.update(status='measured_rejected_default_path_ended', new_pgo_builds_executed=2, database_pairs_executed=8,
               result_message='assistant-matched-repeat-result', negative_or_mixed_metrics_preserved=60,
               source_sanitizers_rerun=False,
               artifacts=[{'path':RAW_DEST, 'sha256':RAW_SHA}, {'path':AUDIT_DEST, 'sha256':sha(audit)}])
    new['messages'].append({'id':'assistant-matched-repeat-result', 'role':'assistant', 'content':
        'assistant完成唯一独立复验：2次新根PGO、8对通过，R/N仍acdd/07da，主机9V45。N/R：1CPU首周期阶段和0.98142、查询wall/CPU=0.95282/0.96347，各3/4好；2CPU阶段和1.01120、查询1.01333、首条1.18029且4/4慢，写入CPU1.00710(3/4慢)、system1.41108(4/4增)。双方无过滤首轮/重启均选2线程，不能归因分流不等。保留60项负面及旧N1/首轮记录；未触发预定义联合阈值，但跨轮未证明普遍保优，终止该INSERT默认采用路线，不跑第三轮。阶段和非连续端到端；R默认，不推断正式分数。'})
    new['messages'].append({'id':'assistant-jsonl-cursor-plan', 'role':'assistant', 'content':
        'assistant新候选仅改main.cpp的JSONL换行扫描游标，保留帧/错误/EOF/shutdown/持久化/线程语义。静态与模型已检查，模型扫描量不等于实际read边界或收益；当前新PGO/DB0。计划原根PGO一次、既有18门禁+实际程序16项分帧门禁，原1CPU12+2CPU8对、exact/2GiB/swap0。20对仅筛查；保护阶段两顺序均慢>2%或峰值内存增>5%阻止默认采用。全负面保留，须见真实写入/生命周期改善；不复活INSERT/CRC/线程方案，不正式提交。'})
    new['experiments'].append({'id':'jsonl-newline-cursor-root-screen', 'proposed_by':'assistant', 'executed_by':'assistant',
        'status':'planned_unmeasured', 'user_request_message':'user-new-directions-request',
        'plan_message':'assistant-jsonl-cursor-plan', 'planned_root_pgo_builds':1, 'planned_database_pairs':20,
        'new_pgo_builds_executed':0, 'database_pairs_executed':0, 'default_adopted':False, 'assistant_formal_submissions':0,
        'preparation_evidence':{'archive_experiment':'matched-root-single-repeat', 'source_location':'jsonl-cursor-screen-plan.json', 'sha256':PLAN_SHA}})
    need(new['messages'][:129] == old['messages'] and [m for m in new['messages'] if m['role']=='user'] == users, 'old message/user changed')
    need(new['experiments'][:52] == old['experiments'][:52], 'old experiment changed')
    for key in old:
        if key not in ('messages','experiments'):
            need(new[key] == old[key], 'root field changed: ' + key)
    spec = importlib.util.spec_from_file_location('preview_checker', repo / 'minivec/tools/validate_iteration_material.py')
    checker = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(checker)
    checker.validate(repo)
    checker.check_structure(new,new)
    for pointer in pointers(old):
        need(encode(checker.resolve_pointer(new,pointer)) == encode(checker.resolve_pointer(old,pointer)), 'old pointer changed')
    result = encode(new)
    need(len(result) <= 131072 - 1500, 'insufficient space for final cursor result')
    summary = {'status':'preview_only_not_applied', 'repository_writes':0, 'git_commands':0,
               'new_database_runs_by_script':0, 'source_bytes':len(raw), 'source_sha256':BASE,
               'preview_bytes':len(result), 'preview_sha256':sha(result), 'remaining_bytes':131072-len(result),
               'original_messages_preserved':129, 'original_users_preserved':45, 'messages':len(new['messages']),
               'experiments':len(new['experiments']), 'selected_runtime_and_formal_results_unchanged':True,
               'all_old_pointer_targets_unchanged':True, 'repeat_verified_pairs':8, 'cursor_executed_pairs':0,
               'prospective_full_repository_validation_run':False, 'apply_available':False,
               'suggested_copy':[
                   {'source':'performance/matched-insert-repeat-6d2c433.zip', 'target':RAW_DEST, 'bytes':len(actual_raw), 'sha256':RAW_SHA},
                   {'source':'iteration5-matched-repeat-cursor-audit.zip', 'target':AUDIT_DEST, 'bytes':len(audit), 'sha256':sha(audit)},
                   {'source':'repeat-cursor-material-preview.json', 'targets':['conversation.json','agent/conversation.json'], 'bytes':len(result), 'sha256':sha(result)}]}
    for name, data in [('iteration5-matched-repeat-cursor-audit.zip',audit), ('repeat-cursor-material-preview.json',result),
                       ('repeat-cursor-material-summary.json',encode(summary))]:
        destination=work/name
        need(not destination.exists(), 'refuse overwrite')
        destination.write_bytes(data)
    print(json.dumps({key:summary[key] for key in ('status','preview_bytes','remaining_bytes','preview_sha256')}, indent=2))

if __name__ == '__main__':
    main()
