"""Second matched run only; no pooled or cross-host causal ratios."""
import json,re
from pathlib import Path
from statistics import median
import analyze_crc_root as c
w=Path(__file__).resolve().parent;p=w/'matched-insert-repeat-independent-analysis.json';d=c.read(p)
assert c.sha(p)=='32986509633832b7a627a2fd4756a68617eae09a7d38f921294a307827b1ad3f'
assert d['status']=='verified' and d['verified_pairs']==8
out={'status':'derived_from_verified_second_run','decision':'end_default_INSERT_adoption_path_keep_R',
 'run_id':43475743893,'job_id':132058993324,'artifact_id':14062767408,
 'harness_commit':d['harness_commit'],'raw_sha256':d['artifact_sha256'],'analysis_sha256':c.sha(p),
 'model':next(x.split(':',1)[1].strip() for x in d['actual_cpu_model'].splitlines() if x.startswith('Model name:')),
 'new_pgo_builds':2,'programs':{},'measurements':{},'negative_metric_entries':len(d['all_negative_or_mixed_metrics'])}
for label,v in d['programs'].items():
 out['programs'][label]={k:v[k] for k in ('source_commit','binary_sha256','image_id','source_sanitizers_rerun')}
 out['programs'][label]['training']={k:v['training'][k] for k in ('build_log_sha256','training_manifest_sha256','profile_sha256_from_build_log')}
 out['programs'][label]['training']['verified_oracle_records']=len(v['training']['oracle_records'])
for cpu,m in d['measurements'].items():
 metrics={}
 for k,v in m['extra_summary']['standard10k'].items():
  rows=v['raw_pairs'];valid=all(x['baseline']>0 for x in rows)
  ratios=[x['candidate']/x['baseline'] for x in rows] if valid else []
  metrics[k]={'candidate_over_baseline_median':median(ratios) if valid else None,
   'candidate_larger_pairs':v['candidate_larger_pairs'],'raw_pairs':rows,
   'leave_one_pair_out_medians':[median(ratios[:i]+ratios[i+1:]) for i in range(4)] if valid else None}
 for k,v in m['summary']['standard10k'].items():
  if k.startswith('query_'):
   rows=v['raw_pairs'];ratios=[x['candidate_seconds']/x['baseline_seconds'] for x in rows]
   metrics[k]={'candidate_over_baseline_median':median(ratios),'candidate_larger_pairs':v['candidate_slower_pairs'],
    'raw_pairs':rows,'leave_one_pair_out_medians':[median(ratios[:i]+ratios[i+1:]) for i in range(4)]}
 policies=[]
 for pair in m['resources_and_policy']:
  item={'pair_index':pair['pair_index'],'order':pair['order']}
  for role,side in pair['sides'].items():
   logs=side['policy']['fanout_log_lines']
   wake=[float(re.search(r'wake_us=([0-9.]+)',x).group(1)) for x in logs if 'median of 200 handshakes' in x]
   decisions=[int(re.search(r'-> ([12]) threads?',x).group(1)) for x in logs if 'fanout rows=' in x]
   assert len(wake)==2 and len(decisions)==8 and set(decisions)=={2}
   item[role]={'startup_wake_us':wake,'logged_unfiltered_threads':decisions,'cpu_intervals':side['cpu_intervals']}
  policies.append(item)
 out['measurements'][cpu]={'metrics':metrics,'policy':policies,'joint_wall_cpu_regressions':d['joint_wall_cpu_default_regressions'][cpu]}
out['interpretation']=[
 'Exactly the one agreed independent repetition was completed. Keep selected R and stop pursuing default adoption of this INSERT version; no third favorable-result hunt.',
 'One-CPU query and first-cycle benefits recur within this host, but two-CPU first-query wall worsens in all four pairs; two-CPU ingest system CPU also rises in all four, and total ingest CPU rises in three.',
 'No predefined joint wall/CPU >2% default threshold was triggered. The recommendation is based on failure to demonstrate preserved two-CPU behavior and repeatable general benefit, not a claim that this threshold failed.',
 'Every startup in both CPU groups chooses two threads for eligible unfiltered queries on both sides; filtered queries remain serial. This round two-CPU adverse first-query results cannot be attributed to unequal selected fanout.',
 'Second-run R and N ELF bytes equal the corresponding first matched-run bytes after new original Docker/PGO builds; new image IDs and training logs are separately bound. This does not identify CPU/ISA/PGO causality.',
 'Hosts differ from the first matched run. No ratios or sample distributions are pooled; original N1/5606 rejection and all first-run negatives remain valid records.',
 'First lifetime and restart-inclusive wall values are stage sums. CPU is measured only by phase, not separately for first request and later requests. No formal score claim or automatic adoption.'
]
target=w/'matched-insert-repeat-decision.json';assert not target.exists()
target.write_text(json.dumps(out,ensure_ascii=False,indent=2)+'\n',encoding='utf8')
print(json.dumps({'path':str(target),'bytes':target.stat().st_size,'sha256':c.sha(target)}))
