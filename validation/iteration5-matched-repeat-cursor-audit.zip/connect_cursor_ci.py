"""Wire the actual-image framing gate without changing the frozen paired plan."""
from pathlib import Path

p=Path(__file__).resolve().parent/'seekdb/minivec/tools/ci_score.sh'
b=p.read_bytes(); nl=b'\r\n' if b'\r\n' in b else b'\n'
text=b.decode().replace('\r\n','\n')
old='python3 minivec/tests/topk_bounds.py --binary "$scratch/image-binary" 2>&1 | tee protocol-results/image-binary-topk.log\n'
new='python3 minivec/tests/test_jsonl_cursor.py --binary "$scratch/image-binary" --output protocol-results/image-binary-jsonl-cursor.json 2>&1 | tee protocol-results/image-binary-jsonl-cursor.log\n'+old
assert text.count(old)==1
text=text.replace(old,new)
old="image_binary_sha=Path('protocol-results/image-binary-sha256.txt').read_text().split()[0]\n"
new=old+'''cursor=json.loads(Path('protocol-results/image-binary-jsonl-cursor.json').read_text())
cursor_expected={
    'fragment_writer_1','fragment_writer_7','fragment_writer_4096','fragment_writer_65536',
    'large_64k_writer_4096','large_64k_writer_65536',
    'large_256k_writer_4096','large_256k_writer_65536','vector_insert_writer_65536',
    'crlf_split','eof_valid_unterminated_no_execute','eof_truncated_json_no_execute',
    'duplicate_keys_no_execute','malformed_frame_no_execute',
    'shutdown_same_write_discards_tail','escaped_newline'}
if (cursor.get('status')!='passed' or cursor.get('binary_sha256')!=image_binary_sha or
        len(cursor.get('checks',[]))!=len(cursor_expected) or
        {c.get('name') for c in cursor['checks']}!=cursor_expected or
        any(c.get('status')!='passed' for c in cursor['checks'])):
    raise SystemExit('Actual image JSONL framing evidence is incomplete')
'''
assert text.count(old)==1
text=text.replace(old,new)
old="        'actual_image_54_utf8_atomicity_cases': True,\n"
new=old+"        'actual_image_jsonl_cursor_frames': True,\n"
assert text.count(old)==1
text=text.replace(old,new)
p.write_bytes(text.encode().replace(b'\n',nl))
print('Added actual-image JSONL framing gate; performance plan unchanged')
