"""Independent read-only audit: two newly built roots and eight default pairs.

No DB/compiler is run here. New image gates are not source-sanitizer reruns.
"""
import argparse
import ast
import json
import math
from pathlib import Path
import re
from statistics import median
import analyze_crc_root as core
import analyze_highest_compare as highest
import analyze_insert_copy_root as insert
import analyze_insert_thread_control as control
from analyze_crc_root import require,digest,sha,read,git,blob,safe_name,cpus,counters,io_counters,timings,lifecycle_timings,LABELS,TOOLS

SOURCES={'r2':'33a52a7dd4426af059ec2334b7c93a07c38c93c9','n2':'7554753868330006270cf39b1d32108f0a40ccac'}
HARNESS_COMMIT='6d2c4331d82073cc166c32c29f59dcf6cfaf31da'
OLD={'r2':core.BASE_BINARY,'n2':control.N_SHA}
DOCKER='8014b651f2974844a411fdc1b88b9b6e46a6010eb31be14f28d909e77eeb8b5b'
CONTEXT_PATHS=('Dockerfile','.dockerignore','minivec/src','minivec/third_party','minivec/tools/pgo/train.cpp','minivec/tools/pgo/run-training.sh')
GATES={'actual_image_handshake','actual_image_public_20','actual_image_interactive','actual_elf_json_8','actual_elf_utf8_54','actual_elf_topk_serial','actual_elf_topk_parallel'}
JSON_CASES=['typed_rows','row_encoding_reuse','transactions_and_invalid_input','crash_recovery','mode_switch','fragmented_jsonl','parallel_insert_errors','legacy_mode']
TOPK='PASS JSONL TopK against exact float32 oracle, including ties, filters and rollback'


def plan(count):
    require(type(count) is int and count in (1,2),'unsupported matched CPU')
    return [{'scenario':'standard10k','seed':7319,'pair_index':i,'order':['baseline','candidate'] if i%2==0 else ['candidate','baseline']} for i in range(4)]


def source_contexts(root,repo,commit,prep):
    require(prep['status']=='verified' and prep['harness_commit']==commit and prep['harness_matches_git'] is True and
            prep['source_commits']==SOURCES and prep['context_differences']==['minivec/src/exec.cpp'] and
            prep['dockerfile_sha256']==DOCKER and prep['feature_flags']==core.FLAGS and prep['build_args']=={} and
            prep['new_pgo_builds_planned']==2 and prep['source_sanitizers_rerun'] is False,'matched preparation policy differs')
    require(set(prep['source_sha256'])==set(SOURCES),'unexpected source label')
    tree=ast.parse(blob(repo,commit,'minivec/tools/prepare_matched_insert_roots.py'))
    declarations=[x for x in tree.body if isinstance(x,ast.Assign) and any(isinstance(t,ast.Name) and t.id=='TOOL_PATHS' for t in x.targets)]
    require(len(declarations)==1,'tool inventory declaration missing')
    paths=ast.literal_eval(declarations[0].value)
    expected=set(git(repo,'ls-tree','-r','--name-only',commit,'--',*paths).decode().splitlines())
    require(set(prep['harness_file_sha256'])==expected and TOOLS.issubset(expected),'complete harness Git inventory differs')
    for path,h in prep['harness_file_sha256'].items():require(digest(blob(repo,commit,path))==h,'harness Git mismatch: '+path)
    maps={}
    for label,source in SOURCES.items():
        directory=root/(label+'-context')
        paths=set(git(repo,'ls-tree','-r','--name-only',source,'--',*CONTEXT_PATHS).decode().splitlines())
        require(paths==set(prep['source_sha256'][label])=={p.relative_to(directory).as_posix() for p in directory.rglob('*') if p.is_file()},'complete build context differs')
        maps[label]={}
        for path in sorted(paths):
            safe_name(path);raw=blob(repo,source,path)
            require((directory/path).read_bytes()==raw and digest(raw)==prep['source_sha256'][label][path],'actual context bytes differ: '+path)
            maps[label][path]=digest(raw)
        docker=(directory/'Dockerfile').read_text(encoding='utf8')
        require(maps[label]['Dockerfile']==DOCKER and core.COMPILER in docker and 'WORKDIR /src' in docker and 'ARG ENABLE_PGO=1' in docker and
                all(f in docker for f in core.FLAGS) and '-fprofile-generate=/pgo' in docker and '-fprofile-use=/pgo' in docker and
                '-Werror=missing-profile -Werror=coverage-mismatch' in docker,'original root compile/training/workdir policy differs')
    require(set(maps['r2'])==set(maps['n2']) and [p for p in maps['r2'] if maps['r2'][p]!=maps['n2'][p]]==['minivec/src/exec.cpp'], 'source inputs differ beyond exec.cpp')
    return {'source_commits':SOURCES,'context_sha256':maps,'only_changed_build_input':'minivec/src/exec.cpp','harness_git_inputs':len(expected)}


def training(directory,source_hashes):
    log=directory/'docker-build.log';text=log.read_text(encoding='utf8');manifests=[];records=[]
    require(core.COMPILER in text and '-fprofile-generate=/pgo' in text and '-fprofile-use=/pgo' in text,'actual original compiler/PGO build log incomplete')
    for line in text.splitlines():
        if '{' not in line:continue
        raw=line[line.index('{'):]
        try:item=json.loads(raw)
        except ValueError:continue
        if not isinstance(item,dict):continue
        if item.get('kind')=='build_only_general_PGO_training':manifests.append(item)
        if item.get('actual_file','').startswith('responses-'):records.append({'record':item,'json_record_sha256':digest(raw.encode())})
    require(len(manifests)==1,'must have exactly one training corpus per build')
    manifest=manifests[0]
    require(manifest['seed']==2026111201 and manifest['phase_requests']==[950,40,13],'training seed/phase policy differs')
    expected={(f'responses-{t}-{p}.jsonl',f'phase-{p}.expected.jsonl',[951,41,14][p]) for t in (1,2) for p in range(3)}
    require(len(records)==6 and {(r['record']['actual_file'],r['record']['expected_file'],r['record']['responses']) for r in records}==expected and
            all(r['record']['status']=='passed' for r in records),'six independent training oracle outputs incomplete')
    profiles=re.findall(r'([0-9a-f]{64})\s+/pgo/(minivec-[A-Za-z_]+\.gcda)',text)
    names={'minivec-'+Path(p).stem+'.gcda' for p in source_hashes if p.startswith('minivec/src/') and p.endswith('.cpp')}
    require(len(profiles)==len(names) and {p for _,p in profiles}==names,'complete six-profile inventory differs')
    result={'status':'passed','build_log_sha256':sha(log),'training_manifest':manifest,
        'training_manifest_sha256':digest(json.dumps(manifest,sort_keys=True,separators=(',',':')).encode()),
        'oracle_records':records,'profile_sha256_from_build_log':{p:h for h,p in profiles},'profile_contents_archived':False,
        'scope':'Original Docker log records, not recovered gcda contents or labelled function counts.'}
    require(result==read(directory/'training-evidence.json'),'independent training evidence differs')
    return result


def image_gates(root,repo,commit,label):
    directory=root/label;public={c['id'] for c in json.loads(blob(repo,commit,'mysqltest/manifest.json'))['cases']}
    require(len(public)==20,'public inventory differs')
    for name,expected in [('image-handshake',{'handshake'}),('image-public',public)]:
        data=read(directory/name/'result.json')
        require(data['passed'] is True and len(data['cases'])==len(expected) and {c['id'] for c in data['cases']}==expected and all(c['status']=='PASS' for c in data['cases']),'image public/handshake output incomplete')
    events=read(directory/'image-interactive/events.json')
    require(len(events)==20 and sum(v.get('fragmented_utf8_request') is True for v in events)==1 and
            sum(v.get('exit_before_stdin_close') is True for v in events)==2 and sum(v.get('response',{}).get('ok') is False for v in events)==3 and
            all(v.get('stdin_open') is True for v in events if 'response' in v) and
            (directory/'image-interactive.log').read_text().strip().startswith('PASS: official Session,'),'interactive events incomplete')
    require([x for x in (directory/'json.log').read_text().splitlines() if x.startswith('PASS ')]==['PASS '+x for x in JSON_CASES],'ELF JSON eight cases incomplete')
    u=read(directory/'utf8.json');expected={(raw,dim,path) for raw in ('ff','c080','eda080','e4b8','f4908080','80') for dim in (None,127,128) for path in ('ORDER BY id LIMIT 10','unbounded','ORDER BY id LIMIT 4096')}
    require(u['status']=='passed' and len(u['checks'])==54 and {(x['malformed_hex'],x['projected_vector_dimension'],x['path']) for x in u['checks']}==expected and all(x['status']=='passed' for x in u['checks']),'ELF 54 UTF8 cases incomplete')
    for name in ('topk.log','topk-parallel.log'):require((directory/name).read_text().strip()==TOPK,'actual ELF serial/parallel TopK output incomplete')
    return dict.fromkeys(GATES,True)


def bind_programs(root,repo,commit,prep,binding,summary):
    require(binding['status']=='verified' and binding['prepare_proof_sha256']==sha(root/'prepare-proof.json') and
            binding['identity_sha256']==sha(root/'identities.json') and binding['new_pgo_builds']==2 and
            binding['source_sanitizers_rerun'] is False and binding['automatic_adoption'] is False,'new root binding differs')
    require(set(binding['programs'])==set(summary['programs'])==set(SOURCES),'program label inventory differs')
    ids=read(root/'identities.json');require(set(ids)=={'baseline','candidate'},'identity role set differs')
    reports={};corpora=[]
    for role,label in [('baseline','r2'),('candidate','n2')]:
        directory=root/label;record=read(directory/'proof.json');data=(directory/'minivec').read_bytes();insert.elf(data)
        image=(directory/'image-id.txt').read_text().strip();inspection=read(directory/'image-inspect.json')
        require(re.fullmatch(r'sha256:[0-9a-f]{64}',image) and len(inspection)==1 and inspection[0]['Id']==image and
                inspection[0]['Config']['Entrypoint']==['/minivec','--data','/data'] and inspection[0]['Config']['WorkingDir']=='/data','new actual image inspection differs')
        require(record==binding['programs'][label] and record['status']=='verified' and record['label']==label.upper() and record['source_commit']==SOURCES[label] and
                record['binary_sha256']==digest(data)==(directory/'binary-sha256.txt').read_text().split()[0] and record['image_id']==image and
                record['feature_flags']==core.FLAGS and record['new_pgo_builds']==1 and record['source_sha256']==prep['source_sha256'][label] and
                record['source_sanitizers_rerun'] is False and record['official_binary_identity_known'] is False and record['harness_commit']==commit and
                record['prepare_proof_sha256']==sha(root/'prepare-proof.json'),'new program provenance differs')
        require(record['prior_binary_sha256_for_comparison_only']==OLD[label] and record['matches_imported_prior_binary']==(digest(data)==OLD[label]),'old/new byte comparison mislabelled')
        train=training(directory,record['source_sha256']);corpora.append(train['training_manifest'])
        require(record['training_evidence_sha256']==sha(directory/'training-evidence.json'),'new training evidence unbound')
        gates=image_gates(root,repo,commit,label);expected=gates|{'original_root_docker_pgo':True,'six_training_oracles':True}
        require(record['checks']==expected and len(expected)==9,'fresh gate scope differs')
        item=ids[role]
        require(item=={'binary':label+'/minivec','binary_sha256':digest(data),'source_commit':SOURCES[label],'evidence_file':label+'/proof.json',
                      'evidence_sha256':sha(directory/'proof.json'),'evidence_binary_pointer':['binary_sha256'],'evidence_commit_pointer':['source_commit'],'environment':{}},'measured new program identity differs')
        observed={'label':label.upper(),'source_commit':SOURCES[label],'binary_sha256':digest(data),'image_id':image,'actual_gate_categories':9,
                  'same_as_prior_imported_bytes':digest(data)==OLD[label],'prior_binary_sha256':OLD[label]}
        require(summary['programs'][label]==observed,'summary new program identity differs')
        reports[label]=observed|{'actual_protocol_gate_groups':7,'source_sanitizers_rerun':False,'training':train}
    require(corpora[0]==corpora[1],'same-runner training corpus differs')
    return ids,reports


def audit(args):
    root,repo,commit=args.input.resolve(),args.repo.resolve(),args.commit
    require(commit==HARNESS_COMMIT,'reader is pinned to reviewed matched-build harness')
    files=core.verify_archive(root,args.archive.resolve(),args.artifact_sha256,args.artifact_bytes);core.manifest_tree(root)
    prep=read(root/'prepare-proof.json');binding=read(root/'binding-proof.json');summary=read(root/'summary.json')
    require(summary['status']=='passed' and summary['exit_code']==0 and summary['expected_pairs']==summary['completed_pairs']==8 and
            summary['new_pgo_builds_planned']==summary['new_pgo_builds_verified']==2 and summary['harness_commit']==commit and
            summary['source_sanitizers_rerun'] is False and summary['formal_submission'] is False and summary['automatic_adoption'] is False and
            summary['official_score'] is None and summary['decision']=='manual_review_required_no_automatic_adoption','matched result scope differs')
    contexts=source_contexts(root,repo,commit,prep);ids,programs=bind_programs(root,repo,commit,prep,binding,summary)
    local=control.reproduce_standard(repo,commit);reports={};negatives=[];hosts=[];tasksets=[];masks={};adverse={}
    for count in (1,2):
        data=read(root/f'measurements-{count}cpu.json');require(data['workloads']==[local['standard10k']],'full new SQL/oracle workload does not reproduce')
        report=verify_matched_measurements(data,count,('standard10k',),root,ids,{'harness_file_sha256':prep['harness_file_sha256']},local)
        report['extra_summary']=insert.extra_summary(data);reports[str(count)]=report
        claimed=summary['comparisons'][str(count)+'cpu'];adverse[str(count)]=insert.collector_default(report['extra_summary']['standard10k'],claimed)
        components=[]
        for pair in data['pairs']:
            row={k:pair[k] for k in ('pair_index','order')}
            for role in ('baseline','candidate'):
                phases={x['phase']:x for x in pair[role]['adapter']['phase_cgroups']};before,after=[counters(phases[k]['cpu.stat']) for k in ('before_ingest','after_ingest')]
                row[role]={k:after[k]-before[k] for k in ('usage_usec','user_usec','system_usec','throttled_usec')};require(all(x>=0 for x in row[role].values()),'negative ingest CPU components')
            components.append(row)
        require(components==claimed['ingest_cpu_components'],'collector user/system CPU arithmetic differs');report['ingest_cpu_components']=components
        for key in ('user_usec','system_usec','throttled_usec'):
            rows=[]
            for r in components:
                b,c=r['baseline'][key],r['candidate'][key];rows.append({'pair_index':r['pair_index'],'order':r['order'],'baseline':b,'candidate':c,
                    'baseline_over_candidate':b/c if c else None,'candidate_minus_baseline':c-b,'candidate_larger':c>b})
            report['extra_summary']['standard10k']['ingest_'+key]=highest.pair_summary(rows)
        hosts.append(data['host']);tasksets.append(data['taskset']);masks[count]=data['db_cpus']
        require(re.fullmatch('[0-9a-f]{64}',data['taskset']['sha256']),'taskset identity missing')
        for metric,value in report['extra_summary']['standard10k'].items():
            if value['candidate_larger_pairs']:negatives.append({'cpu_count':count,'metric':metric,**value})
        for phase,value in report['summary']['standard10k'].items():
            if value['candidate_slower_pairs']:negatives.append({'cpu_count':count,'phase':phase,**value})
    require(hosts[0]==hosts[1] and tasksets[0]==tasksets[1] and masks[1]==masks[2][:1],'same runner/tool/CPU selection differs')
    require(set(summary['comparisons'])=={'1cpu','2cpu'} and summary['any_joint_default_regression']==any(adverse.values()),'combined adverse summary differs')
    return {'status':'verified','verified_pairs':8,'new_root_pgo_builds':2,'harness_commit':commit,'artifact_sha256':args.artifact_sha256,'artifact_files':files,
        'contexts':contexts,'programs':programs,'workload_identity_audit':local['standard10k'],'measurements':reports,
        'all_negative_or_mixed_metrics':negatives,'joint_wall_cpu_default_regressions':adverse,'host':hosts[0],'actual_cpu_model':(root/'lscpu.txt').read_text(),
        'source_sanitizers_rerun':False,'automatic_adoption':False,'official_score':None,'score_floor_proven':False,
        'limitations':['R2/N2 are two newly built actual original-root images, not relabelled old acdd/5606; measured ELF hashes and image identities are explicit.',
        'Fresh protocol gates are seven groups per actual image/ELF, plus original Docker and six PGO oracle evidence. No new 18 source/root gate run or source sanitizer rerun is claimed.',
        'Same runner, original /src workdir, compiler/default flags and training corpus remove those previous differences; source-induced PGO feedback and whole-program code layout remain part of the candidate effect.',
        'Four AB/BA pairs per logical CPU at one seed, only standard10k. No EE, new scenarios, formal machine claim, score-floor guarantee or automatic adoption.',
        'First lifecycle wall is the measured stage/request sum through shutdown; labelled first CPU ends before shutdown. Ingest split has wall only; user/system CPU spans the full ingest boundary.',
        'Whole-cgroup totals include restart verification; process IO and device-accounting counters are distinct proxies, not official T/B/M. All adverse paired phases remain.',
        'All current standard SQL/oracle content is reproduced in Python; the executed harness checks queries 0/1/999 independently and all restart IDs/sampled vectors, not all 1000 against a separate oracle.',
        'Only gcda digests and six oracle outcomes are archived; no recovered profile function counts. This reader executes no database or compiler.']}


def main():
    p=argparse.ArgumentParser(description=__doc__)
    for name in ('input','archive','output'):p.add_argument('--'+name,type=Path,required=True)
    p.add_argument('--repo',type=Path,default=Path(__file__).resolve().parent/'seekdb');p.add_argument('--commit',required=True)
    p.add_argument('--artifact-sha256',required=True);p.add_argument('--artifact-bytes',type=int,required=True);args=p.parse_args()
    require(not args.output.exists() and not args.output.resolve().is_relative_to(args.input.resolve()),'refuse overwrite/evidence mutation')
    require(re.fullmatch('[0-9a-f]{40}',args.commit) and re.fullmatch('[0-9a-f]{64}',args.artifact_sha256),'full expected identities required')
    result=audit(args);args.output.write_text(json.dumps(result,ensure_ascii=False,indent=2,allow_nan=False)+'\n',encoding='utf8')
    print(json.dumps({'status':result['status'],'verified_pairs':result['verified_pairs'],'negative_metrics':len(result['all_negative_or_mixed_metrics']),'output':str(args.output)}))


def verify_matched_measurements(data, count, cases, programs, ids, proof, workloads):
    expected = plan(count)
    require(data.get('insert_copy_reference') is None and data.get('insert_thread_control') is False and data.get('matched_insert_roots') is True, 'matched root family differs')
    require(data['status'] == 'passed' and data['expected_pairs'] == data['completed_pairs'] == len(data['pairs']) == len(expected), 'measurement incomplete')
    require(data['plan'] == expected and [{k: p[k] for k in ('scenario', 'seed', 'pair_index', 'order')} for p in data['pairs']] == expected, 'measurement plan mismatch')
    require(data['query_mode_policy']=='exact','measurement mode is not exact')
    require(data['comparison_kind'] == 'whole_version_diagnostic' and data['official_score'] is None and data['official_binary_identity_known'] is False, 'scope mismatch')
    require(data['identity_record_sha256'] == sha(programs / 'identities.json'), 'identity JSON mismatch')
    require(data['workloads'] == [workloads[n] for n in cases], 'regenerated workload/oracle hash mismatch')
    require(data['db_cpu_count'] == count and len(set(data['db_cpus'])) == count and data['protection_only'] is False, 'CPU plan mismatch')
    require(set(data['db_cpus']).issubset(set(data['host']['driver_affinity'])), 'CPU selection outside inherited driver affinity')
    require(data['requested_limits'] == {'cpu_quota_us': count * 100000, 'cpu_period_us': 100000, 'memory_max': '2147483648', 'swap_max': '0'}, 'resource request mismatch')
    require(data['launcher_sha256'] == sha(programs / 'cgroup_exec'), 'actual launcher differs')
    seen = {}
    for path, h in data['tool_hashes'].items():
        names = [name for name in TOOLS if path.endswith('/' + name)]
        require(len(names) == 1 and names[0] not in seen, 'tool path inventory mismatch')
        name = names[0]; seen[name] = h; require(proof['harness_file_sha256'][name] == h, 'executed tool differs from Git proof')
    require(set(seen) == TOOLS, 'tool set incomplete')
    for role in ('baseline', 'candidate'):
        item = data['identities'][role]
        for key in ('binary_sha256', 'source_commit', 'evidence_sha256', 'environment'):
            require(item[key] == ids[role][key], 'measured role identity mismatch')
        require(item['environment'] == {}, 'unexpected runtime override')
    details, grouped, lifecycle_grouped = [], {}, {}
    for pair in data['pairs']:
        name = pair['scenario']; require(pair['all_responses_identical'] is True, 'output equivalence absent')
        b, c = pair['baseline'], pair['candidate']; detail = {k: pair[k] for k in ('scenario', 'seed', 'pair_index', 'order')}; detail['sides'] = {}
        for role, run in (('baseline', b), ('candidate', c)):
            g, adapter, policy = run['cgroup'], run['adapter'], run['thread_policy_observations']
            require(run['declared_environment'] == {} and run['effective_environment'] == {} and run['query_mode_policy']=='exact', 'run override/mode differs')
            modes = adapter['completed_request_modes']
            require(set(modes) == {'exact'} and modes['exact'] > 0 and modes['exact'] == adapter['completed_transport_requests'],
                    'actual transport request mode differs')
            require(not g['timeout'] and not g.get('request_timeout_observed') and not g.get('cleanup_kill_required') and not g.get('watchdog_error') and not any(g['oom_events_delta'].values()), 'timeout/OOM/process failure')
            for when in ('before', 'after'):
                require(g[when]['cpu.max'].split() == [str(count * 100000), '100000'], 'actual quota differs')
                require(g[when]['memory.max'] == '2147483648' and g[when]['memory.swap.max'] == '0', 'actual 2GiB/swap0 differs')
            for ancestor in g['ancestor_constraints']:
                cap = ancestor['memory.max']
                require(not isinstance(cap, str) or not cap.isdigit() or int(cap) >= 2147483648,
                        'ancestor memory constraint below 2GiB')
            require(not g['after']['cgroup.procs'].strip(), 'live DB remains')
            ready = adapter['ready_memberships']; require(len(ready) == (1 if name == 'wide768' else 2), 'ready/restart evidence missing')
            for item in ready:
                require(item['pid'] in item['members'] and item['driver_pid'] not in item['members'] and
                        item['actual_exe'] == data['identities'][role]['binary'] and item['runtime_environment'] == {} and cpus(item['cpus_allowed_list']) == set(data['db_cpus']), 'actual executable/cgroup/affinity mismatch')
            phases = adapter['phase_cgroups']; require(len(phases) == (14 if name == 'wide768' else 15 if name.startswith('spill_') else 8), 'phase observations missing')
            for phase in phases:
                require(phase['memory.max'] == '2147483648' and phase['memory.swap.max'] == '0', 'phase memory/swap cap differs')
                require(not phase.get('native_tasks_error') and not phase.get('task_read_errors') and phase['native_tasks'] and sum(t['main'] for t in phase['native_tasks']) == 1, 'native task evidence missing')
                require(all(cpus(t['cpus_allowed_list']) == set(data['db_cpus']) for t in phase['native_tasks']), 'native task affinity drift')
            before, after = counters(g['before']['cpu.stat']), counters(g['after']['cpu.stat'])
            require(g['resource_delta']['cpu_stat_delta'] == {k: v - before.get(k, 0) for k, v in after.items()} and
                    g['resource_delta']['memory_peak_bytes'] == int(g['after']['memory.peak']), 'resource arithmetic differs')
            ib, ia = io_counters(g['before']['io.stat']), io_counters(g['after']['io.stat'])
            require(g['resource_delta']['io_stat_delta'] == {dev: {k: v - ib.get(dev, {}).get(k, 0) for k, v in fields.items()} for dev, fields in ia.items()}, 'device IO counter arithmetic differs')
            require(policy['stderr_complete'] is True and policy['requested_query_threads'] == 'automatic', 'policy observations incomplete')
            logs = policy['fanout_log_lines']; wake = [x for x in logs if '(measured, median of 200 handshakes)' in x]
            require(len(wake) == len(ready), 'real startup calibration missing')
            marker = 'single-CPU affinity; adaptive query fanout disabled, startup calibration retained'
            require(not any(marker in x for x in logs), 'rejected affinity policy unexpectedly active')
            cpu_intervals = {}
            by_phase = {x['phase']: x for x in phases}
            for start, end in (('after_index_build', 'query_before_update'), ('after_restart', 'query_after_restart')):
                if start in by_phase and end in by_phase:
                    left, right = by_phase[start], by_phase[end]
                    old = {(t['tid'], t['starttime_ticks']): t['cpu_ticks'] for t in left['native_tasks']}
                    cpu_intervals[end] = {'start': start, 'end': end, 'cpu_usage_usec': counters(right['cpu.stat'])['usage_usec'] - counters(left['cpu.stat'])['usage_usec'],
                        'nonmain_cpu_ticks_delta': sum(t['cpu_ticks'] - old.get((t['tid'], t['starttime_ticks']), 0) for t in right['native_tasks'] if not t['main']),
                        'scope': 'Includes restart ID/vector/payload verification.' if start == 'after_restart' else 'Post-index snapshot through first query phase; excludes restart verification.',
                        'nonmain_scope': 'All nonmain native tasks, not exclusively a named query worker.'}
            detail['sides'][role] = {'resources': g['resource_delta'], 'policy': policy, 'cpu_intervals': cpu_intervals}
        if name == 'wide768':
            for run in (b, c):
                require(run['status'] == 'passed' and set(run['phases']) == LABELS, 'projection phase schema differs')
                for phase in run['phases'].values():
                    require(all(r['search_mode']=='exact' for r in phase['requests']), 'projection sent a non-exact request')
                    require(len(phase['requests']) == 3 and phase['independent_oracle'] and phase['wall_seconds'] == sum(r['seconds'] for r in phase['requests']), 'projection oracle/timer evidence missing')
            for label in LABELS:
                require([(r['response_sha256'], r['response_bytes']) for r in b['phases'][label]['requests']] == [(r['response_sha256'], r['response_bytes']) for r in c['phases'][label]['requests']], 'projection responses differ')
        else:
            require(b['response_sha256'] == c['response_sha256'], 'lifecycle responses differ')
            for run in (b, c):
                require(all(q['modes']==['exact']*len(q['per_request_seconds']) for q in run['query'].values()), 'query mode trace is not all exact')
                if name.startswith('spill_'):
                    require(run['real_spill_observed'] is True and run['correctness']['all_query_responses_independent_oracle'] is True and len(run['write_cycles']) == 4 and len(run['query']) == 6 and
                            all(len(q['per_request_seconds']) == (16 if name.endswith('q16') else 1) for q in run['query'].values()), 'spill independent oracle/counts missing')
                    require(run['correctness']['all_restarted_ids_checked'] == 5000 and run['correctness']['all_mutated_payloads_and_tombstones_checked'] == [0, 1, 7, 1007], 'spill restart verification missing')
                else:
                    require(set(run['query']) == {'query_before_update', 'query_after_restart'} and all(len(q['per_request_seconds']) == 1000 for q in run['query'].values()) and
                            run['correctness']['sampled_topk_oracle_queries'] == [0, 1, 999], 'resident oracle/counts missing')
                    rows = workloads[name]['rows']
                    require(run['correctness']['all_restarted_ids_checked'] == rows and run['correctness']['restarted_vector_ids_checked'] == [0, 1, rows // 2, rows - 1], 'resident restart verification missing')
        bv, cv = timings(b), timings(c); require(set(bv) == set(cv), 'phase timers differ')
        for phase in bv:
            require(math.isfinite(bv[phase]) and math.isfinite(cv[phase]) and bv[phase] >= 0 and cv[phase] > 0, 'invalid measured timer')
            grouped.setdefault(name, {}).setdefault(phase, []).append({'pair_index': pair['pair_index'], 'order': pair['order'], 'baseline_seconds': bv[phase], 'candidate_seconds': cv[phase], 'baseline_over_candidate': bv[phase] / cv[phase], 'candidate_slower': cv[phase] > bv[phase]})
        bl, cl = lifecycle_timings(b), lifecycle_timings(c)
        require(set(bl) == set(cl), 'derived lifecycle boundaries differ')
        for phase in bl:
            require(math.isfinite(bl[phase]) and math.isfinite(cl[phase]) and bl[phase] >= 0 and cl[phase] > 0,
                    'invalid derived lifecycle timer')
            lifecycle_grouped.setdefault(name, {}).setdefault(phase, []).append({'pair_index': pair['pair_index'],
                'order': pair['order'], 'baseline_seconds': bl[phase], 'candidate_seconds': cl[phase],
                'baseline_over_candidate': bl[phase] / cl[phase], 'candidate_slower': cl[phase] > bl[phase]})
        details.append(detail)
    summary = {name: {phase: {'raw_pairs': rows, 'median_baseline_over_candidate': median(r['baseline_over_candidate'] for r in rows), 'candidate_slower_pairs': sum(r['candidate_slower'] for r in rows)} for phase, rows in phases.items()} for name, phases in grouped.items()}
    require(summary == data['summary'], 'independent summary arithmetic differs')
    lifecycle_summary = {name: {phase: {'raw_pairs': rows, 'median_baseline_over_candidate': median(r['baseline_over_candidate'] for r in rows),
        'candidate_slower_pairs': sum(r['candidate_slower'] for r in rows)} for phase, rows in phases.items()} for name, phases in lifecycle_grouped.items()}
    return {'verified_pairs': len(expected), 'summary': summary, 'derived_lifecycle_summary': lifecycle_summary,
            'lifecycle_scope': 'First lifetime sums startup, all measured requests and first shutdown; excludes restart and its verification/query/shutdown. Restart-inclusive totals are shown separately. These are sums of measured request/lifecycle timers, not end-to-end wall time including oracle work and telemetry gaps. Wide projection has no restart. No first-lifetime cgroup CPU total is inferred across unavailable shutdown boundaries.',
            'resources_and_policy': details,
            'host': data['host'], 'db_cpus': data['db_cpus'], 'ancestor_constraints': data['pairs'][0]['baseline']['cgroup']['ancestor_constraints']}

if __name__ == '__main__': main()
