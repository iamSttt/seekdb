"""Independent actual-root20 JSONL cursor audit; no DB/compiler execution.

Reuses the archived root20 identity/resource/oracle reader. Checksum and INSERT
ownership checks are regression gates, not adopted runtime optimizations.
"""
import argparse,ast,json,math,re
from pathlib import Path
import analyze_crc_root as core
import analyze_highest_compare as stats
import analyze_insert_copy_root as insert
from analyze_crc_root import require,sha,read,blob,digest,git

R_SOURCE='33a52a7dd4426af059ec2334b7c93a07c38c93c9'
MAIN_SHA='9bd82108aa918edf61a7571f8ca31cc6a245a9517c7812b2d66e9e6187ce7875'
CURSOR_GATE='actual_image_jsonl_cursor_frames'
GATES=core.GATES|{'insert_owned_copy_normal_and_sanitized',CURSOR_GATE}
CASES=('fragment_writer_1','fragment_writer_7','fragment_writer_4096','fragment_writer_65536',
 'large_64k_writer_4096','large_64k_writer_65536','large_256k_writer_4096','large_256k_writer_65536',
 'vector_insert_writer_65536','crlf_split','eof_valid_unterminated_no_execute','eof_truncated_json_no_execute',
 'duplicate_keys_no_execute','malformed_frame_no_execute','shutdown_same_write_discards_tail','escaped_newline')
JSON_CASES=('typed_rows','row_encoding_reuse','transactions_and_invalid_input','crash_recovery',
 'mode_switch','fragmented_jsonl','parallel_insert_errors','legacy_mode')
TOPK='PASS JSONL TopK against exact float32 oracle, including ties, filters and rollback'
MODEL_SCOPE='pure framing model; no database execution or actual read-chunk measurement'

def runtime_guard(repo,commit):
    maps=[]
    for revision in (R_SOURCE,commit):
        names=git(repo,'ls-tree','-r','--name-only',revision,'--','minivec/src').decode().splitlines()
        maps.append({p:digest(blob(repo,revision,p)) for p in names})
    require(set(maps[0])==set(maps[1]),'cursor runtime inventory changed')
    changed=sorted(p for p in maps[0] if maps[0][p]!=maps[1][p])
    require(changed==['minivec/src/main.cpp'] and maps[1][changed[0]]==MAIN_SHA,'candidate is not the reviewed cursor-only runtime')
    for p in ('Dockerfile','.dockerignore','minivec/tools/pgo/train.cpp','minivec/tools/pgo/run-training.sh'):
        require(blob(repo,R_SOURCE,p)==blob(repo,commit,p),'build/PGO policy changed')
    require(git(repo,'ls-tree','-r',R_SOURCE,'--','minivec/third_party')==
            git(repo,'ls-tree','-r',commit,'--','minivec/third_party'),'third-party build inputs changed')
    return {'reference_source_commit':R_SOURCE,'only_changed_runtime_files':changed,
            'reviewed_main_sha256':MAIN_SHA,'db_and_exec_retained':True}

def harness_inventory(repo,commit,proof):
    tree=ast.parse(blob(repo,commit,'minivec/tools/prepare_small_compute.py'))
    declarations=[n for n in ast.walk(tree) if isinstance(n,ast.Assign) and
                  any(isinstance(t,ast.Name) and t.id=='tool_paths' for t in n.targets)]
    require(len(declarations)==1,'reviewed full harness inventory absent')
    paths=ast.literal_eval(declarations[0].value)
    require(len(paths)==len(set(paths)) and set(paths)==set(proof['harness_file_sha256']),
            'full imported harness inventory differs')

def cursor_gate(root,repo,commit,candidate):
    tree=ast.parse(blob(repo,commit,'minivec/tests/test_jsonl_cursor.py'))
    declarations=[n for n in tree.body if isinstance(n,ast.Assign) and
                  any(isinstance(t,ast.Name) and t.id=='EXPECTED_CASES' for t in n.targets)]
    require(len(declarations)==1 and ast.literal_eval(declarations[0].value)==CASES,'cursor test inventory differs from reviewed 16 cases')
    result=read(root/'image-binary-jsonl-cursor.json')
    require(result['status']=='passed' and result['binary_sha256']==candidate and
            result['scope']=='actual binary protocol/persistence correctness' and
            result['fragmentation_scope']=='writer chunks; kernel read boundaries are not controlled or measured',
            'actual cursor framing result identity/scope differs')
    checks=result['checks']
    require(len(checks)==len(CASES) and [x['name'] for x in checks]==list(CASES) and
            all(x['status']=='passed' for x in checks),'cursor16 failed or incomplete')
    for item in checks:
        name=item['name']
        if name.startswith('fragment_writer_'):
            require(item['writer_chunk_bytes']==int(name.rsplit('_',1)[1]) and item['payload_bytes']>0 and
                    item['tail_waited_for_newline'] is True,'fragment-tail evidence differs')
        elif name.startswith('large_'):
            _,size,_,chunk=name.split('_')
            require(item['writer_chunk_bytes']==int(chunk) and item['payload_bytes']>int(size[:-1])*1024 and
                    item['kind']=='valid INSERT with block-comment padding','large-frame evidence differs')
        elif name=='vector_insert_writer_65536':
            require(item['writer_chunk_bytes']==65536 and item['rows']==100 and item['dimension']==128 and
                    item['payload_bytes']>65536,'vector-frame evidence differs')
        elif name=='crlf_split':require(item['split_between_cr_and_lf'] is True,'CRLF evidence absent')
        elif name.startswith('eof_'):
            require(item['restart_checked_persistent_rows'] is True and item['tail_executed'] is False,'EOF persistence evidence absent')
        elif name=='duplicate_keys_no_execute':
            require(item['duplicate_spellings']==['literal','escaped-equivalent'] and item['mutations']==0,'duplicate-key oracle differs')
        elif name=='malformed_frame_no_execute':
            require(item['invalid_shapes']==['missing_brace','trailing_garbage','empty_frame'] and item['mutations']==0,'malformed oracle differs')
        elif name=='shutdown_same_write_discards_tail':
            require(item['single_writer_send_bytes']>0 and item['restart_checked_persistent_rows'] is True and
                    item['read_coalescing_not_assumed'] is True,'shutdown tail evidence absent')
        elif name=='escaped_newline':require(item['writer_chunk_bytes']==item['physical_newlines']==1,'escaped newline oracle differs')
        else:raise ValueError('unreviewed cursor case')
    require([line for line in (root/'image-binary-jsonl-cursor.log').read_text().splitlines() if line.startswith('PASS ')]==
            ['PASS '+name for name in CASES],'cursor actual log incomplete')
    model=result['mechanism_model']
    require(model['scope']==MODEL_SCOPE and model['status']=='passed' and model['not_a_performance_measurement'] is True,
            'pure framing model mislabeled as database evidence')
    expected={('mixed',n) for n in (1,7,4096,65536)}|{('long',n) for n in (4096,65536)}
    require(len(model['cases'])==6 and {(x['name'],x['model_chunk_bytes']) for x in model['cases']}==expected,'model case inventory differs')
    for row in model['cases']:
        require(row['cursor_scanned_bytes']==row['payload_bytes']<=row['reference_scanned_bytes'] and
                row['payload_bytes']==(268 if row['name']=='mixed' else 262145),'model arithmetic differs')
    return {'actual_cases':16,'binary_sha256':candidate,'actual_result_sha256':sha(root/'image-binary-jsonl-cursor.json'),
            'writer_chunks_not_kernel_reads':True,'model_scope':MODEL_SCOPE,
            'scope':'The Git-bound actual-binary harness checked responses/persistence. Raw response bodies are not archived for replay; no actual scanned-byte or read-chunk measurement is inferred.'}

def supplemental_gates(root,gates):
    counts={}
    for mode in ('normal','sanitized'):
        matches=re.findall(r'^PASS INSERT owned-copy (\d+) checks$',(root/('insert-owned-copy-'+mode+'.log')).read_text(),re.M)
        require(len(matches)==1 and int(matches[0])==952,'current ownership regression incomplete')
        counts[mode]=int(matches[0])
    require(counts==gates['insert_owned_copy_checks'],'ownership count binding differs')
    require([s for s in (root/'image-binary-json.log').read_text().splitlines() if s.startswith('PASS ')]==
            ['PASS '+s for s in JSON_CASES],'actual ELF JSON8 evidence incomplete')
    for name in ('image-binary-topk.log','image-binary-topk-parallel.log'):
        require((root/name).read_text().strip()==TOPK,'actual ELF exact TopK evidence incomplete')
    events=read(root/'image-interactive/events.json')
    require(len(events)==20 and sum(x.get('fragmented_utf8_request') is True for x in events)==1 and
            sum(x.get('exit_before_stdin_close') is True for x in events)==2 and
            sum(x.get('response',{}).get('ok') is False for x in events)==3,'actual image interactive evidence incomplete')
    return counts

def audit(args):
    root,repo,commit=args.input.resolve(),args.repo.resolve(),args.commit
    runtime=runtime_guard(repo,commit)
    proof=read(root/'small-compute-root/programs/root-proof.json');harness_inventory(repo,commit,proof)
    gates=read(root/'root-gates-summary.json')
    require(set(gates['checks'])==GATES and all(v is True for v in gates['checks'].values()),'complete current19 root gates differ')
    ownership=supplemental_gates(root,gates)
    framing=cursor_gate(root,repo,commit,gates['image_binary_sha256'])
    # The underlying reader's checks are unchanged, apart from supplying this
    # explicitly reviewed gate inventory. No archive/source is rewritten.
    previous_gates=core.GATES
    insert.clear_generator_modules()
    try:
        core.GATES=GATES
        result=core.audit(args)
    finally:
        core.GATES=previous_gates
        insert.clear_generator_modules()
    first=None;extra_negative=[]
    for count in (1,2):
        data=read(root/f'small-compute-root/measurements-{count}cpu.json')
        require(data.get('insert_copy_reference') is None and data.get('insert_thread_control') is False and
                data.get('matched_insert_roots') is False,'wrong measurement family masquerades as root20')
        observed=(data['host'],data['taskset'],data['launcher_sha256'])
        require(first is None or observed==first,'1/2 CPU host/tool changed');first=observed
        require(re.fullmatch('[0-9a-f]{64}',data['taskset']['sha256']),'taskset identity missing')
        if count==1:one_cpu=data['db_cpus']
        else:require(one_cpu==data['db_cpus'][:1],'CPU selections are not nested')
        for pair in data['pairs']:
            for role in ('baseline','candidate'):
                require(pair[role]['effective_environment']=={},'unexpected effective runtime override')
        extra=stats.summarize_extra(data);result['measurements'][str(count)]['extra_summary']=extra
        for scenario,metrics in extra.items():
            for name,entry in metrics.items():
                if entry['candidate_larger_pairs']:extra_negative.append({'cpu_count':count,'scenario':scenario,'metric':name,**entry})
    result['candidate_kind']='jsonl_input_newline_cursor'
    result['runtime_delta_audit']=runtime;result['cursor_framing_gate']=framing
    result['insert_ownership_regression_checks']=ownership
    result['checksum_and_persistence_regression_checks']=result.pop('crc_checks')
    result['checksum_runtime_optimization_adopted']=False
    result['insert_copy_runtime_optimization_adopted']=False
    result['all_negative_or_mixed_resource_and_combined_metrics']=extra_negative
    result['limitations']=[x for x in result['limitations'] if 'pure CRC instruction-cost isolation' not in x]
    result['limitations'] += [
      'This candidate changes only the reviewed main.cpp JSONL newline-search cursor. db.cpp/exec.cpp remain R. CRC header and INSERT ownership tests are regression checks, not runtime adoption.',
      'Root20 compares a new actual-root PGO program with historical imported R/acdd. It is not the two-new-build matched INSERT experiment; compiler/PGO/layout effects remain part of the whole-version contrast.',
      '19 current root gate groups plus root20 and 18 persistence compatibility checks are explicit. Historical correctness claims cannot replace missing current artifact outputs.',
      'The cursor test controls writer chunk sizes, not kernel read boundaries. Pure framing-model byte counts are not actual-runtime counters or performance measurements.',
      'Normal root20 has seven resident phase snapshots and no before_ingest snapshot. No BEGIN/INSERT/COMMIT CPU subtotals are inferred. Resource totals and available query intervals remain separately labelled.'
    ]
    return result

def main():
    p=argparse.ArgumentParser(description=__doc__)
    for name in ('input','archive','output'):p.add_argument('--'+name,type=Path,required=True)
    p.add_argument('--repo',type=Path,default=Path(__file__).resolve().parent/'seekdb')
    p.add_argument('--commit',required=True);p.add_argument('--artifact-sha256',required=True);p.add_argument('--artifact-bytes',type=int,required=True)
    args=p.parse_args();require(not args.output.exists() and not args.output.resolve().is_relative_to(args.input.resolve()),'refuse evidence/output overwrite')
    require(re.fullmatch('[0-9a-f]{40}',args.commit) and re.fullmatch('[0-9a-f]{64}',args.artifact_sha256),'full expected identities required')
    result=audit(args);args.output.write_text(json.dumps(result,ensure_ascii=False,indent=2,allow_nan=False)+'\n',encoding='utf8')
    print(json.dumps({'status':result['status'],'pairs':result['verified_pairs'],'root_gate_groups':len(result['root_gates']),
                     'cursor_actual_cases':result['cursor_framing_gate']['actual_cases'],'output':str(args.output)}))

if __name__=='__main__':main()
