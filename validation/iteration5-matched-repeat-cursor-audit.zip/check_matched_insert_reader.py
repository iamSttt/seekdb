"""Pure-Python matched-reader controls; no database, Docker or compiler run."""
import ast
import copy
import json
from pathlib import Path
import shutil
import sys
import tempfile
from types import SimpleNamespace
sys.dont_write_bytecode = True
import analyze_matched_insert_roots as r

W = Path(__file__).resolve().parent
repo = W / 'seekdb'
checks = []

def need(value):
    if not value: raise AssertionError('reader preflight assertion failed')

def check(name, fn):
    fn(); checks.append({'name': name, 'status': 'passed'})

def reject(name, fn):
    try: fn()
    except (ValueError, KeyError, FileNotFoundError):
        checks.append({'name': name, 'status': 'passed', 'expected_rejection': True})
    else: raise AssertionError('invalid evidence accepted: ' + name)

check('reader_AST', lambda: ast.parse((W / 'analyze_matched_insert_roots.py').read_text(encoding='utf8')))
for count in (1, 2):
    p = r.plan(count)
    check(str(count) + 'cpu_exact_four_balanced_pairs', lambda p=p: need(len(p) == 4 and
          len({x['pair_index'] for x in p}) == 4 and {x['scenario'] for x in p} == {'standard10k'} and
          {x['seed'] for x in p} == {7319} and sum(x['order'] == ['baseline', 'candidate'] for x in p) == 2))
for bad in (0, 3, True):
    reject('unsupported_CPU_' + str(bad), lambda bad=bad: r.plan(bad))
reject('wrong_harness_pin', lambda: r.audit(SimpleNamespace(input=W, repo=repo, commit=r.SOURCES['n2'])))
reject('missing_new_artifact', lambda: r.audit(SimpleNamespace(input=W/'absent-matched-root', repo=repo,
       commit=r.HARNESS_COMMIT, archive=W/'absent-matched-root.zip', artifact_sha256='0'*64, artifact_bytes=1)))
prior = W / 'performance/insert-copy-7554753'
old = r.read(prior/'insert-copy-root/retained-1cpu.json')
reject('old_24pair_family_cannot_be_matched', lambda: r.verify_matched_measurements(old, 1, ('standard10k',), W, {}, {}, {}))
old_control = r.read(W/'performance/insert-thread-control-33a52a7/measurements.json')
reject('old_thread_control_cannot_be_matched', lambda: r.verify_matched_measurements(old_control, 1, ('standard10k',), W, {}, {}, {}))

# Existing context exports are byte-checked against their exact Git sources.
# The local preparation fixture reconstructs the new committed tool inventory;
# it is not a CI preparation result and is never persisted as one.
context = W/'matched-root-context-preflight'
prep = r.read(context/'prepare-proof.json')
tree = ast.parse(r.blob(repo, r.HARNESS_COMMIT, 'minivec/tools/prepare_matched_insert_roots.py'))
paths = ast.literal_eval(next(n.value for n in tree.body if isinstance(n, ast.Assign) and
    any(isinstance(t, ast.Name) and t.id == 'TOOL_PATHS' for t in n.targets)))
inventory = r.git(repo, 'ls-tree', '-r', '--name-only', r.HARNESS_COMMIT, '--', *paths).decode().splitlines()
prep.update(harness_commit=r.HARNESS_COMMIT, harness_matches_git=True,
            harness_file_sha256={p:r.digest(r.blob(repo,r.HARNESS_COMMIT,p)) for p in inventory})
observed = r.source_contexts(context, repo, r.HARNESS_COMMIT, prep)
check('actual_Git_contexts_only_exec_diff', lambda: need(observed['only_changed_build_input']=='minivec/src/exec.cpp'))
bad = copy.deepcopy(prep); bad['source_sha256']['r2']['Dockerfile'] = '0'*64
reject('wrong_context_digest', lambda: r.source_contexts(context, repo, r.HARNESS_COMMIT, bad))
bad = copy.deepcopy(prep); del bad['harness_file_sha256']['minivec/tools/small_compute.py']
reject('missing_harness_Git_input', lambda: r.source_contexts(context, repo, r.HARNESS_COMMIT, bad))

sys.path.insert(0, str(repo/'minivec/tools'))
from prepare_matched_insert_roots import training_evidence
with tempfile.TemporaryDirectory(prefix='matched-reader-preflight-') as td:
    out = Path(td)
    shutil.copyfile(prior/'docker-build.log', out/'docker-build.log')
    source = r.read(prior/'insert-copy-root/programs/root-proof.json')['root_input_sha256']
    evidence = training_evidence(out/'docker-build.log', source)
    (out/'training-evidence.json').write_text(json.dumps(evidence),encoding='utf8')
    actual = r.training(out,source)
    check('archived_log_six_oracles_six_profiles_replay', lambda: need(len(actual['oracle_records'])==6 and
          len(actual['profile_sha256_from_build_log'])==6))
    text = (out/'docker-build.log').read_text(encoding='utf8')
    lines = text.splitlines(keepends=True)
    oracle = next(i for i,line in enumerate(lines) if '"actual_file"' in line and 'responses-' in line)
    (out/'docker-build.log').write_text(''.join(lines[:oracle]+lines[oracle+1:]),encoding='utf8')
    reject('missing_training_oracle', lambda:r.training(out,source))
    (out/'docker-build.log').write_text(text+lines[oracle],encoding='utf8')
    reject('duplicate_training_oracle', lambda:r.training(out,source))
    (out/'docker-build.log').write_text(text,encoding='utf8')
    profile = next(line for line in lines if '/pgo/minivec-' in line and '.gcda' in line and
                   r.re.search(r'[0-9a-f]{64}\s+/pgo/',line))
    (out/'docker-build.log').write_text(text+profile,encoding='utf8')
    reject('duplicate_profile_record', lambda:r.training(out,source))
    (out/'docker-build.log').write_text(text,encoding='utf8')
    bad = copy.deepcopy(evidence); bad['training_manifest_sha256']='0'*64
    (out/'training-evidence.json').write_text(json.dumps(bad),encoding='utf8')
    reject('unbound_training_evidence', lambda:r.training(out,source))

local = r.control.reproduce_standard(repo,r.HARNESS_COMMIT)
check('committed_workload_full_SQL_oracle_matches_prior',lambda:need([local['standard10k']]==old['workloads'][:1]))
result={'status':'passed','check_count':len(checks),'checks':checks,'database_runs':0,'compiler_runs':0,
        'actual_new_artifact_verified':False,'harness_commit':r.HARNESS_COMMIT,'source_commits':r.SOURCES,
        'reader_sha256':r.sha(W/'analyze_matched_insert_roots.py'),
        'scope':'Pure-Python reader controls, exact Git source contexts, historical build-log replay and workload regeneration. No new build or performance result.'}
(W/'matched-insert-reader-preflight.json').write_text(json.dumps(result,indent=2)+'\n',encoding='utf8')
print(json.dumps({k:result[k] for k in ('status','check_count','database_runs','actual_new_artifact_verified','reader_sha256')}))
