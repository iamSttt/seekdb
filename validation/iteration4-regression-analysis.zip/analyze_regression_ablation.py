#!/usr/bin/env python3
"""Read-only audit of a complete138-pair PGO ablation artifact.

No output is written until all integrity/source/binary/oracle checks pass.
Bootstrap summaries are predeclared descriptive secondary evidence, conditional
on these fixed workloads, one build per role and one shared host; not p-values.
"""
import argparse
from collections import Counter, defaultdict
import hashlib
import json
import math
from pathlib import Path
import random
import re
import shlex
from statistics import median

import analyze_retained_final as shared

HERE = Path(__file__).resolve().parent
BASELINE = 'e020fdeb67dd8b64b77f0f8c2905f137f0112bba'
SEEDS = (7319, 8911, 13337)
ROLES = ('baseline', 'equality', 'dom')
CONTRASTS = ('equality', 'dom', 'aa')
CASES = ('standard10k', 'resident30k', 'filter60k', 'many16', 'spill_compound', 'spill_high', 'wide128', 'wide768')
LONG = {'standard10k', 'resident30k', 'filter60k'}
AA_CASES = {'resident30k', 'filter60k', 'many16'}
PROJECTIONS = {'many16': (8192, 16, 256), 'wide128': (1024, 128, 96), 'wide768': (1024, 768, 96)}
FLAGS = {role: ['-DMVDB_ENABLE_SPILL_FILTER', '-DMVDB_ENABLE_TYPED_JSON', '-DMVDB_TYPED_WIDE_VECTOR_ONLY', '-DMVDB_MULTI_POSTING_REUSE_ONLY'] +
         ([] if role == 'baseline' else ['-DMVDB_ENABLE_EQUALITY_FASTPATH'] if role == 'equality' else ['-DMVDB_ENABLE_DOM_ROW_RESERVE']) for role in ROLES}
COMPILER = 'gcc:13.3.0-bookworm@sha256:1d71f0f3450214bef38fe09e6f610fb6cca90cf97b43f4ce845bfc32a4168818'
COMMON = '-O3 -std=c++17 -fno-math-errno -ffunction-sections -fdata-sections -Wl,--gc-sections -static -pthread -Isrc'
ARCHIVE = ('Dockerfile', '.dockerignore', 'minivec/src', 'minivec/third_party', 'minivec/tests', 'minivec/tools', 'protocol_check')
MODULES = ('benchmark_iteration.py', 'benchmark_report_matrix.py', 'benchmark_projection.py', 'benchmark_filter_repeat.py')
BOOTSTRAP_REPLICATES = 2000
BOOTSTRAP_SEED = 2026111307
require, read, sha, child = shared.require, shared.read, shared.sha, shared.child


def subset(files, prefix):
    return {n[len(prefix):]: value for n, value in files.items() if n.startswith(prefix)}


def hash_map(files):
    return {n: hashlib.sha256(value).hexdigest() for n, value in files.items()}


def audit_manifest(root):
    manifest = read(child(root, 'hashes.json'))
    require(type(manifest['artifacts']) is list and manifest['artifacts'], 'missing manifest entries')
    entries = {}
    for item in manifest['artifacts']:
        name = item['path']; require(name not in entries and name != 'hashes.json', 'duplicate/self manifest entry')
        path = child(root, name); shared.integer(item['bytes']); shared.hash_ok(item['sha256'])
        require(path.stat().st_size == item['bytes'] and sha(path) == item['sha256'], 'artifact size/hash changed: ' + name)
        entries[name] = item['sha256']
    require({p.relative_to(root).as_posix() for p in root.rglob('*') if p.is_file()} == set(entries) | {'hashes.json'}, 'manifest/file inventory differs')
    for name in ('build-input.json', 'context.json', 'correctness.json', 'measurements.json', 'summary.json', 'run-status.json', 'stage.txt', 'unit/passed.tsv'):
        require(name in entries, 'required evidence absent from manifest: ' + name)
    return entries


def expected_dockerfile(original, flags):
    original = original.decode('utf-8').replace('\r\n', '\n')
    needle = "flags='" + COMMON + "'"
    generate = 'g++ $flags -fprofile-generate=/pgo -fprofile-update=atomic src/*.cpp -o /minivec;'
    effective = 'flags="$flags $FEATURE_FLAGS";'
    continuation = ' ' + chr(92) + '\n'
    require(original.count(needle) == original.count(generate) == original.count(effective) == original.count('strip /minivec;') == 1, 'Dockerfile anchors changed')
    require('FROM ' + COMPILER + ' AS build' in original.splitlines(), 'compiler pin mismatch')
    proof = continuation + '         cp /minivec /training/instrumented-minivec;' + continuation + '         sha256sum /minivec > /training/instrumented-binary-sha256.txt;'
    layout = 'cp /minivec /training/unstripped-minivec;' + continuation + '    nm -nSC /minivec > /training/symbols.txt;' + continuation + '    objdump -h /minivec > /training/sections.txt;' + continuation + '    strip /minivec;'
    return original.replace(needle, "flags='" + COMMON + ' ' + ' '.join(flags) + "'").replace(generate, generate + proof).replace(
        effective, effective + continuation + '    printf "%s\\n" "$flags" > /training/effective-flags.txt;').replace('strip /minivec;', layout).encode()


def tree_hash(root):
    return {p.relative_to(root).as_posix(): sha(p) for p in sorted(root.rglob('*')) if p.is_file()}


def prefix_manifest(path, prefix):
    result = {}
    for line in path.read_text(encoding='utf-8').splitlines():
        match = re.fullmatch(r'([0-9a-f]{64}) [ *](.+)', line)
        require(match is not None and match[2].startswith(prefix), 'invalid source/profile manifest')
        name = match[2][len(prefix):]; require(name and name not in result, 'duplicate manifest path'); result[name] = match[1]
    require(result, 'empty source/profile manifest'); return result


def audit_builds(root, candidate, source, inputs, context):
    require(re.fullmatch('[0-9a-f]{40}', candidate or ''), 'full expected candidate commit required')
    require(inputs['baseline_commit'] == context['baseline_commit'] == BASELINE and inputs['candidate_commit'] == context['candidate_commit'] ==
            inputs['harness_commit'] == context['harness_commit'] == candidate, 'baseline/candidate/harness commit mismatch')
    require(inputs['compiler_image'] == context['compiler_image'] == COMPILER, 'compiler mismatch')
    require(context['profile_generate_flags'] == ['-fprofile-generate=/pgo', '-fprofile-update=atomic'] and
            context['profile_use_flags'] == ['-fprofile-use=/pgo', '-Werror=missing-profile', '-Werror=coverage-mismatch'], 'profile matching flags differ')
    require(set(inputs['roles']) == set(context['profile_source_proof']) == set(ROLES), 'PGO roles differ')
    snapshots = {side: source.files(commit, ARCHIVE) for side, commit in (('baseline', BASELINE), ('candidate', candidate))}
    require(inputs['snapshot_files'] == {side: hash_map(files) for side, files in snapshots.items()}, 'Git archive snapshot set/content differs')
    for role in ROLES:
        record, proof = inputs['roles'][role], context['profile_source_proof'][role]
        snapshot_role = 'baseline' if role == 'baseline' else 'candidate'
        files = snapshots[snapshot_role]; prefix = role + '-pgo/'
        require(record['snapshot'] == snapshot_role and record['source_commit'] == proof['source_commit'] == (BASELINE if role == 'baseline' else candidate), 'role source mismatch')
        require(record['feature_flags'] == proof['feature_flags'] == FLAGS[role] and record['root_feature_flags_override'] == proof['root_feature_flags_override'] == '', 'role flags contaminated')
        expected_source = hash_map(subset(files, 'minivec/src/')); expected_third = hash_map(subset(files, 'minivec/third_party/'))
        require(record['engine_source'] == proof['source_sha256'] == tree_hash(root / prefix / 'built-source') == expected_source, 'actual/source/Git engine mismatch')
        require(record['third_party'] == tree_hash(root / prefix / 'built-third-party') == expected_third, 'actual third party mismatch')
        require(record['production_dockerfile_sha256'] == hashlib.sha256(files['Dockerfile']).hexdigest() and
                record['dockerignore_sha256'] == hashlib.sha256(files['.dockerignore']).hexdigest(), 'production build input mismatch')
        build = child(root, 'build-input/Dockerfile.' + role)
        require(build.read_bytes() == expected_dockerfile(files['Dockerfile'], FLAGS[role]) and sha(build) == record['build_dockerfile_sha256'] == proof['build_dockerfile_sha256'], 'temporary Dockerfile differs beyond reviewed proof/flags')
        training = root / prefix / 'training'
        expected_training = {n: hashlib.sha256(files['minivec/tools/pgo/' + n]).hexdigest() for n in ('train.cpp', 'run-training.sh')}
        require(expected_training == record['training_source'] == proof['training_source_sha256'] == {n: sha(training / n) for n in expected_training}, 'training source differs')
        effective = child(root, prefix + 'training/effective-flags.txt')
        require(shlex.split(effective.read_text()) == proof['effective_compiler_flags'] == shlex.split(COMMON) + FLAGS[role] and sha(effective) == proof['effective_flags_sha256'], 'actual compiler flag mismatch')
        for filename, key in (('minivec', 'binary_sha256'), ('training/instrumented-minivec', 'instrumented_binary_sha256'), ('training/unstripped-minivec', 'unstripped_binary_sha256')):
            require(sha(child(root, prefix + filename)) == proof[key], 'actual binary checksum differs: ' + role + '/' + filename)
        require(prefix_manifest(training / 'instrumented-binary-sha256.txt', '/') == {'minivec': proof['instrumented_binary_sha256']}, 'instrumented binary manifest differs')
        binary_line = shared.checksum_text(child(root, prefix + 'binary-sha256.txt'))
        require(len(binary_line) == 1 and next(iter(binary_line.values())) == proof['binary_sha256'] and next(iter(binary_line)).replace('\\', '/').endswith('/' + role + '-pgo/minivec'), 'runtime binary manifest differs')
        image = read(child(root, prefix + 'image.json')); require(len(image) == 1 and shared.image_id(image[0]['Id']) == proof['image_id'], 'built image differs')
        cost = read(child(root, prefix + 'build-cost.json'))
        require(cost['status'] == 'passed' and cost['pgo_enabled'] is True and type(cost['nanoseconds']) is int and cost['nanoseconds'] > 0, 'build failed or missing cost record')
        child(root, prefix + 'build.log')
        profiles = tree_hash(training / 'profile-data')
        require(profiles == proof['profile_sha256'] == prefix_manifest(training / 'profile-sha256.txt', '/pgo/') and
                len(profiles) == sum(n.endswith('.cpp') for n in expected_source) and all(n.endswith('.gcda') for n in profiles), 'own-source/profile proof mismatch')
        corpus = tree_hash(training / 'corpus')
        require(corpus == proof['training_corpus_sha256'] == prefix_manifest(training / 'corpus-sha256.txt', '/training/corpus/'), 'training corpus differs')
        responses = {p.name: sha(p) for p in training.glob('responses-*.jsonl')}
        oracle = [json.loads(line) for line in (training / 'verification.jsonl').read_text().splitlines()]
        require(oracle == proof['training_oracle'] and len(oracle) == len(responses) == 6 and responses == proof['training_response_sha256'] and
                all(v['status'] == 'passed' and type(v['responses']) is int and v['responses'] > 0 for v in oracle) and
                {v['actual_file'] for v in oracle} == set(responses), 'training oracle/response proof incomplete')
        require(proof['layout_sha256'] == {n: sha(child(root, prefix + 'training/' + n)) for n in ('symbols.txt', 'sections.txt')}, 'layout diagnostics differ')
    require(context['candidate_sources_identical'] is True and context['training_corpora_equal'] is True and
            all(context['profile_source_proof'][r]['training_corpus_sha256'] == context['profile_source_proof']['baseline']['training_corpus_sha256'] for r in ROLES), 'candidate/corpus equality assertion false')
    differences = {part: [n for n in sorted(set(inputs['roles']['baseline'][part]) | set(inputs['roles']['equality'][part]))
                         if inputs['roles']['baseline'][part].get(n) != inputs['roles']['equality'][part].get(n)] for part in ('engine_source', 'third_party', 'training_source')}
    require(inputs['source_differences'] == context['source_differences'] == differences, 'source difference metadata differs')
    return snapshots


def expected_plan():
    plan = []
    for case_index, name in enumerate(CASES):
        for seed_index, seed in enumerate(SEEDS):
            for index in range(max(5 if name in LONG else 1, 2 if name in AA_CASES else 0)):
                shift = (case_index + seed_index + index) % 3
                for role in CONTRASTS[shift:] + CONTRASTS[:shift]:
                    count = (2 if name in AA_CASES else 0) if role == 'aa' else (5 if name in LONG else 1)
                    if index >= count: continue
                    order = ['baseline', 'candidate']
                    if (case_index + seed_index + index + CONTRASTS.index(role)) % 2: order.reverse()
                    plan.append({'scenario': name, 'seed': seed, 'pair_index': index, 'contrast': role, 'order': order,
                                 'query_threads': 2 if name in ('standard10k', 'resident30k') else 1})
    require(len(plan) == 138, 'internal analysis plan count error'); return plan


def audit_correctness(root, context):
    checks = read(child(root, 'correctness.json'))
    wanted = {(r, t) for r in ROLES for t in ('json_protocol', 'utf8_atomicity', 'topk_serial', 'topk_parallel')}
    require(checks['status'] == 'passed' and len(checks['checks']) == 12 and {(c['role'], c['test']) for c in checks['checks']} == wanted, 'missing actual binary gate')
    for check in checks['checks']:
        require(type(check['returncode']) is int and check['returncode'] == 0 and check.get('failure') is None and
                check['binary_sha256'] == context['profile_source_proof'][check['role']]['binary_sha256'], 'gate failed/tested different binary')
        for stream in ('stdout', 'stderr'): child(root, check['role'] + '-pgo/' + check['test'] + '.' + stream + '.log')
    expected_utf8 = {(raw, dim, path) for raw in ('ff', 'c080', 'eda080', 'e4b8', 'f4908080', '80') for dim in (None, 127, 128) for path in ('ORDER BY id LIMIT 10', 'unbounded', 'ORDER BY id LIMIT 4096')}
    for role in ROLES:
        data = read(child(root, role + '-utf8.json'))
        require(data['status'] == 'passed' and len(data['checks']) == 54 and
                {(c['malformed_hex'], c['projected_vector_dimension'], c['path']) for c in data['checks']} == expected_utf8 and
                all(c['status'] == 'passed' and c['valid_prefix_bytes'] == 90000 for c in data['checks']), 'actual UTF8 cases incomplete')
    expected_units = {('control', 'normal', 'equality_fastpath'), ('dom', 'sanitized', 'typed_response'),
                      *(('equality', mode, test) for mode in ('normal', 'sanitized') for test in ('equality_fastpath', 'filter_paths', 'filter_reuse'))}
    units = [tuple(line.split('\t')) for line in child(root, 'unit/passed.tsv').read_text().splitlines()]
    require(len(units) == 8 and set(units) == expected_units, 'source gate inventory differs')
    for role, mode, test in units:
        label = role + '-' + mode + '-' + test
        require(child(root, 'unit/' + label).stat().st_size > 0, 'missing source gate binary')
        flags = child(root, 'unit/' + label + '-flags.txt').read_text().split()
        extra = [] if role == 'control' else ['-DMVDB_ENABLE_EQUALITY_FASTPATH'] if role == 'equality' else ['-DMVDB_ENABLE_DOM_ROW_RESERVE']
        optimize = ['-O2'] if mode == 'normal' else ['-O1', '-g', '-fno-omit-frame-pointer', '-fsanitize=address,undefined', '-fno-pie', '-no-pie']
        require(flags == ['-std=c++17', '-pthread', '-Isrc', *FLAGS['baseline'], '-DMVDB_FILTER_DIAGNOSTICS', *extra, *optimize], 'source gate flags differ')
        child(root, 'unit/' + label + '.log'); child(root, 'unit/' + label + '-build.log')


def audit_measurements(root, context, inputs, snapshots, data):
    require(data['status'] == 'passed' and data['binary_unchanged'] is True and 'error' not in data and 'failed_pair' not in data, 'failed benchmark')
    require(data['baseline_commit'] == BASELINE and data['candidate_commit'] == context['candidate_commit'] and data['build_context_sha256'] == sha(root / 'context.json'), 'raw context/source differs')
    require(data['plan'] == inputs['plan'] == expected_plan() and len(data['pairs']) == 138, '138-pair plan differs')
    source = hash_map(snapshots['candidate'])
    require(data['driver_sha256'] == source['minivec/tools/benchmark_regression_ablation.py'] and
            data['harness_sha256'] == {n: source['minivec/tools/' + n] for n in MODULES}, 'actual harness differs from Git source')
    require(data['environment_before_overrides'] == {} and len(data['host']['affinity']) == len(set(data['host']['affinity'])) == 2 and data['host']['platform'] == context['platform'], 'runtime environment/host differs')
    require(set(data['binaries']) == set(ROLES), 'runtime roles differ')
    for role in ROLES:
        require(data['binaries'][role]['sha256'] == context['profile_source_proof'][role]['binary_sha256'], 'measured binary differs')
        require(data['binaries'][role]['path'].replace('\\', '/').endswith('/' + role + '-pgo/minivec'), 'measured binary path differs')
    workloads = {(v['scenario'], v['seed']): v for v in data['workloads']}
    require(len(workloads) == len(data['workloads']) == 24 and set(workloads) == {(name, seed) for name in CASES for seed in SEEDS}, 'workload set differs')
    for (name, seed), item in workloads.items():
        if name in PROJECTIONS:
            path = child(root, f'measurements.inputs/{name}-{seed}.jsonl')
            require((item['rows'], item['dimension'], item['string_codepoints']) == PROJECTIONS[name] and item['input_sha256'] == sha(path) and item['input_bytes'] == path.stat().st_size and
                    item['input_path'].replace('\\', '/').endswith(f'/measurements.inputs/{name}-{seed}.jsonl'), 'projection corpus hash/shape differs')
    seen = set()
    for pair, planned in zip(data['pairs'], expected_plan()):
        require(type(pair['seed']) is int and type(pair['pair_index']) is int and all(pair[k] == planned[k] for k in planned), 'identity/order/thread schedule differs')
        ident = tuple(pair[k] for k in ('contrast', 'scenario', 'seed', 'pair_index')); require(ident not in seen, 'duplicate pair'); seen.add(ident)
        role = 'baseline' if pair['contrast'] == 'aa' else pair['contrast']
        require(pair['binary_paths'] == {'baseline': data['binaries']['baseline']['path'], 'candidate': data['binaries'][role]['path']} and
                pair['binary_sha256'] == {'baseline': data['binaries']['baseline']['sha256'], 'candidate': data['binaries'][role]['sha256']}, 'AA/role path or binary checksum differs')
        require(pair['query_environment'] == {'MVDB_QUERY_THREADS': str(planned['query_threads'])}, 'thread override differs')
        work = workloads[(pair['scenario'], pair['seed'])]
        require(pair['workload_sha256'] == work.get('workload_sha256', work.get('input_sha256')), 'different paired corpus')
        shared.hash_ok(pair['workload_sha256'])
        if pair['scenario'] in PROJECTIONS:
            shared.check_projection(pair)
            for side in ('baseline', 'candidate'):
                run = pair[side]; policy = run['policy_evidence']
                require(policy['requested_query_threads'] == 1 and policy['no_query_fanout_diagnostics'] is True and len(policy['task_snapshots']) == 14 and
                        all('native_tasks' in s for s in policy['task_snapshots']) and run['stderr']['bytes'] <= 4096 and 'fanout ' not in run['stderr']['tail'], 'projection fixed-query-thread evidence missing')
        else:
            adapted = dict(pair)
            name = pair['scenario']; plan = 'spill_filters' if name.startswith('spill_') else 'standard' if name == 'standard10k' else 'boundaries'
            if plan == 'spill_filters': adapted['spec'] = [5000, 128, 10, 8192, 'compound' if name == 'spill_compound' else 'high']
            else: adapted.update(zip(('rows', 'dimension', 'updated_rows', 'padding_bytes', 'group_modulus', 'mixed_filters'), shared.SPECS[name]))
            shared.check_lifecycle(adapted, plan, 1000 if name in LONG else 64)
            require((work['rows'], work['dimension'], work['queries']) == ((5000, 128, 64) if plan == 'spill_filters' else (shared.SPECS[name][0], shared.SPECS[name][1], 1000)), 'iteration workload dimensions differ')
            for side in ('baseline', 'candidate'):
                run = pair[side]; policy = run['policy_evidence']; stderr = run['stderr']
                text = stderr['tail_utf8']; forced = [int(v) for v in re.findall(r'-> ([12]) threads? \(forced\)', text)]
                decisions = [int(v) for v in re.findall(r'-> ([12]) threads?', text)]
                require(not stderr['truncated'] and text.count('minivec ready data=') == 2 and policy['requested_threads'] == pair['query_threads'] and
                        policy['stderr_decisions'] == decisions and policy['stderr_forced_decisions'] == forced, 'query policy logs incomplete')
                require((decisions == forced == [2] * 8) if pair['query_threads'] == 2 else (not decisions and 'fanout ' not in text), 'fixed thread policy not observed')
                snaps = {s['phase']: s for s in run['resource_snapshots']}
                for phase, start in (('query_before_update', 'after_index_build'), ('query_after_restart', 'after_restart')):
                    before, after = snaps[start], snaps[phase]; old = {t['tid']: t['cpu_ticks'] for t in before['native_tasks']}
                    delta = sum(t['cpu_ticks'] - old.get(t['tid'], 0) for t in after['native_tasks'] if not t['main'])
                    require(delta == policy['phase_task_activity'][phase]['nonmain_cpu_ticks_delta'] and
                            (delta > 0 and len(after['native_tasks']) >= 2 if pair['query_threads'] == 2 else delta == 0), 'thread CPU evidence differs')
    return workloads


def timing_values(run, scenario):
    if scenario in PROJECTIONS:
        return {**{'lifecycle/' + k: v for k, v in run['lifecycle_seconds'].items()}, **{'query/' + k: v['wall_seconds'] for k, v in run['phases'].items()},
                'accounted_timer_sum': math.fsum(run['lifecycle_seconds'].values()) + math.fsum(p['wall_seconds'] for p in run['phases'].values())}
    result = dict(run['phase_seconds'])
    for phase, item in run['query'].items():
        values = item['per_request_seconds']
        for label, selected in (('first', values[:1]), ('front64', values[:64]), ('after_first_front64', values[1:64]), ('after64', values[64:])):
            if selected: result[phase + '/' + label] = math.fsum(selected)
        if scenario == 'standard10k':
            for label, start in (('unfiltered_exact_all', 0), ('single_filter_ann_all', 1), ('unfiltered_exact_after_first', 2), ('single_filter_ann_after_first', 3)):
                result[phase + '/' + label] = math.fsum(values[start::2])
            for begin, end in ((0, 64), (64, 256), (256, 512), (512, 1000)):
                for parity, label in ((0, 'unfiltered_exact'), (1, 'single_filter_ann')):
                    indices = [i for i in range(max(begin, 2), min(end, len(values))) if i % 2 == parity]
                    if indices: result[f'{phase}/{label}_window_{indices[0]}_{indices[-1]}'] = math.fsum(values[i] for i in indices)
    return result


def descriptive_bootstrap(rows):
    if len(rows) != 15: return None
    # Preserve the fixed3-seed allocation. Resampling across all15 as if inputs
    # were independently drawn would obscure the five repeated runs per seed.
    groups = [[r['baseline_over_candidate'] for r in rows if r['seed'] == seed] for seed in SEEDS]
    require(all(len(g) == 5 for g in groups), '15-pair bootstrap needs3x5 design')
    rng = random.Random(BOOTSTRAP_SEED)
    samples = sorted(median([v for group in groups for v in rng.choices(group, k=5)]) for _ in range(BOOTSTRAP_REPLICATES))
    return {'method': 'within-fixed-seed paired bootstrap of median ratio; secondary descriptive only', 'replicates': BOOTSTRAP_REPLICATES,
            'rng_seed': BOOTSTRAP_SEED, 'percentile95_range': [samples[math.floor(.025 * (len(samples) - 1))], samples[math.ceil(.975 * (len(samples) - 1))]],
            'limit': 'Conditional on3 fixed inputs, one PGO build per role and one runner. No population CI, p-value, multiple-comparison correction or automatic significance/adoption claim.'}


def analyze(root, candidate, source):
    root = root.resolve(); hashes = audit_manifest(root)
    inputs, context, data, summary, status = [read(child(root, n + '.json')) for n in ('build-input', 'context', 'measurements', 'summary', 'run-status')]
    require(summary['status'] == status['proof_status'] == 'passed' and summary['exit_code'] == status['exit_code'] == 0 and
            summary['collection_verification_error'] is None and status['collection_verification_error'] is None and summary['stage'] == 'complete' and
            child(root, 'stage.txt').read_text().strip() == 'complete', 'incomplete/failed CI')
    require(summary['verified_total_pairs'] == 138 and summary['per_candidate_pairs'] == 60 and summary['identical_baseline_aa_pairs'] == 18 and
            summary['actual_binary_correctness_gates'] == 12 and summary['actual_utf8_cases'] == 162 and summary['source_diagnostic_sanitizer_gates'] == 8 and
            summary['binary_unchanged'] is True and summary['source_profile_flags_verified'] is True and summary['measurement_sha256'] == sha(root / 'measurements.json'), 'collector counts/proofs differ')
    snapshots = audit_builds(root, candidate, source, inputs, context)
    audit_correctness(root, context); audit_measurements(root, context, inputs, snapshots, data)
    grouped = defaultdict(list)
    for pair in data['pairs']: grouped[(pair['contrast'], pair['scenario'])].append(pair)
    metrics, recomputed = {}, {}
    for (role, scenario), group in grouped.items():
        value_maps = {id(run): timing_values(run, scenario) for pair in group for run in (pair['baseline'], pair['candidate'])}
        record = {'contrast': role, 'scenario': scenario, 'pairs': len(group), 'timings': {}, 'all_pair_identities': [shared.identity(p) for p in group]}
        metrics[role + '/' + scenario] = record; recomputed[role + '/' + scenario] = {}
        for key in sorted(next(iter(value_maps.values()))):
            metric = shared.metric(group, lambda run, k=key: value_maps[id(run)][k])
            metric['descriptive_bootstrap'] = descriptive_bootstrap(metric['raw_pairs'])
            metric['screening_only'] = len(group) != 15
            record['timings'][key] = metric
            ratios = [p['baseline_over_candidate'] for p in metric['raw_pairs']]
            def ratio_summary(values): return {'pairs': len(values), 'median_baseline_over_candidate': median(values), 'minimum': min(values), 'maximum': max(values), 'candidate_slower_pairs': sum(v < 1 for v in values)}
            recomputed[role + '/' + scenario][key] = {**ratio_summary(ratios), 'baseline_seconds_median': metric['baseline']['median'], 'candidate_seconds_median': metric['candidate']['median'],
                'by_seed': {str(seed): ratio_summary([r for p, r in zip(group, ratios) if p['seed'] == seed]) for seed in SEEDS},
                'by_order': {first: ratio_summary([r for p, r in zip(group, ratios) if p['order'][0] == first]) for first in ('baseline', 'candidate') if any(p['order'][0] == first for p in group)}}
        record['details'] = shared.projection_metrics(group) if scenario in PROJECTIONS else shared.lifecycle_metrics(group)
    require(recomputed == data['summary'], 'driver summary differs from independently recomputed paired values')
    for key, group in metrics.items():
        aa = metrics.get('aa/' + group['scenario'])
        if group['contrast'] != 'aa' and aa:
            group['aa_measurement_context'] = {'comparison': 'aa/' + group['scenario'], 'pairs': aa['pairs'],
                'timings': {name: {'candidate_median_ratio': item['baseline_over_candidate']['median'],
                    'aa_median_ratio': aa['timings'][name]['baseline_over_candidate']['median'],
                    'aa_min_ratio': aa['timings'][name]['baseline_over_candidate']['min'], 'aa_max_ratio': aa['timings'][name]['baseline_over_candidate']['max']}
                    for name, item in group['timings'].items()},
                'limit': 'Six identical-binary A/A pairs characterize observed process/host variation only; do not normalize away losses or infer that PGO build variance was excluded.'}
    return {'status': 'verified', 'kind': 'regression_ablation_138_readonly_audit', 'candidate_commit': candidate, 'baseline_commit': BASELINE,
        'analysis_tool_sha256': {Path(__file__).name: sha(Path(__file__)), Path(shared.__file__).name: sha(Path(shared.__file__))},
        'verified_pairs': 138, 'official_score': None, 'automatic_adoption': False, 'artifact_manifest_sha256': sha(root / 'hashes.json'),
        'artifact_files_verified': hashes, 'profile_source_proof': context['profile_source_proof'], 'source_differences': context['source_differences'],
        'host': {'cpu_info': context['cpu_info'], **data['host']}, 'groups': metrics,
        'limitations': ['Source baseline is delivered e020, independently rebuilt with original PGO and four flags; it is not the earlier delivered binary bytes.',
            'Candidate contrast changes its named macro on candidate source; both share all candidate source files. Layout/profile effects are not isolated from the code change.',
            'Three-pair protection cases are descriptive screens: retain every sample, no bootstrap/significance claim.',
            'Fifteen-pair bootstrap is predeclared secondary, stratified within fixed seeds, not a general confidence guarantee.',
            'No cohort-wide speedup is computed from differently weighted scenarios. Every negative pair and order/seed subgroup remains.',
            'Projection accounted totals include ingestion and all query timers, excluding oracle/untimed setup. Process counters are not official cgroup scores.',
            'Source/profile manifests and retained binaries are audited; this analysis does not rebuild/execute them or replay every stored-value oracle.',
            'Formal competition submission is prohibited; this tool cannot submit or change production switches.']}


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--input', type=Path, required=True); parser.add_argument('--candidate-commit', required=True)
    parser.add_argument('--source-repo', type=Path, default=HERE / 'seekdb'); parser.add_argument('--output', type=Path, required=True)
    args = parser.parse_args()
    require(not args.output.exists(), 'refusing to overwrite analysis')
    require(not args.output.resolve().is_relative_to(args.input.resolve()), 'output must be outside immutable raw artifact')
    result = analyze(args.input, args.candidate_commit, shared.GitSource(args.source_repo))
    with args.output.open('x', encoding='utf-8', newline='\n') as file:
        json.dump(result, file, ensure_ascii=False, indent=2, allow_nan=False); file.write('\n')
    print(json.dumps({'status': result['status'], 'verified_pairs': 138, 'output': str(args.output.resolve())}))


if __name__ == '__main__': main()
