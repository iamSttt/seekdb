#!/usr/bin/env python3
"""Controlled138-artifact analyzer tests, no benchmark execution or real result."""
from contextlib import redirect_stdout
from copy import deepcopy
import json
import os
from pathlib import Path
import sys
import tempfile

import analyze_regression_ablation as audit
import check_regression_ablation as fixture

HERE = Path(__file__).resolve().parent


class FixtureGit:
    def __init__(self, scratch):
        self.scratch = scratch

    def files(self, commit, selectors):
        assert commit in (audit.BASELINE, 'b' * 40)
        root = self.scratch / ('baseline' if commit == audit.BASELINE else 'candidate')
        return {p.relative_to(root).as_posix(): p.read_bytes() for p in root.rglob('*') if p.is_file()}


def save(path, data):
    path.write_text(json.dumps(data, indent=2, allow_nan=False) + '\n', encoding='utf-8')


def refresh_manifest(root):
    save(root / 'hashes.json', {'artifacts': [{'path': p.relative_to(root).as_posix(), 'bytes': p.stat().st_size, 'sha256': audit.sha(p)}
        for p in sorted(root.rglob('*')) if p.is_file() and p.name != 'hashes.json']})


def main():
    checks = []
    with tempfile.TemporaryDirectory(prefix='regression-analysis-fixture-', dir=HERE) as temporary:
        root = Path(temporary); out, scratch = root / 'out', root / 'scratch'
        data = fixture.make_fixture(out, scratch)
        context = audit.read(out / 'context.json'); inputs = audit.read(out / 'build-input.json')
        # Emulate Linux write_text LF; the imported fixture generator runs on
        # Windows and otherwise writes CRLF into its temporary Dockerfiles.
        for role in audit.ROLES:
            generated = out / 'build-input' / ('Dockerfile.' + role)
            generated.write_bytes(generated.read_text().encode('utf-8'))
            inputs['roles'][role]['build_dockerfile_sha256'] = audit.sha(generated)
            context['profile_source_proof'][role]['build_dockerfile_sha256'] = audit.sha(generated)
        save(out / 'build-input.json', inputs); save(out / 'context.json', context)
        data['build_context_sha256'] = audit.sha(out / 'context.json')
        data['host']['platform'] = context['platform']
        for pair in data['pairs']:
            if pair['scenario'] in audit.PROJECTIONS:
                for side in ('baseline', 'candidate'):
                    pair[side]['policy_evidence']['task_snapshots'] = [{'native_tasks': [{'tid': 100, 'main': True, 'cpu_ticks': 1}]} for _ in range(14)]
        save(out / 'measurements.json', data)
        for role in audit.ROLES:
            target = out / (role + '-pgo')
            save(target / 'build-cost.json', {'status': 'passed', 'pgo_enabled': True, 'nanoseconds': 1})
            (target / 'build.log').write_text('synthetic, not compiled\n')
            for label in ('json_protocol', 'utf8_atomicity', 'topk_serial', 'topk_parallel'):
                for stream in ('stdout', 'stderr'): (target / (label + '.' + stream + '.log')).write_text('synthetic log\n')
            utf8 = audit.read(out / (role + '-utf8.json'))
            for item in utf8['checks']: item['valid_prefix_bytes'] = 90000
            save(out / (role + '-utf8.json'), utf8)
        for line in (out / 'unit/passed.tsv').read_text().splitlines():
            role, mode, test = line.split('\t'); label = role + '-' + mode + '-' + test
            extra = [] if role == 'control' else ['-DMVDB_ENABLE_EQUALITY_FASTPATH'] if role == 'equality' else ['-DMVDB_ENABLE_DOM_ROW_RESERVE']
            optimize = ['-O2'] if mode == 'normal' else ['-O1', '-g', '-fno-omit-frame-pointer', '-fsanitize=address,undefined', '-fno-pie', '-no-pie']
            (out / 'unit' / label).write_bytes(b'synthetic unit binary')
            (out / 'unit' / (label + '-flags.txt')).write_text('\n'.join(['-std=c++17', '-pthread', '-Isrc', *audit.FLAGS['baseline'], '-DMVDB_FILTER_DIAGNOSTICS', *extra, *optimize]))
            for suffix in ('.log', '-build.log'): (out / 'unit' / (label + suffix)).write_text('synthetic log\n')
        with open(os.devnull, 'w') as stream, redirect_stdout(stream): fixture.proof.collect(out, 0)
        source = FixtureGit(scratch)
        result = audit.analyze(out, 'b' * 40, source)
        assert result['verified_pairs'] == 138 and len(result['groups']) == 19
        assert result['groups']['equality/standard10k']['timings']['query_after_restart/single_filter_ann_window_513_999']['descriptive_bootstrap']['replicates'] == 2000
        assert result['groups']['dom/wide128']['timings']['accounted_timer_sum']['descriptive_bootstrap'] is None
        assert result['groups']['equality/resident30k']['aa_measurement_context']['pairs'] == 6
        assert result['groups']['aa/many16']['timings']['accounted_timer_sum']['descriptive_bootstrap'] is None
        checks.append({'name': 'complete138_synthetic_artifact_all_source_profile_binary_oracle_and_summary_checks', 'result': 'accepted, no real result written'})
        original_read_bytes = Path.read_bytes
        def refuse_binary_load(path):
            if path.parent.name == 'unit' or path.name in ('minivec', 'instrumented-minivec', 'unstripped-minivec'):
                raise AssertionError('binary was loaded instead of streaming its hash')
            return original_read_bytes(path)
        Path.read_bytes = refuse_binary_load
        try:
            audit.audit_manifest(out)
            audit.audit_builds(out, 'b' * 40, source, inputs, context)
        finally: Path.read_bytes = original_read_bytes
        checks.append({'name': 'runtime_instrumented_unstripped_unit_binary_hashes_streamed', 'result': 'passed with read_bytes forbidden for binaries'})
        original_argv = sys.argv
        destination = root / 'existing.json'; destination.write_bytes(b'preserve')
        for name, output in [('nooverwrite', destination), ('output_inside_raw', out / 'new-analysis.json')]:
            sys.argv = ['analyze_regression_ablation.py', '--input', str(out), '--candidate-commit', 'b' * 40, '--output', str(output)]
            try: audit.main()
            except ValueError: checks.append({'name': name, 'result': 'rejected before source lookup/output write'})
            else: raise AssertionError(name)
        sys.argv = original_argv
        assert destination.read_bytes() == b'preserve' and not (out / 'new-analysis.json').exists()
        saved_manifest = (out / 'hashes.json').read_bytes()
        file = out / 'unit/control-normal-equality_fastpath'; content = file.read_bytes()
        file.write_bytes(content + b'changed')
        try: audit.audit_manifest(out)
        except ValueError: checks.append({'name': 'large_binary_modified', 'result': 'rejected'})
        else: raise AssertionError('modified binary accepted')
        file.write_bytes(content)
        missing = out / 'dom-pgo/build.log'; content = missing.read_bytes(); missing.unlink()
        try: audit.audit_manifest(out)
        except ValueError: checks.append({'name': 'listed_log_missing', 'result': 'rejected'})
        else: raise AssertionError('missing log accepted')
        missing.write_bytes(content)
        manifest = audit.read(out / 'hashes.json')
        for name, mutate in [('escape', lambda d: d['artifacts'][0].update(path='../outside')), ('duplicate', lambda d: d['artifacts'].append(d['artifacts'][0]))]:
            broken = deepcopy(manifest); mutate(broken); save(out / 'hashes.json', broken)
            try: audit.audit_manifest(out)
            except ValueError: checks.append({'name': 'manifest_' + name, 'result': 'rejected'})
            else: raise AssertionError(name)
        (out / 'hashes.json').write_bytes(saved_manifest)
        snapshots = audit.audit_builds(out, 'b' * 40, source, inputs, context)
        for name, mutate in [
            ('duplicate_pair', lambda d: d['pairs'].__setitem__(1, deepcopy(d['pairs'][0]))),
            ('AA_changed_binary_path', lambda d: next(p for p in d['pairs'] if p['contrast'] == 'aa')['binary_paths'].__setitem__('candidate', '/wrong/minivec')),
            ('wrong_ABBA', lambda d: d['pairs'][0]['order'].reverse()),
            ('empty_query_phases', lambda d: d['pairs'][0]['candidate'].__setitem__('query', {})),
            ('incomplete_oracle', lambda d: d['pairs'][0]['candidate']['correctness'].__setitem__('sampled_topk_oracle_queries', [])),
            ('query_timing_tamper', lambda d: d['pairs'][0]['candidate']['query']['query_before_update']['per_request_seconds'].__setitem__(0, 17.0)),
            ('projection_wrong_phase', lambda d: next(p for p in d['pairs'] if p['scenario'] == 'wide128')['candidate']['phases'].__setitem__('wrong', next(p for p in d['pairs'] if p['scenario'] == 'wide128')['candidate']['phases'].pop('wide_all'))),
            ('projection_wrong_values_digest', lambda d: next(p for p in d['pairs'] if p['scenario'] == 'wide768')['candidate']['phases']['wide_all']['requests'][0].__setitem__('response_sha256', '0' * 64)),
            ('forced_policy_mismatch', lambda d: d['pairs'][0]['candidate']['policy_evidence'].__setitem__('requested_threads', 1)),
        ]:
            broken = deepcopy(data); mutate(broken)
            try: audit.audit_measurements(out, context, inputs, snapshots, broken)
            except (ValueError, KeyError): checks.append({'name': name, 'result': 'rejected'})
            else: raise AssertionError(name)
        contaminated = deepcopy(context); contaminated['profile_source_proof']['dom']['feature_flags'].append('-DMVDB_ENABLE_EQUALITY_FASTPATH')
        try: audit.audit_builds(out, 'b' * 40, source, inputs, contaminated)
        except ValueError: checks.append({'name': 'cross_candidate_macro_contamination', 'result': 'rejected'})
        else: raise AssertionError('flags accepted')
        try: audit.audit_builds(out, 'bbbbbbb', source, inputs, context)
        except ValueError: checks.append({'name': 'candidate_prefix', 'result': 'rejected'})
        else: raise AssertionError('prefix accepted')
        source_changed = deepcopy(inputs); source_changed['snapshot_files']['candidate']['Dockerfile'] = '0' * 64
        try: audit.audit_builds(out, 'b' * 40, source, source_changed, context)
        except ValueError: checks.append({'name': 'snapshot_Git_mismatch', 'result': 'rejected'})
        else: raise AssertionError('source accepted')
        assert audit.audit_manifest(out)
    report = {'status': 'passed', 'scope': 'controlled synthetic artifact audit only; no Linux compile, real run analysis or performance result',
        'analyzer_sha256': audit.sha(HERE / 'analyze_regression_ablation.py'), 'shared_analyzer_sha256': audit.sha(HERE / 'analyze_retained_final.py'),
        'test_sha256': audit.sha(Path(__file__)), 'checks': checks}
    save(HERE / 'regression-ablation-analyzer-static-validation.json', report)
    print(json.dumps({'status': 'passed', 'checks': len(checks), 'scope': report['scope']}))


if __name__ == '__main__': main()
