# Regression round-one evidence, commit 76d7687

All measured outputs and analysis are preserved unchanged, including negative
pairs and the original wording. The raw measurement ZIP is archived separately
as `iteration4-regression-raw.zip`. This analysis ZIP includes the complete
derived analysis, frozen analyzers and synthetic checks, 20-check proof, root
validation proof, and the original root-image validation ZIP. `seekdb/` contains
only committed 76d7687 dependencies needed by the synthetic checks, not a full
repository or a runnable database. Source blobs were obtained from that commit,
not the later working tree.

## Correction to historical interpretation

Raw `summary.json` and analyzer `limitations[0]` wrongly say the rebuilt baseline
is not the earlier delivered binary bytes. It was a NEW IMAGE BUILD, but its
actual binary SHA256 is acddca115ab183bfc6419e27c9e3383cfd1a9046e3897e5ea516cd7bc0f29f54,
identical to the earlier311 actual-root binary. The original image was not reused.
Do not treat image identity as binary identity. Originals are retained for audit;
the authoritative corrected interpretation is in `iteration4-regression-results.json`.
The current76 root validation image has another SHA and no performance run; it
is not any of the three measured PGO roles.

## Read-only reproduction

Extract this ZIP to a writable directory. Extract the raw measurement ZIP to a
different directory. Use a real git checkout retaining e020 and 76 commits:

```
python analyze_regression_ablation.py --input RAW_DIRECTORY --source-repo REPOSITORY --candidate-commit 76d7687b6eb002bb765bb555102d528166af50ac --output NEW_ANALYSIS.json
python check_regression_analysis.py
```

The first command audits the original artifacts without rerunning Linux tests;
the output must not exist or be inside RAW_DIRECTORY. The second runs only
controlled synthetic proof tests and refreshes a synthetic proof file in the
extracted copy. It does not benchmark a database. The frozen analyzer deliberately
reproduces its historical wording; apply the correction above when interpreting.

## Decision and limits

Both equality fastpath and DOM row reserve are rejected for default adoption.
Their implementation is being removed from current runtime source; the immutable
76 commit and full raw ZIP retain the experiment. No old .919/.979 regression is
declared recovered, no official score is inferred, no formal submission occurred.
The next bulk-output candidate is preparation only, with no measured result here.
