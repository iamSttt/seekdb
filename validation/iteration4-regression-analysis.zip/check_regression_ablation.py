#!/usr/bin/env python3
"""Synthetic parser/build-plan tests only, never database performance."""
from copy import deepcopy
import importlib.util
import json
from pathlib import Path
import shutil
import sys
import tempfile

HERE = Path(__file__).resolve().parent
TOOLS = HERE / 'seekdb/minivec/tools'
sys.path.insert(0, str(TOOLS))
import benchmark_regression_ablation as bench
import regression_ablation_proof as proof
spec = importlib.util.spec_from_file_location('fixture120', HERE / 'check_retained_final_analyzer.py')
old = importlib.util.module_from_spec(spec); spec.loader.exec_module(old)


def write(path, data):
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_bytes(data if isinstance(data, bytes) else data.encode())


def lifecycle(name, role, threads):
    plan = 'spill_filters' if name.startswith('spill_') else 'standard' if name == 'standard10k' else 'boundaries'
    run = old.lifecycle(name, plan, 64 if name.startswith('spill_') else 1000, 1 if role == 'baseline' else .99)
    lines = 'minivec ready data=/synthetic\n'
    if threads == 2: lines += ('mvdb: fanout -> 2 threads (forced)\n' * 4)
    lines *= 2
    run['stderr'] = {'total_bytes': len(lines), 'tail_source_bytes': len(lines), 'truncated': False, 'tail_utf8': lines}
    for snapshot in run['resource_snapshots']:
        restarted = snapshot['phase'] in ('after_restart', 'query_after_restart', 'before_final_shutdown')
        ident = 200 if restarted else 100
        after = snapshot['phase'] not in ('after_index_build', 'after_restart', 'after_ingest')
        snapshot['native_tasks'] = [{'tid': ident, 'main': True, 'cpu_ticks': 10}]
        if threads == 2: snapshot['native_tasks'].append({'tid': ident + 1, 'main': False, 'cpu_ticks': 20 if after else 0})
        snapshot['clock_ticks_per_second'] = 100
    run['policy_evidence'] = bench.repeat.observed_policy(run, threads)
    return run


def make_fixture(out, scratch):
    for role in ('baseline', 'candidate'):
        root = scratch / role
        write(root / 'Dockerfile', (HERE / 'seekdb/Dockerfile').read_bytes())
        write(root / '.dockerignore', b'synthetic ignore\n')
        write(root / 'minivec/src/db.cpp', b'// synthetic source fixture, not compiled\n')
        write(root / 'minivec/third_party/json.hpp', b'// synthetic thirdparty fixture\n')
        for name in ('train.cpp', 'run-training.sh'): write(root / 'minivec/tools/pgo' / name, (TOOLS / 'pgo' / name).read_bytes())
        if role == 'candidate':
            for name in ('benchmark_regression_ablation.py', 'regression_ablation_proof.py', 'benchmark_iteration.py', 'benchmark_report_matrix.py', 'benchmark_projection.py', 'benchmark_filter_repeat.py'):
                write(root / 'minivec/tools' / name, (TOOLS / name).read_bytes())
    (out / 'build-input').mkdir(parents=True)
    write(out / 'lscpu.txt', 'synthetic host, no measurement\n')
    write(out / 'stage.txt', 'complete\n')
    proof.initialize(out, scratch, 'b' * 40)
    inputs = proof.read(out / 'build-input.json')
    for role, flags in proof.FLAGS.items():
        target = out / (role + '-pgo'); training = target / 'training'
        src = scratch / ('baseline' if role == 'baseline' else 'candidate')
        shutil.copytree(src / 'minivec/src', target / 'built-source')
        shutil.copytree(src / 'minivec/third_party', target / 'built-third-party')
        for name in ('train.cpp', 'run-training.sh'): write(training / name, (src / 'minivec/tools/pgo' / name).read_bytes())
        write(target / 'minivec', ('synthetic runtime ' + role).encode())
        write(target / 'binary-sha256.txt', proof.sha(target / 'minivec') + '  ' + str(target) + '/minivec\n')
        write(training / 'instrumented-minivec', ('synthetic instrumented ' + role).encode())
        write(training / 'instrumented-binary-sha256.txt', proof.sha(training / 'instrumented-minivec') + '  /minivec\n')
        write(training / 'unstripped-minivec', b'synthetic unstripped bytes')
        write(training / 'symbols.txt', b'synthetic symbol data')
        write(training / 'sections.txt', b'synthetic section data')
        write(training / 'effective-flags.txt', proof.COMMON + ' ' + ' '.join(flags) + '\n')
        write(training / 'profile-data/minivec-db.gcda', b'synthetic gcda, not a measured profile')
        write(training / 'profile-sha256.txt', proof.sha(training / 'profile-data/minivec-db.gcda') + '  /pgo/minivec-db.gcda\n')
        write(training / 'corpus/phase.jsonl', b'{"synthetic":true}\n')
        write(training / 'corpus-sha256.txt', proof.sha(training / 'corpus/phase.jsonl') + '  /training/corpus/phase.jsonl\n')
        oracle = []
        for threads in (1, 2):
            for phase in (0, 1, 2):
                name = f'responses-{threads}-{phase}.jsonl'; write(training / name, b'{"synthetic":true}\n')
                oracle.append({'actual_file': name, 'status': 'passed', 'responses': 1})
        write(training / 'verification.jsonl', ''.join(json.dumps(v) + '\n' for v in oracle))
        proof.save(target / 'image.json', [{'Id': 'sha256:' + proof.sha(target / 'minivec')}])
    proof.verify_builds(out, scratch)
    first_context = (out / 'context.json').read_bytes(); proof.verify_builds(out, scratch)
    assert (out / 'context.json').read_bytes() == first_context, 'postmeasurement verify would mutate context hash'
    context = proof.read(out / 'context.json')
    checks = []
    for role in proof.FLAGS:
        for name in ('json_protocol', 'utf8_atomicity', 'topk_serial', 'topk_parallel'):
            checks.append({'role': role, 'test': name, 'returncode': 0, 'binary_sha256': context['profile_source_proof'][role]['binary_sha256']})
        proof.save(out / (role + '-utf8.json'), {'status': 'passed', 'checks': [{'status': 'passed', 'malformed_hex': raw, 'projected_vector_dimension': dim, 'path': path}
            for raw in ('ff', 'c080', 'eda080', 'e4b8', 'f4908080', '80') for dim in (None, 127, 128) for path in ('ORDER BY id LIMIT 10', 'unbounded', 'ORDER BY id LIMIT 4096')]})
    proof.save(out / 'correctness.json', {'status': 'passed', 'checks': checks})
    units = [('control', 'normal', 'equality_fastpath'), ('dom', 'sanitized', 'typed_response')]
    units.extend(('equality', m, t) for m in ('normal', 'sanitized') for t in ('equality_fastpath', 'filter_paths', 'filter_reuse'))
    write(out / 'unit/passed.tsv', ''.join('\t'.join(v) + '\n' for v in units))
    data = {'status': 'passed', 'binary_unchanged': True, 'baseline_commit': proof.BASELINE, 'candidate_commit': context['candidate_commit'],
        'build_context_sha256': proof.sha(out / 'context.json'), 'plan': bench.make_plan(), 'pairs': [], 'workloads': [],
        'environment_before_overrides': {}, 'host': {'affinity': [0, 1]},
        'binaries': {r: {'path': str(out / (r + '-pgo/minivec')), 'sha256': context['profile_source_proof'][r]['binary_sha256']} for r in proof.FLAGS},
        'driver_sha256': inputs['snapshot_files']['candidate']['minivec/tools/benchmark_regression_ablation.py'],
        'harness_sha256': {n: inputs['snapshot_files']['candidate']['minivec/tools/' + n] for n in ('benchmark_iteration.py', 'benchmark_report_matrix.py', 'benchmark_projection.py', 'benchmark_filter_repeat.py')}}
    corpora = {}
    for name in bench.CASES:
        for seed in bench.SEEDS:
            item = {'scenario': name, 'seed': seed}
            if name in bench.PROJECTED:
                path = out / 'measurements.inputs' / f'{name}-{seed}.jsonl'; write(path, b'{"synthetic":true}\n')
                rows, dim, width = bench.projection.CASES[name]
                item.update(input_path=str(path), input_bytes=path.stat().st_size, input_sha256=proof.sha(path), rows=rows, dimension=dim, string_codepoints=width)
                corpora[(name, seed)] = item['input_sha256']
            else:
                rows, dim = (bench.base.FULL_CASES[name] if name in bench.ITERATION else bench.matrix.CASES[name])[:2]
                item.update(rows=rows, dimension=dim, queries=1000 if name in bench.ITERATION else 64, workload_sha256='f' * 64)
                corpora[(name, seed)] = item['workload_sha256']
            data['workloads'].append(item)
    for planned in data['plan']:
        name = planned['scenario']; role = 'baseline' if planned['contrast'] == 'aa' else planned['contrast']
        pair = {**planned, 'workload_sha256': corpora[(name, planned['seed'])],
            'binary_sha256': {side: data['binaries'][actual]['sha256'] for side, actual in (('baseline', 'baseline'), ('candidate', role))},
            'binary_paths': {'baseline': str(out / 'baseline-pgo/minivec'), 'candidate': str(out / (role + '-pgo/minivec'))},
            'query_environment': {'MVDB_QUERY_THREADS': str(planned['query_threads'])}}
        for side, actual in (('baseline', 'baseline'), ('candidate', role)):
            if name in bench.PROJECTED:
                run = old.projection(name, 1 if actual == 'baseline' else .99)
                run['policy_evidence'] = {'requested_query_threads': 1, 'no_query_fanout_diagnostics': True, 'task_snapshots': [{}] * 14}
                pair[side] = run
            else: pair[side] = lifecycle(name, actual, planned['query_threads'])
        pair['all_responses_identical_and_independently_verified' if name in bench.PROJECTED else 'all_responses_identical'] = True
        data['pairs'].append(pair)
    data['summary'] = bench.summarize(data['pairs']); proof.save(out / 'measurements.json', data)
    return data


def main():
    cases = []
    with tempfile.TemporaryDirectory(prefix='regression-ablation-parser-', dir=HERE) as temporary:
        root = Path(temporary); out, scratch = root / 'out', root / 'scratch'
        data = make_fixture(out, scratch)
        summary = proof.verify_results(out); assert summary['verified_total_pairs'] == 138
        cases.append({'case': 'complete138_synthetic_evidence_with3_builds12_gates162_utf8_8_source_gates', 'result': 'accepted'})
        for name, mutate in [
            ('missing_pair', lambda d: d['pairs'].pop()),
            ('duplicate_pair', lambda d: d['pairs'].__setitem__(1, deepcopy(d['pairs'][0]))),
            ('wrong_abba', lambda d: d['pairs'][0]['order'].reverse()),
            ('empty_query_map', lambda d: d['pairs'][0]['candidate'].__setitem__('query', {})),
            ('query_count_short', lambda d: d['pairs'][0]['candidate']['query']['query_before_update']['per_request_seconds'].pop()),
            ('response_mismatch', lambda d: d['pairs'][0]['candidate'].__setitem__('response_sha256', '0' * 64)),
            ('aa_different_binary', lambda d: next(p for p in d['pairs'] if p['contrast'] == 'aa')['binary_paths'].__setitem__('candidate', '/different/path')),
            ('wrong_projection_phase', lambda d: next(p for p in d['pairs'] if p['scenario'] == 'many16')['candidate']['phases'].__setitem__('renamed', next(p for p in d['pairs'] if p['scenario'] == 'many16')['candidate']['phases'].pop('wide_all'))),
            ('missing_projection_oracle', lambda d: next(p for p in d['pairs'] if p['scenario'] == 'wide128')['candidate']['phases']['wide_all'].__setitem__('independent_oracle', '')),
            ('projection_sha_mismatch', lambda d: next(p for p in d['pairs'] if p['scenario'] == 'wide768')['candidate']['phases']['wide_all']['requests'][0].__setitem__('response_sha256', '0' * 64)),
            ('thread_policy_mismatch', lambda d: d['pairs'][0]['candidate']['policy_evidence'].__setitem__('requested_threads', 1)),
            ('source_driver_mismatch', lambda d: d.__setitem__('driver_sha256', '0' * 64)),
            ('context_hash_mismatch', lambda d: d.__setitem__('build_context_sha256', '0' * 64)),
            ('inherited_environment', lambda d: d.__setitem__('environment_before_overrides', {'MVDB_QUERY_THREADS': '1'})),
        ]:
            changed = deepcopy(data); mutate(changed)
            try: changed['summary'] = bench.summarize(changed['pairs'])
            except (KeyError, ValueError, ZeroDivisionError): pass
            proof.save(out / 'measurements.json', changed)
            try: proof.verify_results(out)
            except (ValueError, KeyError): cases.append({'case': name, 'result': 'rejected'})
            else: raise AssertionError(name)
        proof.save(out / 'measurements.json', data)
        path = out / 'measurements.inputs/wide128-7319.jsonl'; original = path.read_bytes(); path.write_bytes(b'changed')
        try: proof.verify_results(out)
        except ValueError: cases.append({'case': 'projection_corpus_changed', 'result': 'rejected'})
        else: raise AssertionError('corpus changed')
        path.write_bytes(original)
        flags = out / 'dom-pgo/training/effective-flags.txt'; original = flags.read_bytes(); flags.write_bytes(original + b' -DMVDB_ENABLE_EQUALITY_FASTPATH\n')
        try: proof.verify_builds(out, scratch)
        except ValueError: cases.append({'case': 'cross_candidate_flag_leak', 'result': 'rejected'})
        else: raise AssertionError('flag leaked')
        flags.write_bytes(original)
        proof.verify_builds(out, scratch)
        assert proof.verify_results(out)['verified_total_pairs'] == 138
        # Prefix invariant uses the real generator, not a duplicated implementation.
        short = bench.base.make_workload((128, 16, 0, 0, 10, True), 7319, 64, 100, 10)
        long = bench.base.make_workload((128, 16, 0, 0, 10, True), 7319, 1000, 100, 10)
        assert all(short[k] == long[k] for k in ('create', 'inserts', 'vectors')) and short['queries'] == long['queries'][:64]
        cases.append({'case': 'real_generator_64_request_prefix_and_data_preserved', 'result': 'passed'})
        standard = data['summary']['equality/standard10k']
        assert 'query_before_update/single_filter_ann_window_3_63' in standard and 'query_after_restart/single_filter_ann_window_513_999' in standard
        assert 'query_after_restart/unfiltered_exact_after_first' in standard and 'query_after_restart/after64' in standard
        cases.append({'case': 'standard_parity_windows_and_after936_explicit', 'result': 'passed'})
    report = {'status': 'passed', 'scope': 'synthetic build/evidence parser fixtures and real workload generator prefix checks only; no Linux compile or performance result',
        'files_sha256': {n: proof.sha(TOOLS / n) for n in ('ci_regression_ablation.sh', 'benchmark_regression_ablation.py', 'regression_ablation_proof.py')}, 'cases': cases}
    proof.save(HERE / 'regression-ablation-static-validation.json', report)
    print(json.dumps({'status': 'passed', 'cases': len(cases), 'scope': report['scope']}))


if __name__ == '__main__': main()
