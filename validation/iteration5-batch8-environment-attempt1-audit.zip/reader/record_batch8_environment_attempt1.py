"""Read-only environment audit plus authorized append-only material update."""
import copy,hashlib,importlib.util,io,json,zipfile
from pathlib import Path
import analyze_batch8_primary_root as reader
from analyze_crc_root import require,read,sha,digest,blob,git
W=Path(__file__).resolve().parent;R=W/'seekdb';rawroot=W/'batch8-environment-attempt1-raw'
RAW='validation/iteration5-batch8-environment-attempt1-raw.zip'
RAW_SHA='59793c22f4b581bff1dff439fba896d8521db3fea5a9d61f7ea4a52a8203499d'
AUDIT='validation/iteration5-batch8-environment-attempt1-audit.zip'
MATERIAL_SHA='51ee180b6f85c2f7b4930d5b6e1851af6a662541a13a4ee28a7decb61f494cae'
def enc(x):return (json.dumps(x,ensure_ascii=False,separators=(',',':'),allow_nan=False)+'\n').encode()
count=reader.core.verify_archive(rawroot,R/RAW,RAW_SHA,41503)
receipt=read(W/'batch8-environment-attempt1-api-receipt.json');a=receipt['artifact']
require(receipt['run_id']==43506915917 and receipt['job_id']==132166852233 and receipt['commit']==a['workflow_run']['head_sha']==reader.CANDIDATE_COMMIT and a['workflow_run']['id']==receipt['run_id'],'API execution identity differs')
require(a['id']==14076856521 and a['digest']=='sha256:'+RAW_SHA and a['size_in_bytes']==41503 and a['name']=='root-image-validation','API artifact differs')
jobs=receipt['jobs']['jobs'];running=[j for j in jobs if j['conclusion']!='skipped']
require(len(running)==1 and running[0]['id']==receipt['job_id'] and running[0]['name']=='validate' and running[0]['status']=='completed' and running[0]['conclusion']=='failure','API job state differs')
require(count==11 and {p.name for p in rawroot.iterdir()}=={'batch8-environment-exit-code.txt','batch8-environment.json','batch8-environment.log','batch8-native-isa-probe','batch8-native-isa-probe.sha256','batch8-probe-compiler-image.json','compiler.txt','docker-version.txt','input-sha256.txt','lscpu.txt','runtime-commit.txt'},'unexpected execution output inventory')
env=read(rawroot/'batch8-environment.json')
require(env=={'schema_version':1,'status':'unsupported_native_isa','native_row_isa':'avx512','selected_batch_isa':'avx2','avx2':True,'avx512':True,'database_runs':0,'pgo_builds':0,'performance_pairs':0},'not the allowed unsupported ISA branch')
require((rawroot/'batch8-environment-exit-code.txt').read_text().strip()=='78' and (rawroot/'runtime-commit.txt').read_text().strip()==reader.CANDIDATE_COMMIT,'exit/commit differs')
probe=rawroot/'batch8-native-isa-probe';reader.elf(probe.read_bytes());require(sha(probe)==(rawroot/'batch8-native-isa-probe.sha256').read_text().split()[0],'actual probe differs')
compiler=read(rawroot/'batch8-probe-compiler-image.json');require(len(compiler)==1 and 'gcc@'+reader.core.COMPILER.split('@')[1] in compiler[0]['RepoDigests'],'probe compiler digest differs')
inputs={}
for line in (rawroot/'input-sha256.txt').read_text().splitlines():
    h,p=line.split(maxsplit=1);p=p.lstrip('*');require(p not in inputs,'duplicate input');inputs[p]=h
require(set(inputs)==set(git(R,'ls-tree','-r','--name-only',reader.CANDIDATE_COMMIT,'--',*reader.INPUT_PATHS).decode().splitlines()),'complete root input inventory differs')
for p,h in inputs.items():require(digest(blob(R,reader.CANDIDATE_COMMIT,p))==h,'Git source mismatch '+p)
source_guard=reader.runtime_guard(R,reader.CANDIDATE_COMMIT)
shell=blob(R,reader.CANDIDATE_COMMIT,'minivec/tools/ci_score.sh').decode()
require(shell.index('exit "$probe_status"')<shell.index('bash minivec/tools/ci_crc_checks.sh --unit')<shell.index('docker build'),'unsupported branch does not precede all native/DB root gates')
rerun=read(W/'batch8-environment-rerun-receipt.json')
require(rerun['status']==201 and rerun['run_id']==receipt['run_id'] and rerun['rerun_job_id']==receipt['job_id'] and rerun['environment_attempt_requested']==2,'rerun receipt differs')
analysis={'status':'verified_environment_exclusion','candidate_commit':reader.CANDIDATE_COMMIT,'run_id':receipt['run_id'],'job_id':receipt['job_id'],'environment_attempt':1,
 'API_job_conclusion':'failure','classification':'predeclared unsupported native ISA; not an algorithm/correctness/performance failure',
 'artifact':{'path':RAW,'bytes':41503,'sha256':RAW_SHA,'artifact_id':a['id'],'file_count':count},'environment':env,'exit_code':78,
 'probe_binary_sha256':sha(probe),'probe_compiler_image_id':compiler[0]['Id'],'probe_native_builds':1,'root_PGO_builds':0,'database_runs':0,'performance_pairs':0,
 'root_Git_input_files_verified':len(inputs),'source_snapshot_files_verified':source_guard['source_snapshot_verified_count'],
 'evidence_scope':'The fixed Git shell exits at the ISA probe before DB/native correctness gates or root PGO; complete artifact has only 11 preflight outputs. No candidate gate or timing is claimed.',
 'API_job_inventory_limit':'Receipt contains the first 30 jobs, not an independently complete 36-job listing; only its reported validate job is asserted.',
 'rerun_request':rerun,'environment_attempt_limit':3,'algorithm_workload_threshold_changes':False,'selected_runtime_change':False,'formal_submission':False,
 'raw_files':{p.name:{'bytes':p.stat().st_size,'sha256':sha(p)} for p in sorted(rawroot.iterdir())}}
araw=enc(analysis);(W/'batch8-environment-attempt1-independent-analysis.json').write_bytes(araw)
files={'independent-analysis.json':araw,'reader/record_batch8_environment_attempt1.py':Path(__file__).read_bytes(),
 'api-receipt.json':(W/'batch8-environment-attempt1-api-receipt.json').read_bytes(),'rerun-receipt.json':(W/'batch8-environment-rerun-receipt.json').read_bytes()}
for name in ['analyze_batch8_primary_root.py','batch8_reader_gates.py','evaluate_batch8_primary24_screen.py','evaluate_norm_maxabs_primary24_screen.py','analyze_crc_root.py','analyze_highest_compare.py','analyze_cursor_root.py']:
    files['reader/'+name]=(W/name).read_bytes()
files['manifest.json']=enc({'scope':'Environment exclusion only; no DB/PGO/performance results','files':{n:{'bytes':len(b),'sha256':digest(b)} for n,b in sorted(files.items())}})
buffer=io.BytesIO()
with zipfile.ZipFile(buffer,'w',compression=zipfile.ZIP_DEFLATED,compresslevel=9) as z:
    for n,b in sorted(files.items()):
        info=zipfile.ZipInfo(n,(2026,11,14,0,0,0));info.external_attr=0o100644<<16;z.writestr(info,b,compress_type=zipfile.ZIP_DEFLATED,compresslevel=9)
archive=buffer.getvalue();raw=(R/'conversation.json').read_bytes();require(sha(R/'conversation.json')==MATERIAL_SHA and (R/'agent/conversation.json').read_bytes()==raw,'material source drift')
before=json.loads(raw);after=copy.deepcopy(before);e=after['experiments'][-1];require(e['id']=='batch8-avx2-highest-primary24','experiment drift')
e['status']='environment_attempt1_excluded_attempt2_requested';e['environment_attempts_completed']=1
e['artifacts'] += [{'path':RAW,'sha256':RAW_SHA},{'path':AUDIT,'sha256':digest(archive)}]
after['messages'].append({'id':'assistant-batch8-environment-attempt1','role':'assistant','content':'环境获取1：原生AVX512，预检退出78；仅构建ISA探针，DB/PGO/性能对数均0，不是算法失败。原证据已核验归档；同提交已请求第2次环境获取，最多3次规则及R默认不变。'})
require(after['messages'][:-1]==before['messages'] and after['experiments'][:-1]==before['experiments'][:-1],'history mutation')
material=enc(after);require(len(material)<=131072,'material overflow')
spec=importlib.util.spec_from_file_location('validate_env_attempt1',R/'minivec/tools/validate_iteration_material.py');v=importlib.util.module_from_spec(spec);spec.loader.exec_module(v);v.validate(R);v.check_structure(after,after)
require(not (R/AUDIT).exists(),'audit exists');(R/AUDIT).write_bytes(archive)
(R/'conversation.json').write_bytes(material);(R/'agent/conversation.json').write_bytes(material)
validation=v.validate(R)
result={'status':'applied','validation':validation,'audit_bytes':len(archive),'audit_sha256':digest(archive),'analysis_bytes':len(araw),'analysis_sha256':digest(araw),'user_objects_unchanged':True,'DB_runs_by_reader':0,'Git_mutations':0}
(W/'batch8-environment-attempt1-material-receipt.json').write_bytes(enc(result));print(json.dumps(result,indent=2))
