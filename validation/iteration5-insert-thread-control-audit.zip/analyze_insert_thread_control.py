"""Independent read-only audit of exactly eight imported R/N thread controls.

The current harness checkout has retained source. Its executable N is imported
from 7554753, never rebuilt here. Only Python readers/generators are executed.
"""
import argparse
import ast
import io
import importlib
import json
import math
from pathlib import Path
import re
from statistics import median
import sys
import tempfile
import zipfile
import analyze_crc_root as core
import analyze_highest_compare as highest
import analyze_insert_copy_root as insert
from analyze_crc_root import require,digest,sha,read,git,blob,safe_name,cpus,counters,io_counters,timings,lifecycle_timings,LABELS,TOOLS

N_COMMIT=insert.INSERT_COMMIT
HARNESS_COMMIT='33a52a7dd4426af059ec2334b7c93a07c38c93c9'
N_SHA='56061188b2f84127e563e1d061452ec6cc62c8fddbdf09c23bcf4d8b155c2784'
N_IMAGE='sha256:0d5a6f0a2757101bbca1c03dad4b4bb46d25b14dd56661eaf4b58a2e1041984e'
N_ARCHIVE='validation/iteration5-insert-copy-n-raw.zip'
N_ARCHIVE_SHA='a0e9d3e89add2e85ac841e01083ea7a29e220f2d4b65dd7cd6b3538c69278ae3'
N_ARCHIVE_BYTES=3723866
TASK_COUNTERS=('minflt','majflt','voluntary_ctxt_switches','nonvoluntary_ctxt_switches')


def control_plan():
    out=[]
    for i in range(4):
        for policy in (('default','single') if i%2==0 else ('single','default')):
            forward=(i%2==0)==(policy=='default')
            out.append({'scenario':'standard10k','seed':7319,'pair_index':i,
                        'order':['baseline','candidate'] if forward else ['candidate','baseline'],'policy':policy})
    return out


def policy_environment(policy):
    require(policy in ('default','single'),'unexpected control policy')
    return {} if policy=='default' else {'MVDB_PARSE_THREADS':'1','MVDB_QUERY_THREADS':'1'}


def reproduce_standard(repo,commit):
    insert.clear_generator_modules()
    with tempfile.TemporaryDirectory(prefix='mvdb-thread-workload-') as td:
        tree=Path(td)
        for path in TOOLS:
            target=tree/path;target.parent.mkdir(parents=True,exist_ok=True);target.write_bytes(blob(repo,commit,path))
        sys.dont_write_bytecode=True;sys.path.insert(0,str(tree/'minivec/tools'))
        try:
            h=importlib.import_module('small_compute');b=importlib.import_module('benchmark_iteration')
            w=importlib.import_module('benchmark_write_query');p=importlib.import_module('benchmark_projection')
            work=h.workload('standard10k',b,w,p,query_mode='exact')
            return {'standard10k':h.workload_identity('standard10k',work,b)}
        finally:
            sys.path.remove(str(tree/'minivec/tools'));insert.clear_generator_modules()


def imported_identity(root,repo,commit):
    programs=root/'programs';proof=read(programs/'import-proof.json');ids=read(programs/'identities.json')
    require(proof['status']=='verified' and proof['harness_commit']==commit and proof['harness_matches_git'] is True and
            proof['source_commit']==N_COMMIT and proof['binary_sha256']==N_SHA and proof['retained_binary_sha256']==core.BASE_BINARY and
            proof['archive_sha256']==N_ARCHIVE_SHA and proof['archive_bytes']==N_ARCHIVE_BYTES and proof['prior_image_id']==N_IMAGE and
            proof['prior_root_gates']==18 and proof['prior_verified_pairs']==24 and proof['new_root_builds']==proof['new_pgo_builds']==proof['new_database_runs']==0 and
            proof['runtime_policy_changed'] is False and proof['prior_candidate_adoption']=='not_adopted_default', 'import/harness scope differs')
    require(proof['identity_sha256']==sha(programs/'identities.json'),'identity file binding differs')
    tree=ast.parse(blob(repo,commit,'minivec/tools/prepare_insert_thread_control.py'))
    assignments=[n for n in tree.body if isinstance(n,ast.Assign) and any(isinstance(t,ast.Name) and t.id=='TOOLS' for t in n.targets)]
    require(len(assignments)==1,'diagnostic tool inventory declaration absent')
    # The only nonliteral member in this tuple is the pinned N archive constant.
    expected=set()
    for item in assignments[0].value.elts:
        if isinstance(item,ast.Name):require(item.id=='ARCHIVE','unknown dynamic diagnostic input');expected.add(N_ARCHIVE)
        else:expected.add(ast.literal_eval(item))
    require(set(proof['harness_file_sha256'])==expected and TOOLS.issubset(expected),'complete diagnostic input inventory differs')
    for path,h in proof['harness_file_sha256'].items():require(digest(blob(repo,commit,path))==h,'diagnostic Git input differs: '+path)
    require(proof['harness_file_sha256']['minivec/src/db.cpp']==insert.DB_SHA and
            proof['harness_file_sha256']['minivec/src/exec.cpp']=='366eb7a8f0bb22ae113aa9e841443f8913b4e876cc6599183bd6450f914137e5',
            'current checkout retained source restoration differs')
    raw=blob(repo,commit,N_ARCHIVE)
    require(len(raw)==N_ARCHIVE_BYTES and digest(raw)==N_ARCHIVE_SHA,'immutable original N artifact differs')
    with zipfile.ZipFile(io.BytesIO(raw)) as z:
        names=z.namelist();require(len(names)==len(set(names)),'prior artifact duplicate name')
        for name in names:safe_name(name)
        prefix='insert-copy-root/'
        manifest_raw=z.read(prefix+'hashes.json');entries=json.loads(manifest_raw)['artifacts']
        require(len({x['path'] for x in entries})==len(entries) and {prefix+x['path'] for x in entries}=={n for n in names if n.startswith(prefix)}-{prefix+'hashes.json'},'prior nested complete inventory differs')
        for entry in entries:
            safe_name(entry['path']);value=z.read(prefix+entry['path'])
            require(len(value)==entry['bytes'] and digest(value)==entry['sha256'],'prior member differs')
        oldids=json.loads(z.read(prefix+'programs/retained-identities.json'))
        oldroot=json.loads(z.read(prefix+'programs/root-proof.json'));gates=json.loads(z.read('root-gates-summary.json'))
        require(set(gates['checks'])==insert.GATES and gates['passed'] is True and all(v is True for v in gates['checks'].values()) and
                gates['insert_owned_copy_checks']=={'normal':952,'sanitized':952} and gates['runtime_commit']==oldroot['source_commit']==N_COMMIT and
                gates['image_binary_sha256']==oldroot['binary_sha256']==N_SHA and gates['image_id']==oldroot['image_id']==N_IMAGE and
                digest(z.read('root-gates-summary.json'))==oldroot['root_gate_summary_sha256'], 'historical N root gates identity differs')
        require(oldroot['root_input_manifest_sha256']==digest(z.read('input-sha256.txt')),'historical N input manifest differs')
        require(set(oldroot['root_input_sha256'])==set(git(repo,'ls-tree','-r','--name-only',N_COMMIT,'--',*core.INPUT_PATHS).decode().splitlines()),'historical complete N source inventory differs')
        for path,h in oldroot['root_input_sha256'].items():require(digest(blob(repo,N_COMMIT,path))==h,'historical N Git source differs')
        original_summary=json.loads(z.read(prefix+'summary.json'))
        require(original_summary['status']=='passed' and original_summary['exit_code']==0 and original_summary['expected_pairs']==original_summary['completed_pairs']==24 and original_summary['automatic_adoption'] is False,'prior N evidence incomplete')
        for dest,source in {'prior-root-gates.json':'root-gates-summary.json','prior-root-inputs.txt':'input-sha256.txt',
                'prior-n-summary.json':prefix+'summary.json','prior-manifest.json':prefix+'hashes.json'}.items():
            require((programs/dest).read_bytes()==z.read(source),'imported prior evidence changed')
        require(set(ids)=={'baseline','candidate'},'identity role inventory differs')
        for role,source,expected_sha in [('baseline',core.BASE,core.BASE_BINARY),('candidate',N_COMMIT,N_SHA)]:
            item=ids[role];old=oldids[role]
            require(item==old|{'binary':role+'-minivec','evidence_file':role+'-proof.json'},'imported identity changed beyond paths')
            require(item['source_commit']==source and item['binary_sha256']==expected_sha and item['environment']=={},'imported executable source/environment differs')
            program=(programs/item['binary']).read_bytes();insert.elf(program)
            require(program==z.read(prefix+'programs/'+old['binary']) and digest(program)==expected_sha,'imported actual ELF differs')
            require((programs/item['evidence_file']).read_bytes()==z.read(prefix+'programs/'+old['evidence_file']) and sha(programs/item['evidence_file'])==item['evidence_sha256'],'imported original proof differs')
        retained=read(programs/'baseline-proof.json')
        oldpaths=set(git(repo,'ls-tree','-r','--name-only',core.BASE,'--','minivec/src').decode().splitlines())|{'minivec/tools/pgo/train.cpp','minivec/tools/pgo/run-training.sh'}
        require(retained['status']=='verified' and retained['feature_flags']==core.FLAGS and set(retained['source_and_training_sha256'])==oldpaths,'retained source manifest incomplete')
        for path,h in retained['source_and_training_sha256'].items():require(digest(blob(repo,core.BASE,path))==h,'retained source differs')
        prior=json.loads(z.read(prefix+'retained-1cpu.json'))
        std=next(w for w in prior['workloads'] if w['scenario']=='standard10k')
        require(proof['standard_workload']==std,'prior standard workload binding differs')
    return proof,ids


def ingest_task_detail(run):
    p={x['phase']:x for x in run['adapter']['phase_cgroups']};b,a=p['before_ingest'],p['after_ingest']
    bc,ac=counters(b['cpu.stat']),counters(a['cpu.stat'])
    cpu={k:ac[k]-bc[k] for k in ('usage_usec','user_usec','system_usec','throttled_usec')}
    require(all(x>=0 for x in cpu.values()),'negative ingest CPU delta')
    old={};new={}
    for phase,target in ((b,old),(a,new)):
        require(phase.get('extended_counter_scope'),'extended counter scope absent')
        for task in phase['native_tasks']:
            identity=(task['tid'],task['starttime_ticks']);require(identity not in target,'duplicate task identity')
            require(all(type(task.get(k)) is int and task[k]>=0 for k in TASK_COUNTERS),'missing/invalid task counters')
            target[identity]=task
    matched=[];born=[]
    for identity,task in new.items():
        if identity in old:
            value={k:task[k]-old[identity][k] for k in TASK_COUNTERS};require(all(x>=0 for x in value.values()),'task counters move backwards')
            matched.append({'tid':task['tid'],'main':task['main'],'delta':value})
        else:born.append({'tid':task['tid'],'main':task['main'],'since_task_creation':{k:task[k] for k in TASK_COUNTERS}})
    vanished=[{'tid':k[0],'starttime_ticks':k[1]} for k in old.keys()-new.keys()]
    return {'cpu_delta':cpu,'matched_tasks':matched,'new_live_tasks':born,'vanished_tasks':vanished,
        'scope':'Matched TID/starttime deltas plus new live task lifetime counters. Tasks born and exited between snapshots are not observed; not a complete scheduler trace.'}


def policy_report(data,policy):
    pairs=[p for p in data['pairs'] if p['policy']==policy];require(len(pairs)==4,'policy not four pairs')
    ex=insert.extra_summary({'pairs':pairs})['standard10k'];phase_rows={}
    for pair in pairs:
        b,c=core.timings(pair['baseline']),core.timings(pair['candidate'])
        for name in b:
            phase_rows.setdefault(name,[]).append({'pair_index':pair['pair_index'],'order':pair['order'],'baseline':b[name],'candidate':c[name],
                'baseline_over_candidate':b[name]/c[name] if c[name] else None,'candidate_larger':c[name]>b[name]})
        bd,cd=(ingest_task_detail(pair[role]) for role in ('baseline','candidate'))
        for key in ('user_usec','system_usec','throttled_usec'):
            name='ingest_'+key;bvalue,cvalue=bd['cpu_delta'][key],cd['cpu_delta'][key]
            phase_rows.setdefault(name,[]).append({'pair_index':pair['pair_index'],'order':pair['order'],'baseline':bvalue,'candidate':cvalue,
                'baseline_over_candidate':bvalue/cvalue if cvalue else None,'candidate_larger':cvalue>bvalue})
    return {'derived_metrics':ex,'raw_phase_and_cpu_metrics':{k:highest.pair_summary(v) for k,v in phase_rows.items()}}


def audit(args):
    root,repo,commit=args.input.resolve(),args.repo.resolve(),args.commit
    require(commit==HARNESS_COMMIT,'reader is pinned to reviewed thread-control harness')
    count=core.verify_archive(root,args.archive.resolve(),args.artifact_sha256,args.artifact_bytes);core.manifest_tree(root)
    proof,ids=imported_identity(root,repo,commit);data=read(root/'measurements.json');summary=read(root/'summary.json')
    require(summary['status']=='passed' and summary['exit_code']==0 and summary['expected_pairs']==summary['completed_pairs']==8 and
            summary['harness_commit']==commit and summary['imported_runtime_sources']=={'baseline':core.BASE,'candidate':N_COMMIT} and
            summary['binary_sha256']=={'baseline':core.BASE_BINARY,'candidate':N_SHA} and summary['prior_candidate_image_id']==N_IMAGE and
            summary['new_root_builds']==summary['new_pgo_builds']==0 and summary['formal_submission'] is False and
            summary['automatic_adoption'] is False and summary['runtime_policy_changed'] is False and summary['candidate_default_status']=='not_adopted',
            'control result scope/inventory differs')
    local=reproduce_standard(repo,commit)
    require(data['workloads']==[local['standard10k']]==[proof['standard_workload']],'current standard SQL/oracle full-content hash differs')
    verified=verify_control_measurements(data,1,('standard10k',),root/'programs',ids,proof,local)
    reports={};negatives=[];differences={};detail_rows=[]
    for policy in ('default','single'):
        report=policy_report(data,policy);reports[policy]=report
        insert.collector_default(report['derived_metrics'],summary['policies'][policy])
        for kind,metrics in report.items():
            for metric,value in metrics.items():
                if value['candidate_larger_pairs']:negatives.append({'policy':policy,'metric_group':kind,'metric':metric,**value})
    for pair in data['pairs']:
        row={k:pair[k] for k in ('policy','pair_index','order')};row['baseline'],row['candidate']=(ingest_task_detail(pair[role]) for role in ('baseline','candidate'))
        m={role:insert.metrics(pair[role],'standard10k') for role in ('baseline','candidate')}
        mapping={'ingest_wall_seconds':'ingest_wall_seconds','ingest_cpu_usec':'ingest_cpu_usec',
                 'first_1000_queries_wall_seconds':'first_lifetime_query_total','first_1000_queries_cpu_usec':'first_queries_cpu_usec'}
        values={key:m['candidate'][source]-m['baseline'][source] for key,source in mapping.items()}
        values.update({key:row['candidate']['cpu_delta'][key]-row['baseline']['cpu_delta'][key] for key in ('user_usec','system_usec')})
        row['candidate_minus_baseline']=values;detail_rows.append(row);differences[(pair['policy'],pair['pair_index'])]=values
    require(detail_rows==summary['ingest_detail'],'collector task/CPU details differ')
    interactions={}
    for key in differences[('default',0)]:
        changes=[differences[('single',i)][key]-differences[('default',i)][key] for i in range(4)]
        interactions[key]={'single_minus_default_of_candidate_minus_baseline':changes,'median':median(changes)}
    require(interactions==summary['within_runner_policy_difference'],'policy interaction arithmetic differs')
    require(set(summary['policies'])=={'default','single'},'collector policy inventory differs')
    return {'status':'verified','verified_pairs':8,'artifact_sha256':args.artifact_sha256,'artifact_files':count,'harness_commit':commit,
        'imported_runtime_sources':{'baseline':core.BASE,'candidate':N_COMMIT},'binary_sha256':{'baseline':core.BASE_BINARY,'candidate':N_SHA},
        'prior_candidate_image_id':N_IMAGE,'prior_root_gate_groups':18,'prior_verified_pairs':24,'new_root_builds':0,'new_pgo_builds':0,
        'current_checkout_runtime':'Retained db/exec Git blobs; not built or executed by this diagnostic.',
        'historical_N_gates_scope':'Prior 7554753 image gates, not current checkout root validation.',
        'workload_identity_audit':local['standard10k'],'policies':reports,'all_negative_or_mixed_metrics':negatives,
        'ingest_task_details':detail_rows,'within_runner_policy_difference':interactions,'resources_and_policy':verified['resources_and_policy'],
        'host':data['host'],'actual_cpu_model':(root/'lscpu.txt').read_text(),'automatic_adoption':False,'official_score':None,
        'limitations':['Four paired runs per policy at one seed, interleaved and balanced AB/BA. No score floor or default-policy adoption.',
        'Both parse/query settings change together; query startup calibration also disappears with query=1. Interactions do not isolate parser, query worker, scheduler or allocator.',
        'N default regression/non-adoption remains. Same-run policy interaction is not a cross-run speedup calculation. All adverse raw pairs preserved.',
        'First-lifetime wall is a request/stage timer sum; CPU first-lifetime endpoint precedes shutdown. Ingest has three wall subtotals but only whole-stage CPU.',
        'Fault/context-switch counters describe tasks alive at snapshots; new live task counters start at task creation, vanished task work is incomplete. They are not a complete system-call trace.',
        'Exact SQL/oracle content is regenerated in Python only. Query oracle samples 0/1/999 plus all restart IDs and sampled vectors; not an independent oracle for every one of 1000 queries. All response digests match within pairs.',
        'Only cgroup CPU/memory/block-accounting and process IO proxies are available; not formal T/B/M or direct physical device traffic. No database ran during this audit.']}


def main():
    p=argparse.ArgumentParser(description=__doc__)
    for key in ('input','archive','output'):p.add_argument('--'+key,type=Path,required=True)
    p.add_argument('--repo',type=Path,default=Path(__file__).resolve().parent/'seekdb');p.add_argument('--commit',required=True)
    p.add_argument('--artifact-sha256',required=True);p.add_argument('--artifact-bytes',type=int,required=True);args=p.parse_args()
    require(not args.output.exists() and not args.output.resolve().is_relative_to(args.input.resolve()),'refuse overwrite/raw output')
    require(re.fullmatch('[0-9a-f]{40}',args.commit) and re.fullmatch('[0-9a-f]{64}',args.artifact_sha256),'full expected identities required')
    result=audit(args);args.output.write_text(json.dumps(result,ensure_ascii=False,indent=2,allow_nan=False)+'\n',encoding='utf8')
    print(json.dumps({'status':result['status'],'verified_pairs':result['verified_pairs'],'negative_metrics':len(result['all_negative_or_mixed_metrics']),'output':str(args.output)}))


def verify_control_measurements(data, count, cases, programs, ids, proof, workloads):
    expected = control_plan()
    require(data.get('insert_copy_reference') is None and data.get('insert_thread_control') is True, 'control family differs')
    require(data['status'] == 'passed' and data['expected_pairs'] == data['completed_pairs'] == len(data['pairs']) == len(expected), 'measurement incomplete')
    require(data['plan'] == expected and [{k: p[k] for k in ('scenario', 'seed', 'pair_index', 'order', 'policy')} for p in data['pairs']] == expected, 'measurement plan mismatch')
    require(data['query_mode_policy']=='exact','measurement mode is not exact')
    require(data['comparison_kind'] == 'whole_version_diagnostic' and data['official_score'] is None and data['official_binary_identity_known'] is False, 'scope mismatch')
    require(data['identity_record_sha256'] == sha(programs / 'identities.json'), 'identity JSON mismatch')
    require(data['workloads'] == [workloads[n] for n in cases], 'regenerated workload/oracle hash mismatch')
    require(data['db_cpu_count'] == count and len(set(data['db_cpus'])) == count and data['protection_only'] is False, 'CPU plan mismatch')
    require(set(data['db_cpus']).issubset(set(data['host']['driver_affinity'])), 'CPU selection outside inherited driver affinity')
    require(data['requested_limits'] == {'cpu_quota_us': count * 100000, 'cpu_period_us': 100000, 'memory_max': '2147483648', 'swap_max': '0'}, 'resource request mismatch')
    require(data['launcher_sha256'] == sha(programs.parent / 'cgroup_exec'), 'actual launcher differs')
    seen = {}
    for path, h in data['tool_hashes'].items():
        names = [name for name in TOOLS if path.endswith('/' + name)]
        require(len(names) == 1 and names[0] not in seen, 'tool path inventory mismatch')
        name = names[0]; seen[name] = h; require(proof['harness_file_sha256'][name] == h, 'executed tool differs from Git proof')
    require(set(seen) == TOOLS, 'tool set incomplete')
    for role in ('baseline', 'candidate'):
        item = data['identities'][role]
        for key in ('binary_sha256', 'source_commit', 'evidence_sha256', 'environment'):
            require(item[key] == ids[role][key], 'measured role identity mismatch')
        require(item['environment'] == {}, 'unexpected runtime override')
    details, grouped, lifecycle_grouped = [], {}, {}
    for pair in data['pairs']:
        name = pair['scenario']; require(pair['all_responses_identical'] is True, 'output equivalence absent')
        b, c = pair['baseline'], pair['candidate']; detail = {k: pair[k] for k in ('scenario', 'seed', 'pair_index', 'order', 'policy')}; detail['sides'] = {}
        for role, run in (('baseline', b), ('candidate', c)):
            g, adapter, policy = run['cgroup'], run['adapter'], run['thread_policy_observations']
            wanted = policy_environment(pair['policy'])
            require(run['declared_environment'] == wanted and run['effective_environment'] == wanted and run['thread_control_policy'] == pair['policy'] and run['query_mode_policy']=='exact', 'run override/mode differs')
            modes = adapter['completed_request_modes']
            require(set(modes) == {'exact'} and modes['exact'] > 0 and modes['exact'] == adapter['completed_transport_requests'],
                    'actual transport request mode differs')
            require(not g['timeout'] and not g.get('request_timeout_observed') and not g.get('cleanup_kill_required') and not g.get('watchdog_error') and not any(g['oom_events_delta'].values()), 'timeout/OOM/process failure')
            for when in ('before', 'after'):
                require(g[when]['cpu.max'].split() == [str(count * 100000), '100000'], 'actual quota differs')
                require(g[when]['memory.max'] == '2147483648' and g[when]['memory.swap.max'] == '0', 'actual 2GiB/swap0 differs')
            for ancestor in g['ancestor_constraints']:
                cap = ancestor['memory.max']
                require(not isinstance(cap, str) or not cap.isdigit() or int(cap) >= 2147483648,
                        'ancestor memory constraint below 2GiB')
            require(not g['after']['cgroup.procs'].strip(), 'live DB remains')
            ready = adapter['ready_memberships']; require(len(ready) == (1 if name == 'wide768' else 2), 'ready/restart evidence missing')
            for item in ready:
                require(item['pid'] in item['members'] and item['driver_pid'] not in item['members'] and
                        item['actual_exe'] == data['identities'][role]['binary'] and item['runtime_environment'] == wanted and cpus(item['cpus_allowed_list']) == set(data['db_cpus']), 'actual executable/cgroup/affinity mismatch')
            phases = adapter['phase_cgroups']; require(len(phases) == (14 if name == 'wide768' else 15 if name.startswith('spill_') else 8), 'phase observations missing')
            for phase in phases:
                require(phase['memory.max'] == '2147483648' and phase['memory.swap.max'] == '0', 'phase memory/swap cap differs')
                require(not phase.get('native_tasks_error') and not phase.get('task_read_errors') and phase['native_tasks'] and sum(t['main'] for t in phase['native_tasks']) == 1, 'native task evidence missing')
                require(all(cpus(t['cpus_allowed_list']) == set(data['db_cpus']) for t in phase['native_tasks']), 'native task affinity drift')
            before, after = counters(g['before']['cpu.stat']), counters(g['after']['cpu.stat'])
            require(g['resource_delta']['cpu_stat_delta'] == {k: v - before.get(k, 0) for k, v in after.items()} and
                    g['resource_delta']['memory_peak_bytes'] == int(g['after']['memory.peak']), 'resource arithmetic differs')
            ib, ia = io_counters(g['before']['io.stat']), io_counters(g['after']['io.stat'])
            require(g['resource_delta']['io_stat_delta'] == {dev: {k: v - ib.get(dev, {}).get(k, 0) for k, v in fields.items()} for dev, fields in ia.items()}, 'device IO counter arithmetic differs')
            require(policy['stderr_complete'] is True and policy['requested_query_threads'] == wanted.get('MVDB_QUERY_THREADS', 'automatic') and policy['requested_parse_threads'] == wanted.get('MVDB_PARSE_THREADS', 'automatic'), 'policy observations incomplete')
            logs = policy['fanout_log_lines']; wake = [x for x in logs if '(measured, median of 200 handshakes)' in x]
            require(len(wake) == (len(ready) if pair['policy'] == 'default' else 0), 'startup calibration does not match explicit policy')
            marker = 'single-CPU affinity; adaptive query fanout disabled, startup calibration retained'
            require(not any(marker in x for x in logs), 'rejected affinity policy unexpectedly active')
            cpu_intervals = {}
            by_phase = {x['phase']: x for x in phases}
            for start, end in (('after_index_build', 'query_before_update'), ('after_restart', 'query_after_restart')):
                if start in by_phase and end in by_phase:
                    left, right = by_phase[start], by_phase[end]
                    old = {(t['tid'], t['starttime_ticks']): t['cpu_ticks'] for t in left['native_tasks']}
                    cpu_intervals[end] = {'start': start, 'end': end, 'cpu_usage_usec': counters(right['cpu.stat'])['usage_usec'] - counters(left['cpu.stat'])['usage_usec'],
                        'nonmain_cpu_ticks_delta': sum(t['cpu_ticks'] - old.get((t['tid'], t['starttime_ticks']), 0) for t in right['native_tasks'] if not t['main']),
                        'scope': 'Includes restart ID/vector/payload verification.' if start == 'after_restart' else 'Post-index snapshot through first query phase; excludes restart verification.',
                        'nonmain_scope': 'All nonmain native tasks, not exclusively a named query worker.'}
            detail['sides'][role] = {'resources': g['resource_delta'], 'policy': policy, 'cpu_intervals': cpu_intervals}
        if name == 'wide768':
            for run in (b, c):
                require(run['status'] == 'passed' and set(run['phases']) == LABELS, 'projection phase schema differs')
                for phase in run['phases'].values():
                    require(all(r['search_mode']=='exact' for r in phase['requests']), 'projection sent a non-exact request')
                    require(len(phase['requests']) == 3 and phase['independent_oracle'] and phase['wall_seconds'] == sum(r['seconds'] for r in phase['requests']), 'projection oracle/timer evidence missing')
            for label in LABELS:
                require([(r['response_sha256'], r['response_bytes']) for r in b['phases'][label]['requests']] == [(r['response_sha256'], r['response_bytes']) for r in c['phases'][label]['requests']], 'projection responses differ')
        else:
            require(b['response_sha256'] == c['response_sha256'], 'lifecycle responses differ')
            for run in (b, c):
                require(all(q['modes']==['exact']*len(q['per_request_seconds']) for q in run['query'].values()), 'query mode trace is not all exact')
                if name.startswith('spill_'):
                    require(run['real_spill_observed'] is True and run['correctness']['all_query_responses_independent_oracle'] is True and len(run['write_cycles']) == 4 and len(run['query']) == 6 and
                            all(len(q['per_request_seconds']) == (16 if name.endswith('q16') else 1) for q in run['query'].values()), 'spill independent oracle/counts missing')
                    require(run['correctness']['all_restarted_ids_checked'] == 5000 and run['correctness']['all_mutated_payloads_and_tombstones_checked'] == [0, 1, 7, 1007], 'spill restart verification missing')
                else:
                    require(set(run['query']) == {'query_before_update', 'query_after_restart'} and all(len(q['per_request_seconds']) == 1000 for q in run['query'].values()) and
                            run['correctness']['sampled_topk_oracle_queries'] == [0, 1, 999], 'resident oracle/counts missing')
                    rows = workloads[name]['rows']
                    require(run['correctness']['all_restarted_ids_checked'] == rows and run['correctness']['restarted_vector_ids_checked'] == [0, 1, rows // 2, rows - 1], 'resident restart verification missing')
        bv, cv = timings(b), timings(c); require(set(bv) == set(cv), 'phase timers differ')
        for phase in bv:
            require(math.isfinite(bv[phase]) and math.isfinite(cv[phase]) and bv[phase] >= 0 and cv[phase] > 0, 'invalid measured timer')
            grouped.setdefault(name + '/' + pair['policy'], {}).setdefault(phase, []).append({'pair_index': pair['pair_index'], 'order': pair['order'], 'baseline_seconds': bv[phase], 'candidate_seconds': cv[phase], 'baseline_over_candidate': bv[phase] / cv[phase], 'candidate_slower': cv[phase] > bv[phase]})
        bl, cl = lifecycle_timings(b), lifecycle_timings(c)
        require(set(bl) == set(cl), 'derived lifecycle boundaries differ')
        for phase in bl:
            require(math.isfinite(bl[phase]) and math.isfinite(cl[phase]) and bl[phase] >= 0 and cl[phase] > 0,
                    'invalid derived lifecycle timer')
            lifecycle_grouped.setdefault(name + '/' + pair['policy'], {}).setdefault(phase, []).append({'pair_index': pair['pair_index'],
                'order': pair['order'], 'baseline_seconds': bl[phase], 'candidate_seconds': cl[phase],
                'baseline_over_candidate': bl[phase] / cl[phase], 'candidate_slower': cl[phase] > bl[phase]})
        details.append(detail)
    summary = {name: {phase: {'raw_pairs': rows, 'median_baseline_over_candidate': median(r['baseline_over_candidate'] for r in rows), 'candidate_slower_pairs': sum(r['candidate_slower'] for r in rows)} for phase, rows in phases.items()} for name, phases in grouped.items()}
    require(summary == data['summary'], 'independent summary arithmetic differs')
    lifecycle_summary = {name: {phase: {'raw_pairs': rows, 'median_baseline_over_candidate': median(r['baseline_over_candidate'] for r in rows),
        'candidate_slower_pairs': sum(r['candidate_slower'] for r in rows)} for phase, rows in phases.items()} for name, phases in lifecycle_grouped.items()}
    return {'verified_pairs': len(expected), 'summary': summary, 'derived_lifecycle_summary': lifecycle_summary,
            'lifecycle_scope': 'First lifetime sums startup, all measured requests and first shutdown; excludes restart and its verification/query/shutdown. Restart-inclusive totals are shown separately. These are sums of measured request/lifecycle timers, not end-to-end wall time including oracle work and telemetry gaps. Wide projection has no restart. No first-lifetime cgroup CPU total is inferred across unavailable shutdown boundaries.',
            'resources_and_policy': details,
            'host': data['host'], 'db_cpus': data['db_cpus'], 'ancestor_constraints': data['pairs'][0]['baseline']['cgroup']['ancestor_constraints']}

if __name__ == '__main__': main()
