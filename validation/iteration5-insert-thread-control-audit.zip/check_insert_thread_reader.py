"""Pure-Python thread-reader checks; never invokes a DB or a compiler."""
import ast
import copy
import json
from pathlib import Path
import sys
from types import SimpleNamespace
sys.dont_write_bytecode=True
import analyze_insert_thread_control as r

W=Path(__file__).resolve().parent
checks=[]
def check(name,fn):fn();checks.append({'name':name,'status':'passed'})
def need(value):
    if not value:raise AssertionError('preflight mismatch')
def reject(name,fn):
    try:fn()
    except (ValueError,KeyError,FileNotFoundError):checks.append({'name':name,'status':'passed','expected_rejection':True})
    else:raise AssertionError('bad evidence accepted: '+name)

check('reader_AST',lambda:ast.parse((W/'analyze_insert_thread_control.py').read_text(encoding='utf8')))
p=r.control_plan()
check('exact_8_unique_policy_pairs',lambda:need(len(p)==8 and len({(x['policy'],x['pair_index']) for x in p})==8))
for policy in ('default','single'):
    check(policy+'_4_balanced_AB_BA',lambda policy=policy:need(len([x for x in p if x['policy']==policy])==4 and
          sum(x['order']==['baseline','candidate'] for x in p if x['policy']==policy)==2))
check('explicit_two_environment_keys',lambda:need(r.policy_environment('default')=={} and
      r.policy_environment('single')=={'MVDB_PARSE_THREADS':'1','MVDB_QUERY_THREADS':'1'}))
reject('unknown_policy',lambda:r.policy_environment('query_only'))
actual=r.read(W/'performance/insert-copy-7554753/insert-copy-root/retained-1cpu.json')
reject('old_24data_cannot_be_control',lambda:r.verify_control_measurements(actual,1,('standard10k',),W,{}, {},{}))
reject('wrong_harness_pin',lambda:r.audit(SimpleNamespace(input=W,repo=W/'seekdb',commit=r.N_COMMIT)))
reject('missing_actual_artifact',lambda:r.audit(SimpleNamespace(input=W/'missing-thread',repo=W/'seekdb',commit=r.HARNESS_COMMIT,
      archive=W/'missing-thread.zip',artifact_sha256='0'*64,artifact_bytes=1)))
task={'tid':10,'starttime_ticks':3,'main':True,**{k:10 for k in r.TASK_COUNTERS}}
after={**task,**{k:12 for k in r.TASK_COUNTERS}}
born={'tid':11,'starttime_ticks':4,'main':False,**{k:5 for k in r.TASK_COUNTERS}}
fixture={'adapter':{'phase_cgroups':[
    {'phase':'before_ingest','cpu.stat':'usage_usec 10\nuser_usec 8\nsystem_usec 2\nthrottled_usec 0','native_tasks':[task],'extended_counter_scope':'controlled fixture'},
    {'phase':'after_ingest','cpu.stat':'usage_usec 20\nuser_usec 14\nsystem_usec 6\nthrottled_usec 0','native_tasks':[after,born],'extended_counter_scope':'controlled fixture'}]}}
d=r.ingest_task_detail(fixture)
check('matched_deltas_new_task_lifetime_separate',lambda:need(d['cpu_delta']=={'usage_usec':10,'user_usec':6,'system_usec':4,'throttled_usec':0} and
      d['matched_tasks'][0]['delta']==dict.fromkeys(r.TASK_COUNTERS,2) and d['new_live_tasks'][0]['since_task_creation']==dict.fromkeys(r.TASK_COUNTERS,5)))
bad=copy.deepcopy(fixture);del bad['adapter']['phase_cgroups'][1]['native_tasks'][0]['minflt']
reject('missing_extended_counter',lambda:r.ingest_task_detail(bad))
bad=copy.deepcopy(fixture);bad['adapter']['phase_cgroups'][1]['native_tasks'][0]['minflt']=9
reject('backwards_matched_counter',lambda:r.ingest_task_detail(bad))
bad=copy.deepcopy(fixture);bad['adapter']['phase_cgroups'][1]['native_tasks'].append(copy.deepcopy(after))
reject('duplicate_native_identity',lambda:r.ingest_task_detail(bad))
reuse=copy.deepcopy(fixture);reuse['adapter']['phase_cgroups'][1]['native_tasks'][0]['starttime_ticks']=8
check('reused_TID_is_new_task_not_delta',lambda:need(len(r.ingest_task_detail(reuse)['matched_tasks'])==0 and
      len(r.ingest_task_detail(reuse)['new_live_tasks'])==2 and len(r.ingest_task_detail(reuse)['vanished_tasks'])==1))
repo=(W/'seekdb').resolve()
check('harness_runtime_sources_distinct',lambda:need(r.HARNESS_COMMIT!=r.N_COMMIT and
      r.digest(r.blob(repo,r.HARNESS_COMMIT,'minivec/src/exec.cpp'))=='366eb7a8f0bb22ae113aa9e841443f8913b4e876cc6599183bd6450f914137e5'))
local=r.reproduce_standard(repo,r.HARNESS_COMMIT)
check('current_standard_full_SQL_oracle_hash_matches_prior',lambda:need([local['standard10k']]==actual['workloads'][:1]))
result={'status':'passed','check_count':len(checks),'checks':checks,'database_runs':0,'compiler_runs':0,
        'actual_new_artifact_verified':False,'harness_commit':r.HARNESS_COMMIT,'imported_N_source_commit':r.N_COMMIT,
        'reader_sha256':r.sha(W/'analyze_insert_thread_control.py'),
        'scope':'Pure reader controls, original workload Python regeneration and explicitly constructed task-counter fixtures. No constructed measurement is treated as performance evidence.'}
(W/'insert-thread-reader-preflight.json').write_text(json.dumps(result,indent=2)+'\n',encoding='utf8')
print(json.dumps({k:result[k] for k in ('status','check_count','database_runs','actual_new_artifact_verified','reader_sha256')}))
