# INSERT 原候选的 PGO 混杂因素复核

本次只读日志、Git和已归档二进制/profile数据，没有编译、运行数据库或更改仓库。现行8对线程诊断不变，N仍不默认采用，V2仍暂缓。

## 已核实证据

- 导入R/acdd来自 `bulk-loop-c3d421e/baseline-pgo`，context记录AMD EPYC9V74，CPU flags包含avx2、avx512f、avx512bw。当前N755根构建/测量记录AMD EPYC7763，flags含avx2而不含avx512。两者固定gcc13.3、四宏、O3/static编译tokens相同，没有 `-march=native`；训练器和训练shell源码SHA相同。
- R原独立构建额外保存instrumented/unstripped程序、symbols和gcda；N使用原根Docker流程，只记录gcda哈希，没有把gcda内容和instrumented程序放进artifact。因此原R/N不仅训练主机不同，证据收集步骤也不同；不能说已经是严格匹配的源码消融。
- 对R已归档instrumented ELF做只读ELF64解析，把 `__gcov_` 函数对象中的ident/line/cfg三个校验值与GCC13 gcda function记录对应，再读取arc counters。quantized `distance_avx512`、float `bound_sum_avx512`均有非零训练计数；两种AVX2函数也有非零计数。instrumented SHA及六份gcda SHA均与context proof和训练manifest逐一相符。原始数值/对应校验/哈希保存在 `work/retained-pgo-dispatch-counters.json`。这些是arc计数，未把某个槽位擅自标为函数调用次数。
- 量化选择器在 `quantized_bound.h` 的条件是avx512f+bw+avx2优先AVX512，否则AVX2；float bound选择器优先avx512f+avx2。AVX512函数在n<32时转调用AVX2。训练包含16/128/512维，因此不能说R从未训练AVX2，也不能用全量函数非零计数证明各维度覆盖均衡。
- N日志没有直接输出分派路径，N的gcda内容缺失。由相同选择器、未关闭AVX512的编译宏和7763的可见CPU特性，推断N训练128/512维走AVX2很有根据，但仍应标为源码+硬件推断，不冒充已读N函数计数。

## 历史已做与未做

E020四次独立PGO baseline（regression-ablation、bulk-typed、bulk-guard、bulk-loop）均生成acdd，主机覆盖Xeon8573C和EPYC9V45/9V74；C3原根CI在Xeon8370C也记录acdd。这些机器的存档均有AVX512，支持“多个AVX512主机曾复现同字节”，不能替代Zen3匹配重建。

Git历史中N复制机制首次在755引入，随后33a52a7恢复exec。已检查N原24对的prepare/root proof、CI构建日志和现有build context：N只新建一次实际根镜像，R是导入字节；尚未找到“同一runner、同根Docker路径重新构建R和N”这项实验的记录。旧其他候选做过同机重建，不等于N做过。现有24对只能说明两个固定whole-version程序在该机的差异，不能拆分为源码复制、反馈画像或布局各占多少。查询改善而INSERT用户态CPU下降，也不能反推PGO就是根因。

## 最小下一测试建议

相比马上改V2，匹配PGO重建更直接检验当前尚未排除的混杂因素。具体只需一轮、两次PGO构建、默认10k每CPU4对（1CPU与2CPU，共8对）；不加EE、不加V2、不加新场景或线程阈值矩阵，维持exact/2GiB/swap0和原COMMIT/完整首周期/负样本。

可固定R源码为 `33a52a7dd4426af059ec2334b7c93a07c38c93c9`，N源码为 `7554753868330006270cf39b1d32108f0a40ccac`。已核对两提交的Dockerfile、.dockerignore、完整src/third_party与PGO工具：只有 `minivec/src/exec.cpp` 不同。用同一runner顺序执行同一原根Docker路径和相同flags、同训练CPU可见集合，每个源码独立新建自己的profile；不跨源码复用gcda。保存两个实际根image/ELF/hash、完整输入、训练oracle/日志，并在不重新训练的前提下保留build-stage的profile和corpus证据。

新建的R/N各自使用新SHA，不替换旧acdd/5606标签。先比对它们与旧SHA：若都一致，就排除了本轮比较中“该次重建改变最终机器码”的解释；若变化，必须直接测新两个程序，不能乘旧比值。匹配主机与路径仍不能把源码改变诱发的PGO/代码布局变化与纯复制成本完全分开，也不能保证正式分数。本建议尚未实现、启动或测量，是否安排应等当前8对线程诊断结束。
