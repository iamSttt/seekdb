"""Small controlled thread-collector preflight; no DB execution."""
import ast,copy,json,sys
from pathlib import Path
w=Path(__file__).resolve().parent;t=w/'seekdb/minivec/tools';sys.path.insert(0,str(t))
import small_compute as s
from summarize_small_root import verify_measurement
from summarize_insert_thread_control import ingest_detail
checks=[]
def check(name,fn):fn();checks.append(name)
def need(ok):
 if not ok:raise AssertionError('failed controlled assertion')
def reject(fn):
 try:fn()
 except (ValueError,KeyError):return
 raise AssertionError('invalid fixture accepted')
for name in ('prepare_insert_thread_control.py','summarize_insert_thread_control.py','small_compute.py','summarize_small_root.py'):
 ast.parse((t/name).read_text(encoding='utf8'),filename=name)
raw=json.loads((w/'performance/insert-copy-7554753/insert-copy-root/retained-1cpu.json').read_bytes())
data=copy.deepcopy(raw);data.update(insert_thread_control=True,insert_copy_reference=None,
 expected_pairs=8,completed_pairs=8,plan=s.thread_control_plan(),pairs=[])
for entry in s.thread_control_plan():
 p=copy.deepcopy(raw['pairs'][entry['pair_index']]);p.update(entry)
 for role in ('baseline','candidate'):
  r=p[role];env=s.thread_control_environment(entry['policy'])
  r.update(declared_environment=env,effective_environment=env,thread_control_policy=entry['policy'])
  for ready in r['adapter']['ready_memberships']:ready['runtime_environment']=env
  for phase in r['adapter']['phase_cgroups']:
   if phase['phase'] in ('before_ingest','after_ingest'):
    phase['extended_counter_scope']='controlled fixture; not measured'
    for task in phase['native_tasks']:
     for key in ('minflt','majflt','voluntary_ctxt_switches','nonvoluntary_ctxt_switches'):
      task[key]=0 if phase['phase']=='before_ingest' else 1
 data['pairs'].append(p)
def verify(value):verify_measurement(value,1,('standard10k',),value['identity_record_sha256'],value['identities'],thread_control=True)
check('controlled_8_pair_inventory',lambda:verify(data))
for label,change in (
 ('missing_pair',lambda x:x['pairs'].pop()),
 ('policy_order',lambda x:x['pairs'][0].update(policy='single')),
 ('runtime_environment',lambda x:x['pairs'][0]['candidate']['adapter']['ready_memberships'][0].update(runtime_environment={'MVDB_QUERY_THREADS':'1'})),
 ('declared_environment',lambda x:x['pairs'][1]['candidate'].update(declared_environment={})),
 ('effective_environment',lambda x:x['pairs'][1]['candidate'].update(effective_environment={})),
 ('uncapped_memory',lambda x:x['pairs'][0]['baseline']['cgroup']['before'].update({'memory.max':'max'}))):
 broken=copy.deepcopy(data);change(broken)
 check('reject_'+label,lambda broken=broken:reject(lambda:verify(broken)))
r=data['pairs'][0]['candidate']
check('fault_switch_boundaries',lambda:need(len(ingest_detail(r)['matched_tasks'])==2 and len(ingest_detail(r)['new_live_tasks'])==1))
bad=copy.deepcopy(r);del bad['adapter']['phase_cgroups'][0]['native_tasks'][0]['minflt']
check('reject_missing_fault',lambda:reject(lambda:ingest_detail(bad)))
bad=copy.deepcopy(r);bad['adapter']['phase_cgroups'][0]['native_tasks'][0]['voluntary_ctxt_switches']=2
check('reject_backwards_switch_counter',lambda:reject(lambda:ingest_detail(bad)))
for policy in ('default','single'):
 entries=[x for x in s.thread_control_plan() if x['policy']==policy]
 check(policy+'_four_balanced_orders',lambda entries=entries:need(len(entries)==4 and sum(x['order']==['baseline','candidate'] for x in entries)==2))
record={'status':'passed','checks':checks,'count':len(checks),'linux_database_runs':0,
 'scope':'Python syntax and controlled old-result fixtures transformed into the new plan. No new measurement or Linux execution.'}
(w/'insert-thread-collector-preflight.json').write_text(json.dumps(record,indent=2)+'\n')
print(json.dumps({'status':'passed','checks':len(checks),'linux_database_runs':0}))
