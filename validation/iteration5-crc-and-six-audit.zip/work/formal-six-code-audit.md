# 六次正式成功记录的源码审计

审计对象是六个不可变提交及本轮指定起点 `a90b2b7`，未运行数据库、未改仓库、未恢复旧材料、未正式提测。正式 E、MySQL 通过及 Prompt 合并提示由主任务从平台观察后提供；本审计独立核实源码、构建输入和祖先关系。正式二进制及 T/B/M 明细仍未知。

最关键的事实有三点：`ff9c6bf` 与 `2d1dc24` 的完整选定运行构建输入相同，E 却下降 13.748%；最高分 `ee299ad` 不能直接用 `a90b2b7` 代替构建；`e020fde` 到 `7ca3baa` 没有找到默认启用算法的变化。它们都要求做同机、同输入、可绑定实际二进制的对照，不能从跨时间 E 差反推某一优化有罪。

| 提交 | 正式 E（平台观察转述） | 与上一个列出提交的源码关系 |
|---|---:|---|
| `fa562be89069a84215a6196c9e24e4c6274f3862` | 2180.028190 | 较早的精确 Flat/TopK 版本 |
| `ff9c6bfbe89e1045e12ac56652165245c834630c` | 2708.402710 | 领先 fa 9 个提交；增加 resident 直接遍历、BIGINT posting、保守 int8 拒绝、范数遍历顺序、距离投影复用及 float32 解析优化 |
| `2d1dc249bb64804e294b18f49a4634b427952c38` | 2336.046455 | 领先 ff 1 个提交；仅两份 conversation 文件变化，运行构建输入逐字节相同 |
| `ee299adb296a2922d01982aa6c5707d37e767b41` | **3014.419039** | 领先 2d 22 个提交；包含 WAL staging、借用 resident 向量、校准双线程扫描、并行 INSERT 解析、JSONL 快路径、过滤直接遍历及相关正确性修复 |
| `e020fdeb67dd8b64b77f0f8c2905f137f0112bba` | 2937.367246 | 领先 EE 31 个提交；采用 PGO、驻留预算与 UPDATE undo 修改、批量落盘、复合过滤缓存、spill 标量缓存、宽向量 JSON 编码 |
| `7ca3baad3f4c71970b01d194e8eee88a3606ff3b` | 2567.716075 | 领先 E020 8 个提交；默认构建策略相同，源码差异为未启用的 bulk 输出分支及诊断宏 |

祖先关系由 GitHub compare 的 `status=ahead`、`behind_by=0`、`merge_base=前项` 核实；EE 到 a90 另外领先 2 个提交。部分本地仓库是浅克隆，未声称本地 `git log` 已覆盖全部中间历史。API 对大型差异只返回 300 文件，因此完整运行输入来自 Git tree 枚举，不依赖截断的 API 文件清单。

## 最高分 EE 到 a90：受保护源码相同，完整构建输入不同

本地旧 Git 仓库可直接读取 EE 的 commit/tree/blob：

`C:/Users/Lenovo/Documents/Codex/2026-10-30/yan/work/round2-20261112-integration`

EE 的完整 tree 是 `18e18607350d36f5e7b701512d68afdd99df0628`。本审计对导出的每个 blob 重算 Git SHA1，并对 commit 对象重算 SHA1。清理记录中的 69 个 protected blob 在 EE/a90 两棵树中均匹配，但清理还删除了 `src/vector.cpp`、`vector.h`、`crc32.h`，Makefile 删除旧 `test_vector` 目标。

原根 Dockerfile 第 6 行使用 `src/*.cpp`，所以 EE 的编译输入确实包含 `vector.cpp`。即使它是未使用的旧接口、构建带 `--gc-sections`，也不能据此证明链接结果与删除该单元后的 a90 相同。最高版本对照必须使用完整 EE 原根 Docker，不能把部分参考快照或 a90 的构建结果标成 EE 原版。

已导出可复核的最小原构建上下文：

`work/formal-six-source/ee299adb296a2922d01982aa6c5707d37e767b41`

它含原 Dockerfile、.dockerignore、完整 src/third_party 与 Makefile，不含旧 conversation 或其他材料。完整文件清单和各 blob/SHA256 在同目录外的 `formal-six-code-audit.json`。运行构建输入清单摘要为 `9b733cef75f68f03174e526d29a24409e727437b31bc297a19554a575beecdd4`；此摘要按 JSON 内注明的路径—SHA256 映射计算，排除未被根 Docker 使用的 Makefile。

## EE 到 E020：需要分开验证的实际变化

以下位置均指固定导出目录 `formal-six-source/e020fdeb67dd8b64b77f0f8c2905f137f0112bba/`。

| 变化与代码位置 | 为什么值得复测 | 最小独立对照 |
|---|---|---|
| `Dockerfile:3` 默认 `ENABLE_PGO=1`，第 4 行新增四个 feature 宏 | 源码机制与编译训练同时改变，单纯源码差异不足以解释代码生成和场景权重 | 同一当前源码、四宏不变，只比较 PGO 0/1；保留原 EE 构建作为独立参照 |
| `flat_index.cpp:78` 驻留准入改为借用元数据，`:100` 修正 posting 构建预算；`db.cpp:2085` 范数排序受剩余预算限制 | 更多表能驻留并启用缓存，查询可能受益，但建索引、内存与临界路径也改变 | 覆盖 10k/30k/60k 和预算边界，记录建索引、首查、稳定查询、峰值内存；不能只比查询 |
| `db.cpp:1533` 有界 resident undo 替代旧版事务 UPDATE 强制整表 spill；全局旧图像额度为 1 MiB | 保留小 UPDATE 驻留优势，但增加图像分配、登记和提交清理 | 单行/批量 UPDATE，1 写 1 查/重复查；计入 BEGIN、COMMIT、重建和最终关闭 |
| `db.cpp:369` payload 批量写；`flat_index.cpp` 磁盘索引构建缓冲 | 减少系统调用同时增加暂存工作集 | 只切 `MVDB_DISABLE_PAYLOAD_BATCH`；单独核对 IO 和构建计时，不连带回退其他存储修复 |
| `db.cpp:2216` 多列/范围计划，`flat_index.cpp:598` 两槽 posting；`:742` 首次复合过滤保守路径 | 默认单条件缓存也换了表示；复合首次与复用成本不同 | 同源码加入 `MVDB_DISABLE_MULTI_POSTING`，其他宏不变；分别测单等值、范围、复合首次和复用 |
| `db.cpp:2059/2172` spill 标量缓存，最多两列；`exec.cpp:435` 宽向量 typed JSON | 特殊场景已有收益，但构建/筛选成本和输出分布不同 | 分别仅去掉 spill 宏、仅去掉 typed JSON 两个宏；保留大字符串 spill 与宽向量正确性保护负载 |
| `main.cpp:113/367` 关闭未使用的 `Statement.raw` 复制；`sql.cpp:1489` 保留显式开关 | 属于真正减少请求复制的变化，不能与宏下未启用 parser 草案混为一谈 | 与 ingest/解析阶段及内存一同观察，若要消融须只改该参数 |

`MVDB_ENABLE_INDEX_DELTA`、`MVDB_ENABLE_TOKEN_REUSE`、`MVDB_ENABLE_WORKLOAD_FANOUT`、块量化、pilot 等存在于源码，但默认 Docker 没有启用。尤其 `query_cost.h` 的默认包装直接退回原 `query_fanout_wanted`；不应把未启用的 CPU 探测或训练采样当成本轮正式退分原因。

也不能用 `FEATURE_FLAGS=""` 声称“所有新功能关闭”：multi-posting 默认就在 `#ifndef MVDB_DISABLE_MULTI_POSTING` 内，删去 `MVDB_MULTI_POSTING_REUSE_ONLY` 还会改变复合过滤启用时机。

## E020 到 7ca：没有定位到默认算法回退

完整选定输入中只变了 `exec.cpp` 和新增的 `json_response_diagnostics.h`。新 bulk 扩展要求 `MVDB_TYPED_BULK_VECTOR_ONLY`，诊断计数要求 `MVDB_JSON_RESPONSE_DIAGNOSTICS`，根 Docker 四宏均不包含它们；旧 wide-vector 条件保留。Docker、PGO 两个直接训练输入和其他运行源文件相同。

这是“没有发现默认启用逻辑变化”的源码结论，不是“正式二进制一定相同”。源码行号、编译过程、训练 profile、镜像或正式环境仍可能不同；本审计没有取得正式 executable SHA，也不把任何一种可能写成已证实原因。

## 下一步的判据

先用完整 EE 原根 Docker 生成可绑定镜像，与 retained R、当前 CRC C 在同一小算力运行中做配对。固定 exact 请求、种子和资源，旧/新交错执行；首段完整生命周期、重启阶段、重启后查询分别展示，并保留 CPU、内存峰值与设备 IO。需要恢复默认版性能时，再按上表只改变一个因素，保留 spill、宽向量、事务等已有优点的保护场景。

六次正式分数不能代替同机实验；同机小算力结果也不能承诺正式分数必然不低于 3014.419039。这个历史最高值应作为后续评估目标。没有新正式 T/B/M、二进制和评测配置前，不能证明哪一个成本项导致过去的下跌，也不能从共同的 Prompt 合并提示确定材料失败分支。

机器可读证据：`formal-six-code-audit.json`；六组规范化源码差异：`formal-code-*.diff`；API 祖先证据：`formal-history-api-*.json`。规范化差异只为阅读统一换行，身份核验使用原始 Git blob 字节。
