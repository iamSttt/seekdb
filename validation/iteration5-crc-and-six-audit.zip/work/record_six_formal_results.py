"""Record six authenticated UI observations, without repository credentials."""
import hashlib
import json
from pathlib import Path

repo = Path(__file__).resolve().parent / 'seekdb'
def sha(raw): return hashlib.sha256(raw).hexdigest()
def encode(value): return (json.dumps(value, ensure_ascii=False, separators=(',', ':'), allow_nan=False)+'\n').encode('utf8')
rows = [
    ('2026-11-13 23:23','7ca3baad3f4c71970b01d194e8eee88a3606ff3b','2567.716075'),
    ('2026-11-13 18:31','e020fdeb67dd8b64b77f0f8c2905f137f0112bba','2937.367246'),
    ('2026-11-12 19:52','ee299adb296a2922d01982aa6c5707d37e767b41','3014.419039'),
    ('2026-11-11 16:20','2d1dc249bb64804e294b18f49a4634b427952c38','2336.046455'),
    ('2026-11-11 12:23','ff9c6bfbe89e1045e12ac56652165245c834630c','2708.402710'),
    ('2026-11-10 21:33','fa562be89069a84215a6196c9e24e4c6274f3862','2180.028190'),
]
prompt = 'Prompt结果无效、待复核、超出平台0–100范围或缺少材料摘要，本项不参与排名；未截断或换算本地分数。'
observation = {
    'source_url':'https://open.oceanbase.com/train/TestRecord?questionId=600081',
    'read_by':'assistant', 'source':'Authenticated browser UI; each success row opened and three result rows read.',
    'observed_utc_date':'2026-11-13', 'visible_total_submissions':9,
    'successful_records_read':6, 'assistant_formal_submissions':0,
    'repository':'https://github.com/iamSttt/seekdb',
    'credential_policy':'Repository URL credentials omitted; only task-relevant visible result fields retained.',
    'records':[{'submitted_at_display':date,'branch':'codex/round2-optimize-20261112' if i<2 else '2026-competition-round2',
        'commit':commit,'task_status':'执行成功','success_count':1,'failure_count':0,
        'mysql_passed':True,'mysql_detail':'通过；此项为准入条件，不计排名分',
        'performance_E_decimal':value,'performance_E':float(value),
        'performance_detail':'性能评测完成；原始指标 E = '+value,
        'prompt_score':None,'prompt_counted':False,'prompt_detail':prompt}
        for i,(date,commit,value) in enumerate(rows)],
    'highest_observed_commit':rows[2][1],'highest_observed_E':float(rows[2][2]),
    'latest_vs_previous_percent':(float(rows[0][2])/float(rows[1][2])-1)*100,
    'latest_vs_highest_percent':(float(rows[0][2])/float(rows[2][2])-1)*100,
    'not_exposed':['elapsed T','disk B','memory M','formal executable SHA256','image digest',
        'PGO profiles','hardware allocation','exact workload','normalization baseline','specific Prompt failure cause'],
    'interpretation':'Six different submissions over time are observational evidence, not a controlled causal ablation. Local identical binary evidence cannot establish the identity of formal executable builds.'
}
artifact = repo / 'validation/iteration5-formal-six-results.json'
assert not artifact.exists(), 'refuse overwrite'
artifact.write_bytes(encode(observation))
raw = (repo/'conversation.json').read_bytes()
assert raw == (repo/'agent/conversation.json').read_bytes()
assert sha(raw) == 'a093c4daa9b307c7ba419b93f680ff4ef9ee04263155381cd44c15e06e2e9adc'
record=json.loads(raw)
for ident, text in [
    ('user-seven-ca3baa-score-decreased','请查收，你上一版分数更低了'),
    ('user-read-six-successful-submissions','你能否获得网站中成功提交的6次的数据'),
    ('user-learn-from-six-restore-highest','直接根据这六次，研究学习问题所在，让这一版本可以不低于其中最高那版本的分数')]:
    record['messages'].append({'id':ident,'role':'user','content':text,'source_kind':'current_user_message','sha256':sha(text.encode('utf8'))})
    record['provenance']['user_content_sha256'][ident]=sha(text.encode('utf8'))
record['messages'].append({'id':'assistant-six-formal-observation','role':'assistant','content':
    '已逐条读取六次成功记录：fa562=2180.028190、ff9c6=2708.402710、2d1dc=2336.046455、ee299=3014.419039、e020=2937.367246、7ca3baa=2567.716075；全部MySQL过、Prompt未计分且同一通用提示。最新比上次降12.58%、比最高降14.82%。六条不同时间记录不能单独归因代码，平台未显示T/B/M、实际程序摘要、硬件/负载或归一化基线；不将同源本地binary等同正式binary。按用户要求将最高ee299纳入同机对照，定位可复现退化，再修正候选；不保证未经正式评测的分数、不代为提交。CRC实测仍独立进行，尚未推荐正式提交。'})
ref={'path':artifact.relative_to(repo).as_posix(),'sha256':sha(artifact.read_bytes())}
record['experiments'].append({'id':'six-formal-score-observation','executed_by':'assistant','status':'read_only_platform_results_observed',
    'user_request_message':'user-learn-from-six-restore-highest','result_message':'assistant-six-formal-observation',
    'formal_submitted_by':'user','assistant_formal_submissions':0,'highest_commit':rows[2][1],
    'highest_E':float(rows[2][2]),'latest_commit':rows[0][1],'latest_E':float(rows[0][2]),'artifacts':[ref]})
record['official_result']={'new_submission':True,'submitted_by':'user','assistant_submitted':False,
    'commit':rows[0][1],'score':float(rows[0][2]),'score_kind':'performance_E','prompt_score':None,
    'mysql_passed':True,'target':6000,'highest_observed_E':float(rows[2][2]),'artifact':ref}
updated=encode(record)
assert len(updated)<=131072
for path in ('conversation.json','agent/conversation.json'): (repo/path).write_bytes(updated)
print(json.dumps({'bytes':len(updated),'remaining_bytes':131072-len(updated),'sha256':sha(updated),'records':6}))
