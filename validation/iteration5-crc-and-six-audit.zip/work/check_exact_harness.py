"""Controlled mode/resource/collector checks; never runs a database or Linux cgroup."""
import ast,copy,json,sys,tempfile
from pathlib import Path
from types import SimpleNamespace
w=Path(__file__).resolve().parent;tools=w/'seekdb/minivec/tools';sys.path.insert(0,str(tools))
import benchmark_iteration as b
import benchmark_index_delta as d
import benchmark_write_query as q
import benchmark_projection as p
import small_compute as s
import summarize_small_root as c
checks=[]
def check(name,fn):fn();checks.append(name)
def need(ok):assert ok
def reject(fn):
    try:fn()
    except (ValueError,KeyError,AssertionError):return
    raise AssertionError('invalid data accepted')

for path in [tools/name for name in ('small_compute.py','benchmark_iteration.py','benchmark_index_delta.py','benchmark_write_query.py',
                                    'benchmark_projection.py','summarize_small_root.py','prepare_small_compute.py')]:
    ast.parse(path.read_text(encoding='utf8'),filename=str(path))
check('exact_modes',lambda:need([b.query_mode_for(i,'exact') for i in range(4)]==['exact']*4))
check('legacy_mixed_modes',lambda:need([b.query_mode_for(i) for i in range(4)]==['exact','ann','exact','ann']))
check('invalid_mode_rejected',lambda:reject(lambda:b.query_mode_for(0,'hidden')))
a=b.make_workload((16,4,0,0),7319,4,4,3);e=b.make_workload((16,4,0,0),7319,4,4,3,'exact')
check('actual_standard_generator_modes_and_hash',lambda:need(a['queries']==e['queries'] and a['inserts']==e['inserts'] and
    a['query_modes']==['exact','ann','exact','ann'] and e['query_modes']==['exact']*4 and a['sha256']!=e['sha256']))
check('small_identity_binds_modes',lambda:need(s.workload_identity('standard10k',a,b)['sha256']!=s.workload_identity('standard10k',e,b)['sha256']))
for module,name,kwargs in ((d,'mixed_small',{'rows':6400,'dimension':4,'queries':4}),
                           (q,'spill_high_q1',{'cycles':1})):
    left=module.make_workload(name,7319,**kwargs);right=module.make_workload(name,7319,query_mode='exact',**kwargs)
    def modes(work):return [x['mode'] for group in [work['before'],*[v['queries'] for v in work['cycles']],work['after']] for x in group]
    check(name+'_actual_generator_modes',lambda left=left,right=right:need('ann' in modes(left) and set(modes(right))=={'exact'} and
        left['inserts']==right['inserts'] and left['sha256']!=right['sha256']))

class Wire:
    sequence=0
    def send(self,raw):self.request=json.loads(raw)
    def read_line(self,label):return json.dumps({'id':self.sequence,'ok':True,'affected_rows':0}).encode()+b'\n'
wire=Wire();sample=p.exchange(wire,'CREATE TABLE x(id BIGINT PRIMARY KEY);',affected=0,search_mode='exact')
check('projection_actual_wire_exact_and_record',lambda:need(wire.request['search_mode']==sample['search_mode']=='exact'))
wire=Wire();sample=p.exchange(wire,'CREATE TABLE x(id BIGINT PRIMARY KEY);',affected=0,search_mode='ann')
check('projection_argument_reaches_wire_without_override',lambda:need(wire.request['search_mode']==sample['search_mode']=='ann'))

# Execute the actual nested query_phase implementations with an observed request
# boundary and independent tiny response fixtures. No Session replacement or DB.
for module,work in ((b,e),(d,{'before':[{'sql':'q0','mode':'exact','oracle':[]},{'sql':'q1','mode':'exact','oracle':[]}]})):
    tree=ast.parse(Path(module.__file__).read_text(encoding='utf8'));node=next(n for n in ast.walk(tree) if isinstance(n,ast.FunctionDef) and n.name=='query_phase')
    sent=[];result={'query':{}};phases={}
    def request(sql,affected=None,mode='exact'):sent.append(mode);return .001,{'rows':[None]*3}
    env={'workload':work,'query_modes':work.get('query_modes'),'request':request,'result':result,'phases':phases,
         'math':__import__('math'),'summarize':b.summarize,'verify_query':lambda *a:None,'snapshot':lambda *a:None,'require':b.require,
         'base':SimpleNamespace(verify_query=lambda *a:None,require=b.require,summarize=b.summarize),
         'sample':lambda *a:None}
    exec(compile(ast.Module(body=[node],type_ignores=[]),str(module.__file__),'exec'),env)
    if module is b:env['query_phase']('test',{})
    else:env['query_phase']('test',work['before'])
    check(module.__name__+'_actual_query_phase_exact_forwarded',lambda sent=sent,result=result:need(sent and set(sent)=={'exact'} and result['query']['test']['modes']==sent))

raw=json.loads((w/'performance/small-compute-ba12c75/measurements.json').read_bytes())
def fixture(count):
    data=copy.deepcopy(raw);cases=s.CASES if count==1 else s.PROTECTION_CASES
    data.update(comparison_kind='whole_version_diagnostic',query_mode_policy='exact',db_cpu_count=count,db_cpus=list(range(count)),protection_only=count==2)
    data['requested_limits'].update(cpu_quota_us=count*100000,memory_max='2147483648',swap_max='0')
    data['pairs']=[x for x in data['pairs'] if x['scenario'] in cases]
    data['expected_pairs']=data['completed_pairs']=len(data['pairs'])
    for identity in data['identities'].values():identity['environment']={}
    for pair in data['pairs']:
        for role in ('baseline','candidate'):
            run=pair[role];run.update(query_mode_policy='exact',declared_environment={})
            trace=run['adapter'];trace['completed_request_modes']={'exact':trace['completed_transport_requests']}
            if 'query' in run:
                for phase in run['query'].values():phase['modes']=['exact']*len(phase['per_request_seconds'])
            else:
                for phase in run['phases'].values():
                    for sample in phase['requests']:sample['search_mode']='exact'
            for item in trace['ready_memberships']:item['cpus_allowed_list']='0' if count==1 else '0-1'
            group=run['cgroup']
            for observed in [group['before'],group['after'],*trace['phase_cgroups']]:
                observed.update({'cpu.max':f'{count*100000} 100000','memory.max':'2147483648','memory.swap.max':'0'})
            for ancestor in group['ancestor_constraints']:
                if isinstance(ancestor['memory.max'],str) and ancestor['memory.max'].isdigit():ancestor['memory.max']='2147483648'
            for phase in trace['phase_cgroups']:
                for task in phase['native_tasks']:task['cpus_allowed_list']='0' if count==1 else '0-1'
    return data,cases
for count in (1,2):
    data,cases=fixture(count)
    check(f'controlled_{count}cpu_exact_2GiB_metadata',lambda data=data,cases=cases,count=count:c.verify_measurement(data,count,cases,data['identity_record_sha256'],data['identities']))
    variants={
        'mixed_policy':lambda x:x.update(query_mode_policy='mixed'),
        'ann_phase':lambda x:x['pairs'][0]['candidate']['query']['query_before_update']['modes'].__setitem__(0,'ann'),
        'ann_forwarded':lambda x:x['pairs'][0]['candidate']['adapter']['completed_request_modes'].update(ann=1),
        'wrong_memory':lambda x:x['pairs'][0]['candidate']['cgroup']['before'].update({'memory.max':'max'}),
        'swap_enabled':lambda x:x['pairs'][0]['baseline']['cgroup']['after'].update({'memory.swap.max':'1'}),
        'lower_ancestor':lambda x:x['pairs'][0]['baseline']['cgroup']['ancestor_constraints'][0].update({'memory.max':'1048576'})}
    for label,change in variants.items():
        broken=copy.deepcopy(data);change(broken)
        check(f'{count}cpu_{label}_rejected',lambda broken=broken,cases=cases,count=count:reject(lambda:c.verify_measurement(broken,count,cases,broken['identity_record_sha256'],broken['identities'])))

record={'status':'passed','checks':checks,'count':len(checks),'linux_database_runs':0,
        'scope':'Actual workload generators and projection JSON wire encoding; extracted actual query_phase bodies with controlled responses; transformed old metadata fixtures for collector rejection. No new performance or Linux execution.'}
(w/'exact-harness-static-validation.json').write_text(json.dumps(record,indent=2)+'\n')
print(json.dumps({'status':'passed','checks':len(checks),'linux_database_runs':0}))
