"""Package original best-score build inputs, with minimal Git membership proof."""
import base64
import hashlib
import json
from pathlib import Path
import shutil
import subprocess
import zipfile

work=Path(__file__).resolve().parent; repo=work/'seekdb'
commit='ee299adb296a2922d01982aa6c5707d37e767b41'
audit=json.loads((work/'formal-six-code-audit.json').read_bytes())['records'][commit]
source=Path(audit['fixed_source_context']); old=Path(audit['source_repo'])
def git(*args): return subprocess.check_output(['git','-c','safe.directory='+old.as_posix(),'-C',str(old),*args])
def oid(kind,raw): return hashlib.sha1(kind.encode()+b' '+str(len(raw)).encode()+b'\0'+raw).hexdigest()
raw_commit=git('cat-file','commit',commit); assert oid('commit',raw_commit)==commit
trees={}
for name in (commit+'^{tree}',commit+':minivec',commit+':minivec/src',commit+':minivec/third_party'):
    sha1=git('rev-parse',name).decode().strip(); raw=git('cat-file','tree',sha1)
    assert oid('tree',raw)==sha1; trees[sha1]=base64.b64encode(raw).decode()
manifest={'source_commit':commit,'full_tree':audit['full_tree'],'files':audit['files'],
    'git_commit_raw_base64':base64.b64encode(raw_commit).decode(),'git_tree_objects_base64':trees,
    'scope':'Original selected root build inputs, no old conversation material; new rebuild is not the original official binary.'}
target=repo/'validation/iteration5-ee299-root-source.zip'; assert not target.exists()
with zipfile.ZipFile(target,'x',compression=zipfile.ZIP_DEFLATED) as out:
    for name,item in sorted(audit['files'].items()):
        raw=(source/name).read_bytes()
        assert raw==git('show',commit+':'+name) and hashlib.sha256(raw).hexdigest()==item['sha256']
        assert len(raw)==item['bytes'] and oid('blob',raw)==item['git_blob']
        out.writestr('context/'+name,raw)
    out.writestr('manifest.json',json.dumps(manifest,indent=2)+'\n')
raw_zip=work/'performance/crc-root-780be2c.zip'
assert raw_zip.stat().st_size==3020045 and hashlib.sha256(raw_zip.read_bytes()).hexdigest()=='70a0383fc86708ab680315fd9b98d5573d8dedc22f0bf70ea055e6abd7ab11b8'
raw_target=repo/'validation/iteration5-crc-root-raw.zip'; assert not raw_target.exists()
shutil.copyfile(raw_zip,raw_target)
print(json.dumps({'source_zip':str(target),'bytes':target.stat().st_size,'sha256':hashlib.sha256(target.read_bytes()).hexdigest(),
    'source_members':len(audit['files']),'tree_objects':len(trees)}))
