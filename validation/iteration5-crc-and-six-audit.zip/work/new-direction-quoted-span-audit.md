# quoted literal 普通片段批量复制审计

结论：不列为新的优先候选。当前默认 tokenizer 已对无转义、无连续同类引号的字符串使用 `memchr` 与一次 `assign`。普通引号包围的向量字面量会走这条路径，不能以“默认 10k 向量约 25 MB 全部逐字符 push_back”为优化依据。25 MB 是上游提出的工作量估计，本审计未重新测量。CRC 仍是唯一实际候选；CRC 与按目标列类型只复制 INSERT 所需值仍排在前面。

## 已存在的实现与历史

- `minivec/src/sql.cpp:388–410` 是默认 `std::vector<Tok>` 分支的 simple quoted fast path：先 `memchr` 找第一个同类引号，再在前缀内查反斜杠，并排除 doubled quote，随后 `t.text.assign(s,i+1,len)`。
- `sql.cpp:168–190` 的同一逻辑也存在于 `MVDB_ENABLE_TOKEN_REUSE` 分支。这个宏默认关闭不意味着 memchr 路径关闭：默认分支单独保留了相同实现。根 Dockerfile 的四个默认功能宏没有 TOKEN_REUSE。
- 直接读取最初指定的 `a90b2b750e40f020793cddefe01d5b66631afc63:minivec/src/sql.cpp`，已存在该无转义路径。因此它既不是本轮新增，也不应记作尚待完成的 quoted-span 优化。
- 当前只有含反斜杠、doubled quote 或未闭合文本落到 `sql.cpp:414–460` 的逐字符解码循环。当前默认和禁用 TOKEN_REUSE 两套复杂路径均未见普通 span 批量 append；旧 token 借用/复用改变所有权或保留容量，不能替代对此路径的证据。没有对全部历史提交进行穷尽搜索。

## 如果未来有实际复杂字符串热点，最小切入在哪里

仅替换复杂 quoted 路径中的普通字符复制部分，将下一控制字符前的连续字节一次 append；原反斜杠 switch、doubled quote、闭合判定及 Tok 所有权继续使用既有逻辑。无转义 fast path、AST、向量数字转换、解析线程池和 token cache 均不需要改变。当前没有足够的默认负载依据推进这一扩展，本文只保留边界说明。

需要避免引入新的二次扫描：若每处理一次反斜杠都从当前位置用 memchr 搜到字符串末尾的同类引号，密集反斜杠加远处结束引号会反复扫描长后缀。潜在实现需缓存下一同类引号位置，在该前缀内找反斜杠；只有消费掉该引号或越过缓存位置后才重新找下一引号。不能简单循环调用两个面向全部剩余 SQL 的 memchr 并宣称线性。

## 语义边界

- 单引号和双引号均作为字符串，只有当前同类引号终结；另一类是普通内容。
- 保留 `\n/\t/\r/\0/\b/\Z/\\/\'/\"/\%/\_` 及未知 escape 去掉反斜杠、保留后一个字节的既有行为；不得增加新的 SQL 转义解释。
- 连续同类引号解码为一个引号；被反斜杠消费的引号不能提前闭合。尾部单独反斜杠和缺少闭合引号继续产生 1064 与原有错误文本。
- 以 `std::string::size()` 限定搜索，允许嵌入 NUL、UTF-8 高位字节和实际换行；不得改用 `strlen` 或 NUL 终结搜索。
- 引号内注释符号保持数据，不进入外层注释解析。保留 token 起始位置、错误优先级、异常后 UNKNOWN 状态与拥有内存的 AST 生命周期。
- 若未来修改两套 tokenizer，需保持宏开启/关闭语义相同；不应顺带重新启用被否决的 TOKEN_REUSE。

## 已有测试与缺口（只读查看，未执行）

`test_sql.cpp` 的大批 INSERT 已覆盖 `a\nb''c`、quoted vector 保留文本、释放输入后的 AST 所有权、内嵌 NUL 和错误顺序；`test_parser_reuse.cpp` 覆盖 `left\nright''tail`、未闭合引号、2 MiB 无转义串、分配失败与重入；`json_protocol.py:typed_rows` 覆盖 UTF-8、doubled quote、tab/newline/CR/NUL/backslash 和空字符串。

这些现有例子不等于新的 span 实现已验证。只读检查未见专门覆盖“长普通前后缀夹一个 escape、密集 escape、引号与反斜杠紧邻扫描边界、两类引号全部组合、最后一个字节为反斜杠、所有未知 escape”的逐字节差分用例，也没有针对新算法扫描复杂度的证据。不是认定现有程序存在缺陷。

本次未修改仓库、未构建、未运行测试或数据库，没有性能收益结论；仅新增本审计文件。

审计时 HEAD：`780be2c8954ce5706f44abba5681d7326e41a27e`。`sql.cpp` SHA256：`9aff425726495cfa6ab396d08bf61e3484cde5e2a64356f461291e4e18699cd6`。
