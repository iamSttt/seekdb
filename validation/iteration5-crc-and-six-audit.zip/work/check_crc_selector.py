"""Controlled Python checks of fixture selection/expectations. No DB execution."""
import ast,importlib.util,json,struct,subprocess,zlib
from pathlib import Path
from unittest.mock import patch
W=Path(__file__).resolve().parent
P=W/'seekdb/minivec/tests/check_crc_persistence.py'
ast.parse(P.read_text(encoding='utf8'))
spec=importlib.util.spec_from_file_location('crc_fixture_check',P)
m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m)
def field(s):
 b=s.encode('utf8');return struct.pack('<I',len(b))+b
def marker(kind,lsn):return bytes((kind,1))+struct.pack('<Q',lsn)+field('')
def insert(key,lsn):
 body=bytes((1,1))+struct.pack('<Q',lsn)+field('crc_rows')+struct.pack('<I',4)
 body+=b'\1'+struct.pack('<q',key)+b'\1'+struct.pack('<q',key%2)
 body+=b'\2'+field("quoted '[1,2]' utf8 汉字 "+'x'*(17+key))
 body+=b'\3'+struct.pack('<I4f',4,float(key),-0.0,0.125,-3.5)
 return body
def frame(body):return struct.pack('<II',len(body),zlib.crc32(body))+body
bodies=[marker(16,1),insert(40,2),marker(17,3),marker(16,4),insert(59,5)]
raw=b''.join(map(frame,bodies));checks=[]
target=m.committed_insert(raw,m.records(raw),40)
assert target[0]==len(frame(bodies[0])) and target[1]==len(bodies[1])
checks.append('locate committed row by decoded schema/value/transaction, not file position')
def rejects(label,fn):
 try:fn()
 except (AssertionError,ValueError):checks.append(label)
 else:raise AssertionError('expected rejection: '+label)
rejects('uncommitted row is not selected',lambda:m.committed_insert(raw,m.records(raw),59))
rejects('missing row is not selected',lambda:m.committed_insert(raw,m.records(raw),41))
without_commit=b''.join(map(frame,[bodies[0],bodies[1],*bodies[3:]]))
rejects('missing COMMIT rejected',lambda:m.committed_insert(without_commit,m.records(without_commit),40))
bad_lsn=b''.join(map(frame,[bodies[0],bodies[1],marker(17,90),*bodies[3:]]))
rejects('wrong transaction LSN rejected',lambda:m.committed_insert(bad_lsn,m.records(bad_lsn),40))
duplicate=raw+b''.join(map(frame,[marker(16,6),insert(40,7),marker(17,8)]))
rejects('ambiguous duplicate target rejected',lambda:m.committed_insert(duplicate,m.records(duplicate),40))
corrupt=bytearray(raw);corrupt[target[0]+8+target[1]-1]^=1
rejects('independent frame reader rejects selected payload mutation',lambda:m.records(bytes(corrupt)))
rejects('truncated frame rejected',lambda:m.records(raw[:-3]))
def fake_process(keys):
 rows=[[k,k%2,"quoted '[1,2]' utf8 汉字 "+'x'*(17+k),[float(k),-0.0,0.125,-3.5]] for k in keys]
 payload=[{'type':'ready'},{'id':1,'ok':True,'columns':['id','tag','label','v'],'rows':rows},{'id':2,'ok':True}]
 return subprocess.CompletedProcess([],0,'\n'.join(map(json.dumps,payload))+'\n','')
with patch.object(m.subprocess,'run',return_value=fake_process((1,2,7,15))):
 m.query(Path('unused'),Path('unused'),(1,2,7,15));checks.append('committed-prefix response accepted')
with patch.object(m.subprocess,'run',return_value=fake_process((1,2,7,15,40))):
 rejects('reader ignoring damaged committed CRC fails expected IDs',lambda:m.query(Path('unused'),Path('unused'),(1,2,7,15)))
out={'status':'passed','checks':checks,'check_count':len(checks),'database_executions':0,
 'scope':'Synthetic framed bytes and mocked protocol responses only; actual old/new reader compatibility remains pending Linux.'}
(W/'crc-selector-python-validation.json').write_text(json.dumps(out,indent=2)+'\n')
print(json.dumps(out))
