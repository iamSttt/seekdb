"""Archive measured CRC evidence and six-score audits; never submit a benchmark."""
import hashlib
import json
from pathlib import Path
import zipfile

work=Path(__file__).resolve().parent; repo=work/'seekdb'
read=lambda p:json.loads(p.read_bytes())
analysis=read(work/'crc-root-analysis.json')
assert analysis['status']=='verified' and analysis['verified_pairs']==20
assessment={'status':'not_adopted_pending_historical_best_comparison',
    'candidate_commit':'780be2c8954ce5706f44abba5681d7326e41a27e',
    'candidate_binary_sha256':analysis['candidate_binary_sha256'],
    'root_pgo_builds':1,'verified_pairs':20,'unit_oracle_checks_each':35243,'actual_old_new_crc_checks':18,
    'run_id':43454350694,'job_id':131984426940,'artifact_id':14052519019,
    'artifact_sha256':'70a0383fc86708ab680315fd9b98d5573d8dedc22f0bf70ea055e6abd7ab11b8','artifact_bytes':3020045,
    'reason':'Single-CPU default first-lifetime timers and queries regressed in both orders. Spill/recovery benefits and two-CPU gains do not justify unconditional adoption.',
    'selected_runtime_changed':False,'assistant_formal_submissions':0,'formal_score_prediction':None,
    'lifecycle_scope':analysis['measurements']['1']['lifecycle_scope'],
    'screen':{cpu:{scenario:{name:{'median_baseline_over_candidate':item['median_baseline_over_candidate'],
        'candidate_slower_pairs':item['candidate_slower_pairs']} for name,item in phases.items()
        if name in ('first_lifetime_no_restart','restart_inclusive_excluding_verification')}
        for scenario,phases in data['derived_lifecycle_summary'].items()} for cpu,data in analysis['measurements'].items()},
    'uncertainty':'Only two pairs per scenario/CPU at one seed; a whole-version PGO contrast, not a pure CRC cost ablation.'}
path=work/'crc-candidate-assessment.json'; path.write_text(json.dumps(assessment,indent=2)+'\n',encoding='utf8')
raw=(repo/'conversation.json').read_bytes()
assert raw==(repo/'agent/conversation.json').read_bytes()
assert hashlib.sha256(raw).hexdigest()=='04982b2459d30e0266c11520a2f8ab6ded5fb26f1954d0b3fde7c47a1c6b4224'
prior=repo/'validation/iteration5-pre-comparison-material.json'; assert not prior.exists(); prior.write_bytes(raw)
files=['crc-root-analysis.json','analyze_crc_root.py','crc-root-analyzer-preflight.json',
    'crc-candidate-assessment.json','crc-selector-python-validation.json','check_crc_selector.py',
    'exact-harness-static-validation.json','check_exact_harness.py','crc-exact-cap-peer-review.json',
    'formal-regression-build-audit.md','formal-regression-workload-audit.md','formal-six-code-audit.md',
    'formal-six-code-audit.json','ee299-root-input-manifest.json','new-direction-quoted-span-audit.md',
    'record_six_formal_results.py','archive_highest_sources.py','archive_crc_and_six_audit.py']
target=repo/'validation/iteration5-crc-and-six-audit.zip'; assert not target.exists()
with zipfile.ZipFile(target,'x',compression=zipfile.ZIP_DEFLATED) as output:
    for name in files: output.writestr('work/'+name,(work/name).read_bytes())
with zipfile.ZipFile(target) as verify:
    assert verify.testzip() is None
    assert all(verify.read('work/'+name)==(work/name).read_bytes() for name in files)
print(json.dumps({'files':len(files),'bytes':target.stat().st_size,'sha256':hashlib.sha256(target.read_bytes()).hexdigest()}))
