# 正式回退分数与构建身份边界审计

本审计没有找到足以把最新正式降分归因于某个已知构建差异的证据，也没有证据可以把它称作噪声。本地最强事实恰恰是：E020 独立重建的 acdd 程序与 C3 默认根镜像记录的程序 SHA 相同；7ca 的完整28项运行构建输入又与 C3 一致。该事实限制了“7ca 又打开了失败优化导致退化”的解释，但不能证明两次正式评测使用相同程序、机器或负载。

## 正式观察的来源和算术

最新记录来自 root 在用户已登录页面的 CUA 观察，不是本子代理再次登录或直接读取平台：2026-11-13 23:23，提交 `7ca3baad3f4c71970b01d194e8eee88a3606ff3b`，原始 E=2567.716075，MySQL 准入通过，Prompt 没有有效分数，仍是合并错误提示。旧 E020 观察保存在 `validation/iteration4-formal-score-observation.json`。

- 相比 E020 的2937.367246：比值0.8741556162，下降12.584438%。
- 相比旧 EE299 的3014.419039：比值0.8518112584，下降14.818874%。

这是显示值的算术，不是数据库纯查询速度变化，也不是已验证的 E×10^4 映射。没有正式 T/B/M、官方二进制摘要、每次构建日志或重复轮次方差，不能从总 E 分解 CPU、内存、I/O 的责任。Prompt 无效也不等于已知为0分或能解释性能 E 的变化。

## Git 与实际构建证据

本次重新读取固定 Git 对象，而不是使用正在开发 CRC 的工作树来代表7ca。

1. 对 `work/affinity-rollback-proof.json` 的28项运行构建输入逐项重新计算7ca Git blob SHA，全部相同。包括根 Dockerfile、.dockerignore、Makefile、完整 src/third_party、两个 PGO 工具；参考提交为 `c3d421ed0c1f92deaef65cf2a8d28aaa9d477042`。7ca 没有保留上一轮被拒绝的启动 affinity 候选。
2. E020 对相同输入列表只有 `exec.cpp` 不同及新增 `json_response_diagnostics.h`。直接 Git diff 确认：新增 bulk 资格逻辑由未开启的 `MVDB_TYPED_BULK_VECTOR_ONLY` 包围；诊断宏在未开启 `MVDB_JSON_RESPONSE_DIAGNOSTICS` 时为 `((void)0)`。四个默认宏不变。不能只凭预处理意图证明二进制相同，但下项提供了实际 CI SHA 证据。
3. `work/root-c3d421ed-proof.json` 记录 C3 默认根镜像提取程序 SHA 为 `acddca115ab183bfc6419e27c9e3383cfd1a9046e3897e5ea516cd7bc0f29f54`，镜像ID为 `sha256:de94d922b6f781f4f7698b1186caa859096d73cc4647b7d252e056685c776913`。本次重新核对其原始 ZIP 59935字节，SHA `e5b9e1f0623ed74aedeecc8a978224e3dee0515f3ed22a2e48afce17cba18b7d`，与原 proof 相符。该小根门禁 artifact 保存的是 CI 提取摘要，不包含可再次重算的根程序字节。
4. 对 regression-ablation-76d7687、bulk-typed-c562aa2、bulk-guard-85cded3、bulk-loop-c3d421e 四份独立 E020 baseline-pgo/minivec 文件重新哈希，均为上述 acdd，均1477568字节。各 context 的 E020 source manifest、四宏与有效编译参数相同。记录主机包含 Intel Xeon8573C、AMD EPYC9V45和9V74。这至少反驳“每次重新PGO必然产生不同程序”的说法。
5. 所以可以说本地已观测到 E020重建程序=C3根程序；可以说7ca恢复了C3运行构建输入。不能把“相同输入”追加推理成“任何主机每次重建都保证acdd”，更不能据此把正式7ca或正式E020程序认定为acdd。

## Docker/PGO 配置：相同部分与真正的硬件依赖

E020与7ca的根 Dockerfile及两份训练源码逐字节相同。编译镜像固定到 `gcc:13.3.0-bookworm@sha256:1d71f0f3450214bef38fe09e6f610fb6cca90cf97b43f4ce845bfc32a4168818`。默认 ENABLE_PGO=1，参数为 `-O3 -std=c++17 -fno-math-errno -ffunction-sections -fdata-sections -Wl,--gc-sections -static -pthread -Isrc` 加四个默认宏；没有 `-march=native`、LTO或fast-math。训练先 `-fprofile-generate=/pgo -fprofile-update=atomic`，再 `-fprofile-use=/pgo -Werror=missing-profile -Werror=coverage-mismatch`，最后strip。release是scratch，仅复制程序和空data目录。

训练 seed=2026111201，exact请求，16/128/512维，分别1024/10000/1024行；同一数据库生命周期包含写入、查询、修改和重启。脚本以1和2个parse/query线程各跑3阶段，逐响应oracle验证。源码/输入确定性不能保证PGO计数完全确定：

- `distance.h:280` 在运行时按 CPUID 选择AVX512/AVX2/SSE2核；训练机器改变能改变哪些核被记录为热路径。没有native编译不等于训练过程无硬件依赖。
- `query_pool.h:221` 的wake探测使用steady_clock与200次握手排序；强制2线程训练仍会执行该探测。线程调度、样本排序及futex/spin路径的反馈可能改变。`train.cpp` manifest自身也明确说明调度及启动校准可影响profile。
- 若运行时可见在线CPU数或环境不同，`query_pool.h:137` 的模式选择、wake数值与自适应分拆会不同；parse默认线程数看hardware_concurrency。它们是现有代码对资源环境敏感的机制，并不证明正式平台发生了何种变化。1/2CPU、2GiB、swap0只是当前诊断设置，不能冒充正式配置。

四轮本地E020 gcda文件SHA不同，但最终strip程序仍相同。gcda SHA还含构建标识等因素，不能据SHA不同就断言有效计数或代码布局变化。因此本次不能把PGO列为已确认降分原因；只有“官方可能重新训练且缺少其产物”的身份缺口成立。

另一个真实历史提醒是 c562 默认根镜像曾记录62fe4ded…，而其独立E020基线是acdd。`work/root-vs-ablation-build-review.json` 明确未查明当时精确差异原因，旧根 artifact 未保留instrumented/gcda/unstripped字节。那是另一个提交，不能移用来声称7ca正式程序不同。C3后续实际根SHA已匹配acdd。

## 哪些解释足够成立，哪些仍不能成立

| 项目 | 已有证据能支持什么 | 不能据此声称什么 |
|---|---|---|
| 默认功能源码再次退化 | E020到7ca只有关闭宏下代码和空诊断；本地C3根与E020重建SHA相同 | 不能凭正式降分锁定新增bulk/affinity为原因；它们没默认开启 |
| 平台重新构建/训练 | Docker在构建时执行训练，存在运行硬件和调度依赖；平台产物未公开 | 不能认定正式程序与acdd确实不同，也不能定量解释12.58% |
| 资源/负载或评分基线不同 | 用户转述资源记忆不确定，T/B/M及官方配置不可见；程序有资源敏感机制 | 不能断言平台换机、负载变化、基准漂移或全是噪声 |
| 本地小算力结果迁移 | 同轮配对可以筛本地候选，旧单CPU实验显示fanout机制对受限CPU敏感 | 不能把旧结果乘上正式E，亦不能将被2CPU保护组否决的策略重新默认启用 |
| 材料与Prompt | 两份材料变化不会进入scratch release中的程序执行路径；Prompt分支原因未知 | 不能说材料压缩导致E下降，或随意猜一个字段就修好Prompt |
| EE299显示值较高 | 可以保留3014.419039为历史比较值 | 不是回退整个旧EE版本的充分证据；正式环境和功能变化未隔离 |

## acdd 的准确称呼与下一步边界

应称“由E020源码、已验证四宏/PGO流程独立构建且固定保存的本地CI基线程序”。`prepare_small_compute.py` 的 provenance 已明确 `official_binary_sha256:null`、`official_image_identity_proven:false`。它与C3实际根CI提取SHA匹配，这增强了开发版本绑定，却没有建立官方构建链。

我们目前既不能证明acdd等于正式二进制，也不能证明不等于。平台同commit字段只绑定请求的源码标识，缺少实际镜像ID、程序SHA、build args、训练画像及运行环境，无法完成剩余身份链。这是缺证，不是已复现平台或已确定根因。

继续以用户指定a90开发基线及已验证保留功能为准，先完成当前CRC唯一实际候选的小算力同轮对照与保护场景，保留负面结果；按目标列类型只复制INSERT所需值仍是下一候选。不要因单次分数回落未经验证回旧EE，也不要自动正式提交。任何后续本地收益只描述对应程序和环境，正式结果留用户决定是否再试。

本次仅只读源码、Git对象和历史本地证据，新增本审计文件；未读取浏览器凭据、未修改仓库、未运行数据库或新性能实验。最新平台反馈来自root观察，未独立重复登录。

## 新增：最高EE299与a90/E020的构建差异

用户最新要求以六次成功记录中的最高3014.419039作对照。以下是独立只读Git验证，不是把旧分数迁移到新版本：旧完整仓库 `C:/Users/Lenovo/Documents/Codex/2026-10-30/yan/work/round2-20261112-integration` 确实含完整EE299对象。此前报告工作目录reference-ee299ad只是部分摘录，缺third_party/.dockerignore/Makefile，不能直接拿来构建。

EE299到a90的根Dockerfile与.dockerignore逐字节相同。19个旧src文件中仅移除了crc32.h/vector.cpp/vector.h，另Makefile删除旧vector测试目标；其余受保护运行文件相同。本次还复核cleanup-static内69个protected Git blob均与a90一致。更早e8534416dcef2af64847330ffedb12831e45885d到EE299的Docker、.dockerignore、Makefile、src、third_party完全无diff。cleanup-ci记录4212和e853提取程序SHA同为 `9a437ae19ff20dbd7ab2e3242ce16c3b814d80536a0768c628d93d53a7b14bbd`，提供旧清理未改变实际产物的CI证据；它仍不是正式EE产物的公开摘要。

| 构建维度 | EE299与a90 | E020与7ca |
|---|---|---|
| 编译器镜像 | 相同GCC13.3.0固定digest | 相同 |
| 根优化参数 | O3/C++17/fno-math-errno/function-data sections/gc-sections/static/pthread | 原参数保留 |
| PGO | 无训练工具输入，无generate/use阶段 | 默认ENABLE_PGO=1，构建时六阶段原PGO |
| 功能宏 | 根Docker无额外FEATURE_FLAGS | spill filter、typed JSON、wide-only typed、multi-posting reuse四宏 |
| 根上下文 | Docker/.dockerignore/src/third_party | 另外允许并复制train.cpp、run-training.sh |
| release | scratch，程序和空data | 同样；训练文件不进入release |
| Make默认 | O2警告选项，非根Docker使用的O3 | 已修改测试/四宏等；不能以make参数替代根构建对比 |

EE根Docker SHA256为 `d262b689634801e3280f004c7b918afd87a696365fc50ad9e718932c4c63035e`。已把从旧完整Git直接读取的所有原根输入路径和SHA另存为 `work/ee299-root-input-manifest.json`，没有checkout或更改旧/新仓库。

这证明最高历史源码与当前保留版本存在真实的功能和PGO差异，足以说明“当前acdd就是最高历史程序”不成立：两者不能靠标签视作相同对照。它还不能把2.56%或14.82%正式差值归因于PGO或任何单宏；同时发生了运行算法、内存预算与IO路径等变化，需同轮直接比较完整版本。仅在当前源码加ENABLE_PGO=0，测到的是当前算法的无PGO消融，不是最高EE源码恢复。

## 最高历史真实根构建的合规对照路径（尚未执行）

存在可执行的路径，继续使用用户已允许的实验CI；不需要新建云聊天，不改变a90开发基线，不调用正式评测，也不接触登录凭据。

1. 从固定EE完整Git对象生成新的隔离构建上下文，只放原根Docker/.dockerignore与完整src/third_party，逐路径与本次manifest及Git tree核对。不以部分reference目录、当前src或当前Docker代替。CI可只fetch该固定commit到对象库，或携带按原Git blob构造并验证的上下文；不能覆盖当前工作树。
2. 在Linux上原样执行EE根Docker一次，不传当前四宏、不加PGO、不改查询或评分逻辑。保存完整构建日志、镜像ID、实际提取/minivec的SHA、root inputs和compiler image。旧9a437 SHA是可核对的历史CI参考；新build若不相同应调查并保留差异，不能直接宣称已恢复官方二进制。
3. 复用独立oracle/协议及共同输入正确性门禁，任一实际结果不符就记录失败，不能删除断言来使历史程序通过。数据目录各侧独立、请求相同，不把旧程序的文件直接当新程序性能输入。
4. 在同一个CI主机直接比较“EE原根重建程序”和“当前真正候选根程序”，使用一致exact、1/2逻辑CPU、2GiB/swap0诊断约束，保留AB/BA、写入/重启/首查询/保护场景与所有负样本。当前候选可导入本轮已绑定CI artifact的实际程序避免重复PGO；必须重验原archive、proof和program SHA。不能把本轮C/acdd乘下一轮acdd/EE来拼接C/EE。
5. 现成 `prepare_small_compute.py` 固定COMMIT=E020/BINARY_SHA=acdd，不能替换字节或改source标签混用。需要独立历史来源proof/identity入口，并让collector校验EE完整根输入/实际程序；通用measurement runner的version contrast可复用，旧E020结果和导入器保留。这个建议尚未编写或运行新的CI分支。

这是把最高历史源码变为真实可运行对照，不是保证正式分数≥3014.419039的方法。正式程序、T/B/M及环境仍不公开；最多能够在已声明的本地同机条件下拒绝明显落后于历史整版本的候选。最终提交次数由用户控制。
