#!/usr/bin/env python3
"""Prepare, never install, a readable semantic compaction of CLOSED experiments.

Only allowlisted historical observed_result objects change. All phase ratio
medians/extrema, scenario counts, resource medians, decisions, commits, hashes,
failure records, current experiments, and user/assistant messages stay intact.
Removed absolute endpoints/secondary diagnostics remain in the pre-existing
snapshot/artifacts and in an exact local restoration journal.
"""
import argparse,copy,hashlib,importlib.util,json,re
from pathlib import Path

CLOSED=(
 'linux-runtime-gate-4d8de','paired-performance-165-pairs','hotpath-linux-gate',
 'hotpath-paired-90','final-selected-tree-gate','round2-150-pairs',
 'round2-linux-8dbd206','round2-residual-fraction','round2-dot-default-135',
 'round2-linux-61a2b2f','round2-PGO-helper-compile-failure','round2-dot-forced-AVX2',
 'round2-PGO-isolation','round2-linux-502931d','round2-final-PGO-only-105')
TIMING_COLUMNS={'timing_seconds','phase_seconds','seconds'}
RESOURCE_COLUMNS={'resources','resources_proxy','resource_baseline_candidate'}
META_PROTECTED=('decision','recommendation','status','scope','limits','limitations',
                'findings_and_limits','negative_median_results')
def dumps(value):
 return json.dumps(value,ensure_ascii=False,separators=(',',':'),allow_nan=False).encode('utf-8')
def sha(value):return hashlib.sha256(value).hexdigest()
def walk(value,path=()):
 yield path,value
 if isinstance(value,dict):
  for key,child in value.items():yield from walk(child,path+(key,))
 elif isinstance(value,list):
  for i,child in enumerate(value):yield from walk(child,path+(i,))
def get(value,path):
 for key in path:value=value[key]
 return value
def tables(value):
 return [(path,obj) for path,obj in walk(value)
         if isinstance(obj,dict) and isinstance(obj.get('columns'),list)
         and isinstance(obj.get('rows'),dict)]
def core_metrics(result):
 """Compare every scenario's timing ratio triples, counts, resources, seed
 trends and worst-pair identity. Absolute endpoint medians are not ratio data."""
 core={}
 delta_resources=any(value==['baseline_median','candidate_minus_baseline']
                     for path,value in walk(result) if path and path[-1] in ('resource_columns','resource_array_columns'))
 def expanded_resources(value):
  if isinstance(value,list):
   if delta_resources and len(value)==2 and all(type(n) is int for n in value):
    return [value[0],value[0]+value[1]]
   return [expanded_resources(child) for child in value]
  if isinstance(value,dict):return {k:expanded_resources(v) for k,v in value.items()}
  return value
 for path,table in tables(result):
  for name,row in table['rows'].items():
   record={}
   for column,value in zip(table['columns'],row):
    if column in TIMING_COLUMNS or column=='phase_paired_ratios':
     record['phase_paired_ratios']=[None if item is None else item[-3:] for item in value]
    elif column in RESOURCE_COLUMNS:record[column]=expanded_resources(value)
    elif column in ('pairs','rows','dimension','updated_rows',
       'padding_bytes','groups','queries_per_phase','seeds','query_by_seed','lifecycle_by_seed',
       'query_minmax','query_faster_pairs','phase_medians','p95_ratios','query_p95_ms'):
     record[column]=value
    elif column in ('worst_life','worst_paired_lifecycle'):
     record[column]=value[:2]+value[-1:] if len(value)==5 else value
   core['/'.join(map(str,path))+'/'+name]=record
 return core
def prune_table_column(table,name):
 if name not in table['columns']:return
 i=table['columns'].index(name)
 table['columns'].pop(i)
 for row in table['rows'].values():row.pop(i)
def compact(result,identifier,counts):
 delta_resources=identifier in ('paired-performance-165-pairs','hotpath-paired-90',
     'round2-150-pairs','round2-dot-default-135','round2-dot-forced-AVX2')
 def pack_resources(value):
  if isinstance(value,list):
   if len(value)==2 and all(type(n) is int for n in value):
    counts['resource_pairs_delta_encoded']+=1
    return [value[0],value[1]-value[0]]
   return [pack_resources(child) for child in value]
  if isinstance(value,dict):return {k:pack_resources(v) for k,v in value.items()}
  return value
 for _,table in tables(result):
  for i,column in enumerate(table['columns']):
   if column in TIMING_COLUMNS:
    for row in table['rows'].values():
     for j,metric in enumerate(row[i]):
      if metric is not None:
       assert isinstance(metric,list) and len(metric)==5, (identifier,column,metric)
       row[i][j]=metric[2:];counts['phase_endpoint_pairs_removed']+=1
    table['columns'][i]='phase_paired_ratios'
   elif column=='worst_life':
    for row in table['rows'].values():
     metric=row[i]
     assert len(metric)==5
     row[i]=metric[:2]+metric[-1:]
   elif column in RESOURCE_COLUMNS and delta_resources:
    for row in table['rows'].values():row[i]=pack_resources(row[i])
  # These were diagnostic context, not phase result/range/resource data.
  prune_table_column(table,'fanout_diagnostics')
  prune_table_column(table,'slowest')
 for _,obj in list(walk(result)):
  if not isinstance(obj,dict):continue
  for key in ('metric_columns','metric_array_columns'):
   if key in obj:
    value=obj[key]
    if len(value)==5 and value[0] in ('baseline_median','base_median'):
     obj[key]=['median','min','max']
  if delta_resources:
   for key in ('resource_columns','resource_array_columns'):
    if key in obj:obj[key]=['baseline_median','candidate_minus_baseline']
  if 'resources_proxy_columns' in obj:
   aliases={'maximum_observed_process_hwm_bytes':'process_HWM_bytes',
            'pre_shutdown_process_io_read_bytes':'proc_read_bytes',
            'pre_shutdown_process_io_write_bytes':'proc_write_bytes',
            'persistent_files_after_final_shutdown_bytes':'persistent_bytes'}
   obj['resources_proxy_columns']=[aliases.get(value,value) for value in obj['resources_proxy_columns']]
  for old in ('timing_seconds_columns',):
   if old in obj:obj['phase_paired_ratios_columns']=obj.pop(old)
  if 'worst_life_columns' in obj:
   value=obj['worst_life_columns'];obj['worst_life_columns']=value[:2]+value[-1:]
  for key in ('fanout_histogram_key','fanout_diagnostics_columns',
              'slowest_columns','slowest_requests','slowest_paired_lifecycle_sample_columns'):
   obj.pop(key,None)
  # Plain GitHub numeric IDs preserve source identity without repeated URL
  # prefixes. No artifact hashes or schema_reference objects are removed.
  for key,value in list(obj.items()):
   if key in ('ci_run','ci_job','source_run','source_job','run') and isinstance(value,str):
    match=re.fullmatch(r'https://github\.com/iamSttt/seekdb/actions/runs/([0-9]+)(?:/job/([0-9]+))?',value)
    if match:
     obj[key]=int(match.group(2) or match.group(1));counts['github_url_prefixes_removed']+=1
 if identifier=='round2-150-pairs':
  for key in ('profile_columns','profile_repeat_pass_medians','profile_responses_identical',
              'slowest_query_columns','worst_lifecycle_columns','seed_columns'):
   result.pop(key,None)
 if identifier=='round2-dot-forced-AVX2':
  result['metric_columns']=['median','min','max']
  result['resource_columns']=['baseline_median','candidate_minus_baseline']
  result['worst_life_columns']=['seed','pair','ratio']
 if identifier=='paired-performance-165-pairs':
  result['inline_scope']=(
    'Closed history through round2-final-PGO-only: all scenario phase ratios are baseline/'
    'candidate (>1 faster), median/min/max. Columns label resource baseline/delta. '
    'Omitted absolute endpoints and fanout/profile/slowest-request details remain in '
    'validation/iteration3-prior-material-snapshot.zip and hashed artifacts. '
    'GitHub sources use run/job IDs; A/B/C and messages/audit are unchanged.')

def main():
 parser=argparse.ArgumentParser(description=__doc__)
 parser.add_argument('--source',type=Path,default=Path(__file__).parent/'seekdb/conversation.json')
 parser.add_argument('--output-dir',type=Path,default=Path(__file__).parent/'compact-old-metrics')
 args=parser.parse_args();source=args.source.resolve();root=source.parent
 source_bytes=source.read_bytes();original=json.loads(source_bytes)
 candidate=copy.deepcopy(original)
 counts={'phase_endpoint_pairs_removed':0,'github_url_prefixes_removed':0,'resource_pairs_delta_encoded':0}
 old_results={}
 for experiment in candidate['experiments']:
  if experiment['id'] not in CLOSED:continue
  result=experiment['observed_result']
  old_results[experiment['id']]=copy.deepcopy(result)
  compact(result,experiment['id'],counts)
 # Fully exact restore is available from the sidecar's old observed_result
 # objects; human-readable current metrics do not require this restoration.
 restored=copy.deepcopy(candidate)
 for experiment in restored['experiments']:
  if experiment['id'] in old_results:experiment['observed_result']=copy.deepcopy(old_results[experiment['id']])
 assert restored==original, 'modification escaped historical observed_result'
 assert candidate['messages']==original['messages']
 assert candidate['provenance']==original['provenance']
 assert candidate['attribution_audit']==original['attribution_audit']
 original_by_id={e['id']:e for e in original['experiments']}
 key_values={}
 for experiment in candidate['experiments']:
  identifier=experiment['id']
  if identifier not in old_results:
   assert experiment==original_by_id[identifier];continue
  before,after=old_results[identifier],experiment['observed_result']
  a,b=core_metrics(before),core_metrics(after)
  assert a==b, ('core metric changed',identifier)
  for key in META_PROTECTED:
   if key in before:assert before[key]==after[key],(identifier,key)
  # Preserve every commit/artifact/binary/user hash occurrence and its value.
  def hashes(obj):
   return sorted(v for _,v in walk(obj) if isinstance(v,str) and re.fullmatch('[0-9a-f]{40}|[0-9a-f]{64}|sha256:[0-9a-f]{64}',v))
  assert hashes(before)==hashes(after), ('hash changed or removed',identifier)
  key_values[identifier]={'scenario_count':len(a),'core_sha256':sha(dumps(a)),
                         'before_bytes':len(dumps(before)),'after_bytes':len(dumps(after))}
 suffix=b'\r\n' if source_bytes.endswith(b'\r\n') else b'\n' if source_bytes.endswith(b'\n') else b''
 assert dumps(restored)+suffix==source_bytes, 'source is not the expected canonical JSON serialization'
 encoded=dumps(candidate)+suffix
 assert json.loads(encoded)==candidate
 # Reuse owning validator's recursive table/pointer/quote checks against the
 # candidate, and verify artifacts against the real repository without writes.
 spec=importlib.util.spec_from_file_location('material_validator',root/'minivec/tools/validate_iteration_material.py')
 validator=importlib.util.module_from_spec(spec);spec.loader.exec_module(validator)
 validator.check_structure(candidate,candidate)
 for experiment in candidate['experiments']:
  for artifact in experiment.get('artifacts',[]):validator.check_artifact(root,artifact)
  reference=experiment.get('observed_result',{}).get('schema_reference')
  if reference:validator.check_artifact(root,reference,'file')
 user_hashes={entry['id']:sha(entry['content'].encode('utf-8')) for entry in candidate['messages'] if entry['role']=='user'}
 assert user_hashes==candidate['provenance']['user_content_sha256']
 assert source.read_bytes()==source_bytes, 'source changed during preparation; rerun on latest input'
 out=args.output_dir.resolve();out.mkdir(parents=True,exist_ok=True)
 (out/'conversation.candidate.json').write_bytes(encoded)
 (out/'restore-observed-results.json').write_bytes(dumps({'source_sha256':sha(source_bytes),
       'serialization_suffix':suffix.decode('ascii'),'observed_results':old_results}))
 report={'source':str(source),'source_bytes':len(source_bytes),'candidate_bytes':len(encoded),
         'saved_bytes':len(source_bytes)-len(encoded),'saved_KiB':(len(source_bytes)-len(encoded))/1024,
         'remaining_bytes':131072-len(encoded),'source_sha256':sha(source_bytes),
         'candidate_sha256':sha(encoded),'main_material_modified':False,'counts':counts,
         'checks':{'exact_restore_roundtrip':True,'byte_exact_restore_roundtrip':True,
                   'json_roundtrip':True,'core_metrics_unchanged':True,
                   'messages_provenance_attribution_audit_unchanged':True,'hash_occurrences_unchanged':True,
                   'table_pointer_quote_and_artifact_checks':True},
         'per_experiment':key_values,
         'application':'Rerun on latest main material. Root must review/apply both material copies and run full validator.'}
 (out/'validation.json').write_text(json.dumps(report,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
 print(json.dumps({k:report[k] for k in ('source_bytes','candidate_bytes','saved_bytes','saved_KiB','remaining_bytes','counts','checks')},indent=2))
if __name__=='__main__':main()
