import ast,hashlib,json,re,subprocess
from pathlib import Path
w=Path(__file__).resolve().parent;r=w/'seekdb'
s=(r/'minivec/tools/tighter_bound/ci_prototype.sh').read_text()
blocks=re.findall(r"<<'PY'\n(.*?)\nPY\n",s,re.S)
assert len(blocks)==4
for block in blocks:ast.parse(block)
old=subprocess.check_output(['git','-c','safe.directory='+r.as_posix(),'-C',str(r),'show','ebd6d25f27ad1a32fa92d84bcd571ae86b55394e:.github/workflows/minivec-score.yml']).decode()
new=(r/'.github/workflows/minivec-score.yml').read_text()
a=re.findall(r'^    if: \$\{\{ (.+) \}\}$',old,re.M);b=re.findall(r'^    if: \$\{\{ (.+) \}\}$',new,re.M)
assert len(a)==36 and len(b)==37
assert all(y=="!contains(github.event.head_commit.message, '[tighter-bound-prototype]') && ("+x+")" for x,y in zip(a,b))
assert b[-1]=="contains(github.event.head_commit.message, '[tighter-bound-prototype]')"
assert "post.update({name:Path('/sys/fs/cgroup/'+name).read_text().strip()" in s
root=r/'minivec/tools/tighter_bound';manifest=json.loads((root/'handoff-manifest.json').read_bytes())
assert len(manifest['files'])==14
for item in manifest['files']:
    raw=(root/item['path']).read_bytes();assert len(raw)==item['bytes'] and hashlib.sha256(raw).hexdigest()==item['sha256']
assert {p.name for p in root.iterdir() if p.is_file()}=={x['path'] for x in manifest['files']}|{'handoff-manifest.json','ci_prototype.sh'}
result={'status':'static_checks_passed','old_predicates_preserved_under_exclusion':36,'new_job_count':1,'embedded_Python_AST_blocks':4,
 'frozen_handoff_files':14,'wrapper_sha256':hashlib.sha256((root/'ci_prototype.sh').read_bytes()).hexdigest(),
 'scope':'Static source/marker check; no native/DB/CI or YAML schema validation',
 'postflight_fix':'Read live cgroup and affinity after subprocess returns; a nonzero runner exit remains the returned exit.',
 'native_runs':0,'database_runs':0}
(w/'tighter-bound-independent-ci-static-review.json').write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps(result))
