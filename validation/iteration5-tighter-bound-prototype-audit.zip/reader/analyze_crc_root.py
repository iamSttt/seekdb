"""Read-only independent audit of actual-root 12+8 pair IEEE CRC candidate evidence.

Never executes a database or changes an archive. Recreates deterministic input and
oracle content from Git-verified Python generators solely to compare workload hashes.
"""
import argparse
import ast
from functools import lru_cache
import hashlib
import importlib
import json
import math
from pathlib import Path, PurePosixPath
import re
from statistics import median
import struct
import subprocess
import sys
import tempfile
import zipfile
import zlib

BASE = 'e020fdeb67dd8b64b77f0f8c2905f137f0112bba'
BASE_BINARY = 'acddca115ab183bfc6419e27c9e3383cfd1a9046e3897e5ea516cd7bc0f29f54'
FLAGS = ['-DMVDB_ENABLE_SPILL_FILTER', '-DMVDB_ENABLE_TYPED_JSON', '-DMVDB_TYPED_WIDE_VECTOR_ONLY', '-DMVDB_MULTI_POSTING_REUSE_ONLY']
COMPILER = 'gcc:13.3.0-bookworm@sha256:1d71f0f3450214bef38fe09e6f610fb6cca90cf97b43f4ce845bfc32a4168818'
CASES = ('standard10k', 'resident30k', 'filter60k', 'spill_high_q1', 'spill_high_q16', 'wide768')
PROTECTION = ('standard10k', 'resident30k', 'spill_high_q16', 'wide768')
TOOLS = {'minivec/tools/small_compute.py', 'minivec/tools/benchmark_iteration.py',
         'minivec/tools/benchmark_index_delta.py', 'minivec/tools/benchmark_write_query.py',
         'minivec/tools/benchmark_projection.py', 'minivec/tests/json_protocol.py',
         'protocol_check/_transport.py', 'protocol_check/config.json'}
LABELS = {'narrow_top10', 'wide_top10', 'narrow_large4096', 'wide_large4096', 'narrow_all', 'wide_all', 'wide_distance10'}
GATES = {'root_docker_build', 'ieee_crc_byte_oracle_normal_and_sanitized',
         'image_official_handshake_and_public_cases', 'source_official_handshake_and_public_cases',
         'live_stdin_errors_utf8_fragment_shutdown_restart_commit_sigkill', 'make_test',
         'native_spill_cache_budget_writer_and_54_utf8_cases', 'actual_image_54_utf8_atomicity_cases',
         'selected_spill_and_utf8_asan_ubsan', 'parser_ownership_serial_parallel_and_quantized_bound_asan_ubsan',
         'image_binary_json_and_exact_topk_serial_parallel', 'eight_wal_failure_cases_asan_ubsan',
         'query_pool_both_modes_asan_ubsan', 'cross_table_spill_asan_ubsan', 'full_binary_json_ubsan',
         'index_budget_and_resident_update_asan_ubsan', 'compound_reuse_diagnostic_and_sanitizer'}
INPUT_PATHS = ('Dockerfile', '.dockerignore', 'minivec/src', 'minivec/third_party',
               'minivec/Makefile', 'minivec/tests', 'minivec/tools/ci_score.sh',
               'minivec/tools/ci_final_performance.sh', 'minivec/tools/pgo/train.cpp',
               'minivec/tools/pgo/run-training.sh', 'STDIO_PROTOCOL.md', 'protocol_check', 'mysqltest')


def require(value, message):
    if not value: raise ValueError(message)


def digest(raw): return hashlib.sha256(raw).hexdigest()
def sha(path): return digest(path.read_bytes())
def read(path): return json.loads(path.read_bytes())


@lru_cache(maxsize=None)
def git(repo, *args):
    return subprocess.check_output(['git', '-c', 'safe.directory=' + repo.as_posix(), '-C', str(repo), *args])


def blob(repo, commit, path): return git(repo, 'show', commit + ':' + path)


def safe_name(name):
    p = PurePosixPath(name)
    require(name and not p.is_absolute() and p.as_posix() == name and
            not any(x in ('.', '..') for x in p.parts) and
            not any(x in name for x in ('\\', ':', '\0')), 'unsafe path: ' + name)


def verify_archive(root, archive, expected_sha, expected_bytes):
    require(archive.stat().st_size == expected_bytes and sha(archive) == expected_sha, 'artifact API identity differs')
    with zipfile.ZipFile(archive) as z:
        items = z.infolist(); names = [i.filename for i in items]
        require(len(names) == len(set(names)) and len(names) < 1000 and
                sum(i.file_size for i in items) < 512 * 1024**2, 'archive bounds/duplicates')
        for item in items:
            safe_name(item.filename)
            require(not item.is_dir() and (item.external_attr >> 16) & 0o170000 != 0o120000, 'directory/symlink archive entry')
        require(set(names) == {p.relative_to(root).as_posix() for p in root.rglob('*') if p.is_file()}, 'extracted file inventory differs')
        for name in names: require(digest(z.read(name)) == sha(root / name), 'extracted bytes differ: ' + name)
    return len(names)


def cpus(text):
    values = set()
    for part in text.split(','):
        require(re.fullmatch(r'[0-9]+(?:-[0-9]+)?', part) is not None, 'invalid observed CPU mask')
        ends = part.split('-'); first, last = int(ends[0]), int(ends[-1])
        require(0 <= first <= last < 1048576, 'invalid CPU bounds')
        new = set(range(first, last + 1)); require(not new.intersection(values), 'duplicate CPU'); values.update(new)
    return values


def counters(raw): return {p[0]: int(p[1]) for line in raw.splitlines() if len(p := line.split()) == 2}


def io_counters(raw):
    return {parts[0]: {key: int(value) for key, value in (p.split('=', 1) for p in parts[1:])}
            for line in raw.splitlines() if (parts := line.split())}


def timings(run):
    if 'phase_seconds' in run:
        out = dict(run['phase_seconds'])
        for phase, record in run['query'].items():
            samples = record['per_request_seconds']
            for name, sub in (('first', samples[:1]), ('front64', samples[:64]), ('after64', samples[64:])):
                if sub: out[phase + '/' + name] = math.fsum(sub)
        return out
    return {**{'lifecycle/' + k: v for k, v in run['lifecycle_seconds'].items()},
            **{'query/' + k: v['wall_seconds'] for k, v in run['phases'].items()},
            'accounted_timer_sum': math.fsum(run['lifecycle_seconds'].values()) + math.fsum(x['wall_seconds'] for x in run['phases'].values())}


def lifecycle_timings(run):
    """Derived disjoint request-timer sums, never elapsed wall-clock claims."""
    if 'phase_seconds' not in run:
        return {'first_lifetime_no_restart': math.fsum(run['lifecycle_seconds'].values()) +
                math.fsum(p['wall_seconds'] for p in run['phases'].values())}
    phases = run['phase_seconds']
    excluded = {'restart', 'restart_verification_wall', 'query_after_restart',
                'final_shutdown', 'measured_lifecycle'}
    require(excluded.issubset(phases) and 'shutdown' in phases and 'startup' in phases,
            'lifecycle boundary evidence missing')
    first = math.fsum(value for key, value in phases.items() if key not in excluded)
    restart = math.fsum(phases[key] for key in ('restart', 'query_after_restart', 'final_shutdown'))
    total = math.fsum((first, restart))
    require(math.isclose(total, phases['measured_lifecycle'], rel_tol=1e-12, abs_tol=1e-12),
            'separated lifecycle does not reconcile')
    return {'first_lifetime_no_restart': first, 'restart_part_excluding_verification': restart,
            'restart_inclusive_excluding_verification': total,
            'restart_inclusive_with_verification': math.fsum((total, phases['restart_verification_wall']))}


def manifest_tree(directory):
    items = read(directory / 'hashes.json')['artifacts']; seen = set()
    for item in items:
        name = item['path']; safe_name(name)
        require(name not in seen, 'duplicate CRC manifest member'); seen.add(name)
        path = directory / name
        require(path.is_file() and path.stat().st_size == item['bytes'] and sha(path) == item['sha256'],
                'CRC manifest member differs: ' + name)
    require(seen == {p.relative_to(directory).as_posix() for p in directory.rglob('*') if p.is_file()} - {'hashes.json'},
            'CRC manifest inventory differs')
    return len(items)


def crc_checks(root, repo, commit, baseline, candidate, image):
    base = root / 'crc-checks'; unit = base / 'unit'; compat = base / 'compat'
    counts = {name: manifest_tree(base / name) for name in ('unit', 'compat')}
    us, cs = read(unit / 'summary.json'), read(compat / 'summary.json')
    for name, summary in (('unit', us), ('compat', cs)):
        require(summary['status'] == 'passed' and summary['stage'] == name and summary['exit_code'] == 0 and
                summary['formal_submission'] is False and summary['performance_measurements'] == 0,
                'CRC stage failed/incomplete: ' + name)
        require((base / name / 'harness-commit.txt').read_text().strip() == commit, 'CRC stage commit differs')
    unit_paths = {'minivec/src/crc32_ieee.h', 'minivec/tests/test_crc32_ieee.cpp', 'minivec/tools/ci_crc_checks.sh'}
    source = read(unit / 'source-sha256.json')
    require(set(source) == unit_paths, 'CRC unit source inventory differs')
    for path, h in source.items():
        require(digest(blob(repo, commit, path)) == h == sha(unit / 'source' / path), 'CRC unit source not bound to Git')
    observed = {}
    for name in ('normal', 'sanitized'):
        match = re.fullmatch(r'PASS crc32 IEEE slicing-by-8 ([0-9]+) checks\n?', (unit / (name + '.log')).read_text())
        require(match is not None and int(match.group(1)) >= 34000, 'CRC normal/sanitized unit evidence absent')
        observed[name] = int(match.group(1))
        require((unit / ('crc-' + name)).read_bytes().startswith(b'\x7fELF'), 'CRC test binary absent')
    require(observed == us['unit_checks'] and observed['normal'] == observed['sanitized'], 'CRC unit count differs')
    identity, result = read(compat / 'identity.json'), read(compat / 'persistence.json')
    old = '7ca3baad3f4c71970b01d194e8eee88a3606ff3b'
    require(identity['status'] == 'verified' and identity['baseline_source_commit'] == BASE and
            identity['candidate_source_commit'] == identity['new_fixture_source_commit'] == commit and
            identity['old_fixture_source_commit'] == old and identity['candidate_image_id'] == image and
            identity['feature_flags'] == FLAGS and identity['fixture_compile_options'] == ['-O2', '-std=c++17', '-pthread'],
            'CRC old/new source/image policy differs')
    require(sha(compat / 'root-gates-summary.json') == sha(root / 'root-gates-summary.json') and
            sha(compat / 'retained-provenance.json') == sha(root / 'small-compute-root/programs/retained/provenance.json'),
            'CRC root/baseline evidence copy differs')
    require(set(identity['source_sha256']) == {'baseline', 'candidate'}, 'CRC source roles differ')
    for role, revision in (('baseline', old), ('candidate', commit)):
        files = identity['source_sha256'][role]
        names = set(git(repo, 'ls-tree', '-r', '--name-only', revision, '--', 'minivec/src').decode().splitlines())
        require(set(files) == names, 'CRC full source inventory differs')
        for path, h in files.items():
            require(h == digest(blob(repo, revision, path)) == sha(compat / 'source' / role / path), 'CRC fixture source differs from Git')
    # The old helper precedes retained PGO commit E. Its storage compilation
    # units and included headers must nevertheless be byte-identical to E.
    pending = ['minivec/src/' + p for p in ('db.cpp', 'flat_index.cpp', 'value.cpp')]
    storage_files = set()
    while pending:
        path = pending.pop()
        if path in storage_files: continue
        storage_files.add(path)
        require(path in identity['source_sha256']['baseline'], 'old fixture included source is absent')
        raw = blob(repo, old, path)
        require(raw == blob(repo, BASE, path), 'old fixture storage does not match actual baseline: ' + path)
        for name in re.findall(rb'^\s*#\s*include\s*"([^"\r\n]+)"', raw, re.MULTILINE):
            child = (PurePosixPath(path).parent / name.decode('utf8')).as_posix(); safe_name(child)
            pending.append(child)
    common = {'minivec/tests/crc_persistence_fixture.cpp', 'minivec/tests/check_crc_persistence.py', 'minivec/tools/ci_crc_checks.sh'}
    require(set(identity['harness_sha256']) == common, 'CRC harness inventory differs')
    for path, h in identity['harness_sha256'].items():
        require(h == digest(blob(repo, commit, path)) == sha(compat / 'source/common' / path), 'CRC common harness differs from Git')
    require(identity['fixture_source_sha256'] == identity['harness_sha256']['minivec/tests/crc_persistence_fixture.cpp'], 'fixture source identity differs')
    require(result['status'] == 'passed' and result['performance_measurements'] == 0 and result['formal_score'] is None and
            cs['compatibility_checks'] == len(result['checks']) == 18, 'CRC interchange incomplete')
    require(set(result['binaries']) == {'baseline', 'candidate', 'baseline_writer', 'candidate_writer'}, 'CRC executable roles differ')
    for role, expected_sha in (('baseline', baseline), ('candidate', candidate)):
        require(result['binaries'][role]['sha256'] == cs['actual_reader_binary_sha256'][role] ==
                identity[role + '_binary_sha256'] == expected_sha, 'CRC actual reader identity differs')
        require(result['binaries'][role + '_writer']['sha256'] == cs['fixture_writer_binary_sha256'][role] ==
                sha(compat / (role + '-fixture-writer')), 'CRC fixture writer identity differs')
    require(cs['candidate_source_commit'] == commit and cs['candidate_image_id'] == image, 'CRC summary identity differs')
    actual = [(x['kind'], x.get('mode'), x.get('file'), x.get('producer'), x.get('consumer')) for x in result['checks']]
    expected = [('identical_durable_bytes', mode, name, None, None) for mode, names in
                (('wal', ('data.log',)), ('snapshot', ('data.log', 'snapshot.bin', 'snapshot.lsn'))) for name in names]
    expected += [('old_new_interchange', mode, None, producer, consumer) for mode in ('wal', 'snapshot')
                 for producer in ('baseline', 'candidate') for consumer in ('baseline', 'candidate')]
    expected += [(kind, mode, None, None, None) for mode in ('wal', 'snapshot') for kind in ('bad_committed_crc', 'torn_tail')]
    expected += [('bad_snapshot_crc_rejected', None, None, None, consumer) for consumer in ('baseline', 'candidate')]
    require(len(set(actual)) == 18 and set(actual) == set(expected), 'CRC 18-case inventory differs')
    frame_counts = {}
    for item in result['checks']:
        if item['kind'] in ('bad_committed_crc', 'torn_tail'):
            require(item['expected_visible_ids'] == ([1, 2, 7, 15] if item['kind'] == 'bad_committed_crc' else [1, 2, 7, 15, 40]),
                    'committed CRC or torn-tail recovery oracle differs')
        elif item['kind'] == 'identical_durable_bytes':
            left = compat / 'persistence' / (item['mode'] + '-baseline') / item['file']
            right = compat / 'persistence' / (item['mode'] + '-candidate') / item['file']
            require(left.read_bytes() == right.read_bytes() and sha(left) == item['sha256'], 'original old/new durable bytes differ')
    for mode in ('wal', 'snapshot'):
        for role in ('baseline', 'candidate'):
            directory = compat / 'persistence' / (mode + '-' + role)
            raw = (directory / 'data.log').read_bytes(); at = 0; frames = 0
            while at < len(raw):
                require(len(raw) - at >= 8, 'original WAL header is truncated')
                size, expected_crc = struct.unpack_from('<II', raw, at)
                require(size > 0 and at + 8 + size <= len(raw), 'original WAL payload bounds differ')
                require(zlib.crc32(raw[at+8:at+8+size]) == expected_crc, 'original WAL differs from independent IEEE CRC')
                at += 8 + size; frames += 1
            require(frames > 0, 'original WAL unexpectedly empty')
            frame_counts[mode + '-' + role] = frames
            if mode == 'snapshot':
                raw = (directory / 'snapshot.bin').read_bytes()
                require(len(raw) > 4 and zlib.crc32(raw[:-4]) == struct.unpack_from('<I', raw, len(raw)-4)[0], 'original snapshot IEEE CRC differs')
    return {'unit_checks': observed, 'compatibility_checks': 18, 'actual_reader_binary_sha256': cs['actual_reader_binary_sha256'],
            'fixture_writer_binary_sha256': cs['fixture_writer_binary_sha256'], 'manifest_file_counts': counts,
            'independently_checked_original_WAL_frames': frame_counts, 'old_fixture_storage_matches_retained_source': True,
            'old_fixture_transitive_storage_sources': sorted(storage_files),
            'scope': 'Unit source, logs, fixture source, whole source snapshots, actual reader SHA values and all 18 case identities are checked. Original durable bytes are checked with Python zlib. Fixture writers are standalone helpers, not PGO programs. Protocol response bodies were checked by the Git-bound harness but not retained for independent replay; damaged WAL copies may have been repaired by recovery and are not claimed to preserve pre-read damage bytes.'}


def training_log(root, repo, commit):
    text = (root / 'docker-build.log').read_text(encoding='utf8')
    require(COMPILER in text and COMPILER.encode() in blob(repo, commit, 'Dockerfile'), 'compiler pin missing')
    records = []
    for line in text.splitlines():
        if '{' not in line: continue
        try: data = json.loads(line[line.index('{'):])
        except json.JSONDecodeError: continue
        if isinstance(data, dict) and 'actual_file' in data and 'expected_file' in data: records.append(data)
    expected = {(f'responses-{t}-{p}.jsonl', f'phase-{p}.expected.jsonl', [951, 41, 14][p]) for t in (1, 2) for p in range(3)}
    require(len(records) == 6 and {(r['actual_file'], r['expected_file'], r['responses']) for r in records} == expected and
            all(r['status'] == 'passed' for r in records), 'six PGO training oracle records missing')
    profiles = re.findall(r'\b([0-9a-f]{64})\s+(/pgo/minivec-[A-Za-z_]+\.gcda)', text)
    require(len(profiles) == 6 and {p for _, p in profiles} == {'/pgo/minivec-' + n + '.gcda' for n in ('db', 'exec', 'flat_index', 'main', 'sql', 'value')}, 'PGO profile inventory differs')
    for p in ('minivec/tools/pgo/train.cpp', 'minivec/tools/pgo/run-training.sh', 'Dockerfile'):
        require(blob(repo, commit, p) == blob(repo, BASE, p), 'training/build policy changed: ' + p)
    return {'oracle': records, 'profile_hashes_from_build_log': dict((p, h) for h, p in profiles),
            'scope': 'Build log records six independent oracle successes and six profile digests; release artifact does not include raw gcda bytes.'}


def reproduce_workloads(repo, commit):
    # Workload generation is pure Python. No binary is launched and no measured
    # timer is reused; temporary paths mirror the Git source layout for imports.
    with tempfile.TemporaryDirectory(prefix='mvdb-workload-audit-') as td:
        tree = Path(td)
        for path in TOOLS:
            target = tree / path; target.parent.mkdir(parents=True, exist_ok=True); target.write_bytes(blob(repo, commit, path))
        sys.dont_write_bytecode = True
        sys.path.insert(0, str(tree / 'minivec/tools'))
        try:
            harness = importlib.import_module('small_compute')
            base = importlib.import_module('benchmark_iteration')
            writes = importlib.import_module('benchmark_write_query')
            projection = importlib.import_module('benchmark_projection')
            result = {}
            for name in CASES:
                work = harness.workload(name, base, writes, projection, query_mode="exact")
                result[name] = harness.workload_identity(name, work, base)
                del work
        finally:
            sys.path.remove(str(tree / 'minivec/tools'))
    return result


def workload_reference(repo, commit, measured, local):
    # Exact-mode inputs are new. Do not reuse an old mixed-mode digest as proof.
    require(measured['query_mode_policy']=='exact','Linux workload is not exact')
    expected={x['scenario']:x for x in measured['workloads']};differences=[]
    require(tuple(expected)==CASES,'Linux workload inventory differs')
    for name,item in local.items():
        require({k:v for k,v in item.items() if k!='sha256'}==
                {k:v for k,v in expected[name].items() if k!='sha256'},
                'new exact SQL generator or parameters do not reproduce: '+name)
        if item!=expected[name]:differences.append(name)
    require(set(differences)<={'resident30k','filter60k'},'unexpected local full-content mismatch')
    return expected,{'linux_expected_workload_identities':expected,'local_recomputed_workload_identities':local,
        'all_exact_sql_generator_hashes_and_parameters_match':True,
        'local_complete_content_hash_mismatch_scenarios':differences,
        'scope':'Git-verified exact-mode SQL generator hashes and parameters reproduce in Windows. Four scenario full-content hashes must match; known Windows/Linux float-oracle differences may affect 30k/60k. Linux 1/2-CPU common workloads must have identical full hashes. No old mixed-mode hash is reused or absent raw oracle body claimed independently reconstructed.'}


def verify_measurements(data, count, cases, programs, ids, proof, workloads):
    expected = [{'scenario': n, 'seed': 7319, 'pair_index': i, 'order': ['baseline', 'candidate'] if i == 0 else ['candidate', 'baseline']} for n in cases for i in range(2)]
    require(data['status'] == 'passed' and data['expected_pairs'] == data['completed_pairs'] == len(data['pairs']) == len(expected), 'measurement incomplete')
    require(data['plan'] == expected and [{k: p[k] for k in ('scenario', 'seed', 'pair_index', 'order')} for p in data['pairs']] == expected, 'measurement plan mismatch')
    require(data['query_mode_policy']=='exact','measurement mode is not exact')
    require(data['comparison_kind'] == 'whole_version_diagnostic' and data['official_score'] is None and data['official_binary_identity_known'] is False, 'scope mismatch')
    require(data['identity_record_sha256'] == sha(programs / 'identities.json'), 'identity JSON mismatch')
    require(data['workloads'] == [workloads[n] for n in cases], 'regenerated workload/oracle hash mismatch')
    require(data['db_cpu_count'] == count and len(set(data['db_cpus'])) == count and data['protection_only'] == (count == 2), 'CPU plan mismatch')
    require(set(data['db_cpus']).issubset(set(data['host']['driver_affinity'])), 'CPU selection outside inherited driver affinity')
    require(data['requested_limits'] == {'cpu_quota_us': count * 100000, 'cpu_period_us': 100000, 'memory_max': '2147483648', 'swap_max': '0'}, 'resource request mismatch')
    require(data['launcher_sha256'] == sha(programs.parent / 'cgroup_exec'), 'actual launcher differs')
    seen = {}
    for path, h in data['tool_hashes'].items():
        names = [name for name in TOOLS if path.endswith('/' + name)]
        require(len(names) == 1 and names[0] not in seen, 'tool path inventory mismatch')
        name = names[0]; seen[name] = h; require(proof['harness_file_sha256'][name] == h, 'executed tool differs from Git proof')
    require(set(seen) == TOOLS, 'tool set incomplete')
    for role in ('baseline', 'candidate'):
        item = data['identities'][role]
        for key in ('binary_sha256', 'source_commit', 'evidence_sha256', 'environment'):
            require(item[key] == ids[role][key], 'measured role identity mismatch')
        require(item['environment'] == {}, 'unexpected runtime override')
    details, grouped, lifecycle_grouped = [], {}, {}
    for pair in data['pairs']:
        name = pair['scenario']; require(pair['all_responses_identical'] is True, 'output equivalence absent')
        b, c = pair['baseline'], pair['candidate']; detail = {k: pair[k] for k in ('scenario', 'seed', 'pair_index', 'order')}; detail['sides'] = {}
        for role, run in (('baseline', b), ('candidate', c)):
            g, adapter, policy = run['cgroup'], run['adapter'], run['thread_policy_observations']
            require(run['declared_environment'] == {} and run['query_mode_policy']=='exact', 'run override/mode differs')
            modes = adapter['completed_request_modes']
            require(set(modes) == {'exact'} and modes['exact'] > 0 and modes['exact'] == adapter['completed_transport_requests'],
                    'actual transport request mode differs')
            require(not g['timeout'] and not g.get('request_timeout_observed') and not g.get('cleanup_kill_required') and not g.get('watchdog_error') and not any(g['oom_events_delta'].values()), 'timeout/OOM/process failure')
            for when in ('before', 'after'):
                require(g[when]['cpu.max'].split() == [str(count * 100000), '100000'], 'actual quota differs')
                require(g[when]['memory.max'] == '2147483648' and g[when]['memory.swap.max'] == '0', 'actual 2GiB/swap0 differs')
            for ancestor in g['ancestor_constraints']:
                cap = ancestor['memory.max']
                require(not isinstance(cap, str) or not cap.isdigit() or int(cap) >= 2147483648,
                        'ancestor memory constraint below 2GiB')
            require(not g['after']['cgroup.procs'].strip(), 'live DB remains')
            ready = adapter['ready_memberships']; require(len(ready) == (1 if name == 'wide768' else 2), 'ready/restart evidence missing')
            for item in ready:
                require(item['pid'] in item['members'] and item['driver_pid'] not in item['members'] and
                        item['actual_exe'] == data['identities'][role]['binary'] and cpus(item['cpus_allowed_list']) == set(data['db_cpus']), 'actual executable/cgroup/affinity mismatch')
            phases = adapter['phase_cgroups']; require(len(phases) == (14 if name == 'wide768' else 15 if name.startswith('spill_') else 7), 'phase observations missing')
            for phase in phases:
                require(phase['memory.max'] == '2147483648' and phase['memory.swap.max'] == '0', 'phase memory/swap cap differs')
                require(not phase.get('native_tasks_error') and not phase.get('task_read_errors') and phase['native_tasks'] and sum(t['main'] for t in phase['native_tasks']) == 1, 'native task evidence missing')
                require(all(cpus(t['cpus_allowed_list']) == set(data['db_cpus']) for t in phase['native_tasks']), 'native task affinity drift')
            before, after = counters(g['before']['cpu.stat']), counters(g['after']['cpu.stat'])
            require(g['resource_delta']['cpu_stat_delta'] == {k: v - before.get(k, 0) for k, v in after.items()} and
                    g['resource_delta']['memory_peak_bytes'] == int(g['after']['memory.peak']), 'resource arithmetic differs')
            ib, ia = io_counters(g['before']['io.stat']), io_counters(g['after']['io.stat'])
            require(g['resource_delta']['io_stat_delta'] == {dev: {k: v - ib.get(dev, {}).get(k, 0) for k, v in fields.items()} for dev, fields in ia.items()}, 'device IO counter arithmetic differs')
            require(policy['stderr_complete'] is True and policy['requested_query_threads'] == 'automatic', 'policy observations incomplete')
            logs = policy['fanout_log_lines']; wake = [x for x in logs if '(measured, median of 200 handshakes)' in x]
            require(len(wake) == len(ready), 'real startup calibration missing')
            marker = 'single-CPU affinity; adaptive query fanout disabled, startup calibration retained'
            require(not any(marker in x for x in logs), 'rejected affinity policy unexpectedly active')
            cpu_intervals = {}
            by_phase = {x['phase']: x for x in phases}
            for start, end in (('after_index_build', 'query_before_update'), ('after_restart', 'query_after_restart')):
                if start in by_phase and end in by_phase:
                    left, right = by_phase[start], by_phase[end]
                    old = {(t['tid'], t['starttime_ticks']): t['cpu_ticks'] for t in left['native_tasks']}
                    cpu_intervals[end] = {'start': start, 'end': end, 'cpu_usage_usec': counters(right['cpu.stat'])['usage_usec'] - counters(left['cpu.stat'])['usage_usec'],
                        'nonmain_cpu_ticks_delta': sum(t['cpu_ticks'] - old.get((t['tid'], t['starttime_ticks']), 0) for t in right['native_tasks'] if not t['main']),
                        'scope': 'Includes restart ID/vector/payload verification.' if start == 'after_restart' else 'Post-index snapshot through first query phase; excludes restart verification.',
                        'nonmain_scope': 'All nonmain native tasks, not exclusively a named query worker.'}
            detail['sides'][role] = {'resources': g['resource_delta'], 'policy': policy, 'cpu_intervals': cpu_intervals}
        if name == 'wide768':
            for run in (b, c):
                require(run['status'] == 'passed' and set(run['phases']) == LABELS, 'projection phase schema differs')
                for phase in run['phases'].values():
                    require(all(r['search_mode']=='exact' for r in phase['requests']), 'projection sent a non-exact request')
                    require(len(phase['requests']) == 3 and phase['independent_oracle'] and phase['wall_seconds'] == sum(r['seconds'] for r in phase['requests']), 'projection oracle/timer evidence missing')
            for label in LABELS:
                require([(r['response_sha256'], r['response_bytes']) for r in b['phases'][label]['requests']] == [(r['response_sha256'], r['response_bytes']) for r in c['phases'][label]['requests']], 'projection responses differ')
        else:
            require(b['response_sha256'] == c['response_sha256'], 'lifecycle responses differ')
            for run in (b, c):
                require(all(q['modes']==['exact']*len(q['per_request_seconds']) for q in run['query'].values()), 'query mode trace is not all exact')
                if name.startswith('spill_'):
                    require(run['real_spill_observed'] is True and run['correctness']['all_query_responses_independent_oracle'] is True and len(run['write_cycles']) == 4 and len(run['query']) == 6 and
                            all(len(q['per_request_seconds']) == (16 if name.endswith('q16') else 1) for q in run['query'].values()), 'spill independent oracle/counts missing')
                    require(run['correctness']['all_restarted_ids_checked'] == 5000 and run['correctness']['all_mutated_payloads_and_tombstones_checked'] == [0, 1, 7, 1007], 'spill restart verification missing')
                else:
                    require(set(run['query']) == {'query_before_update', 'query_after_restart'} and all(len(q['per_request_seconds']) == 1000 for q in run['query'].values()) and
                            run['correctness']['sampled_topk_oracle_queries'] == [0, 1, 999], 'resident oracle/counts missing')
                    rows = workloads[name]['rows']
                    require(run['correctness']['all_restarted_ids_checked'] == rows and run['correctness']['restarted_vector_ids_checked'] == [0, 1, rows // 2, rows - 1], 'resident restart verification missing')
        bv, cv = timings(b), timings(c); require(set(bv) == set(cv), 'phase timers differ')
        for phase in bv:
            require(math.isfinite(bv[phase]) and math.isfinite(cv[phase]) and bv[phase] >= 0 and cv[phase] > 0, 'invalid measured timer')
            grouped.setdefault(name, {}).setdefault(phase, []).append({'pair_index': pair['pair_index'], 'order': pair['order'], 'baseline_seconds': bv[phase], 'candidate_seconds': cv[phase], 'baseline_over_candidate': bv[phase] / cv[phase], 'candidate_slower': cv[phase] > bv[phase]})
        bl, cl = lifecycle_timings(b), lifecycle_timings(c)
        require(set(bl) == set(cl), 'derived lifecycle boundaries differ')
        for phase in bl:
            require(math.isfinite(bl[phase]) and math.isfinite(cl[phase]) and bl[phase] >= 0 and cl[phase] > 0,
                    'invalid derived lifecycle timer')
            lifecycle_grouped.setdefault(name, {}).setdefault(phase, []).append({'pair_index': pair['pair_index'],
                'order': pair['order'], 'baseline_seconds': bl[phase], 'candidate_seconds': cl[phase],
                'baseline_over_candidate': bl[phase] / cl[phase], 'candidate_slower': cl[phase] > bl[phase]})
        details.append(detail)
    summary = {name: {phase: {'raw_pairs': rows, 'median_baseline_over_candidate': median(r['baseline_over_candidate'] for r in rows), 'candidate_slower_pairs': sum(r['candidate_slower'] for r in rows)} for phase, rows in phases.items()} for name, phases in grouped.items()}
    require(summary == data['summary'], 'independent summary arithmetic differs')
    lifecycle_summary = {name: {phase: {'raw_pairs': rows, 'median_baseline_over_candidate': median(r['baseline_over_candidate'] for r in rows),
        'candidate_slower_pairs': sum(r['candidate_slower'] for r in rows)} for phase, rows in phases.items()} for name, phases in lifecycle_grouped.items()}
    return {'verified_pairs': len(expected), 'summary': summary, 'derived_lifecycle_summary': lifecycle_summary,
            'lifecycle_scope': 'First lifetime sums startup, all measured requests and first shutdown; excludes restart and its verification/query/shutdown. Restart-inclusive totals are shown separately. These are sums of measured request/lifecycle timers, not end-to-end wall time including oracle work and telemetry gaps. Wide projection has no restart. No first-lifetime cgroup CPU total is inferred across unavailable shutdown boundaries.',
            'resources_and_policy': details,
            'host': data['host'], 'db_cpus': data['db_cpus'], 'ancestor_constraints': data['pairs'][0]['baseline']['cgroup']['ancestor_constraints']}


def audit(args):
    root, repo, commit = args.input.resolve(), args.repo.resolve(), args.commit
    file_count = verify_archive(root, args.archive.resolve(), args.artifact_sha256, args.artifact_bytes)
    gates, final = read(root / 'root-gates-summary.json'), read(root / 'verification-summary.json')
    require(gates['passed'] is True and set(gates['checks']) == GATES and all(x is True for x in gates['checks'].values()), 'root gates incomplete')
    require(final['passed'] is True and set(final['checks']) == GATES | {'actual_root_small_compute_20_pairs', 'actual_crc_old_new_18_checks'} and all(x is True for x in final['checks'].values()), 'combined root gates incomplete')
    require(gates['runtime_commit'] == final['runtime_commit'] == commit == (root / 'runtime-commit.txt').read_text().strip(), 'root commit mismatch')
    require(gates['selected_feature_flags'] == final['selected_feature_flags'] == FLAGS, 'retained default flags differ')
    small = root / 'small-compute-root'; programs = small / 'programs'; proof = read(programs / 'root-proof.json')
    manifest = read(small / 'hashes.json')['artifacts']; paths = [x['path'] for x in manifest]
    require(len(paths) == len(set(paths)) and set(paths) == {p.relative_to(small).as_posix() for p in small.rglob('*') if p.is_file()} - {'hashes.json'}, 'small-root artifact manifest mismatch')
    for item in manifest:
        safe_name(item['path']); p = small / item['path']; require(p.stat().st_size == item['bytes'] and sha(p) == item['sha256'], 'small-root member differs')
    candidate = sha(programs / 'actual-image-minivec'); image = (root / 'image-id.txt').read_text().strip()
    require(re.fullmatch(r'sha256:[0-9a-f]{64}', image) is not None and image == gates['image_id'] == final['image_id'] == proof['image_id'], 'actual image ID mismatch')
    inspect = read(root / 'image-inspect.json'); require(len(inspect) == 1 and inspect[0]['Id'] == image, 'image inspection mismatch')
    require(candidate == proof['binary_sha256'] == gates['image_binary_sha256'] == final['image_binary_sha256'] == (root / 'image-binary-sha256.txt').read_text().split()[0], 'actual root image program differs')
    require(proof['status'] == 'verified' and proof['source_commit'] == commit and proof['feature_flags'] == FLAGS and proof['harness_matches_git'] is True, 'root proof scope mismatch')
    require(sha(programs / 'root-gates-summary.json') == sha(root / 'root-gates-summary.json') == proof['root_gate_summary_sha256'], 'pre-performance root gates changed')
    require(sha(programs / 'root-input-sha256.txt') == sha(root / 'input-sha256.txt') == proof['root_input_manifest_sha256'], 'root input manifest changed')
    inputs = {}
    for line in (root / 'input-sha256.txt').read_text().splitlines():
        h, path = line.split(maxsplit=1); path = path.lstrip('*'); safe_name(path); require(path not in inputs, 'duplicate source input'); inputs[path] = h
    expected_inputs = set(git(repo, 'ls-tree', '-r', '--name-only', commit, '--', *INPUT_PATHS).decode().splitlines())
    require(set(inputs) == expected_inputs and inputs == proof['root_input_sha256'], 'complete root input inventory differs')
    for path, h in inputs.items(): require(digest(blob(repo, commit, path)) == h, 'root input not bound to Git: ' + path)
    for path, h in proof['harness_file_sha256'].items(): require(digest(blob(repo, commit, path)) == h, 'harness not bound to Git: ' + path)
    require(TOOLS.issubset(proof['harness_file_sha256']), 'missing actual imported harness proof')
    ids = read(programs / 'identities.json'); require(set(ids) == {'baseline', 'candidate'}, 'identity role inventory differs')
    for role, item in ids.items():
        safe_name(item['binary']); safe_name(item['evidence_file'])
        require(sha(programs / item['binary']) == item['binary_sha256'] and sha(programs / item['evidence_file']) == item['evidence_sha256'] and item['environment'] == {}, 'immutable binary/proof changed')
    require(ids['candidate']['binary_sha256'] == candidate and ids['candidate']['source_commit'] == commit and ids['baseline']['binary_sha256'] == BASE_BINARY and ids['baseline']['source_commit'] == BASE, 'expected version contrast differs')
    retained = read(programs / 'retained/provenance.json')
    require(retained['status'] == 'verified' and retained['binary_sha256'] == BASE_BINARY and retained['source_commit'] == BASE and retained['harness_matches_git'] is True and retained['harness_commit'] == commit and retained['new_pgo_builds'] == 0, 'retained old PGO identity differs')
    require(retained['retained_archive_sha256'] == '88e4a73af9d333b08a6db817a78c7cb06357fcfddc05eee1b31c2a065aebfef2' and
            retained['retained_archive_bytes'] == 49685962 and retained['compiler_image'] == COMPILER and retained['feature_flags'] == FLAGS, 'retained compiler/archive policy differs')
    baseline_inputs = set(git(repo, 'ls-tree', '-r', '--name-only', BASE, '--', 'minivec/src').decode().splitlines()) | {'minivec/tools/pgo/train.cpp', 'minivec/tools/pgo/run-training.sh'}
    require(set(retained['source_and_training_sha256']) == baseline_inputs, 'retained engine/training inventory incomplete')
    for path, h in retained['source_and_training_sha256'].items(): require(digest(blob(repo, BASE, path)) == h, 'retained source/training Git mismatch')
    require(digest((programs / 'retained/prior-context.json').read_bytes()) == retained['retained_context_sha256'], 'retained prior context changed')
    crc = crc_checks(root, repo, commit, BASE_BINARY, candidate, image); training = training_log(root, repo, commit)
    for variant in ('image', 'source'):
        for phase, count in (('handshake', 1), ('public', 20)):
            public = read(root / (variant + '-' + phase) / 'result.json')
            require(public['passed'] is True and len(public['cases']) == count and all(x['status'] == 'PASS' for x in public['cases']), 'public protocol gate missing')
    utf8 = read(root / 'image-binary-utf8.json')
    expected_utf8 = {(raw, dim, path) for raw in ('ff', 'c080', 'eda080', 'e4b8', 'f4908080', '80') for dim in (None, 127, 128) for path in ('ORDER BY id LIMIT 10', 'unbounded', 'ORDER BY id LIMIT 4096')}
    require(utf8['status'] == 'passed' and len(utf8['checks']) == 54 and {(x['malformed_hex'], x['projected_vector_dimension'], x['path']) for x in utf8['checks']} == expected_utf8 and all(x['status'] == 'passed' for x in utf8['checks']), 'actual image UTF8 gate incomplete')
    overall = read(small / 'summary.json')
    require(overall == final['small_compute'] and overall['status'] == 'passed' and overall['exit_code'] == 0 and overall['expected_pairs'] == overall['completed_pairs'] == 20 and overall['new_pgo_builds'] == 1 and overall['candidate_binary_sha256'] == candidate and overall['candidate_image_id'] == image and overall['candidate_source_commit'] == commit, '20-pair root summary binding mismatch')
    local_workloads = reproduce_workloads(repo, commit)
    expected_workloads, workload_proof = workload_reference(repo, commit, read(small / 'measurements-1cpu.json'), local_workloads)
    measurements = {str(count): verify_measurements(read(small / f'measurements-{count}cpu.json'), count, cases, programs, ids, proof, expected_workloads) for count, cases in ((1, CASES), (2, PROTECTION))}
    negatives, coherent_protection = [], []
    for count, report in measurements.items():
        for scenario, phases in report['summary'].items():
            for phase, entry in phases.items():
                if entry['candidate_slower_pairs'] or entry['median_baseline_over_candidate'] < 1:
                    negatives.append({'cpu_count': int(count), 'scenario': scenario, 'phase': phase, **entry})
                if count == '2' and entry['candidate_slower_pairs'] == 2:
                    coherent_protection.append({'scenario': scenario, 'phase': phase, **entry})
    return {'status': 'verified', 'verified_pairs': 20, 'source_commit': commit, 'baseline_source_commit': BASE,
            'baseline_binary_sha256': BASE_BINARY, 'candidate_binary_sha256': candidate, 'candidate_image_id': image,
            'artifact_sha256': args.artifact_sha256, 'artifact_files': file_count, 'root_git_input_count': len(inputs),
            'harness_git_files': len(proof['harness_file_sha256']), 'root_gates': gates['checks'], 'crc_checks': crc,
            'root_pgo_evidence': training, 'workload_identity_audit': workload_proof,
            'measurements': measurements, 'all_negative_or_mixed_phases': negatives,
            'two_cpu_both_orders_slower': coherent_protection,
            'actual_cpu_model': (small / 'lscpu.txt').read_text(),
            'automatic_adoption': False, 'official_score': None,
            'limitations': ['Two pairs per scenario at one seed; no confidence interval or formal score conversion.',
                'All ratios compare baseline and candidate within the same run; no ratio multiplication across different hosts or prior experiments.',
                'Version contrast includes compiler/PGO/layout effects, not a pure CRC instruction-cost isolation.',
                'Two-CPU protection uses logical CPU affinity and quota; physical-core topology is not established.',
                'Root PGO logs are audited but raw gcda profile bytes are not in the release artifact.',
                'Input/oracle generation is repeated in Windows. SQL hashes/parameters match all scenarios; 30k/60k full float-oracle hashes may differ locally; common scenarios must agree between the new Linux CPU groups. No local database run or absent raw response-body reconstruction is claimed.',
                'Every negative timing phase remains visible. Coherent two-CPU protection regressions require rejection or explanation before default adoption.']}


def main():
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument('--input', type=Path, required=True); p.add_argument('--archive', type=Path, required=True)
    p.add_argument('--repo', type=Path, default=Path(__file__).resolve().parent / 'seekdb')
    p.add_argument('--commit', required=True); p.add_argument('--artifact-sha256', required=True)
    p.add_argument('--artifact-bytes', type=int, required=True); p.add_argument('--output', type=Path, required=True)
    args = p.parse_args(); require(not args.output.exists(), 'refuse overwrite')
    require(not args.output.resolve().is_relative_to(args.input.resolve()), 'analysis must be outside evidence tree')
    require(re.fullmatch('[0-9a-f]{40}', args.commit) is not None and re.fullmatch('[0-9a-f]{64}', args.artifact_sha256) is not None, 'invalid expected identity')
    result = audit(args)
    args.output.write_text(json.dumps(result, ensure_ascii=False, indent=2, allow_nan=False) + '\n', encoding='utf8')
    print(json.dumps({'status': result['status'], 'verified_pairs': result['verified_pairs'],
                      'candidate_binary_sha256': result['candidate_binary_sha256'],
                      'two_cpu_both_orders_slower_phases': len(result['two_cpu_both_orders_slower']),
                      'output': str(args.output)}))


if __name__ == '__main__': main()
