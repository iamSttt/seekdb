"""Freeze independent micro decision/evidence in work only; no material changes."""
import ast,io,json,zipfile
from pathlib import Path
from analyze_crc_root import blob,digest,require
W=Path(__file__).resolve().parent;R=W/'seekdb';COMMIT='ff7f4c414e2717dc7f1de4786af6270a1a606745'
PLAN='validation/iteration5-tighter-bound-prototype-preregistration.json'
def enc(x):return (json.dumps(x,ensure_ascii=False,separators=(',',':'),allow_nan=False)+'\n').encode()
raw=(W/'tighter-bound-independent-analysis.json').read_bytes();a=json.loads(raw)
require(a['status']=='verified_micro_evidence' and a['screen']['eligible_for_database_integration_investigation'] is True,'micro decision drift')
require(len(a['screen']['pairs'])==12 and len(a['screen']['all_negative_pair_metrics'])==6,'pair/adverse inventory')
decision={'status':'mechanism_screen_passed_DB_investigation_only','commit':COMMIT,'api':a['api_binding'],
 'independent_analysis':{'bytes':len(raw),'sha256':digest(raw),'path':'analysis.json'},
 'resources':a['resources'],'native_evidence':a['native_evidence'],'independent_fixture_oracle':a['independent_fixture_oracle'],
 'screen':a['screen'],'limitations':a['limitations'],'reader_successful_on_first_real_artifact_attempt':True,
 'DB_runs':0,'PGO_builds':0,'default_adopted':False,'official_submission':False,
 'production_scope':'Standalone proposed distance.h certificate only. No database result or acceptance of the earlier batch8 candidate is implied.'}
dr=enc(decision);(W/'tighter-bound-micro-decision.json').write_bytes(dr)
files={'analysis.json':raw,'decision.json':dr,'api-receipt.json':(W/'tighter-bound-api-receipt.json').read_bytes(),
 'ci-static-review.json':(W/'tighter-bound-independent-ci-static-review.json').read_bytes(),
 'archive_tighter_bound_micro_audit.py':Path(__file__).read_bytes()}
pending=['analyze_tighter_bound_prototype','analyze_quant_batch_prototype','analyze_crc_root','check_tighter_micro_ci_static'];seen=set()
while pending:
    name=pending.pop()
    if name in seen:continue
    seen.add(name);b=(W/(name+'.py')).read_bytes();files['reader/'+name+'.py']=b
    for node in ast.walk(ast.parse(b)):
        names=[v.name for v in node.names] if isinstance(node,ast.Import) else [node.module] if isinstance(node,ast.ImportFrom) and node.module else []
        pending += [n for n in names if (W/(n+'.py')).is_file()]
pr=blob(R,COMMIT,PLAN);p=json.loads(pr);files['source/'+PLAN]=pr
require(digest(pr)==a['plan_sha256']=='5db6ff13e6cc8f7682ff6e0115ac6a02a1438e09a4dbca4ee28f7d5853509645','plan binding drift')
for name,item in {**p['source_snapshot'],**p['proofs']}.items():
    b=blob(R,COMMIT,name);require(len(b)==item['bytes'] and digest(b)==item['sha256'],'source drift');files['source/'+name]=b
manifest={'scope':'Independent first-pass audit of standalone tighter-bound micro; 12 pairs, DB0/PGO0, six adverse pair metrics retained; only DB integration investigation allowed',
 'raw':{'path':'validation/iteration5-tighter-bound-prototype-raw.zip','bytes':2806409,'sha256':'bc3fd31c039e83aa7f12f779a084671646cfc830c36e015123e50d2596c44c94'},
 'files':{n:{'bytes':len(b),'sha256':digest(b)} for n,b in sorted(files.items())}}
files['manifest.json']=enc(manifest);out=io.BytesIO()
with zipfile.ZipFile(out,'w',zipfile.ZIP_DEFLATED,compresslevel=9) as z:
    for n,b in sorted(files.items()):
        i=zipfile.ZipInfo(n,(2026,11,14,0,0,0));i.external_attr=0o100644<<16;z.writestr(i,b,compress_type=zipfile.ZIP_DEFLATED,compresslevel=9)
archive=out.getvalue();(W/'tighter-bound-prototype-audit.zip').write_bytes(archive)
receipt={'status':'frozen_work_only','analysis_bytes':len(raw),'analysis_sha256':digest(raw),'decision_bytes':len(dr),'decision_sha256':digest(dr),
 'audit_bytes':len(archive),'audit_sha256':digest(archive),'audit_files':len(files),'suggested_repo_path':'validation/iteration5-tighter-bound-prototype-audit.zip',
 'materials_changed':False,'production_changed':False,'Git_mutations':0,'native_or_DB_executions_by_reader':0}
(W/'tighter-bound-micro-audit-receipt.json').write_bytes(enc(receipt));print(json.dumps(receipt,indent=2))
