# Localized bulk guard: immutable192 evidence

Source85cded31d28192f30b4177ed226384ec8d0ffd95. Read bulk-guard-analysis.json for
the independent full audit, bulk-guard-evaluation.json for an independent paired
phase/resource derivation, and bulk-guard-adoption-assessment.json for the
protection decision. bulk-guard-review.json is a compact phase and startup
decomposition retaining the unchanged primary totals and every negative pair.

The raw artifact is separate: validation/iteration4-bulk-guard-raw.zip,
49,699,707 bytes; SHA25644420c714d59c1f98fa32879c917351ca02175aac474eb318217a068b69b31fd.
It contains188 files /241,011,500 unpacked bytes and is not duplicated here.
The complete resumed download was used; the earlier incomplete download was not.
Source/profile/flags/binaries,8 actual-binary gates,108 UTF8 cases,3 diagnostic/
sanitizer source gates,30 fixed workloads and192 unique paired identities were
verified. There are150 candidate pairs (10x15) and42 same-baseline A/A (7x6),
not192 independent PGO builds. Both roles are separately trained once.

## Decision and limitations

Bulk remains OFF. Wide4096/all outputs at16/64/127 dimensions show clear gains,
but30k first1000 and after936 retain losses across seed/order groups and higher
process CPU. The60k restart comparison is also negative. No negative samples,
first requests or startup observations were discarded. Startup decomposition is
secondary: the primary accounted timer sum remains. Projection startup includes
Python process creation, reader-thread start and ready receipt, not isolated
database startup CPU. No pooled or formal score increase is inferred.

Projection resource snapshots are included, not falsely described as absent.
Before/after intervals span three requests and untimed host verification gaps.
RSS is a point sample; HWM is cumulative, not an isolated phase peak; CPU has
coarse kernel-tick resolution. Logical I/O and kernel process I/O accounting are
neither device measurements nor cgroup/official score counters. Missing values
remain unavailable, and A/A does not eliminate PGO rebuild variance.

## The root image is a different, default-off binary

Included root proof and original59,817-byte root validation artifact verify
the four default flags,16 gates and54 actual-image UTF8 cases. Its extracted
binary SHA9cfaf9d0a9792b7915c6dc85ba4585c94e443c8aa2790a7c36fb41aa26b1a623
differs from both measured baselineacddca115ab183bfc6419e27c9e3383cfd1a9046e3897e5ea516cd7bc0f29f54
and bulk candidate2d50c45c9aebee86e9224118aeb294dc574c7c6edea1fdde2dc596aeb751bda3.
The192 experiment does not claim to measure this root image. The small root
artifact records CI extraction SHA, not executable bytes for local rehash.
Future adoption requires actual-root correctness and exact measured-binary
identity or a fresh actual-root comparison. No root bridge is enabled here.

## Reproduce read-only checks

Extract this ZIP to a writable directory. Use a separate complete raw artifact
directory and full Git repository retaining85cded3 and e020:

python analyze_bulk_guard.py --input RAW --source-repo REPO --candidate-commit 85cded31d28192f30b4177ed226384ec8d0ffd95 --output NEW_ANALYSIS.json
python evaluate_bulk_guard_192.py --artifact RAW --analysis NEW_ANALYSIS.json --candidate-commit 85cded31d28192f30b4177ed226384ec8d0ffd95 --output NEW_EVALUATION.json
python -B check_bulk_guard_analysis.py

Do not overwrite evidence or write analysis inside RAW. The15 reader checks and
12 producer checks are controlled fixtures, not Linux engine execution.
seekdb/ is a frozen dependency snapshot for these tests, not a full checkout.
The historical root verification and summarize_bulk_guard.py scripts require
their original work/repository/artifact layout; their immutable outputs are
included for inspection. Source-only static proof hashes may describe Windows
line endings, while the actual Git/source audit uses exact committed blobs.
archive-manifest.json hashes all other members. No default flags, formal
submission, official score, conversation record or source code are changed by
this archive operation.
