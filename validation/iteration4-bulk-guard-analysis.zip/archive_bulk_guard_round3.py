"""Freeze the successful192 raw artifact and its complete read-only interpretation."""
import hashlib,json,shutil,subprocess,sys,tempfile,zipfile
from pathlib import Path

HERE=Path(__file__).resolve().parent;REPO=HERE/'seekdb'
COMMIT='85cded31d28192f30b4177ed226384ec8d0ffd95'
RAW_SHA='44420c714d59c1f98fa32879c917351ca02175aac474eb318217a068b69b31fd'

def digest(data):return hashlib.sha256(data).hexdigest()
def sha(path):
    h=hashlib.sha256()
    with path.open('rb') as f:
        for b in iter(lambda:f.read(1024*1024),b''):h.update(b)
    return h.hexdigest()
def encoded(value):return (json.dumps(value,indent=2,ensure_ascii=False,allow_nan=False)+'\n').encode()

raw=HERE/'performance/bulk-guard-85cded3-resumed.zip'
assert raw.stat().st_size==49699707 and sha(raw)==RAW_SHA
raw_target=REPO/'validation/iteration4-bulk-guard-raw.zip'
assert not raw_target.exists();shutil.copyfile(raw,raw_target);assert sha(raw_target)==RAW_SHA
names=[
 'analyze_bulk_guard.py','analyze_bulk_typed.py','analyze_retained_final.py','augment_bulk_projection_resources.py',
 'check_bulk_guard_analysis.py','check_bulk_guard.py','check_retained_final_analyzer.py',
 'bulk-guard-analysis.json','bulk-guard-review.json','summarize_bulk_guard.py',
 'evaluate_bulk_guard_192.py','bulk-guard-evaluation.json','bulk-guard-adoption-assessment.json',
 'bulk-guard-analyzer-static-validation.json','bulk-guard-harness-static-validation.json','localized-bulk-cpp-static-validation.json',
 'root-85cded3-proof.json','root-85cded3-github-observation.json','verify_root_85cded3.py',
 'archive_bulk_guard_round3.py',
]
entries={n:(HERE/n).read_bytes() for n in names}
analysis=json.loads(entries['bulk-guard-analysis.json']);proof=json.loads(entries['bulk-guard-analyzer-static-validation.json'])
assert analysis['status']=='verified' and analysis['verified_pairs']==192 and analysis['candidate_commit']==COMMIT
assert proof['status']=='passed' and len(proof['checks'])==15
for field,name in [('analyzer_sha256','analyze_bulk_guard.py'),('shared_analyzer_sha256','analyze_retained_final.py'),('test_sha256','check_bulk_guard_analysis.py')]:assert proof[field]==digest(entries[name]),name
evaluation=json.loads(entries['bulk-guard-evaluation.json'])
assert evaluation['candidate_commit']==COMMIT and evaluation['verified_pairs']==192
assert evaluation['evidence']['independent_analysis_sha256']==digest(entries['bulk-guard-analysis.json'])
assert evaluation['evidence']['evaluation_tool_sha256']==digest(entries['evaluate_bulk_guard_192.py'])
root_proof=json.loads(entries['root-85cded3-proof.json'])
entries['root-image-validation-85cded3.zip']=(HERE/'performance/root-image-validation-85cded3.zip').read_bytes()
assert digest(entries['root-image-validation-85cded3.zip'])==root_proof['artifact_sha256']
assert root_proof['checks']==16 and root_proof['actual_image_utf8_checks']==54 and root_proof['experimental_bulk_macro_enabled'] is False
entries['raw-artifact-reference.json']=encoded({'source_commit':COMMIT,'zip':'validation/iteration4-bulk-guard-raw.zip',
    'bytes':raw.stat().st_size,'sha256':RAW_SHA,'entries':188,'uncompressed_bytes':241011500,
    'manifest_sha256':analysis['artifact_manifest_sha256'],'measurement_sha256':analysis['artifact_files_verified']['measurements.json'],
    'download_note':'Copied only the complete resumed download; the earlier incomplete ZIP was not used.'})
snapshot=['Dockerfile','protocol_check/_transport.py','minivec/tests/json_protocol.py','minivec/tests/test_bulk_typed_response.cpp','minivec/tests/test_typed_response.py']
snapshot+=['minivec/tools/'+n for n in ('ablation_build.py','bulk_guard_proof.py','benchmark_bulk_guard.py','ci_bulk_guard_confirmation.sh',
    'bulk_typed_proof.py','benchmark_bulk_typed.py','benchmark_regression_ablation.py','regression_ablation_proof.py',
    'benchmark_iteration.py','benchmark_report_matrix.py','benchmark_projection.py','benchmark_filter_repeat.py','pgo/train.cpp','pgo/run-training.sh')]
git=['git','-c','safe.directory='+REPO.as_posix(),'-C',str(REPO)]
for name in snapshot:entries['seekdb/'+name]=subprocess.check_output(git+['show',COMMIT+':'+name])
entries['README.md']=b'''# Localized bulk guard: immutable192 evidence

Source85cded31d28192f30b4177ed226384ec8d0ffd95. Read bulk-guard-analysis.json for
the independent full audit, bulk-guard-evaluation.json for an independent paired
phase/resource derivation, and bulk-guard-adoption-assessment.json for the
protection decision. bulk-guard-review.json is a compact phase and startup
decomposition retaining the unchanged primary totals and every negative pair.

The raw artifact is separate: validation/iteration4-bulk-guard-raw.zip,
49,699,707 bytes; SHA25644420c714d59c1f98fa32879c917351ca02175aac474eb318217a068b69b31fd.
It contains188 files /241,011,500 unpacked bytes and is not duplicated here.
The complete resumed download was used; the earlier incomplete download was not.
Source/profile/flags/binaries,8 actual-binary gates,108 UTF8 cases,3 diagnostic/
sanitizer source gates,30 fixed workloads and192 unique paired identities were
verified. There are150 candidate pairs (10x15) and42 same-baseline A/A (7x6),
not192 independent PGO builds. Both roles are separately trained once.

## Decision and limitations

Bulk remains OFF. Wide4096/all outputs at16/64/127 dimensions show clear gains,
but30k first1000 and after936 retain losses across seed/order groups and higher
process CPU. The60k restart comparison is also negative. No negative samples,
first requests or startup observations were discarded. Startup decomposition is
secondary: the primary accounted timer sum remains. Projection startup includes
Python process creation, reader-thread start and ready receipt, not isolated
database startup CPU. No pooled or formal score increase is inferred.

Projection resource snapshots are included, not falsely described as absent.
Before/after intervals span three requests and untimed host verification gaps.
RSS is a point sample; HWM is cumulative, not an isolated phase peak; CPU has
coarse kernel-tick resolution. Logical I/O and kernel process I/O accounting are
neither device measurements nor cgroup/official score counters. Missing values
remain unavailable, and A/A does not eliminate PGO rebuild variance.

## The root image is a different, default-off binary

Included root proof and original59,817-byte root validation artifact verify
the four default flags,16 gates and54 actual-image UTF8 cases. Its extracted
binary SHA9cfaf9d0a9792b7915c6dc85ba4585c94e443c8aa2790a7c36fb41aa26b1a623
differs from both measured baselineacddca115ab183bfc6419e27c9e3383cfd1a9046e3897e5ea516cd7bc0f29f54
and bulk candidate2d50c45c9aebee86e9224118aeb294dc574c7c6edea1fdde2dc596aeb751bda3.
The192 experiment does not claim to measure this root image. The small root
artifact records CI extraction SHA, not executable bytes for local rehash.
Future adoption requires actual-root correctness and exact measured-binary
identity or a fresh actual-root comparison. No root bridge is enabled here.

## Reproduce read-only checks

Extract this ZIP to a writable directory. Use a separate complete raw artifact
directory and full Git repository retaining85cded3 and e020:

python analyze_bulk_guard.py --input RAW --source-repo REPO --candidate-commit 85cded31d28192f30b4177ed226384ec8d0ffd95 --output NEW_ANALYSIS.json
python evaluate_bulk_guard_192.py --artifact RAW --analysis NEW_ANALYSIS.json --candidate-commit 85cded31d28192f30b4177ed226384ec8d0ffd95 --output NEW_EVALUATION.json
python -B check_bulk_guard_analysis.py

Do not overwrite evidence or write analysis inside RAW. The15 reader checks and
12 producer checks are controlled fixtures, not Linux engine execution.
seekdb/ is a frozen dependency snapshot for these tests, not a full checkout.
The historical root verification and summarize_bulk_guard.py scripts require
their original work/repository/artifact layout; their immutable outputs are
included for inspection. Source-only static proof hashes may describe Windows
line endings, while the actual Git/source audit uses exact committed blobs.
archive-manifest.json hashes all other members. No default flags, formal
submission, official score, conversation record or source code are changed by
this archive operation.
'''
entries['archive-manifest.json']=encoded({'source_commit':COMMIT,'scope':'All other members, frozen source snapshots and original evidence',
    'files':[{'path':n,'bytes':len(v),'sha256':digest(v)} for n,v in sorted(entries.items())]})
target=REPO/'validation/iteration4-bulk-guard-analysis.zip';assert not target.exists()
with zipfile.ZipFile(target,'x',compression=zipfile.ZIP_DEFLATED,compresslevel=9) as z:
    for name,value in sorted(entries.items()):
        info=zipfile.ZipInfo(name,(2026,11,13,0,0,0));info.compress_type=zipfile.ZIP_DEFLATED;z.writestr(info,value,compresslevel=9)
with zipfile.ZipFile(target) as z:
    manifest=json.loads(z.read('archive-manifest.json'))
    assert set(z.namelist())=={v['path'] for v in manifest['files']}|{'archive-manifest.json'}
    for item in manifest['files']:assert digest(z.read(item['path']))==item['sha256']
    with tempfile.TemporaryDirectory(prefix='guard-analysis-unpack-',dir=HERE) as temporary:
        out=Path(temporary).resolve();assert out.is_relative_to(HERE.resolve())
        for name in z.namelist():assert (out/name).resolve().is_relative_to(out)
        z.extractall(out)
        run=subprocess.run([sys.executable,'-B',str(out/'check_bulk_guard_analysis.py')],capture_output=True,text=True,timeout=180)
        assert run.returncode==0,run.stderr
report={'status':'archived_and_verified','source_commit':COMMIT,'raw':{'path':raw_target.relative_to(REPO).as_posix(),'bytes':raw_target.stat().st_size,'sha256':sha(raw_target)},
 'analysis':{'path':target.relative_to(REPO).as_posix(),'bytes':target.stat().st_size,'sha256':sha(target),'members':len(entries)},
 'unpacked_reader_fixture_returncode':run.returncode,'unpacked_reader_fixture_stdout':run.stdout.strip(),
 'scope':'Exact real evidence archives and extracted synthetic reader compatibility; no new Linux engine execution/performance'}
(HERE/'bulk-guard-archive-validation.json').write_bytes(encoded(report));print(json.dumps(report))
