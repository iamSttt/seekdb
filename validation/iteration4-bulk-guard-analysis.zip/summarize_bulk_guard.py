from pathlib import Path
import json,math
import analyze_retained_final as shared

HERE=Path(__file__).resolve().parent
analysis=shared.read(HERE/'bulk-guard-analysis.json')
raw=shared.read(HERE/'performance/bulk-guard-85cded3/measurements.json')
shared.require(analysis['status']=='verified' and analysis['candidate_commit']=='85cded31d28192f30b4177ed226384ec8d0ffd95' and analysis['verified_pairs']==192,'wrong verified input')

def compact(metric):
    return {'baseline_over_candidate':metric['baseline_over_candidate'],'baseline_seconds':metric['baseline'],'candidate_seconds':metric['candidate'],
        'negative_pairs':metric['negative_pairs'],'by_seed':metric['by_seed'],'by_order':metric['by_order']}

groups={}
for key,group in analysis['groups'].items():
    projection='accounted_timer_sum' in group['timings']
    names=['lifecycle/startup','lifecycle/create_and_insert','lifecycle/shutdown','accounted_timer_sum',*['query/'+label for label in shared.LABELS]] if projection else [
        'startup','ingest','index_build','query_before_update','query_after_restart','measured_lifecycle',
        'query_before_update/first','query_before_update/front64','query_before_update/after64',
        'query_after_restart/front64','query_after_restart/after64','query_after_restart/single_filter_ann_after_first']
    groups[key]={'pairs':group['pairs'],'primary':{n:compact(group['timings'][n]) for n in names if n in group['timings']}}
    if projection:
        pairs=[p for p in raw['pairs'] if p['contrast']+'/'+p['scenario']==key]
        groups[key]['secondary_startup_attribution_check']={
            'query_timer_sum':shared.metric(pairs,lambda r:math.fsum(p['wall_seconds'] for p in r['phases'].values())),
            'accounted_without_startup':shared.metric(pairs,lambda r:math.fsum(r['lifecycle_seconds'].values())+math.fsum(p['wall_seconds'] for p in r['phases'].values())-r['lifecycle_seconds']['startup']),
            'startup_raw':[{**shared.identity(p),'baseline_seconds':p['baseline']['lifecycle_seconds']['startup'],'candidate_seconds':p['candidate']['lifecycle_seconds']['startup']} for p in pairs],
            'scope':'Secondary decomposition only. Primary accounted_timer_sum and every negative pair remain. Startup times include Python Popen/reader-thread/ready receipt; they do not isolate database startup CPU.'}
result={'status':'derived_from_verified192','candidate_commit':analysis['candidate_commit'],'baseline_commit':analysis['baseline_commit'],
    'analysis_sha256':shared.sha(HERE/'bulk-guard-analysis.json'),'measurement_sha256':shared.sha(HERE/'performance/bulk-guard-85cded3/measurements.json'),
    'binary_sha256':{r:p['binary_sha256'] for r,p in analysis['profile_source_proof'].items()},'groups':groups,
    'assessment':{'correctness_or_integrity_blocker':False,
        'target_gain':'The16/64/127-dimensional wide4096 and all-row outputs improve on all three seeds. many16/127 have15/15 faster pairs for both outputs; many64 has14/15 large and15/15 all faster.',
        'unresolved_losses':'30k first1000 and front64 remain slower on all three seeds; filter60k restart and wide128 all-output are modestly negative. many16 distance10 and wide768 primary accounted totals retain negative observations. A/A context does not normalize them away.',
        'startup_limit':'Several projection startup intervals differ by tens of milliseconds even in same-binary AA. The interval includes host process/reader-thread orchestration; this is insufficient to assign the difference to engine code. Secondary decomposition is supplied without replacing primary totals.',
        'readiness':'Eligible for a separately validated actual-root candidate only if these workload tradeoffs are accepted. No direct broad adoption or6000-score claim. Actual root executable must match the measured candidate exactly or undergo its own192 comparison.',
        'statistical_scope':'3 fixed workloads and5 paired repetitions each; one PGO build per role. Same-binary AA checks host/process variation, not PGO rebuild variation.'},
    'official_score':None,'automatic_adoption':False}
out=HERE/'bulk-guard-review.json';shared.require(not out.exists(),'refuse overwrite')
out.write_bytes((json.dumps(result,indent=2,ensure_ascii=False,allow_nan=False)+'\n').encode())
print(json.dumps({'status':result['status'],'groups':len(groups),'output':str(out)}))
