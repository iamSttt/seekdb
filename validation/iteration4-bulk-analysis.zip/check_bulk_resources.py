#!/usr/bin/env python3
"""Validate the resource-description amendment against the immutable84 artifact."""
from copy import deepcopy
from pathlib import Path
import json
import augment_bulk_projection_resources as patch

ROOT=Path(__file__).resolve().parent
original=patch.audit.read(ROOT/'bulk-typed-analysis.json')
amended=patch.audit.read(ROOT/'bulk-typed-analysis-resources.json')
keys=amended.pop('resource_description_amendment')['projection_groups_corrected']
recorded_resources=deepcopy(amended['groups']['bulk/many16']['details']['resources'])
checks=[]
for key in keys:
    old,new=original['groups'][key]['details'],amended['groups'][key]['details']
    resources=new['resources']
    assert resources['snapshots_per_process']==14 and len(resources['phases'])==7
    assert 'not device measurements' in new['resource_limit'] and 'resolution' in new['resource_limit']
    new['resources']=old['resources'];new['resource_limit']=old['resource_limit']
assert amended==original
checks.append('All original timings, proof, scores and nonresource fields remain byte-value-equivalent after reversing only the six descriptions/resources and amendment metadata.')
first=next(iter(recorded_resources['phases'].values()))['raw_paired_snapshots'][0]
pair={k:deepcopy(first[k]) for k in ('scenario','seed','pair_index','order','contrast')}
for side in ('baseline','candidate'):
    snapshots=[]
    for phase in recorded_resources['phases'].values():
        recorded=phase['raw_paired_snapshots'][0][side]
        snapshots.extend((deepcopy(recorded['before']),deepcopy(recorded['after'])))
    pair[side]={'policy_evidence':{'task_snapshots':snapshots}}
for side in ('baseline','candidate'):
    for snapshot in pair[side]['policy_evidence']['task_snapshots']:
        snapshot.pop('process_cpu_seconds',None)
missing=patch.projection_resources([pair])
assert all('unavailable' in p['baseline_cpu_delta_seconds'] for p in missing['phases'].values())
checks.append('Missing process CPU remains unavailable; no invented zero or partial aggregate.')
pair['candidate']['policy_evidence']['task_snapshots'].pop()
try:patch.projection_resources([pair])
except ValueError:checks.append('Missing one of14 snapshots rejected.')
else:raise AssertionError('missing snapshot accepted')
report={'status':'passed','scope':'resource availability/correction validation; no new benchmark or changed raw evidence','checks':checks,
        'files_sha256':{n:patch.audit.sha(ROOT/n) for n in ('augment_bulk_projection_resources.py','bulk-typed-analysis.json','bulk-typed-analysis-resources.json','analyze_bulk_typed.py','analyze_retained_final.py')}}
(ROOT/'bulk-resource-correction-validation.json').write_bytes((json.dumps(report,indent=2)+'\n').encode())
print(json.dumps({'status':'passed','checks':len(checks)}))
