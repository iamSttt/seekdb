"""Read-only condensation; no execution, adoption, or sample removal."""
import argparse
import hashlib
import json
from pathlib import Path

p = argparse.ArgumentParser()
p.add_argument('--analysis', type=Path, required=True)
p.add_argument('--output', type=Path, required=True)
a = p.parse_args()
assert not a.output.exists(), 'Refuse overwrite'
raw = a.analysis.read_bytes()
d = json.loads(raw)
assert d['status'] == 'verified' and d['verified_pairs'] == 84
assert d['candidate_commit'] == 'c562aa21b479c090c6080064a40414959e417fbc'
groups = {}
for name, g in d['groups'].items():
    metrics = {}
    for phase, m in g['timings'].items():
        metrics[phase] = {
            'pairs': m['pairs'],
            'baseline_seconds': m['baseline'],
            'candidate_seconds': m['candidate'],
            'paired_baseline_over_candidate': m['baseline_over_candidate'],
            'slower_candidate_pairs': m['candidate_value_larger_pairs'],
            'seed_ratios': {k: v['baseline_over_candidate'] for k,v in m['by_seed'].items()},
            'order_ratios': {k: v['baseline_over_candidate'] for k,v in m['by_order'].items()},
            'negative_pairs': m['negative_pairs'],
        }
    groups[name] = {'pairs': g['pairs'], 'all_phases_including_negative': metrics}
out = {
    'status': 'measured_not_adopted_pending_refinement',
    'executed_by': 'assistant',
    'source_commit': d['candidate_commit'],
    'baseline_commit': d['baseline_commit'],
    'run_id': 43365215272, 'job_id': 131687910283,
    'pairs': 84, 'candidate_pairs': 66, 'same_binary_control_pairs': 18,
    'binary_gates_passed': 8, 'utf8_cases_passed': 108,
    'source_unit_sanitizer_gates_passed': 3,
    'baseline_binary_sha256': 'acddca115ab183bfc6419e27c9e3383cfd1a9046e3897e5ea516cd7bc0f29f54',
    'candidate_binary_sha256': 'd1f1e389cfd5b182d5cdefdf33d6b06d1faadb0bdd536a702e15349aa5e4f7b7',
    'baseline_matches_prior311_binary_bytes': True,
    'default_enabled': False, 'official_score': None,
    'automatic_submission': False,
    'raw_artifact': {
        'path': 'validation/iteration4-bulk-raw.zip',
        'github_artifact_id': 14009978746,
        'bytes': 49108441,
        'sha256': 'dc8564b66324e27a7285093f184c223148261937bb5473457720b7f152c15930',
        'entries': 188, 'uncompressed_bytes': 233694808,
    },
    'analysis_file_sha256': hashlib.sha256(raw).hexdigest(),
    'decision': [
        'Keep the bulk-vector direction as a candidate, not a new default. Preserve the existing four default features and original PGO.',
        '16/64/127-dimensional large-output query phases improve, but filter60k and other protection cases have negative observations. Positive cases do not cancel these negatives.',
        'Move bulk metadata checks into the actual16..127 vector-item short-circuit, then independently confirm. This is a hypothesis, not a proved explanation of millisecond cold-query stalls.',
        'The next plan increases every candidate scenario to15 paired observations and adds same-program controls. No sample from this84-pair run is removed or reclassified.',
    ],
    'groups': groups,
    'limitations': d['limitations'] + [
        'Projection raw data contain before/after /proc CPU, RSS/HWM and I/O proxies. Any older generic-reader note claiming no such data was recorded is superseded by the resource addendum; these are not cgroup scores or physical-device I/O.',
        'Projection repeats within one pair are not independent experiments. All query first requests, later requests, startup/ingestion pauses and negative pairs remain in the complete raw archive.',
        '30k does not project a vector; its observed gain cannot be attributed to activating the bulk encoder. Source/PGO/layout and host effects are not causally separated.',
        'The default root-image correctness proof is separate. Performance evidence applies only to the exact program hashes listed here.',
    ],
}
a.output.write_text(json.dumps(out, ensure_ascii=False, indent=2)+'\n', encoding='utf8', newline='\n')
print(json.dumps({'output': str(a.output), 'bytes': a.output.stat().st_size,
                  'sha256': hashlib.sha256(a.output.read_bytes()).hexdigest()}))
