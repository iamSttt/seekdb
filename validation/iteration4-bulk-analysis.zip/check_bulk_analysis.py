#!/usr/bin/env python3
"""Focused new84 reader fixtures; no real benchmark or performance conclusions."""
from contextlib import redirect_stdout
from copy import deepcopy
import io
import json
from pathlib import Path
import tempfile

import analyze_bulk_typed as audit
import check_bulk_typed as fixture

HERE=Path(__file__).resolve().parent

class FixtureGit:
    def __init__(self,scratch): self.scratch=scratch
    def files(self,commit,selectors):
        assert commit in (audit.BASELINE,'b'*40)
        root=self.scratch/('baseline' if commit==audit.BASELINE else 'candidate')
        return {p.relative_to(root).as_posix():p.read_bytes() for p in root.rglob('*') if p.is_file()}

def save(path,value):
    path.write_bytes((json.dumps(value,indent=2,allow_nan=False)+'\n').encode())

def manifest(out):
    save(out/'hashes.json',{'artifacts':[{'path':p.relative_to(out).as_posix(),'bytes':p.stat().st_size,'sha256':audit.sha(p)} for p in sorted(out.rglob('*')) if p.is_file() and p.name!='hashes.json']})

def make_fixture(out,scratch):
    data=fixture.make_fixture(out,scratch)
    # Synthetic source difference has the same shape as the reviewed experiment.
    for side in ('baseline','candidate'):
        fixture.write(scratch/side/'minivec/src/exec.cpp', ('// synthetic '+side+' exec\n').encode())
    fixture.write(scratch/'candidate/minivec/src/json_response_diagnostics.h',b'// synthetic diagnostics\n')
    for role in audit.ROLES:
        target=out/(role+'-pgo'); training=target/'training'
        snapshot=scratch/('baseline' if role=='baseline' else 'candidate')/'minivec/src'
        for path in snapshot.iterdir(): fixture.write(target/'built-source'/path.name,path.read_bytes())
        fixture.write(training/'profile-data/minivec-exec.gcda',b'synthetic exec profile')
        fixture.write(training/'profile-sha256.txt',''.join(audit.sha(p)+'  /pgo/'+p.name+'\n' for p in sorted((training/'profile-data').iterdir())))
    fixture.proof.initialize(out,scratch,'b'*40);fixture.proof.verify_builds(out,scratch)
    context=audit.read(out/'context.json');inputs=audit.read(out/'build-input.json')
    for role in audit.ROLES:
        generated=out/'build-input'/('Dockerfile.'+role)
        generated.write_bytes(generated.read_text().encode())
        inputs['roles'][role]['build_dockerfile_sha256']=audit.sha(generated)
        context['profile_source_proof'][role]['build_dockerfile_sha256']=audit.sha(generated)
    save(out/'build-input.json',inputs);save(out/'context.json',context)
    data['build_context_sha256']=audit.sha(out/'context.json')
    data['host']['platform']=context['platform']
    data['kind']='interleaved_bulk_typed_confirmation_84'
    data['parameters']={'seeds':list(audit.SEEDS),'queries_iteration':1000,'queries_spill':64,'projection_repetitions':3,'expected_total_pairs':84}
    for pair in data['pairs']:
        if pair['scenario'] in audit.PROJECTIONS:
            for side in ('baseline','candidate'):
                pair[side]['policy_evidence']['task_snapshots']=[{'native_tasks':[{'tid':100,'main':True,'cpu_ticks':1}]} for _ in range(14)]
    save(out/'measurements.json',data)
    for role in audit.ROLES:
        target=out/(role+'-pgo');save(target/'build-cost.json',{'status':'passed','pgo_enabled':True,'nanoseconds':1})
        fixture.write(target/'build.log','synthetic, not compiled\n')
        for label in ('json_protocol','utf8_atomicity','topk_serial','topk_parallel'):
            for stream in ('stdout','stderr'): fixture.write(target/(label+'.'+stream+'.log'),'synthetic log\n')
        utf8=audit.read(out/(role+'-utf8.json'))
        for item in utf8['checks']:item['valid_prefix_bytes']=90000
        save(out/(role+'-utf8.json'),utf8)
    for role,mode,test in fixture.bulk.UNIT_CASES:
        label='-'.join((role,mode,test))
        fixture.write(out/'unit'/label,b'synthetic binary')
        fixture.write(out/'unit'/(label+'-build.log'),'synthetic build log\n')
    with redirect_stdout(io.StringIO()):fixture.bulk.collect(out,0)
    return data,inputs,context,FixtureGit(scratch)

def main():
    checks=[]
    def reject(name,call):
        try:call()
        except (ValueError,KeyError):checks.append({'case':name,'result':'rejected'})
        else:raise AssertionError(name)
    with tempfile.TemporaryDirectory(prefix='bulk-reader-fixture-',dir=HERE) as temp:
        root=Path(temp);out=root/'out';scratch=root/'scratch'
        data,inputs,context,source=make_fixture(out,scratch)
        result=audit.analyze(out,'b'*40,source)
        assert result['verified_pairs']==84 and len(result['groups'])==13
        assert all(result['groups']['bulk/'+n]['pairs']==3 for n in audit.PROJECTIONS)
        assert result['groups']['bulk/standard10k']['timings']['query_after_restart/single_filter_ann_window_513_999']['descriptive_bootstrap']['replicates']==2000
        assert result['groups']['bulk/many127']['timings']['accounted_timer_sum']['descriptive_bootstrap'] is None
        assert result['groups']['bulk/many64']['details']['phases']['wide_all']['rows_per_response']==8192
        assert result['groups']['bulk/resident30k']['aa_measurement_context']['pairs']==6
        checks.append({'case':'complete84_66bulk18aa_30inputs_5projection_3sourcegates_108utf8','result':'accepted synthetic only'})
        assert not result['earlier_delivery_binary_comparison']['byte_identical_to_earlier_actual_binary']
        equal=deepcopy(context);equal['profile_source_proof']['baseline']['binary_sha256']=result['earlier_delivery_binary_comparison']['earlier_actual_binary_sha256']
        assert audit.delivery_comparison(equal)['byte_identical_to_earlier_actual_binary']
        checks.append({'case':'earlier_delivery_binary_equality_true_and_false_without_image_assumption','result':'passed'})
        snapshots=audit.audit_builds(out,'b'*40,source,inputs,context)
        for name,mutate in [
            ('many64_dimension_changed',lambda d:next(w for w in d['workloads'] if w['scenario']=='many64').__setitem__('dimension',16)),
            ('many127_row_count_changed',lambda d:next(p for p in d['pairs'] if p['scenario']=='many127')['candidate']['phases']['wide_all'].__setitem__('rows_per_response',4096)),
            ('many127_oracle_digest_changed',lambda d:next(p for p in d['pairs'] if p['scenario']=='many127')['candidate']['phases']['wide_all']['requests'][0].__setitem__('response_sha256','0'*64)),
            ('new84_pair_missing',lambda d:d['pairs'].pop()),
            ('AA_changed_binary',lambda d:next(p for p in d['pairs'] if p['contrast']=='aa')['binary_paths'].__setitem__('candidate','/not-baseline')),
            ('new84_parameter_changed_to138',lambda d:d['parameters'].__setitem__('expected_total_pairs',138)),
        ]:
            changed=deepcopy(data);mutate(changed)
            reject(name,lambda:audit.audit_measurements(out,context,inputs,snapshots,changed))
        unit=out/'unit/bulk-sanitized-bulk_typed_response.log';content=unit.read_bytes()
        unit.write_bytes(b'PASS bulk typed admission boundaries bulk=0\n')
        reject('sanitizer_passed_wrong_inactive_path',lambda:audit.audit_correctness(out,context));unit.write_bytes(content)
        unit=out/'unit/passed.tsv';content=unit.read_bytes();unit.write_bytes(content.splitlines(keepends=True)[0])
        reject('three_unit_inventory_missing',lambda:audit.audit_correctness(out,context));unit.write_bytes(content)
        summary=out/'summary.json';original=summary.read_bytes();wrong=audit.read(summary);wrong['verified_total_pairs']=16;save(summary,wrong);manifest(out)
        reject('shadowed_count16_cannot_replace84',lambda:audit.analyze(out,'b'*40,source));summary.write_bytes(original);manifest(out)
        unit=out/'unit/control-normal-bulk_typed_response';content=unit.read_bytes();unit.write_bytes(content+b'changed')
        reject('new_unit_manifest_hash_modified',lambda:audit.audit_manifest(out));unit.write_bytes(content)
        original_read_bytes=Path.read_bytes
        def deny(path):
            if path.parent.name=='unit' and path.suffix=='' or path.name in ('minivec','instrumented-minivec','unstripped-minivec'):raise AssertionError('binary loaded whole')
            return original_read_bytes(path)
        Path.read_bytes=deny
        try:audit.audit_manifest(out);audit.audit_builds(out,'b'*40,source,inputs,context)
        finally:Path.read_bytes=original_read_bytes
        checks.append({'case':'whole_manifest_binary_hashes_streamed','result':'passed'})
        reject('commit_prefix_rejected',lambda:audit.audit_builds(out,'bbbbbbb',source,inputs,context))
        changed=deepcopy(context);changed['profile_source_proof']['bulk']['feature_flags'].append('-DMVDB_ENABLE_DOM_ROW_RESERVE')
        reject('old_failed_macro_cannot_leak',lambda:audit.audit_builds(out,'b'*40,source,inputs,changed))
    report={'status':'passed','scope':'focused synthetic reader tests only; no Linux execution, real artifact analysis, or performance conclusion',
        'analyzer_sha256':audit.sha(HERE/'analyze_bulk_typed.py'),'shared_analyzer_sha256':audit.sha(HERE/'analyze_retained_final.py'),'test_sha256':audit.sha(Path(__file__)),'checks':checks}
    save(HERE/'bulk-typed-analyzer-static-validation.json',report)
    print(json.dumps({'status':'passed','checks':len(checks),'scope':report['scope']}))

if __name__=='__main__':main()
