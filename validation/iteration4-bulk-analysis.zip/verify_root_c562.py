"""Read-only CI/root input verification; archive original bulk artifact bytes."""
import hashlib
import json
from pathlib import Path, PurePosixPath
import re
import shutil
import subprocess
import zipfile

HERE = Path(__file__).resolve().parent
REPO = HERE / 'seekdb'
ROOT = HERE / 'performance/root-image-validation-c562aa2'
COMMIT = 'c562aa21b479c090c6080064a40414959e417fbc'
FLAGS = ['-DMVDB_ENABLE_SPILL_FILTER', '-DMVDB_ENABLE_TYPED_JSON',
         '-DMVDB_TYPED_WIDE_VECTOR_ONLY', '-DMVDB_MULTI_POSTING_REUSE_ONLY']
SELECTORS = ['Dockerfile', '.dockerignore', 'minivec/src', 'minivec/third_party',
             'minivec/Makefile', 'minivec/tests', 'minivec/tools/ci_score.sh',
             'minivec/tools/ci_final_performance.sh', 'minivec/tools/pgo/train.cpp',
             'minivec/tools/pgo/run-training.sh', 'STDIO_PROTOCOL.md', 'protocol_check', 'mysqltest']
git = ['git', '-c', 'safe.directory=' + REPO.as_posix(), '-C', str(REPO)]

def sha(path):
    h = hashlib.sha256()
    with path.open('rb') as f:
        for b in iter(lambda: f.read(1024 * 1024), b''): h.update(b)
    return h.hexdigest()

def read(path):
    return json.loads(path.read_text(encoding='utf-8'))

artifact = ROOT.with_suffix('.zip')
assert sha(artifact) == '5d7e8688e3a2dc3677ac777610063c7d113476fe89106ab99f97574f6dcd0eac'
assert artifact.stat().st_size == 59853
with zipfile.ZipFile(artifact) as z:
    assert z.testzip() is None
    entries = z.infolist()
    assert len(entries) == 94
    for e in entries:
        assert sha(ROOT / e.filename) == hashlib.sha256(z.read(e)).hexdigest(), e.filename

summary = read(ROOT / 'verification-summary.json')
assert summary['runtime_commit'] == COMMIT == (ROOT / 'runtime-commit.txt').read_text().strip()
assert summary['passed'] is True and len(summary['checks']) == 16 and all(v is True for v in summary['checks'].values())
assert summary['selected_feature_flags'] == FLAGS
image_sha = (ROOT / 'image-binary-sha256.txt').read_text().split()[0]
assert summary['image_binary_sha256'] == image_sha
assert summary['source_binary_sha256'] == (ROOT / 'source-binary-sha256.txt').read_text().split()[0]
image = read(ROOT / 'image-inspect.json')
assert len(image) == 1 and image[0]['Id'] == summary['image_id'] == (ROOT / 'image-id.txt').read_text().strip()
assert image[0]['Architecture'] == 'amd64' and image[0]['Os'] == 'linux'
utf8 = read(ROOT / 'image-binary-utf8.json')
expected = {(malformed, dim, path) for malformed in ['ff', 'c080', 'eda080', 'f4908080', 'e4b8', '80']
            for dim in [None, 127, 128] for path in ['ORDER BY id LIMIT 10', 'unbounded', 'ORDER BY id LIMIT 4096']}
actual = {(x['malformed_hex'], x['projected_vector_dimension'], x['path']) for x in utf8['checks']}
assert utf8['status'] == 'passed' and len(utf8['checks']) == 54 and actual == expected
assert all(x['status'] == 'passed' and x['valid_prefix_bytes'] == 90000 for x in utf8['checks'])
for log in ['image-binary-json.log', 'image-binary-topk.log', 'image-binary-topk-parallel.log',
            'filter-reuse-normal.log', 'filter-reuse-sanitized.log']:
    assert 'PASS' in (ROOT / log).read_text(encoding='utf-8')

inputs = {}
for line in (ROOT / 'input-sha256.txt').read_text().splitlines():
    digest, name = line.split('  ', 1)
    p = PurePosixPath(name)
    assert re.fullmatch('[0-9a-f]{64}', digest) and name not in inputs
    assert not p.is_absolute() and p.as_posix() == name and '..' not in p.parts
    inputs[name] = digest
paths = subprocess.check_output(git + ['ls-tree', '-r', '--name-only', COMMIT, '--'] + SELECTORS).decode().splitlines()
assert set(paths) == set(inputs), (set(paths) - set(inputs), set(inputs) - set(paths))
batch = subprocess.check_output(git + ['cat-file', '--batch'], input=''.join(COMMIT + ':' + p + '\n' for p in paths).encode())
offset = 0
blobs = {}
for p in paths:
    end = batch.index(b'\n', offset)
    oid, typ, length = batch[offset:end].split()
    assert typ == b'blob'
    offset = end + 1
    b = batch[offset:offset + int(length)]
    assert len(b) == int(length) and hashlib.sha256(b).hexdigest() == inputs[p], p
    offset += int(length)
    assert batch[offset:offset + 1] == b'\n'; offset += 1
    blobs[p] = b
assert offset == len(batch)
docker = blobs['Dockerfile'].decode()
make = blobs['minivec/Makefile'].decode()
ci = blobs['minivec/tools/ci_score.sh'].decode()
assert re.search(r'ARG FEATURE_FLAGS="' + re.escape(' '.join(FLAGS)) + '"', docker)
assert re.search(r'FEATURE_FLAGS \?= ' + re.escape(' '.join(FLAGS)) + r'\s*\n', make)
assert "FEATURE_FLAGS='" + ' '.join(FLAGS) + "'" in ci
assert 'docker cp "$container:/minivec" "$scratch/image-binary"' in ci
assert 'python3 minivec/tests/test_typed_response.py' in ci

bulk_root = HERE / 'performance/bulk-typed-c562aa2'
context = read(bulk_root / 'context.json')
hashes = {role: p['binary_sha256'] for role, p in context['profile_source_proof'].items()}
for role, digest in hashes.items():
    assert sha(bulk_root / (role + '-pgo') / 'minivec') == digest
matched_roles = [role for role, digest in hashes.items() if digest == image_sha]
raw = bulk_root.with_suffix('.zip')
expected_raw = 'dc8564b66324e27a7285093f184c223148261937bb5473457720b7f152c15930'
assert raw.stat().st_size == 49108441 and sha(raw) == expected_raw
with zipfile.ZipFile(raw) as z:
    assert z.testzip() is None
    raw_files, raw_bytes = len(z.infolist()), sum(e.file_size for e in z.infolist())
target = REPO / 'validation/iteration4-bulk-raw.zip'
if target.exists(): assert sha(target) == expected_raw
else: shutil.copyfile(raw, target)
assert sha(target) == expected_raw

proof = {
    'status': 'verified', 'runtime_commit': COMMIT, 'run_id': 43365215272,
    'job_id': 131687910629, 'github_job_observed_conclusion': 'success',
    'artifact_id': 14010766367, 'artifact_sha256': sha(artifact),
    'artifact_bytes': artifact.stat().st_size, 'artifact_files': 94,
    'immutable_git_inputs_verified': len(inputs), 'input_hashes': inputs,
    'input_manifest_sha256': sha(ROOT / 'input-sha256.txt'),
    'verification_summary_sha256': sha(ROOT / 'verification-summary.json'),
    'checks': 16, 'actual_image_utf8_checks': 54, 'default_flags': FLAGS,
    'image_id': summary['image_id'], 'image_binary_sha256': image_sha,
    'source_binary_sha256': summary['source_binary_sha256'],
    'experimental_bulk_macro_enabled': False, 'measured_role_binary_hashes': hashes,
    'matches_measured_roles': matched_roles, 'performance_measured': bool(matched_roles),
    'performance_scope': 'No measured-role SHA match: the84 paired run must not be attributed to this current default root-image binary.',
    'verification_scope': 'Authenticated GitHub job/artifact metadata plus original ZIP digest, extracted94 files, summary and gate logs, all immutable Git blobs and source feature wiring. This is not a local Docker rebuild or new C++ test run. The small root artifact records CI extraction SHA; it does not contain the executable for independent local rehash.',
    'bulk_raw_archive': {'path': target.relative_to(REPO).as_posix(), 'bytes': raw.stat().st_size,
                         'sha256': expected_raw, 'files': raw_files, 'uncompressed_bytes': raw_bytes,
                         'original_zip_bytes_unchanged': True},
    'analysis_archive_pending': 'Wait for frozen resource-aware analysis/reader; do not rewrite original raw evidence.',
    'formal_submission_performed': False, 'official_score': None,
}
assert not matched_roles
out = HERE / 'root-c562-proof.json'
assert not out.exists()
out.write_bytes((json.dumps(proof, indent=2, allow_nan=False) + '\n').encode())
print(json.dumps({k: proof[k] for k in ['status','runtime_commit','immutable_git_inputs_verified','checks','actual_image_utf8_checks','image_binary_sha256','matches_measured_roles','performance_measured','bulk_raw_archive']}))
