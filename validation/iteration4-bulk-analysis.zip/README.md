# Bulk-output round two: immutable c562 evidence

This archive contains both the original verified84 analysis and a resource-aware
reading edition. Read `bulk-typed-analysis-resources.json` first. The original
reader inherited a claim that projection resources were uninstrumented; that is
incorrect for this harness. The new edition attaches the original14 per-process
snapshots for all6 projection groups and corrects that description. It does not
change timings, source proofs, scores, or raw evidence. The amendment and its
3-check proof explicitly preserve this boundary.

The original full artifact is stored SEPARATELY as
`validation/iteration4-bulk-raw.zip`: 49,108,441 bytes,
SHA256 dc8564b66324e27a7285093f184c223148261937bb5473457720b7f152c15930,
188 files /233,694,808 unpacked bytes. It is not duplicated inside this ZIP.
Every negative pair remains. There are66 candidate pairs and18 same-baseline A/A.
Results are mixed; no default adoption or official score is claimed here.

## Root image is a separate binary

The original59,853-byte root validation artifact and independent root proof are
included. Root job131687910629 succeeded:140 immutable Git input hashes,16 gates,
54 UTF8 cases, and the original four default flags. Its recorded extracted binary
SHA is62fe4dedfeb1e6d08365d4a620262b37721ec2b4465552f127c6c95b4f713e52.
It is neither the baseline acddca115ab183bfc6419e27c9e3383cfd1a9046e3897e5ea516cd7bc0f29f54
nor the bulk candidate d1f1e389cfd5b182d5cdefdf33d6b06d1faadb0bdd536a702e15349aa5e4f7b7.
Therefore the84 paired performance results do not bind this default root image.
The small root artifact records CI extraction SHA, not the executable bytes.

## Reading process snapshots

Before/after snapshots span three requests plus untimed host verification gaps.
RSS is a point sample; HWM is cumulative, not an isolated phase peak. CPU is tick
quantized, so a zero delta need not mean no work. Logical I/O and kernel process
I/O accounting are not device counters or cgroup/official metrics. Missing values
are unavailable rather than zero. These proxies do not prove a causal speedup.

## Reproducing read-only analysis

Extract this ZIP into a writable directory. Use a separate complete raw artifact
directory and a real repository retaining c562 and e020:

```
python analyze_bulk_typed.py --input RAW_DIRECTORY --source-repo REPOSITORY --candidate-commit c562aa21b479c090c6080064a40414959e417fbc --output NEW_ORIGINAL.json
python augment_bulk_projection_resources.py --raw RAW_DIRECTORY --analysis NEW_ORIGINAL.json --output NEW_RESOURCES.json
python check_bulk_analysis.py
python check_bulk_resources.py
python summarize_bulk84.py --analysis bulk-typed-analysis.json --output NEW_SUMMARY.json
```

New analysis outputs must not exist and must be outside RAW_DIRECTORY. The15
reader and3 resource checks are controlled validation, not Linux compilation or
performance experiments. They refresh proof files only in the unpacked copy.
`seekdb/` here is only a frozen c562 dependency snapshot for the synthetic tests,
not a full Git checkout. `verify_root_c562.py` is the historical verification
script and requires its original full work/repository/raw-artifact layout.
`summarize_bulk84.py` preserves all phase metrics and negative pairs in a smaller
summary; its output must not be confused with a rerun of measurements.
The source-only preflight file may record Windows working-file line endings;
the actual root proof instead compares all140 exact immutable Git blobs.

No third-round candidate results exist in this archive. No default switches,
conversation records, documentation decisions or formal submissions are changed
by this archive operation.
