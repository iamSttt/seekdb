#!/usr/bin/env python3
"""Correct the old projection resource description without changing raw evidence."""
import argparse
from collections import defaultdict
from pathlib import Path
import json

import analyze_bulk_typed as audit
import analyze_retained_final as shared

LIMIT = ('Raw Linux /proc process snapshots were recorded before the first and after the third request of each projection phase, outside request timers. '
         'These intervals include untimed host verification gaps. CPU is cumulative utime+stime at clock_ticks_per_second resolution; sub-tick changes can be zero. '
         'VmRSS is instantaneous and VmHWM is the process-wide cumulative high-water mark, not an isolated phase peak; both originate from kernel kB counters converted to bytes. '
         'rchar/wchar/syscr/syscw are process logical-I/O counters; read_bytes/write_bytes are kernel process I/O accounting proxies, not device measurements. '
         'They are neither cgroup memory/I/O nor official score counters. Native task CPU may include parser work, not only query workers. Missing counters remain missing.')

def projection_resources(group):
    phases = {}
    for label in shared.LABELS:
        rows=[]
        for pair in group:
            row={**shared.identity(pair), 'contrast':pair['contrast']}
            for side in shared.SIDES:
                snaps=pair[side]['policy_evidence']['task_snapshots']
                shared.require(len(snaps)==14 and len({s['phase'] for s in snaps})==14,'projection snapshots missing/duplicate')
                byname={s['phase']:s for s in snaps}
                before,after=byname[label+'/before'],byname[label+'/after']
                value={'before':before,'after':after}
                if all('process_cpu_seconds' in v for v in (before,after)):
                    value['process_cpu_seconds_delta']=after['process_cpu_seconds']-before['process_cpu_seconds']
                if all('clock_ticks_per_second' in v for v in (before,after)):
                    value['clock_ticks_per_second']=[before['clock_ticks_per_second'],after['clock_ticks_per_second']]
                row[side]=value
            rows.append(row)
        phases[label]={'raw_paired_snapshots':rows}
        for side in shared.SIDES:
            values=[r[side].get('process_cpu_seconds_delta') for r in rows]
            phases[label][side+'_cpu_delta_seconds']=shared.stats(values) if all(v is not None for v in values) else {'unavailable':'missing in at least one pair; no partial aggregation'}
    return {'source':'policy_evidence.task_snapshots', 'snapshots_per_process':14, 'phases':phases, 'limits':LIMIT}

def augment(raw,analysis):
    raw=raw.resolve(); original=audit.read(analysis)
    shared.require(original['status']=='verified' and original['verified_pairs']==84,'requires verified original84 analysis')
    entries=audit.audit_manifest(raw)
    shared.require(original['artifact_manifest_sha256']==audit.sha(raw/'hashes.json') and original['artifact_files_verified']==entries,'analysis/raw manifest differs')
    data=audit.read(raw/'measurements.json')
    shared.require(original['candidate_commit']==data['candidate_commit'],'analysis/source differs')
    groups=defaultdict(list)
    for pair in data['pairs']:
        if pair['scenario'] in audit.PROJECTIONS:groups[pair['contrast']+'/'+pair['scenario']].append(pair)
    for key,group in groups.items():
        target=original['groups'][key]
        shared.require(target['pairs']==len(group),'analysis group count differs')
        target['details']['resources']=projection_resources(group)
        target['details']['resource_limit']=LIMIT
    original['resource_description_amendment']={'original_analysis_sha256':audit.sha(analysis), 'tool_sha256':audit.sha(Path(__file__)),
        'scope':'Corrects projection resource availability text and appends actual raw process snapshots; original timing ratios, source proofs and raw files unchanged.',
        'projection_groups_corrected':sorted(groups)}
    return original

def main():
    p=argparse.ArgumentParser(description=__doc__);p.add_argument('--raw',type=Path,required=True);p.add_argument('--analysis',type=Path,required=True);p.add_argument('--output',type=Path,required=True);a=p.parse_args()
    shared.require(not a.output.exists() and not a.output.resolve().is_relative_to(a.raw.resolve()),'refuse overwrite/raw output')
    result=augment(a.raw,a.analysis)
    with a.output.open('x',encoding='utf-8',newline='\n') as f:json.dump(result,f,ensure_ascii=False,indent=2,allow_nan=False);f.write('\n')
    print(json.dumps({'status':'verified_resource_description_amended','groups':len(result['resource_description_amendment']['projection_groups_corrected']),'output':str(a.output)}))

if __name__=='__main__':main()
