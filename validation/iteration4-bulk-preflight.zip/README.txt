Static/source inspection and26 synthetic harness checks only; no Linux compile or performance.
Place scripts in work beside a seekdb checkout of the corresponding experimental commit to reproduce check_bulk_typed.py.
Worktree C++ source hashes may retain CRLF; runtime CI independently hashes its immutable Git inputs.
