#!/usr/bin/env python3
"""Controlled evidence-parser tests only; does not execute MiniVectorDB."""
from copy import deepcopy
import importlib.util
import json
from pathlib import Path
import subprocess
import tempfile

HERE = Path(__file__).resolve().parent
spec = importlib.util.spec_from_file_location('audit', HERE / 'analyze_retained_final.py')
audit = importlib.util.module_from_spec(spec)
spec.loader.exec_module(audit)
CANDIDATE = 'a' * 40
FLAGS = ['-DMVDB_ENABLE_SPILL_FILTER', '-DMVDB_ENABLE_TYPED_JSON',
         '-DMVDB_TYPED_WIDE_VECTOR_ONLY', '-DMVDB_MULTI_POSTING_REUSE_ONLY']
SHA_B, SHA_C = 'b' * 64, 'c' * 64
IMAGE_B, IMAGE_C = 'sha256:' + 'd' * 64, 'sha256:' + 'e' * 64
BIG = (1 << 63) + 123
PIN = 'gcc:13.3.0-bookworm@sha256:1d71f0f3450214bef38fe09e6f610fb6cca90cf97b43f4ce845bfc32a4168818'


class FakeSource:
    def __init__(self):
        self.tree = {'Dockerfile': ('FROM ' + PIN + ' AS build\nARG ENABLE_PGO=1\n').encode(),
                     'minivec/src/db.cpp': b'controlled source fixture\n',
                     'minivec/tests/test.cpp': b'controlled test fixture\n',
                     'minivec/tools/pgo/train.cpp': b'controlled training fixture\n'}
        self.tree.update({'minivec/tools/' + n: ('controlled ' + n + '\n').encode() for n in audit.HARNESSES})

    def files(self, commit, selectors):
        assert commit in (CANDIDATE, audit.BASELINE)
        return {n: v for n, v in self.tree.items() if any(n == p or n.startswith(p + '/') for p in selectors)}


def encode(value):
    return (json.dumps(value, indent=2, allow_nan=False) + '\n').encode()


def lifecycle(name, plan, queries, factor):
    rows, updated = (5000, 0) if plan == 'spill_filters' else (audit.SPECS[name][0], audit.SPECS[name][2])
    names = audit.query_names(updated)
    phases = {k: factor for k in ('startup', 'create_table', 'ingest', 'index_build', 'shutdown', 'restart', 'restart_verification_wall', 'final_shutdown')}
    data = {'phase_seconds': phases, 'query': {}}
    for phase in names:
        values = [0.001 * factor] * queries
        total = audit.math.fsum(values)
        phases[phase] = total
        data['query'][phase] = {'per_request_seconds': values, 'modes': ['exact' if i % 2 == 0 else 'ann' for i in range(queries)],
            'count': queries, 'seconds': total, 'p50_ms': factor, 'p95_ms': factor, 'first_request_seconds': values[0]}
    if updated: phases['update'] = factor
    phases['measured_lifecycle'] = audit.math.fsum(v for k, v in phases.items() if k != 'restart_verification_wall')
    data['correctness'] = {'sampled_topk_oracle_queries': list(range(queries)) if plan == 'spill_filters' else sorted({0, 1, queries - 1}),
        'all_restarted_ids_checked': rows, 'restarted_vector_ids_checked': sorted({0, 1, rows // 2, rows - 1, max(0, updated - 1)})}
    snapshots = ['after_ingest', 'after_index_build', *names, 'before_shutdown', 'after_restart', 'before_final_shutdown']
    if updated: snapshots.append('after_update')
    data['resource_snapshots'] = [{'phase': n, 'process_memory_proxy': {'VmRSS_bytes': BIG, 'VmHWM_bytes': BIG + 1, 'VmSize_bytes': BIG + 2},
        'process_io_counters_proxy': {'rchar': BIG + 3, 'read_bytes': 0}, 'process_cpu_seconds': factor,
        'open_rebuildable_files': [{'kind': 'payload', 'logical_bytes': 43745000}, {'kind': 'flat_index', 'logical_bytes': 2640000}] if plan == 'spill_filters' else []} for n in snapshots]
    data.update(response_sha256='f' * 64, shutdown_data_file_bytes=BIG + 5, final_shutdown_data_file_bytes=BIG + 5,
                stderr={'total_bytes': 27, 'tail_source_bytes': 27, 'truncated': False, 'tail_utf8': 'wake_us=1.0 -> 2 threads\n'})
    return data


def projection(name, factor):
    rows = audit.PROJECTIONS[name][0]
    phases = {}
    for label in audit.LABELS:
        samples = [{'seconds': .01 * factor, 'request_bytes': 100, 'response_bytes': BIG, 'response_sha256': 'f' * 64} for _ in range(3)]
        phases[label] = {'requests': samples, 'wall_seconds': sum(s['seconds'] for s in samples), 'response_bytes': 3 * BIG,
            'columns': ['id', 'n', 's', 'v'] if label.startswith('wide') else ['id'],
            'rows_per_response': min(rows, 10) if label.endswith('10') else min(rows, 4096) if label.endswith('4096') else rows,
            'independent_oracle': 'every element, exact integer/string/float32 and signed zero'}
    return {'status': 'passed', 'phases': phases, 'lifecycle_seconds': {'startup': .1 * factor, 'create_and_insert': 1.5 * factor, 'shutdown': .2 * factor},
            'ingest_request_bytes': BIG, 'stderr': {'bytes': 0, 'tail': '', 'sha256': audit.digest(b'')}}


def fixture():
    source = FakeSource(); files = {}
    def js(name, value): files[name] = encode(value)
    def txt(name, value): files[name] = value.encode()
    prefix = 'final-performance/'
    context = {'candidate_commit': CANDIDATE, 'baseline_commit': audit.BASELINE,
        'candidate': {'binary': '/synthetic/candidate', 'image_id': IMAGE_C, 'binary_sha256_before': SHA_C},
        'baseline': {'binary': '/synthetic/baseline', 'image_id': IMAGE_B, 'binary_sha256_before': SHA_B,
            'dockerfile_sha256': audit.digest(source.tree['Dockerfile']), 'enable_pgo': 1, 'build_inputs': 'baseline-inputs.json'},
        'candidate_image_binary_binding_verified': True, 'cpu_affinity': [0, 1], 'platform': 'synthetic-test-platform', 'cpu_info': 'synthetic, not measured',
        'expected_total_pairs': 120, 'benchmark_harness_sha256': {n: audit.digest(source.tree['minivec/tools/' + n]) for n in audit.HARNESSES}}
    benchmarks = {}
    for plan, (cases, per_seed, count) in audit.PLANS.items():
        p = plan == 'projections'; size = len(cases) * 3 * per_seed
        context[plan] = {'seeds': list(audit.SEEDS), 'pairs_per_seed': per_seed, 'pairs': size}
        if plan != 'standard': context[plan]['scenarios'] = list(cases)
        context[plan]['repetitions_per_phase' if p else 'queries_argument'] = count
        raw = {'status': 'passed', 'official_score': None, 'environment': {}, 'pairs': [],
            'host': {'platform': context['platform'], 'affinity': [0, 1]},
            'binaries': {s: {'path': context[s]['binary'], 'sha256': context[s]['binary_sha256_before']} for s in audit.SIDES}}
        if p:
            raw.update(kind='wide_projection_screen', parameters={'seeds': list(audit.SEEDS), 'pairs_per_seed': per_seed, 'repetitions_per_phase': count},
                       harness_sha256=context['benchmark_harness_sha256']['benchmark_projection.py'], workloads=[])
        elif plan == 'spill_filters':
            raw.update(kind='report_matrix_screen', parameters={'seeds': list(audit.SEEDS), 'pairs': per_seed, 'queries': count})
        else:
            raw.update(kind='paired_local_iteration_benchmark', suite='full', seeds=list(audit.SEEDS), pairs_per_seed=per_seed, queries_per_phase=count, batch_size=100, k=10)
        for ci, name in enumerate(cases):
            for si, seed in enumerate(audit.SEEDS):
                checksum = audit.digest((name + str(seed)).encode())
                if p:
                    input_name = f'projections.inputs/{name}-{seed}.jsonl'
                    content = encode({'synthetic': name, 'seed': seed})
                    files[prefix + input_name] = content
                    checksum = audit.digest(content)
                    rows, dim, width = audit.PROJECTIONS[name]
                    raw['workloads'].append({'scenario': name, 'seed': seed, 'rows': rows, 'dimension': dim, 'string_codepoints': width,
                        'input_path': '/synthetic/' + input_name, 'input_bytes': len(content), 'input_sha256': checksum})
                for index in range(per_seed):
                    order = list(audit.SIDES)
                    if (ci + si + index) % 2: order.reverse()
                    pair = {'scenario': name, 'seed': seed, 'pair_index': index, 'order': order,
                            'input_sha256' if p else 'workload_sha256': checksum}
                    if not p:
                        if plan == 'spill_filters': pair['spec'] = [5000, 128, 10, 8192, 'compound' if name == 'spill_compound' else 'high']
                        else: pair.update(zip(('rows', 'dimension', 'updated_rows', 'padding_bytes', 'group_modulus', 'mixed_filters'), audit.SPECS[name]))
                    for side in audit.SIDES:
                        factor = 1.0 if side == 'baseline' else (.8, 1.2, 1.0)[si]
                        pair[side] = projection(name, factor) if p else lifecycle(name, plan, count, factor)
                    pair['all_responses_identical_and_independently_verified' if p else 'all_responses_identical'] = True
                    raw['pairs'].append(pair)
        raw['summary'] = audit.recompute_summary(raw['pairs'], p)
        js(prefix + plan + '.json', raw)
        benchmarks[plan] = {'status': 'passed', 'pairs': size, 'expected_pairs': size, 'complete': True,
            'unique_expected_pair_identities': True, 'measured_binary_sha256_matches': True, 'all_responses_verified': True, 'summary': raw['summary']}
    summary = {'status': 'passed', 'exit_code': 0, 'stage': 'complete', 'total_pairs': 120, 'expected_total_pairs': 120, 'verified_total_pairs': 120,
        'baseline_commit': audit.BASELINE, 'candidate_image_id': IMAGE_C, 'baseline_three_correctness_gates_passed': True,
        'binary_sha256_before': {'baseline': SHA_B, 'candidate': SHA_C}, 'binary_sha256_after': {'baseline': SHA_B, 'candidate': SHA_C},
        'binary_unchanged': {'baseline': True, 'candidate': True}, 'benchmarks': benchmarks}
    js(prefix + 'context.json', context); js(prefix + 'summary.json', summary)
    js(prefix + 'run-status.json', {'exit_code': 0, 'stage': 'complete', 'proof_status': 'passed'})
    txt(prefix + 'stage.txt', 'complete\n'); txt(prefix + 'candidate-path.txt', '/synthetic/candidate\n')
    txt(prefix + 'baseline-binary-sha256.txt', SHA_B + '  /synthetic/baseline\n')
    txt(prefix + 'baseline-build.log', 'synthetic build log for parser tests; no build happened\n')
    js(prefix + 'baseline-image.json', [{'Id': IMAGE_B}])
    js(prefix + 'baseline-inputs.json', {'source_commit': audit.BASELINE, 'unmodified_root_dockerfile': True, 'enable_pgo': 1,
        'archived_files_sha256': {n: audit.digest(v) for n, v in source.files(audit.BASELINE, audit.BASE_INPUTS).items()}})
    checks = []
    for name, overrides in (('json_protocol', {}), ('topk_serial', {'MVDB_QUERY_THREADS': '1'}), ('topk_two_threads', {'MVDB_QUERY_THREADS': '2'})):
        checks.append({'test': name, 'returncode': 0, 'failure': None, 'environment_overrides': overrides, 'elapsed_seconds': .1,
            'stdout_tail': 'synthetic PASS\n', 'stderr_tail': ''})
        txt(prefix + name + '.stdout.log', 'synthetic PASS\n'); txt(prefix + name + '.stderr.log', '')
    js(prefix + 'baseline-correctness.json', {'status': 'passed', 'checks': checks})
    verify = {'passed': True, 'runtime_commit': CANDIDATE, 'checks': {n: True for n in audit.ROOT_CHECKS | {'compound_reuse_diagnostic_and_sanitizer'}},
        'performance_verified_pairs': 120, 'performance_evidence': 'final-performance/summary.json', 'source_image_sanitizer_feature_selection_shared': True,
        'selected_feature_flags': FLAGS, 'image_id': IMAGE_C, 'image_binary_sha256': SHA_C, 'performance_candidate_binary_sha256': SHA_C, 'source_binary_sha256': 'a' * 64}
    js('verification-summary.json', verify); txt('runtime-commit.txt', CANDIDATE + '\n'); txt('image-id.txt', IMAGE_C + '\n')
    js('image-inspect.json', [{'Id': IMAGE_C}]); txt('image-binary-sha256.txt', SHA_C + '  /synthetic/candidate\n')
    txt('source-binary-sha256.txt', 'a' * 64 + '  /synthetic/native\n')
    txt('input-sha256.txt', ''.join(audit.digest(v) + '  ' + n + '\n' for n, v in source.files(CANDIDATE, audit.ROOT_INPUTS).items()))
    js('image-binary-utf8.json', {'status': 'passed', 'checks': [{'malformed_hex': raw, 'projected_vector_dimension': dim, 'path': path, 'status': 'passed', 'valid_prefix_bytes': 90000}
        for raw in ('ff', 'c080', 'eda080', 'e4b8', 'f4908080', '80') for dim in (None, 127, 128) for path in ('ORDER BY id LIMIT 10', 'unbounded', 'ORDER BY id LIMIT 4096')]})
    for mode in ('normal', 'sanitized'): txt('filter-reuse-' + mode + '.log', 'PASS compound first-query gate, synthetic parser fixture\n')
    return files, source


def make_manifest(files):
    prefix = 'final-performance/'
    files[prefix + 'hashes.json'] = encode({'artifacts': [{'path': n[len(prefix):], 'bytes': len(v), 'sha256': audit.digest(v)}
        for n, v in sorted(files.items()) if n.startswith(prefix) and n != prefix + 'hashes.json']})


def alter_json(files, name, callback):
    value = json.loads(files[name]); callback(value); files[name] = encode(value)


def main():
    base, source = fixture(); make_manifest(base)
    results = []
    def case(name, change=None, resign=False, expected=True, commit=CANDIDATE, flags=FLAGS):
        files = dict(base)
        if change: change(files)
        if resign: make_manifest(files)
        with tempfile.TemporaryDirectory(prefix='retained-parser-fixture-', dir=HERE) as temporary:
            root = Path(temporary)
            for name_, content in files.items():
                p = root / name_; p.parent.mkdir(parents=True, exist_ok=True); p.write_bytes(content)
            try:
                report = audit.analyze(root, commit, flags, source)
                if not expected: raise AssertionError('invalid evidence was accepted: ' + name)
                metric = report['scenarios']['standard10k']['metrics']['resource_snapshots']['after_ingest']['process_memory_proxy']['VmRSS_bytes']
                assert metric['raw_pairs'][0]['baseline'] == BIG and type(metric['raw_pairs'][0]['baseline']) is int
                assert metric['by_order']['AB']['baseline']['median'] == BIG and type(metric['by_order']['AB']['baseline']['median']) is int
                projection_metric = report['scenarios']['wide128']['metrics']
                assert projection_metric['lifecycle_seconds']['create_and_insert']['candidate_value_larger_pairs'] == 1
                assert projection_metric['accounted_timer_sum_seconds']['candidate_value_larger_pairs'] == 1
                assert len(projection_metric['lifecycle_seconds']['create_and_insert']['negative_pairs']) == 1
                outcome = 'accepted_synthetic_fixture_only'
            except (ValueError, KeyError, FileNotFoundError) as error:
                if expected: raise
                outcome = type(error).__name__ + ': ' + str(error)
        results.append({'case': name, 'expected_accept': expected, 'outcome': outcome})
    case('complete_120_four_flags_retains_negative_pairs_and_large_integers')
    case('missing_manifest', lambda f: f.pop('final-performance/hashes.json'), expected=False)
    case('missing_listed_log', lambda f: f.pop('final-performance/baseline-build.log'), expected=False)
    case('changed_listed_log', lambda f: f.__setitem__('final-performance/baseline-build.log', b'changed'), expected=False)
    case('log_removed_from_manifest_and_disk', lambda f: f.pop('final-performance/baseline-build.log'), resign=True, expected=False)
    case('unlisted_extra_file', lambda f: f.__setitem__('final-performance/extra.log', b'extra'), expected=False)
    case('manifest_escape', lambda f: alter_json(f, 'final-performance/hashes.json', lambda d: d['artifacts'][0].update(path='../verification-summary.json')), expected=False)
    case('manifest_duplicate_path', lambda f: alter_json(f, 'final-performance/hashes.json', lambda d: d['artifacts'].append(d['artifacts'][0])), expected=False)
    case('candidate_prefix_rejected', expected=False, commit=CANDIDATE[:7])
    case('candidate_commit_mismatch', expected=False, commit='9' * 40)
    case('expected_flags_mismatch', expected=False, flags=FLAGS[:-1])
    case('root_gate_false', lambda f: alter_json(f, 'verification-summary.json', lambda d: d['checks'].update(root_docker_build=False)), expected=False)
    case('root_extra_gate_requires_review', lambda f: alter_json(f, 'verification-summary.json', lambda d: d['checks'].update(unknown_new_gate=True)), expected=False)
    case('reuse_success_log_missing', lambda f: f.pop('filter-reuse-sanitized.log'), expected=False)
    case('image_id_mismatch', lambda f: alter_json(f, 'image-inspect.json', lambda d: d[0].update(Id=IMAGE_B)), expected=False)
    case('native_binary_mismatch', lambda f: f.__setitem__('source-binary-sha256.txt', (SHA_B + '  native\n').encode()), expected=False)
    case('source_checksum_mismatch', lambda f: f.__setitem__('input-sha256.txt', b'0' * 64 + b'  Dockerfile\n'), expected=False)
    case('harness_source_mismatch', lambda f: alter_json(f, 'final-performance/context.json', lambda d: d['benchmark_harness_sha256'].update({'benchmark_projection.py': '0' * 64})), resign=True, expected=False)
    case('baseline_archive_mismatch', lambda f: alter_json(f, 'final-performance/baseline-inputs.json', lambda d: d['archived_files_sha256'].update(Dockerfile='0' * 64)), resign=True, expected=False)
    case('baseline_gate_failure', lambda f: alter_json(f, 'final-performance/baseline-correctness.json', lambda d: d['checks'][0].update(returncode=1)), resign=True, expected=False)
    case('baseline_gate_log_tail_mismatch', lambda f: f.__setitem__('final-performance/topk_serial.stdout.log', b'different\n'), resign=True, expected=False)
    case('raw_binary_mismatch', lambda f: alter_json(f, 'final-performance/standard.json', lambda d: d['binaries']['candidate'].update(sha256=SHA_B)), resign=True, expected=False)
    case('changed_binary_after', lambda f: alter_json(f, 'final-performance/summary.json', lambda d: d['binary_sha256_after'].update(candidate=SHA_B)), resign=True, expected=False)
    case('duplicate_pair', lambda f: alter_json(f, 'final-performance/standard.json', lambda d: d['pairs'].__setitem__(1, deepcopy(d['pairs'][0]))), resign=True, expected=False)
    case('wrong_abba_order', lambda f: alter_json(f, 'final-performance/standard.json', lambda d: d['pairs'][0]['order'].reverse()), resign=True, expected=False)
    case('boolean_pair_index', lambda f: alter_json(f, 'final-performance/standard.json', lambda d: d['pairs'][0].update(pair_index=False)), resign=True, expected=False)
    case('missing_wide128', lambda f: alter_json(f, 'final-performance/projections.json', lambda d: d.update(pairs=[p for p in d['pairs'] if p['scenario'] != 'wide128'])), resign=True, expected=False)
    case('missing_topk_oracle', lambda f: alter_json(f, 'final-performance/boundaries.json', lambda d: d['pairs'][0]['candidate']['correctness'].update(sampled_topk_oracle_queries=[])), resign=True, expected=False)
    case('missing_projection_oracle', lambda f: alter_json(f, 'final-performance/projections.json', lambda d: d['pairs'][0]['candidate']['phases']['wide_top10'].update(independent_oracle='')), resign=True, expected=False)
    case('no_actual_spill', lambda f: alter_json(f, 'final-performance/spill_filters.json', lambda d: d['pairs'][0]['candidate']['resource_snapshots'][1].update(open_rebuildable_files=[])), resign=True, expected=False)
    case('query_sum_mismatch', lambda f: alter_json(f, 'final-performance/standard.json', lambda d: d['pairs'][0]['candidate']['query']['query_before_update'].update(seconds=3.0)), resign=True, expected=False)
    case('ingest_phase_missing', lambda f: alter_json(f, 'final-performance/projections.json', lambda d: d['pairs'][0]['candidate']['lifecycle_seconds'].pop('create_and_insert')), resign=True, expected=False)
    case('projection_bytes_mismatch', lambda f: alter_json(f, 'final-performance/projections.json', lambda d: d['pairs'][0]['candidate']['phases']['wide_top10']['requests'][0].update(response_bytes=1)), resign=True, expected=False)
    case('raw_summary_mismatch', lambda f: alter_json(f, 'final-performance/standard.json', lambda d: d['summary']['standard10k']['ingest'].update(median_baseline_over_candidate=99)), resign=True, expected=False)
    case('recorded_error_even_with_passed', lambda f: alter_json(f, 'final-performance/standard.json', lambda d: d.update(error='failed sample')), resign=True, expected=False)
    case('utf8_one_boundary_missing', lambda f: alter_json(f, 'image-binary-utf8.json', lambda d: d['checks'].pop()), expected=False)
    integer_median = audit.stats([BIG, BIG])
    assert integer_median['median'] == BIG and type(integer_median['median']) is int
    results.append({'case': 'large_even_group_integral_median_exact', 'expected_accept': True, 'outcome': 'exact integer, no float conversion'})
    half = audit.stats([BIG, BIG + 1])
    assert half['median'] is None and half['median_exact_fraction'] == {'numerator': 2 * BIG + 1, 'denominator': 2}
    assert audit.stats([2, 3])['median'] == 2.5 and audit.stats([2, 3])['median_exact_fraction'] == {'numerator': 5, 'denominator': 2}
    results.append({'case': 'large_half_integer_median_exact_rational', 'expected_accept': True, 'outcome': 'null approximate field plus exact numerator/denominator; small half remains exact float'})
    # Independent JSON-reader negative cases preserve the native large integer.
    with tempfile.TemporaryDirectory(prefix='retained-json-fixture-', dir=HERE) as temporary:
        p = Path(temporary) / 'j.json'
        for name, content in [('duplicate_json_keys', b'{"a":1,"a":2}'), ('nonfinite_json', b'{"a":NaN}'), ('overflow_float', b'{"a":1e999}')]:
            p.write_bytes(content)
            try: audit.read(p)
            except ValueError: results.append({'case': name, 'expected_accept': False, 'outcome': 'rejected'})
            else: raise AssertionError(name)
    # Real historical validation is deliberately partial, not a real 120-pair run.
    partial = HERE / 'performance/report-validation-54ce8402'
    if partial.exists():
        try: audit.analyze(partial, CANDIDATE, FLAGS, source)
        except ValueError as error: results.append({'case': 'real_prior_root_validation_without_final_performance', 'expected_accept': False, 'outcome': str(error)})
        else: raise AssertionError('partial validation accepted')
    git = audit.GitSource(HERE / 'seekdb')
    head = subprocess.check_output(git.command('rev-parse', 'HEAD')).decode().strip()
    blobs = git.files(head, ('minivec/tools/benchmark_projection.py',))
    assert set(blobs) == {'minivec/tools/benchmark_projection.py'}
    report = {'status': 'passed', 'scope': 'controlled synthetic artifact/parser checks and read-only Git blob smoke; no Linux build, no database execution, no actual 120-pair result',
        'analyzer_sha256': audit.sha(HERE / 'analyze_retained_final.py'), 'test_sha256': audit.sha(Path(__file__)), 'cases': results,
        'synthetic_positive_cases': sum(r['expected_accept'] for r in results), 'negative_cases': sum(not r['expected_accept'] for r in results),
        'git_blob_smoke': {'commit': head, 'files_sha256': {n: audit.digest(v) for n, v in blobs.items()}}}
    target = HERE / 'retained-final-analyzer-static-validation.json'
    target.write_bytes(encode(report))
    print(json.dumps({'status': 'passed', 'cases': len(results), 'scope': report['scope'], 'proof': str(target)}))


if __name__ == '__main__':
    main()
