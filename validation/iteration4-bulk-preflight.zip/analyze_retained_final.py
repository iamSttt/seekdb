#!/usr/bin/env python3
"""Audit complete root-image artifacts before summarizing the fixed 120-pair plan.

Read-only with respect to source and raw evidence. A complete extracted
protocol-results artifact is required; JSON-only log extraction is insufficient.
Native JSON integers are retained. This checks recorded CI evidence, not a fresh
execution of the independent oracles, and never converts timings to a score.
"""
import argparse
from collections import defaultdict
import hashlib
import json
import math
from pathlib import Path, PurePosixPath
import re
import shlex
from statistics import median
import subprocess

HERE = Path(__file__).resolve().parent
BASELINE = '969ecca98f817ecdef9b0c378fc99a0d6cef510d'
SEEDS = (7319, 8911, 13337)
SIDES = ('baseline', 'candidate')
PLANS = {
    'standard': (('standard10k',), 5, 1000),
    'boundaries': (('resident30k', 'resident50k', 'low16', 'filter60k', 'update10', 'spill'), 5, 64),
    'spill_filters': (('spill_compound', 'spill_high'), 1, 64),
    'projections': (('wide768', 'many16', 'wide128'), 1, 3),
}
SPECS = {'standard10k': (10000, 128, 0, 0, 10, True),
         'resident30k': (30000, 128, 0, 0, 0, False),
         'resident50k': (50000, 128, 0, 0, 0, False),
         'low16': (10000, 16, 0, 0, 0, False),
         'filter60k': (60000, 16, 0, 0, 100, False),
         'update10': (10000, 128, 10, 0, 0, False),
         'spill': (50000, 128, 0, 512, 0, False)}
PROJECTIONS = {'wide768': (1024, 768, 96), 'many16': (8192, 16, 256), 'wide128': (1024, 128, 96)}
LABELS = ('narrow_top10', 'wide_top10', 'narrow_large4096', 'wide_large4096',
          'narrow_all', 'wide_all', 'wide_distance10')
ROOT_INPUTS = ('Dockerfile', '.dockerignore', 'minivec/src', 'minivec/third_party',
               'minivec/Makefile', 'minivec/tests', 'minivec/tools/ci_score.sh',
               'minivec/tools/ci_final_performance.sh', 'minivec/tools/pgo/train.cpp',
               'minivec/tools/pgo/run-training.sh', 'STDIO_PROTOCOL.md', 'protocol_check', 'mysqltest')
BASE_INPUTS = ('Dockerfile', '.dockerignore', 'minivec/src', 'minivec/third_party', 'minivec/tools/pgo')
HARNESSES = ('ci_final_performance.sh', 'benchmark_iteration.py', 'benchmark_report_matrix.py', 'benchmark_projection.py')
ROOT_CHECKS = {'root_docker_build', 'image_official_handshake_and_public_cases',
               'source_official_handshake_and_public_cases',
               'live_stdin_errors_utf8_fragment_shutdown_restart_commit_sigkill', 'make_test',
               'native_spill_cache_budget_writer_and_54_utf8_cases', 'actual_image_54_utf8_atomicity_cases',
               'selected_spill_and_utf8_asan_ubsan', 'parser_ownership_serial_parallel_and_quantized_bound_asan_ubsan',
               'image_binary_json_and_exact_topk_serial_parallel', 'eight_wal_failure_cases_asan_ubsan',
               'query_pool_both_modes_asan_ubsan', 'cross_table_spill_asan_ubsan', 'full_binary_json_ubsan',
               'index_budget_and_resident_update_asan_ubsan', 'same_image_binary_paired_measurements'}


def require(ok, message):
    if not ok:
        raise ValueError(message)


def unique_object(items):
    result = {}
    for key, value in items:
        require(key not in result, 'duplicate JSON key: ' + key)
        result[key] = value
    return result


def read(path):
    def finite(text):
        value = float(text)
        require(math.isfinite(value), 'nonfinite JSON number')
        return value
    def invalid(text):
        raise ValueError('nonfinite JSON constant: ' + text)
    return json.loads(path.read_bytes().decode('utf-8'), object_pairs_hook=unique_object,
                      parse_float=finite, parse_constant=invalid)


def digest(data):
    return hashlib.sha256(data).hexdigest()


def sha(path):
    h = hashlib.sha256()
    with path.open('rb') as stream:
        for block in iter(lambda: stream.read(1024 * 1024), b''):
            h.update(block)
    return h.hexdigest()


def hash_ok(value):
    require(type(value) is str and re.fullmatch('[0-9a-f]{64}', value), 'invalid SHA256')


def integer(value, minimum=0):
    require(type(value) is int and value >= minimum, 'invalid integer')
    return value


def number(value, positive=False):
    require(type(value) in (int, float) and math.isfinite(value) and
            (value > 0 if positive else value >= 0), 'invalid numeric observation')
    return value


def close(a, b):
    return math.isclose(a, b, rel_tol=1e-12, abs_tol=1e-12)


def child(root, name):
    require(type(name) is str and name and '\\' not in name and ':' not in name,
            'invalid evidence path')
    rel = PurePosixPath(name)
    require(not rel.is_absolute() and rel.as_posix() == name and
            all(part not in ('', '.', '..') for part in rel.parts), 'escaping/noncanonical evidence path')
    path = root.joinpath(*rel.parts)
    current = root
    for part in rel.parts:
        current = current / part
        require(not current.is_symlink(), 'symlink evidence path')
    require(path.is_file() and path.resolve().is_relative_to(root.resolve()), 'missing/escaping evidence: ' + name)
    return path


def manifest(root):
    path = child(root, 'hashes.json')
    data = read(path)
    require(type(data.get('artifacts')) is list and data['artifacts'], 'empty artifact manifest')
    seen = {}
    for item in data['artifacts']:
        name = item['path']
        require(name not in seen and name != 'hashes.json', 'duplicate/self manifest entry')
        source = child(root, name)
        integer(item['bytes']); hash_ok(item['sha256'])
        require(source.stat().st_size == item['bytes'] and sha(source) == item['sha256'], 'artifact hash/length mismatch: ' + name)
        seen[name] = item['sha256']
    actual = {p.relative_to(root).as_posix() for p in root.rglob('*') if p.is_file()}
    require(actual == set(seen) | {'hashes.json'}, 'artifact manifest omits files or names missing files')
    expected = {'context.json', 'summary.json', 'run-status.json', 'stage.txt', 'candidate-path.txt',
                'baseline-inputs.json', 'baseline-image.json', 'baseline-binary-sha256.txt',
                'baseline-correctness.json', 'baseline-build.log',
                *(plan + '.json' for plan in PLANS),
                *(test + '.' + stream + '.log' for test in ('json_protocol', 'topk_serial', 'topk_two_threads') for stream in ('stdout', 'stderr')),
                *(f'projections.inputs/{name}-{seed}.jsonl' for name in PROJECTIONS for seed in SEEDS)}
    require(set(seen) == expected, 'manifest inventory differs from the fixed 120-pair tool output')
    return seen


class GitSource:
    """Read immutable Git blobs, not a possibly modified/CRLF working tree."""
    def __init__(self, repo):
        self.repo = repo.resolve()

    def command(self, *args):
        return ['git', '-c', 'safe.directory=' + self.repo.as_posix(), '-C', str(self.repo), *args]

    def files(self, commit, selectors):
        require(re.fullmatch('[0-9a-f]{40}', commit), 'full Git commit ID required')
        resolved = subprocess.check_output(self.command('rev-parse', commit + '^{commit}')).decode().strip()
        require(resolved == commit, 'Git source commit mismatch')
        records = subprocess.check_output(self.command('ls-tree', '-r', '-z', commit, '--', *selectors))
        entries = []
        for record in records.split(b'\0'):
            if record:
                meta, raw_name = record.split(b'\t', 1)
                mode, kind, oid = meta.decode().split()
                require(kind == 'blob' and mode in ('100644', '100755'), 'non-regular Git source')
                entries.append((raw_name.decode('utf-8'), oid))
        require(entries, 'Git source selection is empty')
        raw = subprocess.check_output(self.command('cat-file', '--batch'), input=''.join(oid + '\n' for _, oid in entries).encode())
        result, offset = {}, 0
        for name, oid in entries:
            stop = raw.index(b'\n', offset)
            object_id, kind, size = raw[offset:stop].decode().split()
            require(object_id == oid and kind == 'blob', 'Git batch object mismatch')
            size = int(size); start = stop + 1
            body = raw[start:start + size]
            require(len(body) == size and raw[start + size:start + size + 1] == b'\n', 'short Git blob')
            result[name] = body
            offset = start + size + 1
        require(offset == len(raw), 'extra Git batch content')
        return result


def checksum_text(path):
    result = {}
    for line in path.read_text(encoding='utf-8').splitlines():
        match = re.fullmatch(r'([0-9a-f]{64}) [ *](.+)', line)
        require(match is not None and match[2] not in result, 'invalid/duplicate checksum line')
        result[match[2]] = match[1]
    require(result, 'empty checksum file')
    return result


def only_sha(path):
    values = list(checksum_text(path).values())
    require(len(values) == 1, 'single binary checksum required')
    return values[0]


def image_id(value):
    require(type(value) is str and re.fullmatch('sha256:[0-9a-f]{64}', value), 'immutable image ID required')
    return value


def root_binding(root, context, summary, expected_commit, expected_flags, source):
    require(re.fullmatch('[0-9a-f]{40}', expected_commit or ''), 'candidate commit must be full lowercase 40hex')
    verify = read(child(root, 'verification-summary.json'))
    require(verify['passed'] is True and verify['runtime_commit'] == context['candidate_commit'] == expected_commit ==
            child(root, 'runtime-commit.txt').read_text().strip(), 'root verification/source commit mismatch')
    required_checks = ROOT_CHECKS | ({'compound_reuse_diagnostic_and_sanitizer'} if '-DMVDB_MULTI_POSTING_REUSE_ONLY' in expected_flags else set())
    require(set(verify['checks']) == required_checks and all(v is True for v in verify['checks'].values()),
            'root correctness gate set changed, missing or failed: expected ' + ','.join(sorted(required_checks)))
    require(verify['performance_verified_pairs'] == 120 and verify['performance_evidence'] == 'final-performance/summary.json', 'wrong root performance evidence')
    require(verify['source_image_sanitizer_feature_selection_shared'] is True, 'unbound feature selection')
    flags = verify['selected_feature_flags']
    require(type(flags) is list and len(set(flags)) == len(flags) and all(type(f) is str and re.fullmatch(r'-D[A-Z][A-Z0-9_]*(?:=[01])?', f) for f in flags), 'invalid selected feature flags')
    require(flags == expected_flags, 'root selected flags differ from explicit expected flags')
    if '-DMVDB_MULTI_POSTING_REUSE_ONLY' in flags:
        for mode in ('normal', 'sanitized'):
            require('PASS compound first-query gate,' in child(root, f'filter-reuse-{mode}.log').read_text(encoding='utf-8'), 'missing successful compound-reuse diagnostic log')
    actual_id = image_id(child(root, 'image-id.txt').read_text().strip())
    inspect = read(child(root, 'image-inspect.json'))
    require(len(inspect) == 1 and inspect[0]['Id'] == actual_id == verify['image_id'] ==
            context['candidate']['image_id'] == summary['candidate_image_id'], 'candidate image ID mismatch')
    candidate_sha = only_sha(child(root, 'image-binary-sha256.txt'))
    require(candidate_sha == verify['image_binary_sha256'] == verify['performance_candidate_binary_sha256'] ==
            context['candidate']['binary_sha256_before'], 'candidate root binary checksum mismatch')
    require(only_sha(child(root, 'source-binary-sha256.txt')) == verify['source_binary_sha256'], 'native binary checksum mismatch')
    expected_files = source.files(expected_commit, ROOT_INPUTS)
    hashes = checksum_text(child(root, 'input-sha256.txt'))
    require(hashes == {n: digest(body) for n, body in expected_files.items()}, 'root build/test input set or bytes differ from committed Git blobs')
    harness_files = source.files(expected_commit, tuple('minivec/tools/' + n for n in HARNESSES))
    require(context['benchmark_harness_sha256'] == {n: digest(harness_files['minivec/tools/' + n]) for n in HARNESSES}, 'measurement harness differs from candidate commit')
    pin = 'gcc:13.3.0-bookworm@sha256:1d71f0f3450214bef38fe09e6f610fb6cca90cf97b43f4ce845bfc32a4168818'
    dockerfile = expected_files['Dockerfile'].decode()
    require('FROM ' + pin + ' AS build' in dockerfile.splitlines() and 'ARG ENABLE_PGO=1' in dockerfile.splitlines(), 'root compiler/default PGO proof changed')
    utf8 = read(child(root, 'image-binary-utf8.json'))
    want = {(raw, dim, path) for raw in ('ff', 'c080', 'eda080', 'e4b8', 'f4908080', '80')
            for dim in (None, 127, 128) for path in ('ORDER BY id LIMIT 10', 'unbounded', 'ORDER BY id LIMIT 4096')}
    require(utf8['status'] == 'passed' and len(utf8['checks']) == 54 and
            {(c['malformed_hex'], c['projected_vector_dimension'], c['path']) for c in utf8['checks']} == want and
            all(c['status'] == 'passed' and c['valid_prefix_bytes'] == 90000 for c in utf8['checks']), 'incomplete actual-image UTF8 atomicity cases')
    return {'selected_feature_flags': flags, 'candidate_source_files_verified': len(hashes), 'compiler_image': pin,
            'candidate_image_id': actual_id, 'candidate_binary_sha256': candidate_sha,
            'proof_limit': 'CI recorded actual-image extraction/cmp and passed source/image/sanitizer gates; this analysis does not rebuild the image or rerun oracles.'}


def baseline_binding(root, context, source):
    require(context['baseline_commit'] == BASELINE, 'wrong fixed historical baseline')
    saved = read(child(root, 'baseline-inputs.json'))
    files = source.files(BASELINE, BASE_INPUTS)
    require(saved['source_commit'] == BASELINE and saved['unmodified_root_dockerfile'] is True and
            saved['enable_pgo'] == 1 and saved['archived_files_sha256'] == {n: digest(b) for n, b in files.items()}, 'baseline source/archive proof mismatch')
    baseline = context['baseline']
    require(baseline['dockerfile_sha256'] == digest(files['Dockerfile']) and baseline['enable_pgo'] == 1 and
            baseline['build_inputs'] == 'baseline-inputs.json', 'baseline Dockerfile/PGO binding mismatch')
    image = read(child(root, 'baseline-image.json'))
    require(len(image) == 1 and image_id(image[0]['Id']) == baseline['image_id'], 'baseline image mismatch')
    require(only_sha(child(root, 'baseline-binary-sha256.txt')) == baseline['binary_sha256_before'], 'baseline binary checksum mismatch')
    gates = read(child(root, 'baseline-correctness.json'))
    names = {'json_protocol': {}, 'topk_serial': {'MVDB_QUERY_THREADS': '1'}, 'topk_two_threads': {'MVDB_QUERY_THREADS': '2'}}
    require(gates['status'] == 'passed' and len(gates['checks']) == 3 and {c['test'] for c in gates['checks']} == set(names), 'missing baseline correctness gate')
    for check in gates['checks']:
        require(type(check['returncode']) is int and check['returncode'] == 0 and check['failure'] is None and
                check['environment_overrides'] == names[check['test']], 'baseline correctness gate failed or policy differs')
        number(check['elapsed_seconds'], True)
        for stream in ('stdout', 'stderr'):
            content = child(root, check['test'] + '.' + stream + '.log').read_text(encoding='utf-8')
            require(content[-4096:] == check[stream + '_tail'], 'baseline gate log tail differs')
    return {'source_files_verified': len(files), 'image_id': baseline['image_id'],
            'binary_sha256': baseline['binary_sha256_before'],
            'profile_limit': 'Original committed default-PGO Dockerfile and build log are retained; this final helper does not export individual gcda/corpus hashes.'}


def identity(pair):
    return {k: pair[k] for k in ('scenario', 'seed', 'pair_index', 'order')}


def stats(values):
    integer_values = bool(values) and all(type(value) is int for value in values)
    result = {'count': len(values), 'median': median(values) if values and not integer_values else None,
              'min': min(values) if values else None, 'max': max(values) if values else None}
    if integer_values:
        ordered = sorted(values); mid = len(ordered) // 2
        if len(ordered) % 2:
            result['median'] = ordered[mid]
        else:
            total = ordered[mid - 1] + ordered[mid]
            if total % 2 == 0:
                result['median'] = total // 2
            else:
                # A half-integer outside binary64 precision has no exact JSON
                # float representation. Preserve its rational value explicitly.
                result['median_exact_fraction'] = {'numerator': total, 'denominator': 2}
                result['median'] = total / 2 if abs(total) <= (1 << 53) else None
    return result


def aggregate(rows):
    ratios = [r['baseline_over_candidate'] for r in rows if r['baseline_over_candidate'] is not None]
    return {'pairs': len(rows), 'baseline': stats([r['baseline'] for r in rows]),
            'candidate': stats([r['candidate'] for r in rows]), 'baseline_over_candidate': stats(ratios),
            'candidate_value_larger_pairs': sum(v < 1 for v in ratios), 'undefined_ratio_pairs': len(rows) - len(ratios)}


def metric(pairs, getter):
    rows = []
    for pair in pairs:
        b, c = [number(getter(pair[side])) for side in SIDES]
        rows.append(dict(identity(pair), baseline=b, candidate=c, baseline_over_candidate=b / c if c else None))
    return {**aggregate(rows), 'by_seed': {str(seed): aggregate([r for r in rows if r['seed'] == seed]) for seed in SEEDS},
            'by_order': {order: aggregate([r for r in rows if r['order'][0] == first]) for order, first in (('AB', 'baseline'), ('BA', 'candidate'))},
            'negative_pairs': [identity(r) for r in rows if r['baseline_over_candidate'] is not None and r['baseline_over_candidate'] < 1], 'raw_pairs': rows}


def query_names(updated):
    return ['query_before_update'] + (['query_after_update'] if updated else []) + ['query_after_restart']


def check_lifecycle(pair, plan, queries):
    name = pair['scenario']
    if plan == 'spill_filters':
        rows, dimension, updated = 5000, 128, 0
        require(pair['spec'] == [5000, 128, 10, 8192, 'compound' if name == 'spill_compound' else 'high'], 'spill-filter spec differs')
    else:
        spec = SPECS[name]; rows, dimension, updated = spec[:3]
        require([pair[k] for k in ('rows', 'dimension', 'updated_rows', 'padding_bytes', 'group_modulus', 'mixed_filters')] == list(spec), 'lifecycle corpus spec differs')
    expected_queries = query_names(updated)
    phases = {'startup', 'create_table', 'ingest', 'index_build', 'shutdown', 'restart',
              'restart_verification_wall', 'final_shutdown', 'measured_lifecycle', *expected_queries}
    snapshots = {'after_ingest', 'after_index_build', 'before_shutdown', 'after_restart', 'before_final_shutdown', *expected_queries}
    if updated:
        phases.add('update'); snapshots.add('after_update')
    expected_oracle = list(range(queries)) if plan == 'spill_filters' else sorted({0, 1, queries - 1})
    expected_correctness = {'sampled_topk_oracle_queries': expected_oracle, 'all_restarted_ids_checked': rows,
                            'restarted_vector_ids_checked': sorted({0, 1, rows // 2, rows - 1, max(0, updated - 1)})}
    for side in SIDES:
        run = pair[side]
        require(set(run['phase_seconds']) == phases and set(run['query']) == set(expected_queries), 'lifecycle phase set differs')
        for value in run['phase_seconds'].values(): number(value, True)
        require(close(run['phase_seconds']['measured_lifecycle'], math.fsum(v for k, v in run['phase_seconds'].items()
                if k not in ('measured_lifecycle', 'restart_verification_wall'))), 'lifecycle sum mismatch')
        require(run['correctness'] == expected_correctness, 'independent TopK/restart oracle coverage differs')
        for phase in expected_queries:
            query = run['query'][phase]; values = query['per_request_seconds']
            require(len(values) == queries and query['count'] == queries and
                    query['modes'] == ['exact' if i % 2 == 0 else 'ann' for i in range(queries)], 'query count/mode mismatch')
            for value in values: number(value, True)
            require(query['first_request_seconds'] == values[0] and close(query['seconds'], math.fsum(values)) and
                    close(run['phase_seconds'][phase], math.fsum(values)) and close(query['p50_ms'], 1000 * median(values)) and
                    close(query['p95_ms'], 1000 * sorted(values)[math.ceil(queries * .95) - 1]), 'query summary mismatch')
        resource = run['resource_snapshots']
        require(len(resource) == len(snapshots) and {s['phase'] for s in resource} == snapshots, 'resource snapshot set differs')
        for snapshot in resource:
            for family in ('process_memory_proxy', 'process_io_counters_proxy'):
                for value in snapshot.get(family, {}).values(): integer(value)
            if 'process_cpu_seconds' in snapshot: number(snapshot['process_cpu_seconds'])
            for item in snapshot.get('open_rebuildable_files', []):
                require(item['kind'] in ('payload', 'flat_index'), 'unknown spill-file kind'); integer(item['logical_bytes'])
        if plan == 'spill_filters':
            observed = next(s for s in resource if s['phase'] == 'after_index_build')
            require({v['kind'] for v in observed.get('open_rebuildable_files', []) if v['logical_bytes'] > 0} == {'payload', 'flat_index'}, 'spill-filter benchmark did not record actual payload and flat spill')
        integer(run['shutdown_data_file_bytes']); integer(run['final_shutdown_data_file_bytes']); hash_ok(run['response_sha256'])
    require(pair['all_responses_identical'] is True and pair['baseline']['response_sha256'] == pair['candidate']['response_sha256'], 'lifecycle response mismatch')


def check_projection(pair):
    rows = PROJECTIONS[pair['scenario']][0]
    require(pair['all_responses_identical_and_independently_verified'] is True, 'missing projection oracle assertion')
    for side in SIDES:
        run = pair[side]
        require(run['status'] == 'passed' and set(run['phases']) == set(LABELS) and
                set(run['lifecycle_seconds']) == {'startup', 'create_and_insert', 'shutdown'}, 'projection incomplete')
        for value in run['lifecycle_seconds'].values(): number(value, True)
        integer(run['ingest_request_bytes'], 1)
        for label, phase in run['phases'].items():
            expected_rows = min(rows, 10) if label.endswith('10') else min(rows, 4096) if label.endswith('4096') else rows
            require(phase['rows_per_response'] == expected_rows and phase['columns'] == (['id', 'n', 's', 'v'] if label.startswith('wide') else ['id']) and
                    phase['independent_oracle'] == 'every element, exact integer/string/float32 and signed zero', 'projection oracle/shape mismatch')
            require(len(phase['requests']) == 3, 'projection repeated sample count differs')
            for sample in phase['requests']:
                number(sample['seconds'], True); integer(sample['request_bytes'], 1); integer(sample['response_bytes'], 1); hash_ok(sample['response_sha256'])
            require(close(phase['wall_seconds'], math.fsum(s['seconds'] for s in phase['requests'])) and
                    phase['response_bytes'] == sum(s['response_bytes'] for s in phase['requests']), 'projection phase total mismatch')
    require(pair['baseline']['ingest_request_bytes'] == pair['candidate']['ingest_request_bytes'], 'projection ingest request bytes differ')
    for label in LABELS:
        for b, c in zip(pair['baseline']['phases'][label]['requests'], pair['candidate']['phases'][label]['requests']):
            require(all(b[k] == c[k] for k in ('request_bytes', 'response_bytes', 'response_sha256')), 'projection raw response/request differs')


def recompute_summary(pairs, projection):
    grouped = defaultdict(lambda: defaultdict(list))
    for pair in pairs:
        b, c = pair['baseline'], pair['candidate']
        for phase in b['phases' if projection else 'phase_seconds']:
            bv, cv = (b['phases'][phase]['wall_seconds'], c['phases'][phase]['wall_seconds']) if projection else (b['phase_seconds'][phase], c['phase_seconds'][phase])
            grouped[pair['scenario']][phase].append(bv / cv)
    lo, hi = ('min_baseline_over_candidate', 'max_baseline_over_candidate') if projection else ('minimum', 'maximum')
    return {case: {phase: {'pairs': len(values), 'median_baseline_over_candidate': median(values), lo: min(values), hi: max(values)}
                   for phase, values in phases.items()} for case, phases in grouped.items()}


def check_reports(out, context, summary):
    result = {}
    require(set(summary['benchmarks']) == set(PLANS), 'unexpected/missing report family')
    for plan, (cases, pairs_per_seed, count) in PLANS.items():
        raw = read(child(out, plan + '.json')); projection = plan == 'projections'
        require(raw['status'] == 'passed' and raw.get('official_score') is None and 'error' not in raw and 'failed_pair' not in raw, 'failed/incomplete raw report')
        require(raw['host']['platform'] == context['platform'] and raw['host'].get('cpu_affinity', raw['host'].get('affinity')) == context['cpu_affinity'] and raw['environment'] == {}, 'host/affinity/environment mismatch')
        for side in SIDES:
            require(raw['binaries'][side] == {'path': context[side]['binary'], 'sha256': context[side]['binary_sha256_before']}, 'raw report measured a different binary')
        parameters = context[plan]
        size = len(cases) * len(SEEDS) * pairs_per_seed
        require(parameters['seeds'] == list(SEEDS) and parameters['pairs_per_seed'] == pairs_per_seed and parameters['pairs'] == size, 'context schedule differs')
        if plan != 'standard': require(parameters['scenarios'] == list(cases), 'context scenario order differs')
        if projection:
            require(parameters['repetitions_per_phase'] == count and raw['parameters'] == {'seeds': list(SEEDS), 'pairs_per_seed': pairs_per_seed, 'repetitions_per_phase': count}, 'projection parameters differ')
            require(raw['kind'] == 'wide_projection_screen' and raw['harness_sha256'] == context['benchmark_harness_sha256']['benchmark_projection.py'], 'projection harness differs')
            workloads = {}; require(len(raw['workloads']) == 9, 'projection workload count differs')
            for work in raw['workloads']:
                key = (work['scenario'], work['seed']); require(key not in workloads and key[0] in cases and key[1] in SEEDS, 'duplicate/invalid projection workload')
                require((work['rows'], work['dimension'], work['string_codepoints']) == PROJECTIONS[key[0]], 'projection dimensions differ')
                input_name = f'projections.inputs/{key[0]}-{key[1]}.jsonl'; input_file = child(out, input_name)
                require(work['input_path'].replace('\\', '/').endswith('/' + input_name) and work['input_bytes'] == input_file.stat().st_size and work['input_sha256'] == sha(input_file), 'projection input corpus mismatch')
                workloads[key] = work['input_sha256']
        elif plan == 'spill_filters':
            require(parameters['queries_argument'] == count and raw['parameters'] == {'seeds': list(SEEDS), 'pairs': pairs_per_seed, 'queries': count} and raw['kind'] == 'report_matrix_screen', 'spill-filter parameters differ')
        else:
            require(parameters['queries_argument'] == count and raw['kind'] == 'paired_local_iteration_benchmark' and raw['suite'] == 'full' and
                    raw['seeds'] == list(SEEDS) and raw['pairs_per_seed'] == pairs_per_seed and raw['queries_per_phase'] == count and raw['batch_size'] == 100 and raw['k'] == 10, 'lifecycle parameters differ')
        expected = {(case, seed, index) for case in cases for seed in SEEDS for index in range(pairs_per_seed)}
        seen = set(); workloads_seen = {}
        for pair in raw['pairs']:
            integer(pair['seed']); integer(pair['pair_index'])
            key = (pair['scenario'], pair['seed'], pair['pair_index'])
            require(key in expected and key not in seen, 'duplicate/unexpected pair identity'); seen.add(key)
            order = list(SIDES)
            if (cases.index(key[0]) + SEEDS.index(key[1]) + key[2]) % 2: order.reverse()
            require(pair['order'] == order, 'AB/BA schedule mismatch')
            corpus_key = key[:2]; checksum = pair['input_sha256' if projection else 'workload_sha256']; hash_ok(checksum)
            require(corpus_key not in workloads_seen or workloads_seen[corpus_key] == checksum, 'corpus changed between paired repeats')
            workloads_seen[corpus_key] = checksum
            if projection:
                require(workloads[corpus_key] == checksum, 'pair/corpus binding mismatch'); check_projection(pair)
            else:
                check_lifecycle(pair, plan, count)
        require(seen == expected and len(raw['pairs']) == size, 'missing pair identities')
        recomputed = recompute_summary(raw['pairs'], projection)
        claimed = summary['benchmarks'][plan]
        require(raw['summary'] == recomputed == claimed['summary'], 'raw/collector summary does not equal per-pair recomputation')
        require(claimed['status'] == 'passed' and claimed['pairs'] == claimed['expected_pairs'] == size and all(claimed[k] is True for k in
                ('complete', 'unique_expected_pair_identities', 'measured_binary_sha256_matches', 'all_responses_verified')), 'collector report verification differs')
        result[plan] = raw
    return result


def lifecycle_metrics(group):
    first = group[0]['baseline']
    result = {'phase_seconds': {name: metric(group, lambda r, n=name: r['phase_seconds'][n]) for name in first['phase_seconds']},
              'queries': {}, 'resource_snapshots': {}, 'fanout': []}
    for name in first['query']:
        result['queries'][name] = {'first_request_seconds': metric(group, lambda r, n=name: r['query'][n]['per_request_seconds'][0]),
            'steady_after_first_two_seconds': metric(group, lambda r, n=name: math.fsum(r['query'][n]['per_request_seconds'][2:]))}
        for label, offset in (('exact_after_first_seconds', 2), ('ann_after_first_seconds', 3)):
            result['queries'][name][label] = metric(group, lambda r, n=name, i=offset: math.fsum(r['query'][n]['per_request_seconds'][i::2]))
        result['queries'][name]['mode_group_scope'] = ('Alternating unfiltered exact / single-filter ann' if group[0]['scenario'] == 'standard10k' else 'Alternating exact / ann; predicate family is unchanged by these labels')
    for item in first['resource_snapshots']:
        phase = item['phase']
        def snapshot(run, label=phase):
            return next(s for s in run['resource_snapshots'] if s['phase'] == label)
        records = [snapshot(pair[side]) for pair in group for side in SIDES]
        metrics = {}
        for family in ('process_memory_proxy', 'process_io_counters_proxy'):
            keys = set().union(*(r.get(family, {}) for r in records))
            metrics[family] = {key: (metric(group, lambda r, f=family, k=key: snapshot(r)[f][k]) if
                all(key in r.get(family, {}) for r in records) else {'unavailable': 'not recorded for every pair; no partial aggregate'}) for key in sorted(keys)}
        metrics['cumulative_process_cpu_seconds'] = metric(group, lambda r: snapshot(r)['process_cpu_seconds']) if all('process_cpu_seconds' in r for r in records) else None
        metrics['raw_snapshots'] = [dict(identity(p), **{s: snapshot(p[s]) for s in SIDES}) for p in group]
        result['resource_snapshots'][phase] = metrics
    for key in ('shutdown_data_file_bytes', 'final_shutdown_data_file_bytes'):
        result[key] = metric(group, lambda r, k=key: r[k])
    for pair in group:
        evidence = {}
        for side in SIDES:
            stderr = pair[side]['stderr']; text = stderr.get('tail_utf8', '')
            evidence[side] = {'decisions': [int(v) for v in re.findall(r'-> ([12]) threads?', text)],
                'wake_us': [float(v) for v in re.findall(r'wake_us=([\d.]+)', text)], 'bounded_stderr': stderr}
        result['fanout'].append(dict(identity(pair), **evidence))
    result['resource_limits'] = 'Process snapshots, not cgroup limits or official memory/IO scores; cumulative CPU resets on restart. Missing counters remain missing. Bounded stderr is not a complete per-query execution trace.'
    return result


def projection_metrics(group):
    result = {'lifecycle_seconds': {name: metric(group, lambda r, n=name: r['lifecycle_seconds'][n]) for name in ('startup', 'create_and_insert', 'shutdown')}, 'phases': {}}
    for label in LABELS:
        nested = [dict(identity(p), sample_index=i, baseline=p['baseline']['phases'][label]['requests'][i],
                       candidate=p['candidate']['phases'][label]['requests'][i],
                       baseline_over_candidate=p['baseline']['phases'][label]['requests'][i]['seconds'] / p['candidate']['phases'][label]['requests'][i]['seconds']) for p in group for i in range(3)]
        result['phases'][label] = {'wall_seconds': metric(group, lambda r, n=label: r['phases'][n]['wall_seconds']),
            'first_request_seconds': metric(group, lambda r, n=label: r['phases'][n]['requests'][0]['seconds']),
            'remaining_two_requests_seconds': metric(group, lambda r, n=label: math.fsum(s['seconds'] for s in r['phases'][n]['requests'][1:])),
            'response_bytes': metric(group, lambda r, n=label: r['phases'][n]['response_bytes']),
            'rows_per_response': group[0]['baseline']['phases'][label]['rows_per_response'],
            'nested_samples': nested, 'candidate_slower_nested_samples': sum(v['baseline_over_candidate'] < 1 for v in nested),
            'independent_pair_units': len(group)}
    result['accounted_timer_sum_seconds'] = metric(group, lambda r: math.fsum(r['lifecycle_seconds'].values()) + math.fsum(v['wall_seconds'] for v in r['phases'].values()))
    result['accounted_timer_limit'] = 'Sum of reported timers including create_and_insert and all seven query phases; excludes untimed parsing/oracle/setup, not total elapsed wall time.'
    result['resources'] = None
    result['resource_limit'] = 'Projection harness records no CPU/RSS/physical-I/O data; response bytes are transport bytes.'
    return result


def analyze(root, expected_commit, expected_flags, source):
    root = root.resolve(); require(root.is_dir(), 'complete artifact directory is missing')
    out = root / 'final-performance'; require(out.is_dir() and not out.is_symlink(), 'final-performance directory missing/symlink')
    hashes = manifest(out)
    context, summary, status = [read(child(out, name + '.json')) for name in ('context', 'summary', 'run-status')]
    require(summary['status'] == 'passed' and type(summary['exit_code']) is int and summary['exit_code'] == 0 and summary['stage'] == 'complete' and
            status == {'exit_code': 0, 'stage': 'complete', 'proof_status': 'passed'} and child(out, 'stage.txt').read_text().strip() == 'complete', 'performance pipeline failed/incomplete')
    require(context['expected_total_pairs'] == summary['total_pairs'] == summary['expected_total_pairs'] == summary['verified_total_pairs'] == 120, 'expected 120 verified pairs')
    require(summary['baseline_commit'] == BASELINE and context['candidate_image_binary_binding_verified'] is True and
            summary['baseline_three_correctness_gates_passed'] is True, 'missing source/image/correctness binding')
    require(type(context['cpu_affinity']) is list and len(context['cpu_affinity']) == len(set(context['cpu_affinity'])) == 2 and
            all(type(n) is int and n >= 0 for n in context['cpu_affinity']), 'two-CPU affinity missing')
    for side in SIDES:
        hash_ok(context[side]['binary_sha256_before'])
        require(summary['binary_sha256_before'][side] == summary['binary_sha256_after'][side] == context[side]['binary_sha256_before'] and
                summary['binary_unchanged'][side] is True, 'binary changed or checksum binding differs')
    require(child(out, 'candidate-path.txt').read_text().strip() == context['candidate']['binary'], 'candidate path mismatch')
    proof = root_binding(root, context, summary, expected_commit, expected_flags, source)
    proof['baseline'] = baseline_binding(out, context, source)
    reports = check_reports(out, context, summary)
    # No ratios are emitted before every family, checksum, source and oracle gate passes.
    scenarios = {}
    for plan, report in reports.items():
        for name in PLANS[plan][0]:
            group = [p for p in report['pairs'] if p['scenario'] == name]
            scenarios[name] = {'family': plan, 'pairs': len(group), 'identities': [identity(p) for p in group],
                'oracle_scope': ('Every projected value for all repeated responses' if plan == 'projections' else
                                 'Every filtered TopK request plus all restarted IDs and sampled vectors' if plan == 'spill_filters' else
                                 'Sampled TopK indices 0,1,last in each query phase; all restarted IDs and sampled vectors; other requests check size and cross-binary digest'),
                'metrics': projection_metrics(group) if plan == 'projections' else lifecycle_metrics(group)}
    root_hashes = {n: sha(child(root, n)) for n in ('verification-summary.json', 'input-sha256.txt', 'runtime-commit.txt', 'image-id.txt', 'image-inspect.json', 'image-binary-sha256.txt', 'source-binary-sha256.txt', 'image-binary-utf8.json')}
    if '-DMVDB_MULTI_POSTING_REUSE_ONLY' in expected_flags:
        for mode in ('normal', 'sanitized'):
            name = f'filter-reuse-{mode}.log'; root_hashes[name] = sha(child(root, name))
    return {'status': 'verified', 'kind': 'retained_actual_root_image_120_pair_audit', 'official_score': None,
            'candidate_commit': expected_commit, 'baseline_commit': BASELINE,
            'github_run_id': context.get('github_run_id'), 'github_run_attempt': context.get('github_run_attempt'),
            'verified_pairs': 120, 'source_image_binary_proof': proof,
            'artifact_integrity': {'final_manifest_sha256': sha(out / 'hashes.json'), 'verified_files': hashes, 'root_evidence_sha256': root_hashes},
            'host': {k: context[k] for k in ('platform', 'cpu_affinity', 'cpu_info')}, 'scenarios': scenarios,
            'interpretation': ['Baseline/candidate >1 means candidate has a smaller observed value; only timing metrics imply speed.',
                'Raw integers and integral medians remain integers. Integer half-medians include median_exact_fraction; median is null when binary64 cannot represent that half exactly. Ratios are explicitly floating point.',
                'Every pair, seed, AB/BA order and negative result is retained; nested projection repeats are not independent pairs.',
                'Shared-host/page-cache paired tests are not cold-cache trials or official hidden-case scoring.',
                'wide128 covers only 1024 rows at 128 dimensions; this and wide768 do not establish performance for other dimensions >=128.',
                'Correctness statements audit retained CI oracle records; full response values are not retained for independent replay here.',
                'Final helper retains source/build-log proof for original PGO, not gcda/corpus-by-corpus provenance. Future PGO rebuilds may produce different binaries.']}


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--input', type=Path, required=True, help='complete extracted protocol-results artifact')
    parser.add_argument('--candidate-commit', required=True)
    parser.add_argument('--expected-feature-flags', required=True, help='exact space-separated selected -D flags, in build order')
    parser.add_argument('--source-repo', type=Path, default=HERE / 'seekdb')
    parser.add_argument('--output', type=Path, default=HERE / 'retained-final-analysis.json')
    args = parser.parse_args()
    require(not args.output.exists(), 'refusing to overwrite analysis evidence')
    require(not args.output.resolve().is_relative_to(args.input.resolve()), 'analysis must be outside immutable raw artifact')
    result = analyze(args.input, args.candidate_commit, shlex.split(args.expected_feature_flags), GitSource(args.source_repo))
    with args.output.open('x', encoding='utf-8', newline='\n') as file:
        json.dump(result, file, ensure_ascii=False, indent=2, allow_nan=False); file.write('\n')
    print(json.dumps({'status': result['status'], 'verified_pairs': 120, 'output': str(args.output.resolve())}))


if __name__ == '__main__':
    main()
