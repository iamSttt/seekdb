#!/usr/bin/env python3
"""Small offline validation of gate fixtures and fail-closed trace checks."""
import ast
import copy
import hashlib
import importlib.util
import json
import math
from pathlib import Path

HERE = Path(__file__).resolve().parent
REPO = HERE.parent / "seekdb"
spec = importlib.util.spec_from_file_location("batch8_gate", HERE / "test_batch8_db.py")
gate = importlib.util.module_from_spec(spec)
spec.loader.exec_module(gate)
results = []


def check(name, fn):
    fn()
    results.append({"name": name, "status": "passed"})


def need(value):
    assert value


def rejects(fn):
    try:
        fn()
    except (AssertionError, ValueError):
        return
    raise AssertionError("bad input accepted")


check("python_ast", lambda: ast.parse((HERE / "test_batch8_db.py").read_text()))
check("fixed_21_unique_cases", lambda: need(len(gate.EXPECTED_CASES) == len(set(gate.EXPECTED_CASES)) == 21))
oracle = gate.load_oracle(REPO)
fixture_evidence = []
for count, dimension, zero in ((1027,128,False),(1033,129,False),(7,128,False),(33,128,True)):
    rows, records, query = gate.fixture(oracle,count,dimension,zero_cap=zero)
    distances = [oracle.canonical_squared(vector,query) for _,_,vector in rows]
    # All fixture values are exactly representable dyadic float32. Recover
    # magnitude directly from the oracle's exact 2^-149 lattice integers.
    magnitude = max(abs(coordinate) / (1 << 149) for _,_,vector in rows for coordinate in vector.scaled)
    step = math.ldexp(1.0, math.frexp(magnitude)[1]-7) if magnitude else 1.0
    if magnitude / step > 127:
        step *= 2
    minimum = min(distances)
    if zero:
        check(f"fixture_{count}_{dimension}_zero_cap",lambda:need(minimum == max(distances) == 0))
    else:
        check(f"fixture_{count}_{dimension}_positive_cap_margin",lambda:need(minimum / (step * step) > 16*dimension))
    fixture_evidence.append({"count":count,"dimension":dimension,"zero_cap":zero,"min_exact_distance":minimum,
                             "global_step":step,"rows_sql_sha256":hashlib.sha256("\n".join(vector.sql for _,_,vector in rows).encode()).hexdigest()})


def trace(path,worker,first,last,k=10,dimension=128,zero=False):
    begin=first+k
    end=begin if zero else begin+(last-begin)//8*8
    return dict(path=path,worker=worker,first=first,last=last,batch_begin=begin,batch_end=end,
                batches=(end-begin)//8,dimension=dimension,k=k,row_isa="avx2",batch_isa="avx2")


serial = [trace("serial",0,0,1027)]
parallel = [trace("fanout",0,0,513),trace("fanout",1,513,1027)]
kwargs = dict(path="serial",count=1027,dimension=128,k=10,expected="positive")
check("valid_serial_trace",lambda:gate.verify_traces(serial,**kwargs))
check("valid_reversed_fanout_trace",lambda:gate.verify_traces(list(reversed(parallel)),path="fanout",count=1027,dimension=128,k=10,expected="positive"))
check("valid_zero_cap_trace",lambda:gate.verify_traces([trace("serial",0,0,33,k=1,zero=True)],path="serial",count=33,dimension=128,k=1,expected="zero"))
check("reject_missing_positive_trace",lambda:rejects(lambda:gate.verify_traces([],**kwargs)))
check("reject_excluded_path_trace",lambda:rejects(lambda:gate.verify_traces(serial,**{**kwargs,"expected":"none"})))
for field,value in (("batch_begin",9),("batch_end",1010),("batches",999),("worker",1),("dimension",129)):
    bad=copy.deepcopy(serial);bad[0][field]=value
    check("reject_bad_"+field,lambda bad=bad:rejects(lambda:gate.verify_traces(bad,**kwargs)))
encoded=(gate.TRACE_PREFIX+json.dumps(serial[0])+"\n").encode()
check("parse_valid_trace",lambda:need(gate.parse_traces(encoded)==serial))
bad=serial[0].copy();bad["row_isa"]="avx512"
check("reject_wrong_row_isa",lambda:rejects(lambda:gate.parse_traces((gate.TRACE_PREFIX+json.dumps(bad)).encode())))
bad=serial[0].copy();bad["batches"]=True
check("reject_boolean_counter",lambda:rejects(lambda:gate.parse_traces((gate.TRACE_PREFIX+json.dumps(bad)).encode())))
check("reject_malformed_trace",lambda:rejects(lambda:gate.parse_traces(b"interleaved MVDB_BATCH8_TRACE {}\n")))
check("reject_duplicate_trace_key",lambda:rejects(lambda:gate.parse_traces((gate.TRACE_PREFIX+'{"path":"serial","path":"fanout"}').encode())))
payload={"status":"passed","scope":"offline Python fixture/trace logic only; no native compilation or database execution",
         "checks":results,"checks_count":len(results),"fixtures":fixture_evidence,
         "files":[{"path":name,"sha256":hashlib.sha256((HERE/name).read_bytes()).hexdigest()} for name in
                  ("test_batch8_db.py","test_batch8_bound.cpp")],"native_compilations":0,"database_executions":0}
(HERE/"preflight.json").write_text(json.dumps(payload,indent=2)+"\n",encoding="utf-8")
print(json.dumps({"status":payload["status"],"checks":len(results),"database_executions":0}))
