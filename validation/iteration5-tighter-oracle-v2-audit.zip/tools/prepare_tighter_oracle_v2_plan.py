"""Draft a disclosed gate correction; original frozen plan is immutable."""
import copy, hashlib, json, subprocess
from datetime import datetime, timezone
from pathlib import Path

W=Path(__file__).resolve().parent;R=W/'seekdb'
COMMIT='d767915b4aa816cb2720947ffcbe681819aa6036'
OLD='validation/iteration5-tighter-certificate-primary24-preregistration.json'
TARGET='validation/iteration5-tighter-certificate-primary24-oracle-v2-preregistration.json'
ERRATUM='validation/iteration5-tighter-certificate-oracle-v2-erratum.json'
def enc(value):return (json.dumps(value,ensure_ascii=False,separators=(',',':'),allow_nan=False)+'\n').encode()
def sha(raw):return hashlib.sha256(raw).hexdigest()
def blob(path):return subprocess.check_output(['git','-c','safe.directory='+R.as_posix(),'-C',str(R),'show',COMMIT+':'+path],stderr=subprocess.PIPE)

original=blob(OLD);old=json.loads(original)
audit_raw=(W/'tighter-only-attempt1-independent-audit.json').read_bytes();audit=json.loads(audit_raw)
assert audit['status']=='verified_tool_oracle_semantics_error_no_performance_measurement'
erratum={
    'status':'work_draft_after_failed_v1_gate_before_v2_execution',
    'recorded_at_utc':datetime.now(timezone.utc).isoformat(),
    'experiment_id':old['experiment_id'],'correction_revision':2,
    'original_preregistration':{'path':OLD,'bytes':len(original),'sha256':sha(original),'commit':COMMIT},
    'failed_attempt':{'commit':COMMIT,'run_id':43516543657,'job_id':132199821374,'artifact_id':14081625580,
                      'raw':audit['raw']['path'],'raw_bytes':audit['raw']['bytes'],'raw_sha256':audit['raw']['sha256'],
                      'root_PGO_builds_completed':1,'DB_execution_occurred':True,'first_actual_gate_sessions_started':1,
                      'actual_gate_completed_passed_cases':0,'performance_pairs':0,
                      'recorded_actual_ELF_sha256':audit['failed_actual_gate']['recorded_process_binary_sha256']},
    'error':'v1 expected_rows uses rounded binary64 squared distance directly as projected L2, but both retained and candidate exec return sqrt of that already-rounded squared value. Sorting still uses rounded squared distance then primary key.',
    'evidence_limit':'v1 asserts before storing failed actual/expected rows. The raw response cannot be reconstructed from this artifact, and a simultaneous runtime error is not excluded. The candidate has not passed the new actual-image gate; all24 corrected cases must run.',
    'correction':'Use independent integer/Fraction RN-even sqrt of the canonical binary64 squared value for projected bits; keep squared+PK ranking. Preserve the exact24 fixture/SQL/path inventory, save raw actual and expected response before assertions, and bind the revised driver/verifier in a new source snapshot.',
    'reexecution_reason':'Explicit tool-oracle correction after a correctness-gate stop, not a performance-based rerun or machine selection. The failed attempt stays failed. Build a fresh root PGO image with unchanged production/build/training inputs, then require the complete revised gates before any fixed24 performance measurements.',
    'unchanged':['candidate runtime and four feature flags','root compiler/Docker/training','EE and retained executable imports','24 measurement pairs/7319 seed/exact mode/CPU quotas/2GiB/swap0','all EE/R thresholds and metric definitions','required independent confirmation and user-owned formal submission'],
    'new_run_policy':'One new first-runnable x86_64 run for this disclosed correction; no ISA filtering, no further automatic retry. Native unsupported strict FP, tool, correctness or performance failures remain failures.',
    'independent_failure_audit':{'work_path':'tighter-only-attempt1-independent-audit.json','bytes':len(audit_raw),'sha256':sha(audit_raw)},
    'runtime_changes_for_correction':0,'v2_DB_runs':0,'v2_PGO_builds':0,'assistant_formal_submissions':0}
erratum_raw=enc(erratum);(W/'tighter-oracle-v2-erratum-draft.json').write_bytes(erratum_raw)
p=copy.deepcopy(old)
for key in ('source_snapshot','source_snapshot_methods','source_snapshot_base_commit','gate_preparation_evidence'):
    p.pop(key,None)
p.update(status='work_draft_corrected_gate_not_executed',protocol_revision=2,
         source_snapshot_status='Pending corrected v2 gate review and final Git canonical source snapshot; original plan remains immutable.')
p['tooling_correction']={'mode':'projection_oracle_v2','erratum':{'path':ERRATUM,'bytes':len(erratum_raw),'sha256':sha(erratum_raw)},
                        'original_plan':erratum['original_preregistration'],'previous_attempt':erratum['failed_attempt'],
                        'authorization_scope':erratum['new_run_policy']}
p['planned_gate_inventory']['oracle_schema']='actual-image-tighter-certificate-v2'
p['planned_gate_inventory']['execution_state']='v2 not executed; v1 first case failed under invalid projected-distance expectation'
p['execution']={'this_corrected_plan_new_PGO_builds_executed':0,'this_corrected_plan_database_pairs_executed':0,
                'prior_failed_attempt_root_PGO_builds_completed':1,'prior_failed_attempt_DB_execution_occurred':True,
                'prior_failed_attempt_performance_pairs':0,'default_adopted':False,'assistant_formal_submissions':0}
p['required_evidence']=old['required_evidence']+' Corrected schema-v2 projection oracle and failure-first response capture are mandatory; keep original failed attempt and do not count its partial gates as this corrected run passes.'
preserved=('candidate','references','fixed_plan','environment_acquisition','primary_rules','primary_metric_mapping','retained_protection_rules','confirmation','policy_source','decision')
assert all(p[k]==old[k] for k in preserved)
raw=enc(p);(W/'tighter-oracle-v2-preregistration-draft.json').write_bytes(raw)
message={'id':'assistant-tighter-only-oracle-v2-correction','role':'assistant','content':'tight-only首轮已完成根PGO1次及部分DB门禁；实际header normal/san各6748例、11452601检查通过，但新增actual gate首例失败，性能0对。独立定位v1预期误把L2平方作投影，R与候选原代码均返回sqrt；失败行未保存，不能断言没有其他运行错误。保留原失败与原计划，另立v2工具勘误：独立RN-even sqrt已舍入平方值、排序仍平方+PK、断言前保存响应，优化源码/训练/24对与阈值不变；重新构建用于工具纠错，不按性能换机，R仍默认。'}
(W/'tighter-oracle-v2-message-draft.json').write_bytes(enc(message))
receipt={'status':'work_draft_only','plan_target':TARGET,'plan_bytes':len(raw),'plan_sha256':sha(raw),
         'erratum_target':ERRATUM,'erratum_bytes':len(erratum_raw),'erratum_sha256':sha(erratum_raw),
         'unchanged_sections':list(preserved),'pending':['v2 source handoff and independent review','final sourcepins and erratum status'],'repo_writes':0}
(W/'tighter-oracle-v2-draft-receipt.json').write_bytes(enc(receipt));print(json.dumps(receipt,indent=2))
