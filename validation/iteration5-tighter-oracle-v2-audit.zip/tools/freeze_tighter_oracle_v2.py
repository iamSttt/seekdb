"""Freeze work-only corrected-gate evidence and plan; original plan untouched."""
import ast, copy, hashlib, importlib.util, json, subprocess, zipfile
from pathlib import Path

W=Path(__file__).resolve().parent;R=W/'seekdb';D=W/'tighter-bound-db-gates-v2'
BASE='d767915b4aa816cb2720947ffcbe681819aa6036'
ORIGINAL='validation/iteration5-tighter-certificate-primary24-preregistration.json'
TARGET='validation/iteration5-tighter-certificate-primary24-oracle-v2-preregistration.json'
ERRATUM='validation/iteration5-tighter-certificate-oracle-v2-erratum.json'
AUDIT='validation/iteration5-tighter-oracle-v2-audit.zip'
GIT=['git','-c','safe.directory='+R.as_posix(),'-C',str(R)]
def call(*args):return subprocess.check_output(GIT+list(args),stderr=subprocess.PIPE)
def blob(path):return call('show',BASE+':'+path)
def sha(data):return hashlib.sha256(data).hexdigest()
def enc(obj):return (json.dumps(obj,ensure_ascii=False,separators=(',',':'),allow_nan=False)+'\n').encode()
def need(ok,why):
    if not ok:raise ValueError(why)
def functions(raw):return {n.name:ast.dump(n,include_attributes=False) for n in ast.parse(raw).body if isinstance(n,ast.FunctionDef)}

need(call('rev-parse','HEAD').decode().strip()==BASE,'base changed')
prior_raw=blob(ORIGINAL);old=json.loads(prior_raw)
draft=json.loads((W/'tighter-oracle-v2-preregistration-draft.json').read_bytes())
erratum=json.loads((W/'tighter-oracle-v2-erratum-draft.json').read_bytes())
preflight_raw=(W/'tighter-projection-v2-preflight.json').read_bytes();preflight=json.loads(preflight_raw)
need(preflight['status']=='passed_pure_python_only' and preflight['checks']==2275 and preflight['native_executions']==preflight['database_runs']==preflight['performance_pairs']==0,'preflight claim')
targets={name:('minivec/tools/' if name=='verify_tighter_root.py' else 'minivec/tests/')+name for name in preflight['files']}
files={}
for name,path in targets.items():
    raw=(D/name).read_bytes();need(sha(raw)==preflight['files'][name] and raw==(R/path).read_bytes(),'v2 handoff mismatch '+name)
    if name.endswith('.py'):ast.parse(raw)
    files[path]={'bytes':len(raw),'sha256':sha(raw)}
changed_gate_paths=sorted(path for path in files if (R/path).read_bytes()!=blob(path))
need(changed_gate_paths==['minivec/tests/test_tighter_certificate_db.py','minivec/tools/verify_tighter_root.py'],'unexpected gate edits')
gate_raw=(D/'test_tighter_certificate_db.py').read_bytes();gate_old=blob('minivec/tests/test_tighter_certificate_db.py')
old_functions=functions(gate_old);new_functions=functions(gate_raw)
for name in ('fixture','environment','process_identity','load_oracle','expected_checks'):
    need(old_functions[name]==new_functions[name],'unrelated fixture/identity changes '+name)
spec=importlib.util.spec_from_file_location('independent_projection_v2_review',D/'test_tighter_certificate_db.py')
gate=importlib.util.module_from_spec(spec);spec.loader.exec_module(gate)
need(gate.SCHEMA=='actual-image-tighter-certificate-v2' and len(gate.EXPECTED_CASES)==24,'v2 schema/case count')
# Small independent exact examples only; the existing broader preflight is
# preserved as a reported test, not relabelled as our own native/DB execution.
from fractions import Fraction
for value,expected in ((0.0,'0000000000000000'),(1.0,'3ff0000000000000'),(4.0,'4000000000000000'),
                       (9.0,'4008000000000000'),(2.0**-298,'36a0000000000000')):
    need(gate.rounded_sqrt_binary64_bits(value)==expected,'exact sqrt example')
need(gate.rounded_sqrt_binary64_bits(Fraction((1<<53)+1,1<<53)**2)=='3ff0000000000000','even low midpoint')
need(gate.rounded_sqrt_binary64_bits(Fraction((1<<53)+3,1<<53)**2)=='3ff0000000000002','even high midpoint')
text=gate_raw.decode()
need(text.index('checks.append(check)')<text.index('require(response.get(\'columns\')'),'failure capture ordering')
need('rounded_sqrt_binary64_bits(distance)' in text and 'oracle.canonical_squared(vector,query)' in text,'projection/rank semantics')
verifier=(D/'verify_tighter_root.py').read_text()
need("gate.SCHEMA=='actual-image-tighter-certificate-v2'" in verifier and 'preserved parsed response differs from normalized actual rows' in verifier,'verifier v2/raw-response binding')

runtime_paths=call('ls-tree','-r','--name-only',BASE,'--','Dockerfile','.dockerignore','minivec/src','minivec/third_party','minivec/Makefile','minivec/tools/pgo').decode().splitlines()
for path in runtime_paths:
    original=(R/path).read_bytes();canonical=blob(path)
    # Working-tree CRLF conversion is permitted only when Git-clean has the
    # same object as the fixed base, or original worktree is untouched in Git.
    oid=call('hash-object','--path',path,path).decode().strip()
    actual_oid=call('rev-parse',BASE+':'+path).decode().strip()
    if oid!=actual_oid:
        need(path not in call('diff','--name-only',BASE,'--',path).decode().splitlines(),'runtime/build/training change '+path)
    need(canonical==blob(path),'unstable original blob')
changed=set(call('diff','--name-only',BASE,'--').decode().splitlines())
need(not (changed & set(runtime_paths)),'runtime inputs changed')
snapshot={};methods={}
for path in sorted(old['source_snapshot']):
    if path not in changed:
        data=blob(path);oid=call('rev-parse',BASE+':'+path).decode().strip();methods[path]='unchanged_actual_HEAD_blob'
    else:
        raw=(R/path).read_bytes();oid=call('hash-object','--path',path,path).decode().strip()
        alternatives=[x for x in (raw,raw.replace(b'\r\n',b'\n')) if hashlib.sha1(b'blob '+str(len(x)).encode()+b'\0'+x).hexdigest()==oid]
        need(alternatives,'unknown clean transform');data=alternatives[0];methods[path]='corrected_gate_Git_clean_candidate_pending_staged_check'
    snapshot[path]={'bytes':len(data),'sha256':sha(data),'git_blob':oid}
differences=[path for path in snapshot if snapshot[path]!=old['source_snapshot'][path]]
need(differences==changed_gate_paths,'sourcepins changed beyond two corrected tools')
review={'status':'no_blocking_static_findings_for_v2_tool_correction','base_commit':BASE,
        'gate_sources':files,'changed_gate_sources':changed_gate_paths,'actual_cases_unchanged':24,
        'oracle_proof':'Positive finite binary64 encodings are monotone. Binary search finds the greatest value whose exact dyadic square is <= the exact rational target; an exact squared midpoint comparison chooses the nearest neighbor, and encoding LSB selects ties-to-even. Input is canonical_squared already rounded to binary64, not the unrounded sum.',
        'ranking':'Original canonical squared-distance then primary-key ranking and all fixture/group/K/serial-fanout settings unchanged.',
        'failure_capture':'Successful parsed SQL response plus expected rows is appended as failed before type/bits/order assertions, then normalized actual rows/hash are populated before comparison. finally persists report. This is parsed JSON, not original wire bytes; SQL execution errors can still raise before this response record.',
        'verification':'v2 schema/semantics, all24 independently expected projected bits, raw parsed rows/normalized rows, four actual process identities and logs retained by verifier.',
        'pure_checks_run_here':7,'reported_existing_preflight':{'path':'tighter-projection-v2-preflight.json','bytes':len(preflight_raw),'sha256':sha(preflight_raw),'checks':2275},
        'runtime_build_training_files_unchanged':len(runtime_paths),'source_snapshot_differences':differences,
        'native_builds_run_here':0,'DB_runs_run_here':0,'PGO_builds_run_here':0,
        'limitation':'First failed raw lacked actual response; candidate correctness is still pending the complete corrected actual-image gate. Prior rootPGO/DB execution is not zero.'}
review_raw=enc(review);(W/'tighter-oracle-v2-independent-review.json').write_bytes(review_raw)

payload={
 'failure/audit.json':(W/'tighter-only-attempt1-independent-audit.json').read_bytes(),
 'failure/API-receipt.json':(W/'tighter-only-attempt1-api.json').read_bytes(),
 'failure/job.log':(W/'tighter-only-attempt1-job.log').read_bytes(),
 'failure/original-preregistration.json':prior_raw,
 'v2/independent-review.json':review_raw,'v2/pure-python-preflight.json':preflight_raw,
 'tools/audit_tighter_only_attempt1.py':(W/'audit_tighter_only_attempt1.py').read_bytes(),
 'tools/prepare_tighter_oracle_v2_plan.py':(W/'prepare_tighter_oracle_v2_plan.py').read_bytes(),
 'tools/freeze_tighter_oracle_v2.py':Path(__file__).read_bytes(),
 'tools/check_tighter_projection_v2.py':(W/'check_tighter_projection_v2.py').read_bytes(),
 'tools/tighter_v2_oracle_reader.py':(W/'tighter_v2_oracle_reader.py').read_bytes()}
failure=json.loads(payload['failure/audit.json'])
for path in failure['source_inputs']:payload['failure/source/'+path]=blob(path)
for path in files:payload['v2/source/'+path]=(R/path).read_bytes()
manifest={'schema_version':1,'scope':'Failed actual gate and disclosed projected-distance-oracle correction; raw archive remains a separate fixed artifact, no candidate acceptance.',
          'files':{path:{'bytes':len(data),'sha256':sha(data)} for path,data in sorted(payload.items())}}
payload['manifest.json']=enc(manifest)
audit_path=W/'tighter-oracle-v2-audit.zip'
with zipfile.ZipFile(audit_path,'w',zipfile.ZIP_DEFLATED,compresslevel=9) as z:
    for path,data in sorted(payload.items()):
        info=zipfile.ZipInfo(path,date_time=(1980,1,1,0,0,0));info.compress_type=zipfile.ZIP_DEFLATED;info.external_attr=0o100644<<16;z.writestr(info,data)
audit_bytes=audit_path.read_bytes()
erratum.update(status='frozen_after_failed_v1_gate_before_corrected_v2_execution',
               correction_sources=files,
               independent_review={'archive_path':AUDIT,'archive_sha256':sha(audit_bytes),'member':'v2/independent-review.json','member_sha256':sha(review_raw)},
               audit_archive={'path':AUDIT,'bytes':len(audit_bytes),'sha256':sha(audit_bytes)})
erratum_raw=enc(erratum);(W/'tighter-oracle-v2-erratum-frozen.json').write_bytes(erratum_raw)
draft.update(status='frozen_corrected_v2_gate_before_new_root_PGO_and_DB_execution',
             source_snapshot=snapshot,source_snapshot_base_commit=BASE,source_snapshot_methods=methods,
             source_snapshot_status='Only two corrected gate tools differ from original sourcepins; runtime/build/training unchanged. Parent verifies staged/committed blobs before push.',
             gate_preparation_evidence={'review_archive':AUDIT,'archive_sha256':sha(audit_bytes),'source_location':'v2/independent-review.json','sha256':sha(review_raw),'native_runs':0,'DB_runs':0})
draft['tooling_correction']['erratum']={'path':ERRATUM,'bytes':len(erratum_raw),'sha256':sha(erratum_raw)}
preserved=('candidate','references','fixed_plan','environment_acquisition','primary_rules','primary_metric_mapping','retained_protection_rules','confirmation','policy_source','decision')
need(all(draft[k]==old[k] for k in preserved),'criteria or candidate drift')
raw=enc(draft);(W/'tighter-oracle-v2-preregistration-frozen.json').write_bytes(raw)
receipt={'status':'work_only_frozen_v2_pending_parent_staged_blob_check','plan_target':TARGET,'plan_bytes':len(raw),'plan_sha256':sha(raw),
         'erratum_target':ERRATUM,'erratum_bytes':len(erratum_raw),'erratum_sha256':sha(erratum_raw),
         'audit_target':AUDIT,'audit_bytes':len(audit_bytes),'audit_sha256':sha(audit_bytes),'audit_files':len(payload),
         'independent_review_sha256':sha(review_raw),'sourcepins':len(snapshot),'only_changed_inputs':differences,
         'prior_actual_PGO_builds':1,'prior_DB_executed':True,'prior_performance_pairs':0,'corrected_v2_PGO_builds':0,'corrected_v2_DB_runs':0,
         'repo_writes':0,'Git_mutations':0}
(W/'tighter-oracle-v2-freeze-receipt.json').write_bytes(enc(receipt));print(json.dumps(receipt,indent=2))
