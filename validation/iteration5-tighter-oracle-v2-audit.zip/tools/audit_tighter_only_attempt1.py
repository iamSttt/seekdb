"""Independently audit the failed v1 gate; no DB runs or material changes."""
import ast, hashlib, json, re, subprocess, zipfile
from pathlib import Path, PurePosixPath

W=Path(__file__).resolve().parent; R=W/'seekdb'; D=W/'tighter-only-attempt1-raw'
COMMIT='d767915b4aa816cb2720947ffcbe681819aa6036'
RETAINED='33a52a7dd4426af059ec2334b7c93a07c38c93c9'
ARCHIVE='validation/iteration5-tighter-only-attempt1-raw.zip'
GIT=['git','-c','safe.directory='+R.as_posix(),'-C',str(R)]
def blob(revision,path):return subprocess.check_output(GIT+['show',revision+':'+path],stderr=subprocess.PIPE)
def sha(raw):return hashlib.sha256(raw).hexdigest()
def enc(obj):return (json.dumps(obj,ensure_ascii=False,separators=(',',':'))+'\n').encode()
def need(value,why):
    if not value:raise ValueError(why)

api_raw=(W/'tighter-only-attempt1-api.json').read_bytes();api=json.loads(api_raw)
raw=(R/ARCHIVE).read_bytes();art=api['artifact']
need(api['commit']==api['head_sha']==art['workflow_run']['head_sha']==COMMIT,'API commit')
need(api['run_id']==art['workflow_run']['id']==43516543657 and api['job_id']==132199821374,'API run/job')
need(art['id']==14081625580 and len(raw)==art['size_in_bytes']==194553,'API archive size/id')
need('sha256:'+sha(raw)==art['digest']=='sha256:a586c2cd6b65291250f4a374be8d052c22d4d279abdc4090033d0675a3503d77','API raw hash')
members={}
with zipfile.ZipFile(R/ARCHIVE) as archive:
    for info in archive.infolist():
        path=PurePosixPath(info.filename)
        need(not info.is_dir() and path.as_posix()==info.filename and not path.is_absolute() and
             not any(x in ('..','.') for x in path.parts) and '\\' not in info.filename and ':' not in info.filename,'archive path')
        need(info.filename not in members,'duplicate member')
        payload=archive.read(info);need((D/info.filename).read_bytes()==payload,'extracted member differs')
        members[info.filename]={'bytes':len(payload),'sha256':sha(payload)}
need(len(members)==103,'raw member count')
need((D/'runtime-commit.txt').read_text().strip()==COMMIT,'raw commit')
manifest={}
for line in (D/'input-sha256.txt').read_text().splitlines():
    digest,path=line.split(maxsplit=1);path=path.lstrip('*');need(path not in manifest,'duplicate source input');manifest[path]=digest
source_paths=['minivec/src/exec.cpp','minivec/src/distance.h','minivec/tests/test_tighter_certificate_db.py',
              'minivec/tests/topk_bounds.py','minivec/tests/test_tighter_certificate.cpp','minivec/tools/verify_tighter_root.py',
              'minivec/tools/ci_score.sh','Dockerfile','minivec/tools/pgo/train.cpp','minivec/tools/pgo/run-training.sh']
sources={}
for path in source_paths:
    data=blob(COMMIT,path);need(manifest[path]==sha(data),'executed source input differs '+path)
    sources[path]={'bytes':len(data),'sha256':sha(data)}
exec_raw=blob(COMMIT,'minivec/src/exec.cpp')
need(exec_raw==blob(RETAINED,'minivec/src/exec.cpp'),'retained exec semantics changed')
need(b'return std::sqrt(squared);' in exec_raw,'projection source')
gate_source=blob(COMMIT,'minivec/tests/test_tighter_certificate_db.py').decode();tree=ast.parse(gate_source)
expect=next(n for n in tree.body if isinstance(n,ast.FunctionDef) and n.name=='expected_rows')
expect_text=ast.get_source_segment(gate_source,expect)
need('oracle.canonical_squared(vector,query)' in expect_text and 'double_bits(distance)' in expect_text and 'sqrt' not in expect_text,'v1 squared-projection bug not demonstrated')
need(gate_source.index("require(normalized==expected,")<gate_source.index("checks.append({'name':name"),'v1 failure write ordering changed')
result=json.loads((D/'image-binary-tighter-certificate.json').read_bytes())
binary='fa5e20c6a9cddb31ff3216f64b1241e1d5e5371cfb92fca75482f5acd08fc683'
need(result['schema']=='actual-image-tighter-certificate-v1' and result['status']=='failed' and result['checks']==[],'failure report status')
need(result['binary_sha256']==binary==(D/'image-binary-sha256.txt').read_text().split()[0],'actual reported ELF identity')
need(len(result['sessions'])==1 and result['sessions'][0]['name']=='serial_d128' and result['sessions'][0]['binary_sha256']==binary,'first process identity')
need('serial_d128_unindexed_all: exact projected distance or TopK order mismatch' in result['error'],'first case failure')
need(len(result['expected_cases'])==24 and all('actual_rows' not in c for c in result['checks']),'v1 missing failed response')
log=(D/'image-binary-tighter-certificate.log').read_text()
need(result['error'] in log,'raw exception mismatch')
for item in result['stderr_logs']:
    need(members[item['path']]=={'bytes':item['bytes'],'sha256':item['sha256']},'stderr evidence')
counts={}
for mode in ('normal','sanitized'):
    text=(D/f'tighter-certificate-{mode}.log').read_text()
    need(text.splitlines().count('tighter_bound=PASS')==1,'native pass marker')
    need(re.findall(r'^tighter_bound_checks=(\d+)$',text,re.M)==['11452601'],'native checks')
    need('tighter_bound_cases=6748 midpoint_fixtures=180 rescue_fixtures=10' in text,'native fixture inventory')
    counts[mode]={'fixtures':6748,'checks':11452601,'midpoint_fixtures':180,'analytic_rescue_fixtures':10,'status':'passed'}
build=(D/'docker-build.log').read_text()
oracles=[json.loads(line[line.index('{'):]) for line in build.splitlines() if '"actual_file":"responses-' in line]
need(len(oracles)==6 and all(x['status']=='passed' for x in oracles),'six PGO training oracle records')
need('-fprofile-generate=/pgo' in build and '-fprofile-use=/pgo' in build and '#12 DONE ' in build,'actual PGO build evidence')
need(not any(name.startswith('highest-primary-root/') for name in members) and 'root-gates-summary.json' not in members,'unexpected performance/root pass after failure')
plan_path='validation/iteration5-tighter-certificate-primary24-preregistration.json';plan_raw=blob(COMMIT,plan_path)
report={'status':'verified_tool_oracle_semantics_error_no_performance_measurement',
        'commit':COMMIT,'run_id':43516543657,'job_id':132199821374,'artifact_id':14081625580,
        'raw':{'path':ARCHIVE,'bytes':len(raw),'sha256':sha(raw),'members':members},
        'API_receipt':{'path':'tighter-only-attempt1-api.json','sha256':sha(api_raw)},
        'original_preregistration':{'path':plan_path,'bytes':len(plan_raw),'sha256':sha(plan_raw)},
        'source_inputs':sources,'retained_exec_byte_identical':True,
        'diagnosis':'The v1 oracle sorts by rounded squared distance correctly, but incorrectly compares that squared value to the projected L2 value. Both retained and candidate exec project std::sqrt of the already-rounded binary64 squared distance.',
        'failed_actual_gate':{'name':'serial_d128_unindexed_all','expected_cases':24,'completed_passed_cases':0,'sessions_started':1,'recorded_process_binary_sha256':binary,'response_saved':False},
        'native_header_checks':counts,
        'execution':{'completed_root_PGO_builds':1,'PGO_training_oracle_responses':oracles,'DB_execution_occurred':True,'total_DB_processes_not_recounted':True,'paired_performance_runs':0,'all_root_gates_completed':False},
        'limitations':['The failed response/normalized/expected rows were not written before the v1 assertion. Raw evidence cannot recover those values or prove that no simultaneous runtime mismatch existed.','The raw archive records the actual image/process SHA but does not contain the actual extracted ELF bytes.','Native/header and preceding protocol gates passed as individually recorded; the overall root gate did not pass.'],
        'correction_scope':'Fix projected expected bits only with an independent integer/Fraction RN-even sqrt of canonical binary64 squared values, preserve squared+PK sorting and all24 cases; save response and expectations before asserting. Rebuild and rerun only as disclosed tooling correction, with all workload/performance thresholds and runtime/build/training inputs unchanged.',
        'new_DB_runs_by_this_audit':0,'new_native_builds_by_this_audit':0,'new_PGO_builds_by_this_audit':0}
out=enc(report);(W/'tighter-only-attempt1-independent-audit.json').write_bytes(out)
print(json.dumps({'status':report['status'],'audit_bytes':len(out),'audit_sha256':sha(out),'root_PGO_completed':1,'actual_gate_completed':0,'actual_gate_sessions_started':1,'performance_pairs':0},indent=2))
