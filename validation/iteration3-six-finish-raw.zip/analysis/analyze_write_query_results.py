"""Read-only analysis of the I17/I18 same-PGO lifecycle reports."""
import argparse
import hashlib
import json
import math
from pathlib import Path
import re
from statistics import median

SIDES=('baseline','candidate')
SEEDS=(7319,8911,13337)
SPILL=('spill_low_q1','spill_high_q1','spill_low_q16','spill_high_q16')
FILTER=('resident_compound_q1','resident_compound_q16')

def require(test,message):
    if not test:raise ValueError(message)

def equal(a,b):
    return math.isclose(a,b,rel_tol=1e-11,abs_tol=1e-12)

def load(path):return json.loads(path.read_text(encoding='utf-8'))
def sha(path):return hashlib.sha256(path.read_bytes()).hexdigest()

def audit_side(side,reads,rows,storage):
    phases=side['phase_seconds'];cycles=side['write_cycles'];queries=side['query']
    require(len(cycles)==4 and [c['cycle'] for c in cycles]==list(range(4)),'wrong cycle plan')
    expected_queries={'query_before_mutations','query_after_restart',*[f'query_cycle_{i}' for i in range(4)]}
    require(set(queries)==expected_queries,'missing/extra query phase')
    for name,item in queries.items():
        values=item['per_request_seconds']
        require(len(values)==reads and item['count']==reads,'wrong request count')
        require(all(type(v) in (int,float) and math.isfinite(v) and v>0 for v in values),'invalid request time')
        require(equal(sum(values),phases[name]) and equal(values[0],item['first_request_seconds']),
                'query timing summary does not match raw requests')
        require(item['all_queries_independent_oracle'] is True,'missing per-phase oracle')
    for cycle in cycles:
        index=cycle['cycle'];changes=cycle['mutations']
        require(len(changes)==1 and changes[0]['kind']=='update','not one UPDATE per cycle')
        writes=cycle['begin_seconds']+cycle['commit_seconds']+sum(c['seconds'] for c in changes)
        require(equal(writes,cycle['write_and_commit_seconds']) and
                equal(writes,phases[f'writes_cycle_{index}']),'write/commit timing mismatch')
        require(equal(cycle['query_seconds'],phases[f'query_cycle_{index}']) and
                equal(cycle['first_query_seconds'],queries[f'query_cycle_{index}']['per_request_seconds'][0]),
                'cycle query timing mismatch')
        require(equal(cycle['cycle_seconds'],writes+cycle['query_seconds']),'cycle total mismatch')
    lifecycle=sum(value for key,value in phases.items() if key not in ('measured_lifecycle','restart_verification_wall'))
    require(equal(lifecycle,phases['measured_lifecycle']),'lifecycle omitted or double-counted a phase')
    require(side['correctness']['all_query_responses_independent_oracle'] is True and
            side['correctness']['all_restarted_ids_checked']==rows,'restart/oracle proof missing')
    require(side[storage] is True,'storage observation missing')
    snapshots=side['resource_snapshots'];labels=[x['phase'] for x in snapshots]
    require(len(labels)==len(set(labels)),'duplicate resource snapshot labels')
    snapshot={x['phase']:x for x in snapshots}
    require({'after_ingest','after_index_build','query_before_mutations','before_shutdown',
             'after_restart','query_after_restart','before_final_shutdown'}<=set(snapshot),
            'lifecycle resource snapshots missing')
    observed=snapshot['after_index_build']
    files=observed['open_rebuildable_files']
    if storage=='real_spill_observed':
        require({'payload','flat_index'}<={x['kind'] for x in files if x['logical_bytes']>0},'spill storage not observed')
    else:
        require(not files and observed['process_memory_proxy']['VmRSS_bytes']>0,'resident observation invalid')

def metrics(side):
    result={name:value*1000 for name,value in side['phase_seconds'].items()}
    result['full_run_wall_including_verification']=1000*side['full_run_wall_seconds_including_verification']
    cycles=side['write_cycles'];queries=side['query']
    result['initial_first_query']=1000*queries['query_before_mutations']['first_request_seconds']
    result['initial_index_plus_first_query']=result['index_build']+result['initial_first_query']
    result['restart_first_query']=1000*queries['query_after_restart']['first_request_seconds']
    result['restart_plus_first_query']=result['restart']+result['restart_first_query']
    result['all_cycle_begin']=1000*sum(c['begin_seconds'] for c in cycles)
    result['all_cycle_commit']=1000*sum(c['commit_seconds'] for c in cycles)
    result['all_cycle_dml']=1000*sum(m['seconds'] for c in cycles for m in c['mutations'])
    result['all_cycle_write_and_commit']=1000*sum(c['write_and_commit_seconds'] for c in cycles)
    result['all_cycle_first_query']=1000*sum(c['first_query_seconds'] for c in cycles)
    result['all_cycle_query']=1000*sum(c['query_seconds'] for c in cycles)
    result['all_cycle_write_plus_first_query']=result['all_cycle_write_and_commit']+result['all_cycle_first_query']
    result['all_cycles']=1000*sum(c['cycle_seconds'] for c in cycles)
    warm=[t for i in range(4) for t in queries[f'query_cycle_{i}']['per_request_seconds'][1:]]
    if warm:
        result['all_cycle_warm_queries']=1000*sum(warm)
        result['mean_warm_query']=1000*sum(warm)/len(warm)
    return result

def resources(side):
    snapshots=side['resource_snapshots'];snapshot={x['phase']:x for x in snapshots}
    ends=[snapshot['before_shutdown'],snapshot['before_final_shutdown']]
    result={}
    for field,label in [('VmHWM_bytes','maximum_process_high_water_bytes'),('VmRSS_bytes','maximum_sampled_rss_bytes')]:
        vals=[s.get('process_memory_proxy',{}).get(field) for s in snapshots]
        if all(v is not None for v in vals):result[label]=max(vals)
    if all('process_cpu_seconds' in x for x in ends):
        result['sum_pre_shutdown_process_cpu_seconds']=sum(x['process_cpu_seconds'] for x in ends)
    io_keys=set.intersection(*(set(x.get('process_io_counters_proxy',{})) for x in ends))
    for key in sorted(io_keys):result['sum_pre_shutdown_io_'+key]=sum(x['process_io_counters_proxy'][key] for x in ends)
    phases=[('after_index_build','query_before_mutations')]+[(f'writes_cycle_{i}',f'query_cycle_{i}') for i in range(4)]
    if all('process_cpu_seconds' in snapshot[x] for phase in phases for x in phase):
        result['initial_and_mutation_query_windows_cpu_seconds']=sum(
            snapshot[after]['process_cpu_seconds']-snapshot[before]['process_cpu_seconds'] for before,after in phases)
    for key in sorted(io_keys):
        if all(key in snapshot[x].get('process_io_counters_proxy',{}) for phase in phases for x in phase):
            result['initial_and_mutation_query_windows_io_'+key]=sum(
                snapshot[after]['process_io_counters_proxy'][key]-snapshot[before]['process_io_counters_proxy'][key]
                for before,after in phases)
    for name in ('shutdown_data_file_bytes','final_shutdown_data_file_bytes'):result[name]=side[name]
    return result

def stats(values):return {'median':median(values),'min':min(values),'max':max(values)}

def summarize_pairs(pairs,field):
    names=set.intersection(*(set(p[side][field]) for p in pairs for side in SIDES))
    out={}
    for name in sorted(names):
        b=[p['baseline'][field][name] for p in pairs];c=[p['candidate'][field][name] for p in pairs]
        item={'pairs':len(pairs),'baseline':stats(b),'candidate':stats(c),
              'candidate_minus_baseline':stats([y-x for x,y in zip(b,c)]),
              'candidate_larger_pairs':sum(y>x for x,y in zip(b,c))}
        if all(x>0 and y>0 for x,y in zip(b,c)):item['baseline_over_candidate']=stats([x/y for x,y in zip(b,c)])
        out[name]=item
    return out

def main():
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--input',type=Path,default=Path(__file__).resolve().parent/'performance/report-six-direction-4639078d')
    parser.add_argument('--output',type=Path,default=Path(__file__).resolve().parent/'six-direction-write-query-analysis.json')
    args=parser.parse_args();root=args.input
    context=load(root/'context.json');summary=load(root/'summary.json');status=load(root/'run-status.json')
    require(status['exit_code']==0 and status['proof_complete'] is True and summary['status']=='passed' and
            summary['total_pairs']==27 and summary['unit_gates_passed']==12,'incomplete six-direction run')
    revision=context['source_commit'];require(re.fullmatch('[0-9a-f]{40}',revision),'invalid source commit')
    result={'source_commit':revision,'input_directory':str(root),'official_score':None,'automatic_adoption':False,
            'measurement_unit':'one baseline/candidate pair; 3 seeds x 1 pair per scenario, not 12 independent cycles',
            'metric_units':'timing_ms in milliseconds; resources have units in key names',
            'reports':{},'scenarios':{},'comparisons':{},'definitions':[
                'all_cycles is the sum of four observed BEGIN+one UPDATE+COMMIT+1/16-query cycles.',
                'all_cycle_first_query includes lazy physical-index/cache rebuilding after the UPDATE.',
                'initial_index_plus_first_query includes eager index construction and first lazy-cache query.',
                'measured_lifecycle includes startup/create/ingest/index/queries/writes/commits/shutdown/restart/final-shutdown; correctness verification and snapshots are excluded.',
                'full_run_wall includes verification, snapshots and cleanup, but excludes workload generation.',
                'post-restart first query follows point-query persistence verification; it is not a cold-page-cache observation.',
                'Resource counters are /proc process proxies. Sum of two pre-shutdown counters omits each shutdown and includes verification CPU/IO; no cgroup resource claim.',
                'rchar/read_bytes differ: rchar includes reads served by page cache and protocol; read_bytes counts storage I/O attributed to the process. Neither proves vector index logical bytes.',
                'Maximum process VmHWM is max across two process lifetimes, not a sum and not cgroup peak.',
                'Same source/compiler/original PGO training, separately trained binaries for each feature. Three pairs are screening; no confidence interval/default adoption inferred.',
                'Q1 and Q16 use separate processes/order positions; compare within-scenario paired ratios, not raw cross-scenario speedups or a causal break-even point.'
            ]}
    for filename,feature,cases,storage in [('write-query.json','spill',SPILL,'real_spill_observed'),
                                         ('filter-write-query.json','filter',FILTER,'resident_storage_observed')]:
        path=root/filename;report=load(path);proof=load(root/f'{feature}-build-context.json')
        expected={(case,seed,0) for case in cases for seed in SEEDS}
        ids=[(p['scenario'],p['seed'],p['pair_index']) for p in report['pairs']]
        require(report['status']=='passed' and report['binary_unchanged'] is True and
                report['total_pairs']==report['expected_total_pairs']==len(expected) and len(ids)==len(set(ids)) and
                set(ids)==expected,'wrong report identities')
        require(proof['pgo_enabled'] is True and proof['same_compiler_and_training'] is True and
                proof['source_commit']==revision and proof['feature']==feature,'PGO feature/source proof mismatch')
        require(report['build_context']['sha256']==sha(root/f'{feature}-build-context.json'),'context hash mismatch')
        for side in SIDES:require(report['binaries'][side]['sha256']==proof['binaries'][side]['sha256'],'binary SHA mismatch')
        result['reports'][filename]={'sha256':sha(path),'pairs':len(ids),'build_context_sha256':sha(root/f'{feature}-build-context.json'),
                                   'binaries':report['binaries'],'baseline_flags':proof['baseline_flags'],
                                   'candidate_flags':proof['candidate_flags'],'environment':report['environment']}
        grouped={case:[] for case in cases}
        for raw in report['pairs']:
            require(raw['all_responses_identical'] is True and
                    re.fullmatch('[0-9a-f]{64}',raw['baseline']['response_sha256']) and
                    raw['baseline']['response_sha256']==raw['candidate']['response_sha256'],'response proof mismatch')
            reads=16 if raw['scenario'].endswith('q16') else 1
            require(raw['reads_per_write']==reads and raw['mutation_count']==4,'wrong read/write count')
            pair={key:raw[key] for key in ('scenario','seed','pair_index','order','workload_sha256')}
            for side in SIDES:
                audit_side(raw[side],reads,raw['rows'],storage)
                pair[side]={'timing_ms':metrics(raw[side]),'resources':resources(raw[side]),
                            'write_cycles':raw[side]['write_cycles'],'response_sha256':raw[side]['response_sha256'],
                            'rebuildable_file_snapshots':{s['phase']:s.get('open_rebuildable_files')
                                                        for s in raw[side]['resource_snapshots']},
                            'stderr':raw[side]['stderr']}
            grouped[raw['scenario']].append(pair)
        for case,pairs in grouped.items():
            result['scenarios'][case]={'pairs':len(pairs),'raw_pairs':pairs,
                                      'timing_ms':summarize_pairs(pairs,'timing_ms'),
                                      'resources':summarize_pairs(pairs,'resources')}
    for prefix in ('spill_low','spill_high','resident_compound'):
        result['comparisons'][prefix]={q:{metric:result['scenarios'][prefix+'_'+q]['timing_ms'][metric]
                                         for metric in ('all_cycles','all_cycle_first_query','all_cycle_write_and_commit',
                                                        'measured_lifecycle','restart_plus_first_query')}
                                       for q in ('q1','q16')}
    args.output.write_text(json.dumps(result,indent=2,allow_nan=False)+'\n',encoding='utf-8')
    compact={case:{name:{'B_ms':values['baseline']['median'],'C_ms':values['candidate']['median'],
                         'B_over_C':values.get('baseline_over_candidate'),'candidate_larger_pairs':values['candidate_larger_pairs']}
                   for name,values in item['timing_ms'].items() if name in
                   ('initial_index_plus_first_query','all_cycle_write_and_commit','all_cycle_first_query','all_cycle_query',
                    'all_cycles','measured_lifecycle','restart_plus_first_query','mean_warm_query')}
             for case,item in result['scenarios'].items()}
    print(json.dumps(compact,indent=2))

if __name__=='__main__':main()
