UNEXECUTED DRAFTS. No production switch was changed.
CI is disabled externally. Static checks are not Linux build/performance results.
Choose only one feature patch, and apply the final-performance patch together after measurement.
