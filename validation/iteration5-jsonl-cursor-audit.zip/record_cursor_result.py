"""Archive verified cursor rejection and preserve actual user attribution."""
import hashlib
import io
import json
from pathlib import Path
import zipfile

W=Path(__file__).resolve().parent
R=W/'seekdb'
def sha(b):return hashlib.sha256(b).hexdigest()
def enc(v):return (json.dumps(v,ensure_ascii=False,separators=(',',':'),allow_nan=False)+'\n').encode()
old=(R/'conversation.json').read_bytes()
assert old==(R/'agent/conversation.json').read_bytes()
assert sha(old)=='846bd22e1a9597cb3caec8c432bf95cc25a02bd1ea0529df50ea8b2d52c355c8'
raw=(W/'performance/jsonl-cursor-ba45b12.zip').read_bytes()
assert len(raw)==3009625 and sha(raw)=='764dbcf3b0d900807defaf1686a99a6f2c34a522bcbc2bb0272bce1abd1a6bf1'
analysis=(W/'jsonl-cursor-independent-analysis.json').read_bytes()
assert sha(analysis)=='d36b43d0bacd69619dc1e16f19995195c433079ab268505dea2ff9a22b8e600a'
a=json.loads(analysis)
assert a['status']=='verified' and a['verified_pairs']==20 and len(a['root_gates'])==19
assert a['cursor_framing_gate']['actual_cases']==16
decision=(W/'jsonl-cursor-compact-decision.json').read_bytes()
assert sha(decision)=='84ae19dfa29a378284d2dd94e3b22ed9b1e5bb530844cb5d6083cf9e1719ae10'
names=[
 'analyze_cursor_root.py','analyze_crc_root.py','analyze_highest_compare.py',
 'analyze_insert_copy_root.py','analyze_insert_thread_control.py',
 'jsonl-cursor-independent-analysis.json','jsonl-cursor-decision.json',
 'jsonl-cursor-compact-decision.json','summarize_cursor_decision.py',
 'cursor-root-reader-preflight.json','cursor-root-reader-git-preflight.json',
 'jsonl-cursor-rollback-proof.json','jsonl-cursor-screen-plan.json',
 'record_cursor_result.py']
files={name:(W/name).read_bytes() for name in names}
assert sha(files['analyze_cursor_root.py'])=='31769d06a4a99937cd16abd45108cbe90af4f4ab3e5850aecdb675313bf11c1e'
assert sha(files['cursor-root-reader-preflight.json'])=='ca1e4e3bf8db02c6f06f848021324dd1064c34a0b27ebd853ed2202cc7c3e4ec'
manifest={'kind':'verified_cursor_screen_rejection_and_exact_Git_rollback',
 'source_commit':'ba45b120040cc782498d5f0871a24769e126e93f','run_id':43478055792,
 'job_id':132067025729,'artifact_id':14063653866,'raw_sha256':sha(raw),'raw_bytes':len(raw),
 'files':{name:{'bytes':len(b),'sha256':sha(b)} for name,b in files.items()},
 'scope':'20 actual pairs, 19 root gates, 16 actual framing checks. Reader schema correction is disclosed; no raw evidence changed. No formal submission or score prediction.'}
stream=io.BytesIO()
with zipfile.ZipFile(stream,'w',compression=zipfile.ZIP_DEFLATED,compresslevel=9) as z:
 for name,b in sorted({**files,'manifest.json':enc(manifest)}.items()):
  info=zipfile.ZipInfo(name,(2026,11,14,0,0,0));info.external_attr=0o100644<<16
  z.writestr(info,b,compress_type=zipfile.ZIP_DEFLATED,compresslevel=9)
audit=stream.getvalue()
m=json.loads(old);e=m['experiments'][53]
assert e['id']=='jsonl-newline-cursor-root-screen' and e['status']=='planned_unmeasured'
e.update(status='measured_rejected_retained_runtime_restored',new_pgo_builds_executed=1,database_pairs_executed=20,
 source_commit=manifest['source_commit'],result_message='assistant-jsonl-cursor-result',
 root_gate_groups=19,actual_framing_checks=16,protection_trigger_entries=21,
 artifacts=[{'path':'validation/iteration5-jsonl-cursor-raw.zip','sha256':sha(raw)},
            {'path':'validation/iteration5-jsonl-cursor-audit.zip','sha256':sha(audit)}])
m['messages'].append({'id':'assistant-jsonl-cursor-result','role':'assistant','content':
 'assistant实测：新根PGO1次，19组门禁、16项实际分帧及20对通过；通过不等于性能采用。默认1CPU写入/首周期一好一坏，无稳定收益。2CPU写入两对多14.41/149.08ms，分别占基线首周期2.96%/25.22%；30k查询多22.73/21.24ms且查询CPU同增，触发原保护标准。部分CPU改善仍保留；共141负面阶段、72资源/组合项、21门槛触发项（派生重叠不能加总），无双顺序峰值内存>5%。回退main，28项提交构建输入与R逐Git字节相同，保留测试/原候选；不再追测、不推荐本轮新正式提交。ordinary20未记录effective环境快照，读者按Git schema窄修，原始证据未改。仍未证明E≥3014.419039或6000。'})
before=json.loads(old)
assert m['messages'][:131]==before['messages']
assert [x for x in m['messages'] if x['role']=='user']==[x for x in before['messages'] if x['role']=='user']
assert m['selected_runtime']==before['selected_runtime'] and m['official_result']==before['official_result']
result=enc(m);assert len(result)<=131072
for path,b in [('validation/iteration5-jsonl-cursor-raw.zip',raw),('validation/iteration5-jsonl-cursor-audit.zip',audit)]:
 target=R/path;assert not target.exists();target.write_bytes(b)
for path in ('conversation.json','agent/conversation.json'):(R/path).write_bytes(result)
receipt={'status':'recorded','material_bytes':len(result),'material_sha256':sha(result),'remaining_bytes':131072-len(result),
 'audit_bytes':len(audit),'audit_sha256':sha(audit),'messages':len(m['messages']),'users':45,
 'runtime_adopted':False,'formal_submissions':0}
(W/'jsonl-cursor-record-receipt.json').write_bytes(enc(receipt))
print(json.dumps(receipt))
