"""Cursor root20 actual absolute costs and unchanged preregistered screen."""
import json,math
from pathlib import Path
from statistics import median
import analyze_crc_root as c
import analyze_highest_compare as h
w=Path(__file__).resolve().parent
root=w/'performance/jsonl-cursor-ba45b12'
analysis=w/'jsonl-cursor-independent-analysis.json'
a=c.read(analysis);assert a['status']=='verified' and a['verified_pairs']==20

def cpu_for_phase(run,phase):
    snapshots={x['phase']:x for x in run['adapter']['phase_cgroups']}
    if phase.startswith('query/'):
        name=phase.split('/',1)[1];left,right=name+'/before',name+'/after'
    elif phase=='query_before_update':left,right='after_index_build',phase
    elif phase=='query_after_restart':left,right='after_restart',phase
    else:return None
    if left not in snapshots or right not in snapshots:return None
    return (c.counters(snapshots[right]['cpu.stat'])['usage_usec']-c.counters(snapshots[left]['cpu.stat'])['usage_usec'])/1000

def metrics(run):
    result=h.combined_metrics(run)|h.resource_metrics(run)
    result['first_cycle_stage_sum_ms']=result['first_lifetime_no_restart']*1000
    result['first_queries_wall_ms']=result['first_lifetime_query_total']*1000
    result['whole_cgroup_cpu_ms']=result['whole_cgroup_cpu_usec']/1000
    result['whole_cgroup_peak_mib']=result['whole_cgroup_memory_peak_bytes']/(1024**2)
    if 'phase_seconds' in run:
        result['ingest_wall_ms']=run['phase_seconds']['ingest']*1000
        result['restart_query_wall_ms']=run['phase_seconds']['query_after_restart']*1000
        snapshots={x['phase']:x for x in run['adapter']['phase_cgroups']}
        initial=c.counters(run['cgroup']['before']['cpu.stat'])['usage_usec']
        if 'after_ingest' in snapshots:
            result['startup_create_ingest_CPU_ms']=(c.counters(snapshots['after_ingest']['cpu.stat'])['usage_usec']-initial)/1000
        if 'before_shutdown' in snapshots:
            result['first_cycle_CPU_to_before_shutdown_ms']=(c.counters(snapshots['before_shutdown']['cpu.stat'])['usage_usec']-initial)/1000
        for phase,key in [('query_before_update','first_queries_CPU_ms'),('query_after_restart','restart_query_and_verification_CPU_ms')]:
            value=cpu_for_phase(run,phase)
            if value is not None:result[key]=value
    return result

def summarize(rows):
    keys=rows[0]['baseline'].keys();out={}
    for key in keys:
        pairs=[{'pair_index':r['pair_index'],'order':r['order'],'baseline':r['baseline'][key],'candidate':r['candidate'][key]} for r in rows]
        for p in pairs:
            p['candidate_minus_baseline']=p['candidate']-p['baseline'];p['candidate_larger']=p['candidate']>p['baseline']
            p['candidate_over_baseline']=p['candidate']/p['baseline'] if p['baseline'] else None
        ratios=[p['candidate_over_baseline'] for p in pairs]
        out[key]={'candidate_over_baseline_median':median(ratios) if all(v is not None for v in ratios) else None,
                  'candidate_larger_pairs':sum(p['candidate_larger'] for p in pairs),'raw_pairs':pairs}
    return out

groups={};guards=[];negative=[];memory_guards=[]
for count in (1,2):
    data=c.read(root/f'small-compute-root/measurements-{count}cpu.json')
    for scenario in dict.fromkeys(p['scenario'] for p in data['pairs']):
        pairs=[p for p in data['pairs'] if p['scenario']==scenario];assert len(pairs)==2
        derived=summarize([{'pair_index':p['pair_index'],'order':p['order'],'baseline':metrics(p['baseline']),'candidate':metrics(p['candidate'])} for p in pairs])
        groups[f'{count}cpu/{scenario}']=derived
        all_phases={k for p in pairs for k in c.timings(p['baseline'])}
        # The first-cycle and restart-inclusive stage sums supplement original
        # phases. They never replace or erase any original negative entry.
        all_phases|={k for k in c.lifecycle_timings(pairs[0]['baseline'])}
        for phase in sorted(all_phases):
            rows=[]
            for pair in pairs:
                b,n=pair['baseline'],pair['candidate']
                bv=(c.timings(b)|c.lifecycle_timings(b))[phase]
                nv=(c.timings(n)|c.lifecycle_timings(n))[phase]
                life=c.lifecycle_timings(b)
                row={'pair_index':pair['pair_index'],'order':pair['order'],'baseline_ms':bv*1000,'candidate_ms':nv*1000,
                     'candidate_minus_baseline_ms':(nv-bv)*1000,'candidate_over_baseline':nv/bv,
                     'baseline_first_cycle_stage_sum_ms':life['first_lifetime_no_restart']*1000,
                     'baseline_restart_inclusive_stage_sum_ms':life.get('restart_inclusive_with_verification',life['first_lifetime_no_restart'])*1000,
                     'delta_as_fraction_of_baseline_first_cycle':(nv-bv)/life['first_lifetime_no_restart'],
                     'phase_as_fraction_of_baseline_first_cycle':bv/life['first_lifetime_no_restart'],
                     'baseline_phase_CPU_ms':cpu_for_phase(b,phase),'candidate_phase_CPU_ms':cpu_for_phase(n,phase),
                     'baseline_whole_cgroup_CPU_ms':b['cgroup']['resource_delta']['cpu_stat_delta']['usage_usec']/1000,
                     'candidate_whole_cgroup_CPU_ms':n['cgroup']['resource_delta']['cpu_stat_delta']['usage_usec']/1000}
                rows.append(row)
            item={'cpu_count':count,'scenario':scenario,'phase':phase,'dedicated_protection_plan':count==2,
                  'candidate_over_baseline_median':median(r['candidate_over_baseline'] for r in rows),
                  'candidate_slower_pairs':sum(r['candidate_over_baseline']>1 for r in rows),'raw_pairs':rows}
            if item['candidate_slower_pairs']:negative.append(item)
            if all(r['candidate_over_baseline']>1.02 for r in rows):guards.append(item)
        mem=derived['whole_cgroup_memory_peak_bytes']
        if all(p['candidate_over_baseline']>1.05 for p in mem['raw_pairs']):memory_guards.append({'cpu_count':count,'scenario':scenario,**mem})

result={'status':'derived_from_verified_actual_root20','decision':'revert_cursor_runtime_keep_R_preserve_tests_and_evidence',
 'reason':'No consistent meaningful default ingest/lifecycle benefit; original protection screen is triggered by nontrivial stages. No extra confirmation is justified by this screen alone.',
 'commit':a['source_commit'],'run_id':43478055792,'job_id':132067025729,'artifact_id':14063653866,
 'raw_sha256':a['artifact_sha256'],'analysis_sha256':c.sha(analysis),'candidate_binary_sha256':a['candidate_binary_sha256'],
 'candidate_image_id':a['candidate_image_id'],'baseline_binary_sha256':a['baseline_binary_sha256'],
 'verified_pairs':20,'root_gate_groups':len(a['root_gates']),'cursor_actual_cases':a['cursor_framing_gate']['actual_cases'],
 'groups':groups,'all_negative_timing_entries_with_absolute_impact':negative,
 'screen':{'rule_source':'jsonl-cursor-screen-plan.json','rule_source_sha256':c.sha(w/'jsonl-cursor-screen-plan.json'),
           'rule':'Any protection stage >2% slower in both orders, or >5% peak-memory increase in both orders, blocks default adoption pending specific explanation or independent confirmation.',
           'stage_over_2pct_both_orders':guards,'peak_memory_over_5pct_both_orders':memory_guards,
           'dedicated_two_cpu_protection_triggered':any(x['dedicated_protection_plan'] for x in guards) or any(x['cpu_count']==2 for x in memory_guards),
           'other_one_cpu_two_order_triggers_retained':sum(x['cpu_count']==1 for x in guards)},
 'limitations':[
  'Every original negative phase remains. Derived first-cycle sums overlap component phases; do not add these entries together.',
  'Absolute impact fractions use the retained first-cycle stage sum as a common reference. Restart-stage amounts are not component shares of that first cycle; a separate restart-inclusive denominator is provided.',
  'Only whole-query or wide-projection interval CPU is available. CPU null for an individual RPC or sub-slice means unmeasured; whole-cgroup CPU is shown separately and must not be substituted.',
  'Normal20 has no before_ingest snapshot. startup_create_ingest_CPU_ms includes startup/create work; it is not pure ingest CPU.',
  'The default ingest wall spread is large while whole-CPU/device bytes can be steadier. This suggests waiting/scheduling may contribute but does not prove a cause or erase the measured wall regression.',
  'Two AB/BA pairs per group are a screen, not statistical certainty. No averaging of different scenarios, no cross-host causal ratios, no score projection or automatic adoption.',
  'Pure framing model byte reductions and cursor correctness are not measured runtime scan reductions.'
 ]}
target=w/'jsonl-cursor-decision.json';assert not target.exists()
target.write_text(json.dumps(result,ensure_ascii=False,indent=2)+'\n',encoding='utf8')
print(json.dumps({'output':str(target),'bytes':target.stat().st_size,'sha256':c.sha(target),
 'two_cpu_protection_triggered':result['screen']['dedicated_two_cpu_protection_triggered'],
 'stage_triggers':len(guards),'memory_triggers':len(memory_guards),'negative_timing_entries':len(negative)}))
for label,values in groups.items():
 if label.endswith('/standard10k'):
  print(label,{k:(v['candidate_over_baseline_median'],v['candidate_larger_pairs'],[(p['baseline'],p['candidate']) for p in v['raw_pairs']]) for k,v in values.items() if k in
   ('first_cycle_stage_sum_ms','first_queries_wall_ms','ingest_wall_ms','whole_cgroup_cpu_ms','whole_cgroup_peak_mib','first_queries_CPU_ms','first_cycle_CPU_to_before_shutdown_ms')})
for x in guards:
 print('GUARD',x['cpu_count'],x['scenario'],x['phase'],[(round(r['baseline_ms'],6),round(r['candidate_ms'],6),round(r['candidate_minus_baseline_ms'],6),round(r['delta_as_fraction_of_baseline_first_cycle']*100,4)) for r in x['raw_pairs']])
