import hashlib
import importlib.util
import io
import json
from pathlib import Path
import tempfile
import warnings
import zipfile

work = Path(__file__).resolve().parent
path = work / 'seekdb/minivec/tools/prepare_small_compute.py'
spec = importlib.util.spec_from_file_location('importer', path)
m = importlib.util.module_from_spec(spec); spec.loader.exec_module(m)
checks = []
for name, names, symlink in [
    ('parent_path_rejected', ['../x'], False),
    ('absolute_path_rejected', ['/x'], False),
    ('duplicate_path_rejected', ['x', 'x'], False),
    ('drive_path_rejected', ['C:/x'], False),
    ('symlink_rejected', ['x'], True),
]:
    data = io.BytesIO()
    with warnings.catch_warnings():
        warnings.simplefilter('ignore', UserWarning)
        with zipfile.ZipFile(data, 'w') as z:
            for n in names:
                info = zipfile.ZipInfo(n)
                if symlink: info.external_attr = 0o120777 << 16
                z.writestr(info, b'x')
    data.seek(0)
    with zipfile.ZipFile(data) as z:
        try: m.safe_names(z)
        except ValueError: checks.append(name)
        else: raise AssertionError(name)
with tempfile.TemporaryDirectory(dir=work, prefix='import-negative-') as temp:
    root = Path(temp); archive = root / 'changed.zip'; archive.write_bytes(b'not retained artifact')
    try: m.prepare(work/'seekdb', archive, root/'out')
    except ValueError:
        assert not (root/'out').exists()
        checks.append('changed_archive_rejected_before_output')
    else: raise AssertionError('changed archive accepted')
actual = json.loads((work/'small-compute-import-check/provenance.json').read_bytes())
assert actual['status'] == 'verified' and actual['new_database_tests'] == 0
assert actual['source_commit'] == m.COMMIT and actual['binary_sha256'] == m.BINARY_SHA
assert actual['harness_matches_git'] is False
checks.append('actual_archive_and_git_engine_training_import_no_execution')
out = {'status':'passed', 'checks':checks, 'count':len(checks),
       'scope':'Windows importer checks only; no Linux/cgroup/database measurement.',
       'importer_sha256':hashlib.sha256(path.read_bytes()).hexdigest()}
(work/'small-compute-import-static-validation.json').write_text(json.dumps(out,indent=2)+'\n')
print(json.dumps({'checks':len(checks),'status':'passed'}))
