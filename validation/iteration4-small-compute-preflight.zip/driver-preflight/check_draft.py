"""Controlled Python checks; never launches a DB or writes a real cgroup."""
import copy
import json
import os
from pathlib import Path
import tempfile
from types import SimpleNamespace
from unittest.mock import patch
import small_compute as s

passed = []


def check(name, function):
    function(); passed.append(name)


def rejects(function):
    try: function()
    except (ValueError, KeyError): return
    raise AssertionError('invalid fixture accepted')


check('exact_12_unique_ABBA_pairs', lambda: s.check_plan(s.plan()))
check('missing_pair_rejected', lambda: rejects(lambda: s.check_plan(s.plan()[:-1])))
check('duplicate_pair_rejected', lambda: rejects(lambda: s.check_plan(s.plan()[:-1] + [s.plan()[0]])))
bad = s.plan(); bad[1]['order'] = ['baseline', 'candidate']
check('wrong_order_rejected', lambda: rejects(lambda: s.check_plan(bad)))

with tempfile.TemporaryDirectory() as temporary:
    root = Path(temporary)
    binary = root / 'minivec'; binary.write_bytes(b'controlled fixture only, not executable')
    proof = root / 'proof.json'
    proof.write_text(json.dumps({'status': 'verified', 'commit': 'a' * 40, 'binary': s.sha(binary)}))
    item = {'binary': 'minivec', 'binary_sha256': s.sha(binary), 'source_commit': 'a' * 40,
            'evidence_file': 'proof.json', 'evidence_sha256': s.sha(proof),
            'evidence_binary_pointer': ['binary'], 'evidence_commit_pointer': ['commit']}
    raw = {'baseline': item, 'candidate': copy.deepcopy(item)}
    identities = root / 'identities.json'
    def run_ids(value=raw, allow=False):
        identities.write_text(json.dumps(value)); return s.identities(identities, allow)
    checked = run_ids()
    check('same_binary_default_env', lambda: s.require(checked['baseline']['environment'] == {} and
          checked['candidate']['environment'] == {'MVDB_QUERY_THREADS': '1'}, 'defaults differ'))
    bad = copy.deepcopy(raw); bad['candidate']['binary_sha256'] = '0' * 64
    check('changed_binary_rejected', lambda: rejects(lambda: run_ids(bad)))
    bad = copy.deepcopy(raw); bad['baseline']['evidence_sha256'] = '0' * 64
    check('changed_evidence_rejected', lambda: rejects(lambda: run_ids(bad)))
    bad = copy.deepcopy(raw); bad['baseline']['source_commit'] = 'b' * 40
    check('wrong_source_rejected', lambda: rejects(lambda: run_ids(bad)))
    bad = copy.deepcopy(raw); bad['candidate']['environment'] = {'SECRET_OTHER': 'x'}
    check('unknown_environment_rejected', lambda: rejects(lambda: run_ids(bad)))
    other = root / 'other'; other.write_bytes(b'another controlled binary fixture')
    evidence2 = root / 'proof2.json'; evidence2.write_text(json.dumps({'status': 'verified', 'commit': 'b' * 40, 'binary': s.sha(other)}))
    different = copy.deepcopy(raw)
    different['candidate'].update(binary='other', binary_sha256=s.sha(other), source_commit='b' * 40,
                                  evidence_file='proof2.json', evidence_sha256=s.sha(evidence2))
    check('whole_version_requires_explicit_option', lambda: rejects(lambda: run_ids(different)))
    check('explicit_whole_version_identity_allowed', lambda: run_ids(different, True))

    commands = []
    class FakeLifecycle:
        def __init__(self, *args, command, **kwargs):
            self.command = command; commands.append(command); self.proc = SimpleNamespace(pid=222222)
        def start(self): return 'ready'
    class FakeProjection:
        def __init__(self, command, *args, **kwargs):
            self.command = command; commands.append(command); self.proc = SimpleNamespace(pid=222222)
        def read_json(self, context): return {'type': 'ready'}
    base = SimpleNamespace(Session=FakeLifecycle, process_snapshot=lambda *a: {})
    projection = SimpleNamespace(Session=FakeProjection, exchange=lambda *a, **k: {})
    group = root / 'cg'; group.mkdir(); (group / 'cgroup.procs').write_text('222222')
    prefix = ['/launcher', str(group), '/taskset', '--cpu-list', '3']
    trace = {}; original_read = Path.read_text
    def read(path, *args, **kwargs):
        if str(path).replace('\\', '/') == '/proc/222222/status': return 'Cpus_allowed_list:\t3\n'
        return original_read(path, *args, **kwargs)
    with patch.object(Path, 'read_text', read), patch.object(s.os, 'readlink', return_value=str(binary)):
        with s.command_adapter(base, projection, prefix, binary, group, trace, 3):
            # iteration supplies a prefix; delta and projection do not.
            one = base.Session(command=prefix + [str(binary), '--protocol', 'jsonl'])
            two = base.Session(command=[str(binary), '--protocol', 'jsonl'])
            three = projection.Session([str(binary), '--protocol', 'jsonl'])
            one.start(); one.start(); three.read_json('ready')
            check('double_prefix_rejected', lambda: rejects(lambda: base.Session(command=prefix + prefix + [str(binary)])))
        check('prefix_once_and_restart_identity', lambda: s.require(len(commands) == 3 and
              all(command == prefix + [str(binary), '--protocol', 'jsonl'] for command in commands) and
              len(trace['ready_memberships']) == 3, 'prefix/restart mismatch'))
        check('constructors_restored', lambda: s.require(base.Session is FakeLifecycle and projection.Session is FakeProjection, 'hook leaked'))
        try:
            with s.command_adapter(base, projection, prefix, binary, group, {}, 3): raise RuntimeError('fixture')
        except RuntimeError: pass
        check('exception_restores_hooks', lambda: s.require(base.Session is FakeLifecycle and projection.Session is FakeProjection, 'hook leaked'))

    key = 'MVDB_QUERY_THREADS'; previous = os.environ.get(key); os.environ[key] = '9'
    try:
        try:
            with s.environment({'MVDB_QUERY_THREADS': '1'}):
                s.require(os.environ[key] == '1', 'override absent'); raise RuntimeError('fixture')
        except RuntimeError: pass
        check('environment_restored_after_failure', lambda: s.require(os.environ[key] == '9', 'environment leaked'))
    finally:
        if previous is None: os.environ.pop(key, None)
        else: os.environ[key] = previous

    empty = {'cpu.stat': 'usage_usec 10\nthrottled_usec 3', 'memory.peak': str(2**60 + 3),
             'memory.events': 'oom 0\noom_kill 0', 'io.stat': '8:0 rbytes=2 wbytes=3',
             'cgroup.procs': ''}
    after = dict(empty, **{'cpu.stat': 'usage_usec 31\nthrottled_usec 7', 'memory.events': 'oom 1\noom_kill 1',
                          'io.stat': '8:0 rbytes=4 wbytes=8'})
    delta = s.resource_delta(empty, after)
    check('exact_resource_integer_deltas', lambda: s.require(delta == {
        'cpu_stat_delta': {'usage_usec': 21, 'throttled_usec': 4}, 'memory_peak_bytes': 2**60 + 3,
        'io_stat_delta': {'8:0': {'rbytes': 2, 'wbytes': 5}}}, 'counter arithmetic changed'))
    task = root / '222222'; task.mkdir()
    fields = ['0'] * 50; fields[0] = 'R'; fields[11] = str(2**54); fields[12] = '3'; fields[19] = '42'; fields[36] = '3'
    (task / 'stat').write_text('222222 (name with spaces) ' + ' '.join(fields))
    (task / 'status').write_text('Cpus_allowed_list:\t3\n')
    with patch.object(Path, 'iterdir', return_value=iter([task])), patch.object(s.os, 'sysconf', return_value=100, create=True):
        observed = s.task_snapshot(222222)
    check('task_ticks_starttime_and_affinity', lambda: s.require(observed['native_tasks'] == [{
        'tid': 222222, 'main': True, 'cpu_ticks': 2**54 + 3, 'starttime_ticks': 42,
        'last_processor': 3, 'cpus_allowed_list': '3'}], 'stat field mapping wrong'))
    (group / 'cgroup.procs').write_text('')
    record = {'before': empty, 'timeout': True}
    owner = s.Group(root, SimpleNamespace(), record); owner.path = group
    owner.timer = SimpleNamespace(cancel=lambda: None, join=lambda: None)
    with patch.object(s, 'snapshot', return_value=after), patch.object(s.time, 'sleep'), patch.object(Path, 'rmdir'):
        owner.__exit__(TimeoutError, TimeoutError('fixture timeout'), None)
    check('timeout_and_oom_evidence_survives_failure', lambda: s.require(record['timeout'] and
          record['request_timeout_observed'] and record['oom_events_delta']['oom_kill'] == 1 and
          record['execution_error'].startswith('TimeoutError'), 'failure evidence missing'))

    def run(phases): return {'phases': {k: {'requests': [{'response_sha256': k, 'response_bytes': 1}] * 3} for k in phases}}
    pair = {'scenario': 'wide768', 'baseline': run('abcdefg'), 'candidate': run('abcdefg')}
    check('projection_all_requests_equal', lambda: s.compare(pair))
    pair['candidate']['phases']['a']['requests'][0] = {'response_sha256': 'wrong', 'response_bytes': 1}
    check('projection_mismatched_output_rejected', lambda: rejects(lambda: s.compare(pair)))
    encoding = SimpleNamespace(encoded=lambda value: json.dumps(value, sort_keys=True, separators=(',', ':')).encode())
    work = {'create': 'CREATE', 'inserts': [('INSERT', 2)], 'queries': ['QUERY'], 'update': None, 'updated_rows': 0,
            'before_oracle': {0: [(0, 1)]}, 'after_oracle': {0: [(0, 1)]}, 'oracle_indices': [0], 'query_counts': [1],
            'vectors': [[0.0], [1.0]], 'updated_vector': [2.0], 'rows': 2, 'dimension': 1, 'sha256': 'original-generator-hash'}
    first = s.workload_identity('standard10k', work, encoding)
    work['queries'][0] = 'MUTATED QUERY'
    check('request_mutation_changes_independent_input_hash', lambda: s.require(
        s.workload_identity('standard10k', work, encoding)['sha256'] != first['sha256'], 'static generator hash was trusted'))
    second = s.workload_identity('standard10k', work, encoding)
    work['vectors'][0][0] = 8.0
    check('restart_oracle_mutation_changes_input_hash', lambda: s.require(
        s.workload_identity('standard10k', work, encoding)['sha256'] != second['sha256'], 'restart expectation not bound'))

report = {'status': 'passed', 'checks': passed, 'count': len(passed),
          'scope': 'Pure Python fixtures and mocked constructors/cgroup files. No Linux execution, real process measurement, DB, PGO build or performance result.',
          'source_sha256': {p.name: s.sha(p) for p in [Path(__file__), Path(s.__file__)]}}
Path(__file__).with_name('static-validation.json').write_text(json.dumps(report, indent=2) + '\n', encoding='utf-8')
print(json.dumps({'status': report['status'], 'checks': len(passed)}))
