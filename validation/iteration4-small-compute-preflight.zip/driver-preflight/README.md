# Small compute diagnostic draft

This draft does not edit the repository, launch CI, compile PGO, or claim an official score. The local checks are controlled Python fixtures on Windows; real cgroup operation still needs an ephemeral Linux runner.

The default contrast uses **the same verified executable bytes** twice: A clears the known inherited MiniVectorDB behavior variables and leaves thread selection automatic; B changes only `MVDB_QUERY_THREADS=1`. Parser threads retain their default behavior. Both versions use one-CPU affinity and an aggregate quota of one CPU. The driver and independent oracles keep their original affinity and stay outside the DB cgroup. CPU pinning and quota are separate controls, both recorded and checked. This is an environment diagnostic, not a new optimization or proof that a reconstructed executable matches the unknown official executable bytes.

## Fixed workload and pairing

One seed (`7319`), six workloads, two pairs per workload, order A/B then B/A: **12 pairs / 24 database lifecycles**. Workload generation is reused within a scenario, outside the run cgroup and timers; its hash is checked again afterward.

| Scenario | Fixed workload |
|---|---|
| standard10k | 10,000 × 128, 1,000 alternating unfiltered/filtered queries, restart and 1,000 queries |
| resident30k | 30,000 × 128, 1,000 queries, restart and 1,000 queries |
| filter60k | 60,000 × 16, 1,000 filtered queries, restart and 1,000 queries |
| spill_high_q1 | 5,000 × 128 plus 8,192-byte strings, four one-row write cycles, one read after each write, restart validation |
| spill_high_q16 | Same data and writes, sixteen reads after each write, restart validation |
| wide768 | 1,024 × 768 plus 96-codepoint strings, seven projection phases × three repeats |

The existing query modes and oracles remain intact. Iteration checks all returned TopK lengths and independent first/second/last TopK values, all restarted IDs and sampled vectors. Spill checks every query against its independent exhaustive oracle, actual open spill files, and changed payloads after restart. Projection checks every returned value including BIGINT/UTF8/float32/signed zero. Cross-side aggregate or per-request response hashes are also compared. This draft does not upgrade the iteration oracle into an unimplemented all-1,000-query check.

## Entrypoint

Copying/adapting these files into the repository requires the parent task's final review. The static launcher is an unchanged byte copy of the existing `minivec/tools/cgroup_exec.c`.

```sh
cc -O2 -static cgroup_exec.c -o cgroup_exec
sudo env PYTHONDONTWRITEBYTECODE=1 python3 small_compute.py \
  --tools /absolute/path/to/minivec/tools \
  --identities /absolute/path/to/identities.json \
  --launcher /absolute/path/to/cgroup_exec \
  --output /absolute/path/to/small-compute-results.json
```

The actual command is `cgroup_exec PRIVATE_GROUP /absolute/taskset --cpu-list N ABSOLUTE_DB ...`. `N` defaults to the minimum CPU in the driver's inherited allowed CPU set, or may be supplied with `--db-cpu`. The launcher enters only the DB process into the private cgroup and execs taskset, which execs the declared DB. Each initial/restart ready check verifies `/proc/PID/exe`, cgroup membership, and `Cpus_allowed_list`. No driver affinity change is made. The instrumentation adds these evidence reads to the startup interval; individual request timers retain their original boundaries.

The runner needs delegated cgroup-v2 CPU/memory/IO controllers and `cgroup.kill`, and `taskset` must exist. Unavailable controllers/metrics fail the run; there is no unreported fallback. The harness creates and removes only its unique `/sys/fs/cgroup/minivec-report-*/case-*` directories. It does not reconfigure unrelated groups.

`--cpu-quota-us` and `--cpu-period-us` default to `100000/100000`. **No memory or swap cap is invented:** missing `--memory-max` / `--swap-max` means the tool does not write those controls. Actual values and ancestor constraints are recorded, so inherited caps are not described as unlimited. Explicit caps accept bytes or `max`. Official limits must be separately verified; a demonstration value is not evidence of the official envelope.

Every case records `cpu.stat`, peak/current memory, OOM events and IO counters before/at phases/after process exit, including exceptions. Per-phase `/proc/PID/task` snapshots retain TID, start time, CPU ticks and affinity, and stderr fanout decisions are preserved. Nonmain CPU can include parser work; it is not exclusively query-worker CPU. Exact integer deltas preserve counters above 2^53. The whole-case watchdog kills only its owned DB cgroup on deadline. Protocol timeout, case timeout, OOM, wrong process/affinity, response mismatch or leftover processes cannot produce `passed`. Partial sides, completed transport counts, stderr and resource evidence are saved. The inherited iteration runner does not expose every partial phase timer on an exception; the report says so rather than inventing missing timings. IO stability after exit is bounded and is not proof of official writeback/device accounting.

## Explicit executable identities

`identities.json` contains exactly `baseline` and `candidate`. Relative paths resolve against this JSON's directory. Each record has:

```json
{
  "binary": "imported-baseline/minivec",
  "binary_sha256": "FULL_SHA256",
  "source_commit": "FULL_40_HEX_COMMIT",
  "evidence_file": "provenance.json",
  "evidence_sha256": "FULL_SHA256",
  "evidence_binary_pointer": ["binary_sha256"],
  "evidence_commit_pointer": ["source_commit"],
  "environment": {}
}
```

The candidate default environment is `{"MVDB_QUERY_THREADS":"1"}`; the baseline default is `{}`. Both environments are explicitly saved. The evidence JSON must have `status: "verified"`, and the supplied pointer paths must resolve to the exact executable SHA and source commit. The importer is responsible for performing and retaining that provenance audit; this harness checks the resulting evidence digest and pointers and hashes the actual program before/after each run. It does not pretend to rebuild or independently repeat the importer’s full Git/PGO audit. The default refuses different executable bytes or source declarations. `--allow-version-contrast` explicitly labels a whole-version comparison without assuming only one macro differs.

The current intended control is reconstructed submitted-source `e020fdeb67dd8b64b77f0f8c2905f137f0112bba`, binary `acddca115ab183bfc6419e27c9e3383cfd1a9046e3897e5ea516cd7bc0f29f54`. This identification comes from retained build evidence, **not an official binary hash**. The provenance importer must confirm it before execution.

`--plan-only` creates the 12 identities without starting a process. `check_draft.py` tests the plan and negative identities, prefix-once/restart hooks, cleanup restoration, counter precision, failure evidence and mismatched responses. `static-validation.json` is strictly local fixture evidence. Two pairs at one seed are an economical diagnostic screen, not a confidence claim or grounds for automatic adoption.
