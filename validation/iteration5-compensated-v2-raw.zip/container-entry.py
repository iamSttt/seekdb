import json,os,platform,subprocess,sys
from pathlib import Path
out=Path('/out');requested=int((out/'requested-cpu.txt').read_text())
record={'status':'checking','database_runs':0,'pgo_builds':0,'native_started':False}
def save():(out/'resource-preflight.json').write_text(json.dumps(record,indent=2)+'\n')
save()
try:
    assert platform.system()=='Linux' and platform.machine()=='x86_64','unsupported platform'
    observed={}
    for name,path in {'proc-status':'/proc/self/status','proc-cgroup':'/proc/self/cgroup','cpu-max':'/sys/fs/cgroup/cpu.max','memory-max':'/sys/fs/cgroup/memory.max','memory-swap-max':'/sys/fs/cgroup/memory.swap.max'}.items():
        value=Path(path).read_text();(out/('preflight-'+name+'.txt')).write_text(value);observed[name]=value.strip()
    record['observed']=observed;record['affinity']=sorted(os.sched_getaffinity(0));save()
    quota,period=map(int,observed['cpu-max'].split())
    assert quota==period and period>0,'actual quota must be one CPU'
    assert record['affinity']==[requested],'actual affinity differs'
    assert observed['memory-max']=='2147483648' and observed['memory-swap-max']=='0','actual memory/swap cap differs'
    version=subprocess.run(['g++','-dumpfullversion'],text=True,stdout=subprocess.PIPE,stderr=subprocess.STDOUT,check=True)
    (out/'preflight-compiler-version.txt').write_text(version.stdout)
    assert version.stdout.strip()=='13.3.0','fixed compiler unavailable'
    record.update(status='verified',native_started=False);save()
except Exception as exc:
    record.update(status='failed_before_runner',error=str(exc));save();raise
# The runner owns native attempted/completed counts, including partial failures.
result=subprocess.run([sys.executable,'/prototype/run_linux.py','--output','/out/results'])
(out/'runner-exit.json').write_text(json.dumps({'exit_code':result.returncode,'database_runs':0,'pgo_builds':0})+'\n')
if result.returncode==0:
    with (out/'micro-disassembly.txt').open('w') as disassembly:
        asm=subprocess.run(['objdump','-d','-C','/out/results/micro'],stdout=disassembly,stderr=subprocess.STDOUT)
    (out/'micro-disassembly-status.json').write_text(json.dumps({'exit_code':asm.returncode,'timed':False})+'\n')
    if asm.returncode!=0:raise RuntimeError('actual micro disassembly unavailable')
post={'status':'checking','runner_exit_code':result.returncode}
try:
    post.update({name:Path('/sys/fs/cgroup/'+name).read_text().strip() for name in ('cpu.max','memory.max','memory.swap.max')})
    post['affinity']=sorted(os.sched_getaffinity(0))
    quota,period=map(int,post['cpu.max'].split())
    assert quota==period and period>0 and post['affinity']==[requested],'post-run CPU quota/affinity differs'
    assert post['memory.max']=='2147483648' and post['memory.swap.max']=='0','post-run memory/swap cap differs'
    post['status']='verified'
except Exception as exc:
    post.update(status='failed',error=str(exc))
finally:
    (out/'resource-postflight.json').write_text(json.dumps(post,indent=2)+'\n')
if result.returncode==0 and post['status']!='verified':raise RuntimeError('post-run resource verification failed')
sys.exit(result.returncode)
