#include "cost_diagnostic.h"
#pragma once
#include "distance.h"
#include "quantized_scale.h"
#include <memory>
#include <algorithm>
#include <vector>

namespace mvdb {
namespace quantized_detail {
inline bool normal_fp_environment() {
#if defined(__FAST_MATH__)
  return false;
#elif defined(MVDB_SIMD_BOUND_X86)
  return (_mm_getcsr() & ((1u<<6)|(1u<<15)|(3u<<13)))==0;
#else
  // No portable C++ query for flush-to-zero controls. Preserve exactness by
  // disabling this optional acceleration on unverified floating environments.
  return false;
#endif
}
inline bool power_of_two(double step) {
  if(!(step>0) || !std::isfinite(step))return false;
  uint64_t bits;std::memcpy(&bits,&step,sizeof(bits));
  const uint64_t fraction=bits&0x000fffffffffffffull;
  return (bits>>52) ? fraction==0 : (fraction && !(fraction&(fraction-1)));
}
inline bool encode(float value,double step,int8_t* out) {
  if(!out || !std::isfinite(value))return false;
  const double scaled=static_cast<double>(value)/step;
  if(!std::isfinite(scaled) || scaled < -127 || scaled > 127)return false;
  // Binary32 scaled by a power of two retains its significand. Around a half
  // integer the addition is exact in double; tiny values still encode as zero.
  // Truncation therefore rounds nearest with half ties away from zero.
  const int code=static_cast<int>(scaled+(scaled>=0 ? 0.5 : -0.5));
  *out=static_cast<int8_t>(code);
  return true;
}
inline uint32_t distance_scalar(const int8_t* a,const int8_t* b,size_t n) {
  uint32_t sum=0;
  for(size_t i=0;i<n;++i){const int d=int(a[i])-int(b[i]);sum+=static_cast<uint32_t>(d*d);}
  return sum;
}
#if defined(MVDB_SIMD_BOUND_X86)
__attribute__((target("sse2,no-avx,no-fma")))
inline uint32_t distance_sse2(const int8_t* a,const int8_t* b,size_t n) {
  const __m128i zero=_mm_setzero_si128();
  __m128i sums=zero;size_t i=0;
  for(;i+16<=n;i+=16){
    const __m128i x=_mm_loadu_si128(reinterpret_cast<const __m128i*>(a+i));
    const __m128i y=_mm_loadu_si128(reinterpret_cast<const __m128i*>(b+i));
    const __m128i xs=_mm_cmpgt_epi8(zero,x),ys=_mm_cmpgt_epi8(zero,y);
    const __m128i lo=_mm_sub_epi16(_mm_unpacklo_epi8(x,xs),_mm_unpacklo_epi8(y,ys));
    const __m128i hi=_mm_sub_epi16(_mm_unpackhi_epi8(x,xs),_mm_unpackhi_epi8(y,ys));
    sums=_mm_add_epi32(sums,_mm_madd_epi16(lo,lo));
    sums=_mm_add_epi32(sums,_mm_madd_epi16(hi,hi));
  }
  // Each lane is below 2^31 for n<=65536. Horizontal additions are unsigned
  // modulo 2^32; the final full sum is below 2^32 even for int8 endpoints.
  sums=_mm_add_epi32(sums,_mm_srli_si128(sums,8));
  sums=_mm_add_epi32(sums,_mm_srli_si128(sums,4));
  uint32_t result=static_cast<uint32_t>(_mm_cvtsi128_si32(sums));
  for(;i<n;++i){const int d=int(a[i])-int(b[i]);result+=static_cast<uint32_t>(d*d);}
  return result;
}
__attribute__((target("avx2,no-fma")))
inline uint32_t distance_avx2(const int8_t* a,const int8_t* b,size_t n) {
  __m256i sums=_mm256_setzero_si256();size_t i=0;
  for(;i+16<=n;i+=16){
    const __m256i x=_mm256_cvtepi8_epi16(_mm_loadu_si128(reinterpret_cast<const __m128i*>(a+i)));
    const __m256i y=_mm256_cvtepi8_epi16(_mm_loadu_si128(reinterpret_cast<const __m128i*>(b+i)));
    const __m256i d=_mm256_sub_epi16(x,y);
    sums=_mm256_add_epi32(sums,_mm256_madd_epi16(d,d));
  }
  __m128i total=_mm_add_epi32(_mm256_castsi256_si128(sums),_mm256_extracti128_si256(sums,1));
  total=_mm_add_epi32(total,_mm_srli_si128(total,8));
  total=_mm_add_epi32(total,_mm_srli_si128(total,4));
  uint32_t result=static_cast<uint32_t>(_mm_cvtsi128_si32(total));
  for(;i<n;++i){const int d=int(a[i])-int(b[i]);result+=static_cast<uint32_t>(d*d);}
  return result;
}
#if !defined(MVDB_DISABLE_AVX512_QUANTIZED)
__attribute__((target("avx512f,avx512bw,no-fma")))
inline uint32_t distance_avx512(const int8_t* a,const int8_t* b,size_t n) {
  if(n<32)return distance_avx2(a,b,n);
  __m512i sums=_mm512_setzero_si512();size_t i=0;
  for(;i+32<=n;i+=32){
    const __m512i x=_mm512_cvtepi8_epi16(_mm256_loadu_si256(reinterpret_cast<const __m256i*>(a+i)));
    const __m512i y=_mm512_cvtepi8_epi16(_mm256_loadu_si256(reinterpret_cast<const __m256i*>(b+i)));
    const __m512i d=_mm512_sub_epi16(x,y);
    sums=_mm512_add_epi32(sums,_mm512_madd_epi16(d,d));
  }
  // Each lane is <= (65536/16)*255^2 < 2^31. Reduce with hardware
  // modulo additions, preserving the exact unsigned full sum below 2^32.
  const __m256i halves=_mm256_add_epi32(_mm512_castsi512_si256(sums),_mm512_extracti64x4_epi64(sums,1));
  __m128i total=_mm_add_epi32(_mm256_castsi256_si128(halves),_mm256_extracti128_si256(halves,1));
  total=_mm_add_epi32(total,_mm_srli_si128(total,8));
  total=_mm_add_epi32(total,_mm_srli_si128(total,4));
  uint32_t result=static_cast<uint32_t>(_mm_cvtsi128_si32(total));
  for(;i<n;++i){const int d=int(a[i])-int(b[i]);result+=static_cast<uint32_t>(d*d);}
  return result;
}
#endif
#endif
using Distance = uint32_t(*)(const int8_t*,const int8_t*,size_t);
inline Distance choose_distance() {
#if defined(MVDB_SIMD_BOUND_X86)
#if !defined(MVDB_DISABLE_AVX512_QUANTIZED)
  if(__builtin_cpu_supports("avx512f") && __builtin_cpu_supports("avx512bw") &&
     __builtin_cpu_supports("avx2"))return distance_avx512;
#endif
  if(__builtin_cpu_supports("avx2"))return distance_avx2;
  if(__builtin_cpu_supports("sse2"))return distance_sse2;
#endif
  return distance_scalar;
}
inline double up(double x) {
  return std::isfinite(x) ? distance_detail::positive_neighbors(x).upper : x;
}
} // namespace quantized_detail

// Zero signals unavailable/invalid input; zero-valued data uses unit step.
inline double quantization_step(double max_abs) {
  if(!quantized_detail::normal_fp_environment() ||
     !std::isfinite(max_abs) || max_abs<0)return 0;
  if(max_abs==0)return 1;
  int exponent=0;std::frexp(max_abs,&exponent);
  double step=std::ldexp(1.0,exponent-7);
  if(!(step>0) || !std::isfinite(step))return 0;
  // This division is exact and avoids overflow of 127*step for large inputs.
  if(max_abs/step>127)step*=2;
  return quantized_detail::power_of_two(step) ? step : 0;
}
inline bool quantize_coordinate(float value,double step,int8_t* out) {
  return quantized_detail::normal_fp_environment() &&
         quantized_detail::power_of_two(step) &&
         quantized_detail::encode(value,step,out);
}

// Exact integer distance for n<=65536. Invalid length returns conservative zero.
inline uint32_t quantized_distance_squared(const int8_t* a,const int8_t* b,size_t n) {
  if(n>65536 || (!a && n) || (!b && n))return 0;
  static const auto fn=quantized_detail::choose_distance();
  return fn(a,b,n);
}

// The encoded row must use this same step and be produced by quantize_coordinate.
// Query-scoped: FP controls remain unchanged for its lifetime. Threshold cache
// is mutable and this object must not be shared between concurrent threads.
class QuantizedQueryBound {
 public:
  QuantizedQueryBound(const float* query,size_t n,double step):n_(n) {
    initialize(query,n,step,nullptr);
  }
  QuantizedQueryBound(const float* query,size_t n,double step,const QuantizedScaleView& scales)
      :QuantizedQueryBound(query,n,scales.present() ? 0 : step) {
#if defined(MVDB_ENABLE_BLOCK_QUANT_SCALE) && !defined(MVDB_DISABLE_QUANTIZED_BOUND)
    if(!scales.present())return;
    local_=true;scales_=scales;
    const size_t bytes=scale_cache_bytes(n,scales.step_count);
    if(!bytes || bytes>QuantizedScaleView::query_cache_limit ||
       bytes>scales.query_cache_bytes || !scales.steps || !scales.row_count ||
       scales.block_count!=(scales.row_count-1)/QuantizedScaleView::block_rows+1)return;
    // Exact-size arrays avoid unaccounted vector growth. The parent index has
    // reserved this whole peak for each of two independent query workers.
    scale_bounds_.reset(new(std::nothrow) QuantizedQueryBound[scales.step_count]);
    if(!scale_bounds_)return;
    scale_codes_.reset(new(std::nothrow) int8_t[n*scales.step_count]);
    if(!scale_codes_) {scale_bounds_.reset();return;}
    for(size_t s=0;s<scales.step_count;++s) {
      auto& bound=scale_bounds_[s];bound.n_=n;
      bound.initialize(query,n,scales.steps[s],scale_codes_.get()+s*n);
      enabled_=enabled_ || bound.enabled();
    }
#else
    (void)scales;
#endif
  }
  static size_t scale_cache_bytes(size_t n,size_t steps) {
    if(n<16 || n>65536 || steps<2 || steps>QuantizedScaleView::max_steps)return 0;
    return sizeof(QuantizedQueryBound)*(steps+1)+n*steps;
  }
  bool definitely_greater(const int8_t* row,double threshold,size_t ordinal) const {
#if defined(MVDB_ENABLE_BLOCK_QUANT_SCALE) && !defined(MVDB_DISABLE_QUANTIZED_BOUND)
    if(local_) {
      if(!enabled_ || !scale_bounds_ || ordinal>=scales_.row_count)return false;
      const size_t block=ordinal/QuantizedScaleView::block_rows;
      if(block>=scales_.block_count)return false;
      const size_t id=scales_.block_ids[block];
      return id<scales_.step_count && scale_bounds_[id].definitely_greater(row,threshold);
    }
#else
    (void)ordinal;
#endif
    return definitely_greater(row,threshold);
  }
 private:
  QuantizedQueryBound()=default;
  void initialize(const float* query,size_t n,double step,int8_t* supplied) {
#if !defined(MVDB_DISABLE_QUANTIZED_BOUND)
    if(!query || n<16 || n>65536 || !quantized_detail::normal_fp_environment() ||
       !quantized_detail::power_of_two(step))return;
    step_squared_=step*step;
    if(!(step_squared_>0) || !std::isfinite(step_squared_))return;
    if(!supplied) {
      try {query_.resize(n);} catch(const std::bad_alloc&) {return;}
      supplied=query_.data();
    }
    query_data_=supplied;
    for(size_t i=0;i<n;++i) {
      if(!quantized_detail::encode(query[i],step,&supplied[i])) {
        std::vector<int8_t>().swap(query_);return;
      }
    }
    root_n_=quantized_detail::up(std::sqrt(static_cast<double>(n)));
    kernel_=quantized_detail::choose_distance();
    enabled_=true;
#else
    (void)query;(void)n;(void)step;(void)supplied;
#endif
  }
 public:
  bool enabled() const {return enabled_;}
  const std::vector<int8_t>& coded_query() const {return query_;}
#if defined(MVDB_ENABLE_BLOCK_QUANT_SCALE) && defined(MVDB_BLOCK_SCALE_SELECTIVE)
  bool local_scales() const {return local_;}
#endif
  bool definitely_greater(const int8_t* row,double threshold) const {
#ifdef MVDB_ENABLE_BLOCK_QUANT_SCALE
    if(local_)return false; // old callers cannot supply the required ordinal
#endif
#if defined(MVDB_ENABLE_BLOCK_QUANT_SCALE) && defined(MVDB_BLOCK_SCALE_SELECTIVE)
    return definitely_greater_global(row,threshold);
  }
  // Internal fast path: caller has selected !local_scales() once outside its
  // scan loop. Arithmetic is exactly the old global implementation below.
  bool definitely_greater_global(const int8_t* row,double threshold) const {
#endif
    mvdb_cost::Call diagnostic_quant(mvdb_cost::QuantBound,n_);
    if(!enabled_ || !row || !std::isfinite(threshold) || threshold<0){mvdb_cost::event(mvdb_cost::QuantInvalid);return false;}
    if(!cached_ || threshold!=cached_threshold_)update_cap(threshold);
    if(!usable_cap_){mvdb_cost::event(mvdb_cost::QuantCapUnusable);return false;}
#if defined(MVDB_QUANTIZED_BLOCK_SIZE) && MVDB_QUANTIZED_BLOCK_SIZE > 0
    static_assert(MVDB_QUANTIZED_BLOCK_SIZE>=16,"quantized blocks must be at least 16 coordinates");
    // Each partial sum is an exact nonnegative integer no larger than the full
    // integer distance. The existing full-dimensional outward-rounded cap is
    // unchanged, so exceeding it early proves the same strict rejection.
    // n<=65536 and coordinates in [-127,127] keep the full sum below UINT32_MAX.
    uint32_t sum=0;
    for(size_t offset=0;offset<n_;offset+=MVDB_QUANTIZED_BLOCK_SIZE) {
      const size_t count=std::min<size_t>(MVDB_QUANTIZED_BLOCK_SIZE,n_-offset);
      sum+=kernel_(row+offset,query_data_+offset,count);
      if(static_cast<double>(sum)>cap_)return true;
    }
    return false;
#else
    mvdb_cost::event(mvdb_cost::QuantKernel);
    const bool rejected=static_cast<double>(kernel_(row,query_data_,n_))>cap_;
    if(rejected)mvdb_cost::event(mvdb_cost::QuantReject);
    return rejected;
#endif
  }
 private:
  void update_cap(double threshold) const {
    cached_=true;cached_threshold_=threshold;usable_cap_=false;
    // X=c*A+eX and Q=c*B+eQ, with each coordinate error <=c/2.
    // Hence ||X-Q|| >= c*(sqrt(Qint)-sqrt(n)).
    // Tu is the successor of the canonical threshold. If Qint exceeds this
    // outward-rounded cap, the real squared distance exceeds Tu, so its
    // correctly rounded double is strictly greater than threshold.
    const double tu=quantized_detail::up(threshold);
    if(!std::isfinite(tu))return;
    const double scaled=quantized_detail::up(tu/step_squared_);
    if(!std::isfinite(scaled))return;
    const double root=quantized_detail::up(std::sqrt(scaled));
    if(!std::isfinite(root) || root<4*root_n_)return; // performance fallback only
    const double sum=quantized_detail::up(root+root_n_);
    cap_=quantized_detail::up(sum*sum);
    usable_cap_=std::isfinite(cap_);
  }
  size_t n_=0;
  bool enabled_=false;
  double step_squared_=0,root_n_=0;
  quantized_detail::Distance kernel_=nullptr;
  std::vector<int8_t> query_;
  const int8_t* query_data_=nullptr;
#ifdef MVDB_ENABLE_BLOCK_QUANT_SCALE
  bool local_=false;
  QuantizedScaleView scales_;
  std::unique_ptr<QuantizedQueryBound[]> scale_bounds_;
  std::unique_ptr<int8_t[]> scale_codes_;
#endif
  mutable bool cached_=false,usable_cap_=false;
  mutable double cached_threshold_=0,cap_=0;
};
} // namespace mvdb

