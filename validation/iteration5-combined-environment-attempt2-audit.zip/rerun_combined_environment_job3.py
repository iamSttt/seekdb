"""Retry the frozen unsupported-ISA acquisition; no credentials in outputs."""
import hashlib,json,os,subprocess,urllib.request
from pathlib import Path
root=Path('work/combined-environment-attempt2-raw')
report=json.loads((root/'batch8-environment.json').read_bytes())
assert report['status']=='unsupported_native_isa' and report['native_row_isa']=='avx512'
assert report['database_runs']==report['pgo_builds']==report['performance_pairs']==0
assert (root/'batch8-environment-exit-code.txt').read_text().strip()=='78'
assert (root/'runtime-commit.txt').read_text().strip()=='ab6deae90dfeeb3f1c9e254c43beff0df1c258b6'
raw=Path('work/seekdb/validation/iteration5-combined-environment-attempt2-raw.zip').read_bytes()
assert len(raw)==42475 and hashlib.sha256(raw).hexdigest()=='52ed01c938c458f584e0e0a172ba5cb3f67ef22d7961174256ede37166471bbb'
plan=json.loads(Path('work/seekdb/validation/iteration5-batch8-tighter-primary24-preregistration.json').read_bytes())
assert plan['experiment_id']=='batch8-tighter-certificate-highest-primary24'
assert len(list(root.iterdir()))==11
receipt_path=Path('work/combined-environment-rerun3-receipt.json');assert not receipt_path.exists()
result=subprocess.run(['git','credential','fill'],input='protocol=https\nhost=github.com\n\n',text=True,capture_output=True,check=True,timeout=30,
 env=dict(os.environ,GIT_TERMINAL_PROMPT='0',GCM_INTERACTIVE='Never'))
fields=dict(line.split('=',1) for line in result.stdout.splitlines() if '=' in line)
request=urllib.request.Request('https://api.github.com/repos/iamSttt/seekdb/actions/jobs/132193424438/rerun',data=b'{}',method='POST',
 headers={'Authorization':'Bearer '+fields['password'],'User-Agent':'MiniVectorDB-authorized-CI','Accept':'application/vnd.github+json','Content-Type':'application/json'})
with urllib.request.urlopen(request,timeout=40) as response:
 receipt={'status':response.status,'run_id':43514245437,'rerun_job_id':132193424438,'environment_attempt_requested':3,
 'reason':'predeclared unsupported native ISA with exit78; database/PGO/performance all zero'}
receipt_path.write_bytes((json.dumps(receipt,indent=2)+'\n').encode());print(json.dumps(receipt))
