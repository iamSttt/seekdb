"""Archive exact previous material and the pre-test assistant audit, never a result."""
import hashlib
from pathlib import Path
import zipfile

root = Path(__file__).resolve().parent
repo = root / 'seekdb'
prior = (repo / 'conversation.json').read_bytes()
assert prior == (repo / 'agent/conversation.json').read_bytes()
assert hashlib.sha256(prior).hexdigest() == 'a44c2f56db885c8eb6cb7421c74b058ae1b85e751e9809edafa9c0e7459aa0ab'
target = repo / 'validation/iteration5-prior-material.json'
assert not target.exists() or target.read_bytes() == prior
target.write_bytes(prior)
files = ['new-direction-storage-audit.md', 'new-direction-memory-audit.md',
         'new-direction-frontend-audit.md', 'new-direction-memory-size-estimate.json',
         'estimate_insert_payload.py', 'new-directions-decision.md',
         'record_new_directions.py', 'archive_new_directions.py']
archive = repo / 'validation/iteration5-new-directions-audit.zip'
assert not archive.exists(), 'refuse overwrite'
with zipfile.ZipFile(archive, 'x', compression=zipfile.ZIP_DEFLATED) as output:
    for name in files:
        output.writestr('work/' + name, (root / name).read_bytes())
with zipfile.ZipFile(archive) as verify:
    assert verify.testzip() is None
    assert all(verify.read('work/' + name) == (root / name).read_bytes() for name in files)
print({'files': len(files), 'bytes': archive.stat().st_size,
       'sha256': hashlib.sha256(archive.read_bytes()).hexdigest()})
