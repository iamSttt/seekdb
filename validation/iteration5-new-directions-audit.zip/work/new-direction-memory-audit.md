# Value / AST 内存与所有权审计：下一候选应先消除无用副本

本文件是 assistant 的只读代码审计与实验建议。没有修改仓库、构建数据库、运行新性能实验或推送。代码位置对应当前保留实现。数值估算与既有实测分开标注，不能换算正式分数。

协调决定：当前第一项新实验是独立的持久化 CRC8；本文的 schema-aware copy 仅作为优先内存备选，不与 CRC 变更混测或集成。

## 结论

最值得先做的小候选是：**INSERT 已知目标列为 VECTOR 时，不复制解析器为 VARCHAR 兼容而保留的向量原文，只复制 float 有效载荷，再走原有 Database::insert 验证和事务路径。** 这不是线程、量化下界或 JSON 输出阈值调整，能直接减少默认 10k 导入过程中确定存在的无用分配与复制。

不建议第一步直接把 AST 行 `std::move` 到表中；解析向量的预留容量明显大于实际维度，旧深拷贝恰好会收紧它，盲目移动可能增加数 MiB 永久驻留内存。也不建议直接把 Value 换成三分支 variant：当前 VECTOR 值在解析阶段故意同时拥有 string 和 vector，存在真实双载荷语义。

## 1. 调用链与已确认的副本

1. `main.cpp:339,366`：请求 JSON 持有 SQL string，`parse_sql(...,false)` 不保存 `Statement::raw`，所以这一份 raw 文本的优化已经完成，不能再当新收益。
2. `sql.cpp:650`：quoted vector 被解析成 `Value::ofVec(v)` 后，还执行 `result.s = raw`，保留原始空格、十进制拼写等以适配 VARCHAR 目标。这里不能直接删除 s；`regressions.py:49` 明确要求 vector-like VARCHAR 保留原文。
3. `sql.h:47`：整个多行 INSERT 的 `Statement::rows` 拥有所有 Value。`sql.cpp:1241–1244` 为行分配 Value 数组，literal jobs 最后写入；parser 与 tokens 在 `parse_sql` 返回后销毁，未发现 token 容器常驻泄漏。旧 token-reuse 宏当前关闭。
4. `exec.cpp:174,274,281`：executor 接受 `const Statement&`，循环中的 `auto& row` 实际是 const 引用；`Database::insert(..., std::vector<Value> vals, ...)`（`db.cpp:1370`）按值接收，故每行深拷贝 Value 数组、字符串与 float 数组。
5. `db.cpp:831–879`：`check_value` 对真正 VECTOR 列校验维度/数值后，立刻 `std::string().swap(v->s)`。因此第 4 步刚复制的 vector 原文不会进入表、WAL、输出，确属冗余。
6. `db.cpp:1292,1427`：后续 vals 移动到 Row / Table，没有再复制整行。WAL 的 VECTOR 编码只写 float，不写 s（`db.cpp:247–260`）；行入表后并不存在原文长期占用。
7. 显式列名 INSERT 更重：`exec.cpp:288` 先把 AST 值复制到 schema 顺序的 full，`298` 又把 full 复制给 db.insert。full 在调用后没有再使用，后一次可改移动；这是独立且确定的冗余，但默认 benchmark 没有显式列名，不应把该收益算给默认负载。

## 2. 最小可测实现 A：只消除确定被丢弃的载荷

保持所有 const AST API、事务边界、错误处理、PGO 语料、表布局与查询路径不变。只在 INSERT 执行器构造送给 DB 的 row：

```cpp
// 示意，不是已经实施的代码。
if (column.type == Type::VECTOR && literal.type == Type::VECTOR)
    return Value::ofVec(literal.v); // 只拷贝 float，原文留在 AST
return literal;                    // 其余仍采用原 Value 拷贝语义
```

用新构造的 vector<Value> 调用 `db.insert(..., std::move(owned), ...)`，避免再复制一次；不要传 lvalue。Db 原 check_value 仍决定维度错误、非有限值、记录限制、重复主键及 WAL/事务结果。第一版可仅覆盖无显式列名的正常 INSERT；列重排路径可以独立增加，以免收益归因混杂。

优先限定为“目标与字面值都为 VECTOR”。不要同时把 vector-like VARCHAR 的 float 丢掉，因为 check_value 最前面还对 VECTOR literal 的超大维度进行错误检查；提前改成 VARCHAR 可能改变非法输入的接受范围/错误顺序。这个额外路径需要单独证明。

机制验证可使用一个已完成解析、含大量括号外空格的 quoted vector AST（例如 128 KiB 原文、仅 2 个 float），目标列为 VECTOR(2)。在 AST 建立后限定大额分配，确认执行不再为原文重新分配；然后检查值、AST 原文未变、COMMIT/重启一致。它检查的是实际分配行为，不能用“新分支被调用”代替。普通/显式列名、VARCHAR 原文、维度错误、重复键导致整个多行语句回滚都需走现有语义回归。

性能先做同机小配对：默认 10k×128、batch 100；一个 batch 500 或大 batch 内存压力组；一个 vector-like VARCHAR 保护组。记录导入 wall/CPU、整段生命周期、after_ingest 的 memory.current/peak，以及原有查询保护组。A 首要预测是减少分配和复制时间，**不是承诺大幅降低整个生命周期峰值**。

## 3. 定量边界：累计复制量不等于内存峰值

`work/estimate_insert_payload.py` 直接调用当前 `benchmark_jsonl.py` 生成器并保留首两行 tie，输出 `work/new-direction-memory-size-estimate.json`，不是数据库测量：10k 行、128 维、seed 7319，原文精确为 **25,135,765 B**（不含字符串终止 NUL 与 allocator 头），每行平均2513.5765 B；batch 100 最大原文合计251,602 B，约245.7 KiB。这意味着 A 可以免去约25 MB **累计**无用原文复制，却不会一次释放25 MB峰值。它复现的是仓库合成输入，未冒称正式平台输入。

原 AST、请求 SQL、输入行仍在当前语句期间存活，A 不消除它们。内存释放也不保证 allocator 立即归还页给内核。默认数据进入表后的 float 与 Value 元数据大小基本不变。

已有 b74 实验中保留基线的两个 2CPU standard10k 生命周期，after_ingest 峰值分别 11,669,504 / 11,677,696 B，after_index_build 12,898,304 / 12,906,496 B，而最终峰值是 17,760,256 / 18,030,592 B，出现在重启后的校验/查询区间。摘录见 `work/new-direction-memory-existing-phases.json`。该区间包含 ID/向量独立校验，不能说全部由查询造成；cgroup 也含文件页缓存。这些既有记录说明：只削减初次解析临时对象未必降低这套测试的最终峰值。正式平台具体生命周期仍不可见。

## 4. 为什么现在不要直接消费 AST

`sql.cpp:602` 预留 `body.size()/8+4` 个 float。当前随机 float32 文本平均约 2512 字节/128维，估算预留平均 317.5、范围312–322 个元素，而实际只有128。

旧路径的 std::vector<float> 深拷贝在固定 libstdc++ 实现中通常按 size 分配，表中的 float 容量由约317收紧为128。若把 AST 的 vector 无条件移动进表，10k 行的 float 预留可从约5.12 MB变成12.70 MB，约多7.58 MB。这是容量推导，不是已实测 RSS；应在固定 Linux 编译器下打印/断言 capacity 再确认。

因此“消费 AST”必须先解决容量：精确预数元素并只分配所需空间，或对超大 capacity 做紧缩。后者仍会复制 float；前者给每个 literal 增加扫描工作。它们需要作为另一候选单独衡量，不能把纯 std::move 当作确定内存优化。

同时原 const Statement 可被调用者重复执行、检查错误和复用。若后来做消费路径，宜新增明确的 rvalue/owned 执行入口，仅供 main 中一次性 Statement 使用；保留旧 const 入口。解析必须仍完整结束后再修改表，不能边解析边插入而破坏尾部语法错误的原子性。失败以后允许消耗 AST 的契约也必须明确。

## 5. 紧凑 Value / variant：有上限，但改造范围远大于 A

`value.h:19` 当前包含 tag、int64、string、vector。按固定 x86_64 libstdc++ 常见布局估计为72 B（需要 Linux sizeof 实测）；若只允许 int64/string/vector 之一，variant 可能约40 B。默认3列×10k行最多约960,000 B Value 数组对象节省，另外有 allocator 分级影响；float 5.12 MB、Row metadata、pk map、索引码、页缓存不随之消失，不能声称内存减半。

直接 variant 有具体障碍：

- quoted VECTOR 在解析时同时需要 s 与 v；三分支 variant 丢失真实兼容语义。若加含 string+vector 的 ParsedVector 分支，最大分支约56 B，variant 总体可能64 B，节省会缩水。要接近40 B通常需区分 ParsedValue 与 StoredValue，并重写边界转换。
- `db.cpp:271–281` 的 get_value 直接改 tag 后写成员；`735–737,854–856` 的 coercion 也直接改 tag / clear v；匿名 union 不能保留这种写法而不管理成员生命期。
- `row_heap_bytes`、undo_image_bytes 等现在无条件访问 s 与 v。换 union 后须按活动成员处理；复制/移动/异常保证必须覆盖读取失败、WAL重放、UNDO、spill、槽位回收。
- resident index 借用 float 指针；容器移动须保持原指针与 noexcept 保障，类型切换/回滚仍必须先失效派生索引。
- 持久化格式本身采用明确 tag+payload，不需要改变磁盘格式；风险主要在运行对象的生命周期和分支/代码生成成本，不能用“格式没变”代替回归。

建议只先构建独立 sizeof/构造-复制-移动-销毁实验与全部类型转换清单；若真实内存计分瓶颈仍明确，再做单独受控候选。不建议与 A 同时合并，也不建议为了0.96 MB理论节省立即重写全引擎。

## 6. 一个可独立处理的容量缺口

`check_value` 把 vector-like literal 转成 VARCHAR 时仅 `v->v.clear()`（db.cpp:856），保留了不再使用的 float capacity；row_heap_bytes 只算 size，所以这份额外容量还不计入该预算。它不影响无 VARCHAR 的默认10k表，但影响真实字符串恰好长得像向量的表。

最小修复方向是在**完成原有检查和合法转换后**交换空 vector，以释放 inactive payload，而保留原字符串。这个变更比 variant 小得多，但不能以它作为默认负载收益。建议复用已有 vector-like VARCHAR 拼写、WHERE、重启测试，再增加容量/内存实测；与默认 A 分别记录。

最终优先顺序：A（schema-aware 有效载荷复制）→ 若仍有必要再测消费 AST 的容量方案 → 最后评估 StoredValue 紧凑布局。以上都是尚未执行的候选，不代表新分数或已确认加速。
