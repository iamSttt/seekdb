# 存储路径独立审计：下一轮候选机制

本次只读审计 `work/seekdb/minivec/src/{db,sql,exec,main,flat_index}.cpp`，未改变运行实现、默认参数、耐久语义或正式提交。以下是待测假设，不是性能或分数结论。

## 先纠正成本归因

- 默认 10k × 128 浮点本体为 5,120,000 字节，外加 WAL 行头、主键、标量与事务记录。默认 checkpoint 门槛是 64 MiB（db.cpp:103–109），正常退出 `main.cpp:347–356` 调用 `Database::close()`；close 在 db.cpp:1020–1038 刷新/关闭 WAL 并释放表，**不做全表 snapshot**。不能把这一负载的退出时间归因于全量快照序列化。
- SQL 修改语句由 exec.cpp:866–884 包装为隐式事务；`begin_statement/end_statement` 在 db.cpp:1920–1956。多行 INSERT 不是每行一次 fdatasync；成功语句在 COMMIT 才同步。现有 1 MiB WAL staging 和直接构造 framed INSERT record 已实现（db.cpp:1317–1346、1403–1419），不应重复包装为新优化。
- 创建索引会构建一次；后续 `build_vector_index()` 在已有索引时立即返回（db.cpp:2037）。重启 `open()` 会重建派生索引（1078–1086），写入后失效也可能重建，但普通 1000 次查询并不会每次全量建索引。
- 现有小算力首轮一条 standard10k baseline 样本中：ingest 183.10 ms、index 16.05 ms、首次 1000 查 135.95 ms、shutdown 2.60 ms、restart 71.45 ms。仅用于定位可测区段；这是一个固定种子、单逻辑 CPU 的旧样本，不代表正式评测占比。

## 1. 把兼容 IEEE CRC32 的批量计算接入真正持久化路径

证据：db.cpp:132–152 的 `crc32_upd` 每字节执行一次依赖前一结果的查表/移位；INSERT 在 1416 对每条完整记录做 CRC，WAL replay 在 2782 和 2816 对已提交事务前后两遍计算，snapshot 写/读也调用同一函数。默认载入至少覆盖约 5.12 MB 向量字节的 CRC 工作。

候选：使用同一反射多项式 `0xEDB88320` 的 slicing-by-8，保持原始 accumulator、初始 `0xffffffff`、末尾 XOR 和每个持久化字节不变；仅把连续八字节的更新展开为独立表查找。不要使用 SSE4.2 CRC32 指令直接替换：那会变成 CRC32C，破坏格式兼容。所有同步、记录长度、事务标记和截断规则保持原样。

历史边界：TECHNICAL_REPORT_20261112.md:72 和 cleanup-manifest 显示清理前有孤立的 crc32.h 实验，但它未被运行代码引用、已被移除。当前未读到旧实现源码，故不能称“历史从未尝试CRC”。这里的新实验是将候选真正接入当前 db.cpp 并衡量端到端成本。

最小验证：独立逐位 oracle、`123456789 → cbf43926`、空输入、所有偏移/8字节边界/短尾、随机分块增量；同一个事务输入的旧/新 WAL 字节完全一致；双向打开旧/新 WAL、snapshot；现有截断/坏 CRC/未提交尾部/短写与 COMMIT 后 SIGKILL 继续通过。然后先做 10k 插入+建索引+1000查+退出及重启的少量 AB/BA 对照，记录CPU、周期总耗时和 cgroup 峰值，不能以独立 CRC 微测倍率换算正式分数。

风险：表从 1 KiB 增为 8 KiB，可能影响指令/数据缓存与 PGO 布局；短记录路径可能不赚；CRC部分并非整个 INSERT 耗时。错误的字节序、增量状态或尾部处理会使全部持久化数据不兼容，必须先验证再测性能。

## 2. 让一次性 JSONL INSERT 消费已拥有的 AST 行

证据：parser 在 sql.cpp:642–654 把 quoted vector 同时保存为 float vector 和原始文本（VARCHAR目标需保真）；exec.cpp:278–285 将 `const Statement` 的行传给按值接收的 `Database::insert`。这会深拷贝已拥有的 float vector 和 quoted spelling；db.cpp:880–883 再释放副本里的 spelling，最后 1428 把向量移动到表。默认 10k × 128 至少有一次 5.12 MB float payload 拷贝，另外还有 quoted text 的复制/释放与每行分配。明确列列表还在 exec.cpp:289 逐值拷贝到 full，再按值传入。

候选：保留现有 const/reusable Statement API；为 main.cpp:363–370 的一次性局部 Statement 增加显式拥有/消费入口，预先验证列映射后，把行或映射后的 Value 移交给 Database::insert。不要 const_cast；不要让通用调用者的 AST 在未声明时被破坏。这与旧 I13 tokenizer/TLS复用/取消 Statement.raw 的实验不同；旧“提前丢弃向量字符串”的尝试也不能当作此项已验证。

最小验证：同一 const Statement 可重复执行行为仍保留；一次性API输出与现路径一致；VARCHAR目标的 bracket字符串保真、显式列重排、重复列、后段重复PK/坏维度触发整语句回滚、显式事务前一成功语句不受失败语句影响；大字符串/多行/spill故障。小测先比较有意义的完整 ingest+commit 段和峰值，保留后续查询保护。

风险：API和异常路径比CRC更广；搬移后只剩部分AST，失败重试不能暗中重用它。仅移动 AST 并不会免除类型验证、WAL序列化、索引维护；最小实现必须限制到明确一次性入口，不改变现有测试工具或复用语义。

## 3. 融合索引构建时的范数遍历与全局量化幅值遍历

证据：db.cpp:2081–2117 对 resident vectors 逐坐标计算范数、排序，再调用 add_slot；FlatIndex::add（flat_index.cpp:265–269）只借用向量指针。finish 在 324–345 再全量遍历同一批坐标求 global max-abs，在 383–403 第三次访问坐标编码 int8。默认 exact 不构建 coarse partition（flat_index.cpp:431–435），不能把 partition 当作默认开销。

候选：只在现有 norm-order 路径已经扫描全部 resident 向量时，同时得到全局 max-abs/finite 标记，传给 finish 跳过它的重复统计遍历；排序、codes顺序、量化步长公式和精确距离都不变。无norm-order、disk-backed、分块尺度等未覆盖路径继续原实现。它减少一次向量遍历，区别于旧 I11 改变量化尺度/剪枝算法。

最小验证：逐字节比较 keys/slots/codes、量化步长，覆盖极值、零、负零、subnormal及尺度边界；比较默认与禁用norm-order、无量化预算、磁盘路径的回退；完整TopK及更新/回滚/重启保护。小测把 index_build 独立列出，并计入完整生命周期，不能只报 index 毫秒收益。

风险：融合后的额外 reduction 可能抑制向量化、拖慢范数计算，少一遍访问并不保证更快。新参数/状态须与本次构建绑定，不可跨修改复用过期的幅值；缺失/非法统计必须回退。当前index阶段只占上述单样本的约16 ms，理论收益受限。

## 查到但暂不优先实现的恢复成本

WAL replay 先完整 decode 每条事务记录（db.cpp:2784–2785），遇 COMMIT 又回读、CRC、decode 并应用（2799–2820）；因此已提交事务中的向量和字符串存在两次分配/解码。但仅去掉首遍 decode 会改变“CRC正确但结构坏”的检测/截断行为，不能直接跳过。可另做不分配的结构验证器，或严格限额的事务缓存；前者要保证错误边界一致，后者增加内存。此方向主要改善重启，不改善没有重启的默认首段，因此排在前三项之后。

`put_value` 的 VECTOR 路径并非逐float写 u32：db.cpp:247–258 已在 little-endian 且 sizeof(float)==4 时使用一次 `std::string::append` 批量复制，仅 big-endian fallback 逐float。把它再改成 memcpy 不能宣称新优化；当前应保持不动。
