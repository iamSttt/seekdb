"""Draft only: compact assistant history and record the new direction request.

Default mode only prints an in-memory preview summary. --apply requires the root
agent to have archived the exact prior material and its reviewed audit bundle.
No implementation, Linux test, performance result or formal submission is claimed.
"""
import argparse
import copy
import hashlib
import importlib.util
import json
import os
from pathlib import Path
import re
import subprocess

BASE_COMMIT = '7ca3baad3f4c71970b01d194e8eee88a3606ff3b'
BASE_SHA = 'a44c2f56db885c8eb6cb7421c74b058ae1b85e751e9809edafa9c0e7459aa0ab'
BASE_BYTES = 130588
ARCHIVE_PATH = 'validation/iteration5-prior-material.json'
USER_TEXT = '跳出原有的迭代逻辑，重新寻找其他的优化方向'
USER_IDS = ('user-new-directions-request', 'user-new-directions-request-repeat')
USER_QA_ID = 'user-evaluation-clarifications-shared'
USER_QA_TEXT = '''提供给你一些资料
1. E 的计算标准是什么？ 按照赛题§3.3.3的公式可以推出E∈(0,1)，但是测评性能榜上的E的数值一般显示数千。请问平台评测时展示的 E 是如何计算的？是否等于赛题的E×10⁴？
2.正式评测的机器配置与基线是怎样的，能告知吗？赛题§3.1提到“运行环境、基础镜像、可用依赖、CPU、内存、磁盘、启动及查询超时、数据规模、向量维度和 K 的范围，须在首日开始前随题包冻结发布”
3.§3.3.1：“查询默认为 exact 模式”。计分的性能 benchmark 是否固定为 exact 模式、任何轮次都不会使用 ann？如果确实只跑 exact，那么实现 ANN 对性能分是否完全没有作用？
4.§3.3“默认 10,000 条记录、128 维向量、1,000 条 TopK 查询，K = 10，其中一半查询带普通列等值过滤……”正式计分的性能 benchmark 是否始终是 10,000×128、1,000 查询、K=10、一半过滤、每批 100 条写入？还是默认如此，但是有的不是？
1是为了比较，找了个基线对比了一下。2正式评测是性能非常非常差的机器，1c2g还是2c2g我忘了。3默认参数是exact。4我也没注意'''
USER_SUBMISSION_ID = 'user-seven-ca3baa-self-submission-continue'
USER_SUBMISSION_TEXT = '这一版本我即将提交，晚点出分了登陆上后我告诉你，你先优化就是'

# Historical plans, not later measured result messages. Original message IDs,
# positions, roles and all user/quote evidence remain intact.
MESSAGE_SUMMARIES = {
    'assistant-report-stage-a-plan': '阶段A历史计划：按I05/I08实现有界两列posting与payload批写，先做同GCC/O3无PGO的66对，再独立PGO确认。当时仅本地工具检查通过，Linux未执行；I17用户预测已先保存，未正式提测。',
    'assistant-save-low-battery-20261113': '按用户电量要求保存：e47cb446已推，基础门禁成功，66对仍运行；不提前宣称性能完成。后续默认关闭的候选及测试草稿已保存，当时非最终交付，6000未验证。',
    'assistant-report-stage-b-plan': '阶段B历史计划：I06/I07/I09/I10/I11/I12/I14/I15分别准备默认关闭的单因素实现、门禁与小筛选。I06当时仅非PK UPDATE；I07仍顺扫向量。Linux尚未执行，cgroup诊断不能当正式M/B或分数。',
    'assistant-user-feedback-action': '保存用户I17反馈与I18事前预测；计划补默认退化复验、缓存模式、首次摊销及工作量计数。当时I07未测量、I18未获本人结果反馈，不代写判断；归属后来另由I19纠正。',
    'assistant-stage-b-first-gate-fixes': '历史门禁修复：两份JSON因CRLF/LF摘要变化，统一LF未放宽校验；I06 fixture误期待PK UPDATE成功，改为按既有规范拒绝并保留回滚校验。其余任务当时未完成，不记性能成功。',
    'assistant-report-stage-c-plan': '阶段C历史计划：默认关闭的owning-token复用、typed原子性、过滤生命周期及逻辑IO诊断待Linux。修正spill注错位置但未降断言；768维超量化预算与synthetic绕过生产筛选，使此前小收益/32倍不能归因正式请求优化。',
    'assistant-confirmation-next-plan': '历史确认计划：解析复用、typed、spill缓存分别用原PGO确认；选择性量化尺度仍是假设，默认关闭。所列配对尚未执行，不默认启用或交付。',
    'assistant-filter-repeat-and-gate-plan': '历史计划：旧默认负面去掉唯一线程不等样本后仍约2.6%，AB/BA分歧且同程序漂移8.9%；准备固定线程、交错及A/A复验，不能定性为噪声。rollback slot复用与PGO UTF8门禁当时待执行。',
    'assistant-output-guard-plan': '历史计划：同机对比spill、全typed、投影含至少128维向量才typed，共63对并独立PGO与UTF8门禁。128是assistant待测阈值，收益证据当时只覆盖768维；未测前不默认启用。',
    'assistant-actions-disabled-checkpoint': '历史检查点：63对尚未执行，Actions dispatch返回422 disabled，凭据仅push无admin；未改仓库策略。分析器和默认候选草稿已保存，静态检查不算Linux验证，默认开关未变。',
    'assistant-six-direction-followup-plan': '历史收尾计划：I06补INSERT/DELETE delta但保留近似查询契约；新I17/I18回复按真实时序保存，不倒填旧预测，I19来源纠正保留。用户允许云测试聊天不等于Linux测试完成。',
    'assistant-six-followup-preparation': '历史准备：I06混合delta仍off，计划9对delta、12对spill写查、6对复合过滤及独立门禁。旧只读实验不能回答写后重建成本。当时只有本地工具检查，无新Linux测量，云聊天未返回ID。',
    'assistant-write-query-judgment-followup': '用户新I17要求保护首查与一写一查，16查不是阈值；assistant准备保守准入，尚未验证。I18判断按实际新回复保存，不推断独立作者或Prompt分。I06虽混合写查获益但warm退化，继续off。',
    'assistant-filter-reuse-preparation': '历史候选：首个复合过滤保留原单列路径，成功非空扫描后准入多posting；写入/重建重置，异常不warm，预算不叠加。准备4+6门禁及30对原PGO验证，当时仅静态检查，reuse默认off。',
    'assistant-regression-followup-plan': '历史计划：以e020四宏运行核心定位30k、60k及many16退化，同时保护spill和宽投影。无新结果，不跨基线归因；旧assistant重复指标移至精确归档，user原话/位置不变，正式提交留用户。',
    'assistant-regression-candidates-prepared': '历史准备：等值访问与DOM reserve两个独立候选默认off，计划138对含A/A并保留前64、重启、写入和负面。仅静态准备，真实Linux结果见后续assistant-regression-round1-measured-results。',
    'assistant-bulk-typed-followup-plan': '历史计划：等值/DOM reserve在138对后撤去；仅投影16–127维向量、LIMIT较大等路径试bulk typed，默认off。尚无新Linux结果，保留原>=128维行为及scalar/distance保护；完整准入条件、84对计划（66候选+18同基线AA）与门禁见原档。',
    'assistant-bulk-guard-plan': '历史计划：bulk资格先排除scalar/distance及已有>=128维路径，再检查LIMIT/WHERE/活跃PK，以减少通用成本。诊断单测不代表性能或已解释60k退步；192对（150候选+42同程序AA）和原PGO门禁待执行，默认宏不变。',
    'assistant-bulk-loop-plan': '历史计划：机器码存在投影helper调用，但旧候选也有调用且曾获益，不能据此归因退化；profile调用序号不同不代表分支频率变化。仅改bulk资格为显式for循环，复用192对/原PGO/单测，执行0、默认宏不变，不正式提测。',
}

EXPERIMENT_IDS = ('report-stage-a', 'output-guard-ablation', 'filter-reuse-lifecycle-confirmation',
                  'regression-followup', 'bulk-typed-followup', 'bulk-guard-confirmation', 'bulk-loop-confirmation')
EXPERIMENT_KEEP = ('id', 'executed_by', 'status', 'baseline_commit', 'source_commit',
    'baseline', 'runtime_commit', 'user_direction_ids',
    'user_request_message', 'plan_message', 'result_message', 'database_pairs_executed',
    'candidate_pairs_executed', 'same_binary_control_pairs_executed', 'binary_gates_passed',
    'utf8_cases_passed', 'unit_sanitizer_gates_passed', 'default_enabled',
    'candidate_defaults_enabled', 'source_decision', 'current_default_image_performance_measured',
    'official_submission_authorized')

ASSISTANT_PLAN = (
    '用户连续两次提出同一“跳出原有迭代逻辑”请求；保留两次真实发送记录，第二次为重复确认，不计成第二项技术贡献。'
    '以下具体方向均由assistant审计提出：兼容IEEE CRC32的slicing-by-8、按目标列类型只复制INSERT所需值、'
    'JSONL换行扫描游标、复用已验证envelope的原始ID区间、批量排序距离复用；不是用户逐项提出的方向。'
    '本次先验证CRC，其他四项仅候选，未实现或测量。CRC不改磁盘格式、同步或提交顺序，不用不同多项式的CRC32C替代IEEE；'
    '计划增加CRC边界/分段/参考算法检查及新旧真实WAL、snapshot双向兼容，再构建实际根PGO一次，沿用1CPU12对+2CPU8对。'
    '用户转述资料只支持存在基线比较、机器较差且1c2g或2c2g记忆不确定、默认exact；不能证实E固定乘10^4、正式机器固定配置、永远exact或规模固定。'
    '本轮1/2CPU、2GiB内存、swap0与exact是诊断配置，不是已确认的正式环境。用户表示将自行提交7ca3baa并要求继续优化；assistant不替用户正式提交。'
    '当前新Linux构建、正确性、持久化兼容和性能测量均为0，尚无收益或通过结论；不启用前次被拒绝的affinity策略，不执行正式提交。'
)


def require(value, message):
    if not value: raise ValueError(message)


def sha(raw): return hashlib.sha256(raw).hexdigest()
def encode(value): return (json.dumps(value, ensure_ascii=False, separators=(',', ':'), allow_nan=False) + '\n').encode('utf8')


def pointer(record, location):
    current = record
    for token in location.split('/')[1:]:
        token = token.replace('~1', '/').replace('~0', '~')
        current = current[int(token)] if isinstance(current, list) else current[token]
    return current


def pointer_records(value, record, location=''):
    result = []
    if isinstance(value, dict):
        for key, child in value.items():
            path = location + '/' + key.replace('~', '~0').replace('/', '~1')
            if key == 'pointer' or key.endswith('_pointer'):
                result.append((path, child, copy.deepcopy(pointer(record, child))))
            result += pointer_records(child, record, path)
    elif isinstance(value, list):
        for index, child in enumerate(value): result += pointer_records(child, record, location + '/' + str(index))
    return result


def archive(): return {'path': ARCHIVE_PATH, 'sha256': BASE_SHA}


def build_record(original, audit_artifact, crc_stage):
    record = copy.deepcopy(original)
    users = [(i, copy.deepcopy(m)) for i, m in enumerate(original['messages']) if m['role'] == 'user']
    require(len(users) == 37, 'expected exactly 37 existing user objects')
    refs = pointer_records(original, original)
    journal = []
    for index, message in enumerate(record['messages']):
        ident = message['id']
        if ident not in MESSAGE_SUMMARIES: continue
        require(message['role'] == 'assistant', 'refuse user compression')
        old_size = len(encode(message))
        message['content'] = MESSAGE_SUMMARIES[ident]
        if 'sha256' in message: message['sha256'] = sha(message['content'].encode('utf8'))
        message['archived_original'] = {'archive': 'iteration5_prior_material',
                                         'source_location': '/messages/' + str(index)}
        journal.append({'location': '/messages/' + str(index), 'id': ident,
                        'bytes_before': old_size, 'bytes_after': len(encode(message))})
    require(sum(x['location'].startswith('/messages/') for x in journal) == len(MESSAGE_SUMMARIES), 'missing planned historical message')
    for index, experiment in enumerate(record['experiments']):
        if experiment['id'] not in EXPERIMENT_IDS: continue
        # Every later measured result message is unchanged, including all core
        # positive/negative metrics. Archive only repeated plan/build metadata.
        require(experiment['executed_by'] == 'assistant' and 'result_message' in experiment, 'missing retained decision message')
        compact = {key: copy.deepcopy(experiment[key]) for key in EXPERIMENT_KEEP if key in experiment}
        compact['artifacts'] = [archive()]
        compact['archived_json_location'] = '/experiments/' + str(index)
        compact['archive_scope'] = 'Full original experiment, artifact hashes, plan/build metadata. Measured result message and positive/negative decision remain inline.'
        record['experiments'][index] = compact
        journal.append({'location': '/experiments/' + str(index), 'id': experiment['id'],
                        'bytes_before': len(encode(experiment)), 'bytes_after': len(encode(compact))})
    require(sum(x['location'].startswith('/experiments/') for x in journal) == len(EXPERIMENT_IDS), 'missing planned historical experiment')

    existing_ids = {m['id'] for m in record['messages']}
    require(not any(x in existing_ids for x in (*USER_IDS, USER_QA_ID, USER_SUBMISSION_ID, 'assistant-new-directions-plan')), 'new request already recorded')
    content_sha = sha(USER_TEXT.encode('utf8'))
    first = {'id': USER_IDS[0], 'role': 'user', 'content': USER_TEXT, 'source_kind': 'current_user_message', 'sha256': content_sha}
    repeat = {'id': USER_IDS[1], 'role': 'user', 'content': USER_TEXT, 'source_kind': 'current_user_message', 'sha256': content_sha,
              'duplicate_of': USER_IDS[0], 'contribution_relation': 'repeat_of_same_request_not_a_second_technical_direction'}
    qa = {'id': USER_QA_ID, 'role': 'user', 'content': USER_QA_TEXT, 'source_kind': 'current_user_message',
          'sha256': sha(USER_QA_TEXT.encode('utf8')), 'attribution': 'User supplied this Q&A; external answer author and formal platform configuration are not independently verified.'}
    submission = {'id': USER_SUBMISSION_ID, 'role': 'user', 'content': USER_SUBMISSION_TEXT,
                  'source_kind': 'current_user_message', 'sha256': sha(USER_SUBMISSION_TEXT.encode('utf8')),
                  'referenced_commit': BASE_COMMIT, 'authorization_scope': 'Continue optimization; user performs formal submission.'}
    record['messages'].extend((first, repeat, qa, submission, {'id': 'assistant-new-directions-plan', 'role': 'assistant', 'content': ASSISTANT_PLAN}))
    for message in (first, repeat, qa, submission): record['provenance']['user_content_sha256'][message['id']] = message['sha256']
    record['provenance']['iteration5_prior_material'] = {**archive(), 'bytes': BASE_BYTES, 'commit': BASE_COMMIT,
        'scope': 'Complete byte-preserved pre-compaction JSON. archived_original.archive resolves this provenance key; source_location is its exact external JSON location. All original users/messages/experiments are recoverable.'}
    record['experiments'].append({
        'id': 'new-directions-crc32-ieee-screen', 'executed_by': 'assistant', 'proposed_by': 'assistant',
        'status': 'planned_no_linux_execution' if crc_stage == 'planned' else 'implemented_unmeasured_linux_pending',
        'implementation_status': crc_stage,
        'user_request_message': USER_IDS[0], 'repeat_request_message': USER_IDS[1],
        'plan_message': 'assistant-new-directions-plan',
        'assistant_proposed_directions': ['crc32_ieee_slicing8', 'schema_aware_insert_copy', 'jsonl_scan_cursor', 'validated_envelope_id_span', 'bulk_order_distance_reuse'],
        'active_candidate': 'crc32_ieee_slicing8', 'other_directions_implemented': False,
        'root_pgo_builds_planned': 1, 'new_pgo_builds_executed': 0,
        'planned_database_pairs': 20, 'database_pairs_executed': 0, 'linux_correctness_tests_executed': 0,
        'plan': {'one_cpu_pairs': 12, 'two_cpu_protection_pairs': 8,
                 'memory_limit_bytes': 2147483648, 'swap_limit_bytes': 0, 'query_mode': 'exact',
                 'configuration_scope': 'Diagnostic configuration, not independently confirmed formal benchmark settings.',
                 'correctness': 'IEEE reference/known vectors, chunked state, lengths/alignment; real old/new WAL+snapshot bidirectional compatibility',
                 'unchanged_contract': 'polynomial 0xEDB88320, existing format and durability barriers; no CRC32C substitution'},
        'baseline_four_features_retained': True, 'automatic_adoption': False,
        'formal_submission_authorized': False, 'official_score': None,
        'artifacts': [archive(), audit_artifact],
    })
    require(all(record['messages'][i] == m for i, m in users), 'existing user object or position changed')
    require([m['id'] for m in record['messages'][:len(original['messages'])]] == [m['id'] for m in original['messages']], 'old message positions changed')
    for location, target, value in refs:
        require(pointer(record, location) == target and pointer(record, target) == value, 'existing quote/pointer target changed: ' + location)
    require(record['adopted_directions'] == original['adopted_directions'] and record['direction_status'] == original['direction_status'] and
            record['attribution_audit'] == original['attribution_audit'], 'historical attribution changed')
    # No measured-result message may be accidentally summarized as a plan.
    for exp in original['experiments']:
        if 'result_message' not in exp: continue
        require(exp['result_message'] not in MESSAGE_SUMMARIES, 'measured result message selected for compression')
    return record, journal


def main():
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument('--repo', type=Path, default=Path(__file__).resolve().parent / 'seekdb')
    p.add_argument('--audit-archive', default='validation/iteration5-new-directions-audit.zip')
    p.add_argument('--crc-stage', choices=('planned', 'implemented_unmeasured'), default='planned')
    p.add_argument('--apply', action='store_true', help='Root operator only, after prior material/audit archive review')
    p.add_argument('--preview-output', type=Path, help='Optional preview under work, never under the repository')
    args = p.parse_args(); repo = args.repo.resolve()
    raw = (repo / 'conversation.json').read_bytes()
    require(raw == (repo / 'agent/conversation.json').read_bytes() and len(raw) == BASE_BYTES and sha(raw) == BASE_SHA, 'material drift; refusing overwrite')
    committed = subprocess.check_output(['git', '-c', 'safe.directory=' + repo.as_posix(), '-C', str(repo), 'show', BASE_COMMIT + ':conversation.json'])
    require(committed == raw, 'prior material is not the pinned Git object')
    audit_path = (repo / args.audit_archive).resolve()
    require(audit_path.is_relative_to(repo) and not Path(args.audit_archive).is_absolute(), 'audit archive must be repository relative')
    if args.apply:
        require((repo / ARCHIVE_PATH).read_bytes() == raw, 'root must archive the exact original material before applying')
        require(audit_path.is_file(), 'root must archive the reviewed direction audits first')
    audit_artifact = {'path': args.audit_archive.replace('\\', '/'), 'sha256': sha(audit_path.read_bytes()) if audit_path.exists() else '0' * 64}
    original = json.loads(raw); updated, journal = build_record(original, audit_artifact, args.crc_stage)
    result = encode(updated)
    require(len(result) <= 131072 and 131072 - len(result) >= 3072, 'insufficient space for new results')
    spec = importlib.util.spec_from_file_location('material_checker_draft', repo / 'minivec/tools/validate_iteration_material.py')
    checker = importlib.util.module_from_spec(spec); spec.loader.exec_module(checker)
    checker.check_structure(updated, updated)
    for item in updated['experiments'][-1]['artifacts']:
        if args.apply: checker.check_artifact(repo, item)
    summary = {'mode': 'apply' if args.apply else 'preview_only', 'bytes_before': len(raw), 'bytes_after': len(result),
        'remaining_bytes': 131072 - len(result), 'sha256': sha(result), 'old_users_preserved': 37, 'new_user_messages': 4,
        'unique_new_user_request': 1, 'assistant_messages_summarized': len(MESSAGE_SUMMARIES),
        'experiments_with_archived_repeated_metadata': len(EXPERIMENT_IDS), 'new_linux_runs': 0,
        'new_database_pairs': 0, 'crc_stage': args.crc_stage, 'journal': journal}
    if args.preview_output:
        output = args.preview_output.resolve()
        require(not output.is_relative_to(repo) and not output.exists(), 'preview must be a new file outside repo')
        output.write_bytes(result)
    if args.apply:
        targets = [repo / 'conversation.json', repo / 'agent/conversation.json']
        temporaries = [x.with_suffix('.iteration5.tmp') for x in targets]
        require(not any(x.exists() for x in temporaries), 'temporary material file already exists')
        for path in temporaries: path.write_bytes(result)
        for temporary, target in zip(temporaries, targets): os.replace(temporary, target)
        checker.validate(repo)
    print(json.dumps(summary, ensure_ascii=False, indent=2))


if __name__ == '__main__': main()
