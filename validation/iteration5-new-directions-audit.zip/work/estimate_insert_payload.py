"""Count existing benchmark literal bytes. No database execution or timing."""
import hashlib,json,statistics,sys
from pathlib import Path
W=Path(__file__).resolve().parent
TOOLS=W/'seekdb/minivec/tools'
sys.path.insert(0,str(TOOLS))
import benchmark_jsonl as bench

vectors,_,_,_=bench.make_workload(10000,10,7319)
raw=[bench.vector_literal(v)[1:-1] for v in vectors]
lengths=[len(s.encode('utf8')) for s in raw]
capacities=[len(s[1:-1])//8+4 for s in raw]
assert all(len(v)==128 for v in vectors)
assert vectors[0]==vectors[1]  # Preserve the existing generator's tie case.
out={
 'scope':'Static Python count using the checked-in synthetic generator; no DB execution, speedup, RSS or official score claim.',
 'generator':'minivec/tools/benchmark_jsonl.py',
 'generator_sha256':hashlib.sha256((TOOLS/'benchmark_jsonl.py').read_bytes()).hexdigest(),
 'rows':10000,'dimension':128,'seed':7319,'batch_size':100,
 'quoted_raw_text_bytes_total':sum(lengths),'mean_raw_text_bytes':statistics.mean(lengths),
 'copy_scope':'One redundant retained raw-string deep copy per row at exec.cpp plain INSERT -> Database::insert by value, then released by check_value for target VECTOR. Counts bytes, not allocator headers/NUL or total parser copies.',
 'estimated_ast_vector_reserved_elements_min':min(capacities),
 'estimated_ast_vector_reserved_elements_max':max(capacities),
 'estimated_ast_vector_reserved_elements_mean':statistics.mean(capacities),
 'float_bytes_at_size':10000*128*4,
 'bytes_from_parser_initial_reserve':sum(capacities)*4,
 'extra_reserve_bytes_if_moved_to_resident':sum(c-128 for c in capacities)*4,
 'batch100_peak_ast_raw_text_bytes':max(sum(lengths[a:a+100]) for a in range(0,10000,100)),
 'layout_inference_not_measured':{'libstdcxx_x86_64_Value_expected_bytes':72,
  'variant_three_alternatives_expected_bytes':40,
  'three_column_10000row_value_object_savings_bytes':10000*3*(72-40)},
}
(W/'new-direction-memory-size-estimate.json').write_text(json.dumps(out,indent=2)+'\n',encoding='utf8')
print(json.dumps(out))
