"""Narrow offline identity/source preflight; never executes a native program."""
import ast, hashlib, json, sys
from pathlib import Path
from types import SimpleNamespace

sys.dont_write_bytecode = True
import analyze_quarter_margin_prototype as reader

W = Path(__file__).resolve().parent
repo = W / 'seekdb'
checks = []

def check(name, condition):
    if not condition:
        raise AssertionError(name)
    checks.append(name)

def rejected(name, action):
    try:
        action()
    except (ValueError, AssertionError, RuntimeError):
        checks.append(name)
    else:
        raise AssertionError(name + ' accepted')

new = ast.parse((W / 'analyze_quarter_margin_prototype.py').read_bytes())
old = ast.parse((W / 'analyze_tighter_bound_prototype.py').read_bytes())
check('reader Python AST', True)
for name in ('resources', 'integer', 'oracle', 'micro_corpus', 'measurements'):
    get = lambda tree: next(x for x in tree.body if isinstance(x, ast.FunctionDef) and x.name == name)
    check(name + ' unchanged from old independent reader', ast.dump(get(new)) == ast.dump(get(old)))
args = SimpleNamespace(commit=reader.EXPECTED_COMMIT, plan_sha256=reader.EXPECTED_PLAN_SHA)
reader.frozen_binding(args)
check('exact new commit and plan accepted', True)
rejected('wrong commit rejected', lambda: reader.frozen_binding(SimpleNamespace(commit='0' * 40, plan_sha256=args.plan_sha256)))
rejected('wrong plan rejected', lambda: reader.frozen_binding(SimpleNamespace(commit=args.commit, plan_sha256='0' * 64)))
raw = reader.blob(repo, args.commit, reader.PLAN)
check('committed plan SHA', reader.sha(raw) == args.plan_sha256)
plan = json.loads(raw)
files = {}
for name, info in plan['source_snapshot'].items():
    data = reader.blob(repo, args.commit, name)
    check('Git snapshot ' + name, reader.sha(data) == info['sha256'] and len(data) == info['bytes'])
    files[name] = data
check('exact 27 source inputs', len(files) == 27)
manifest = json.loads(files[reader.PREFIX + 'handoff-manifest.json'])
check('exact 23-member manifest', len(manifest['files']) == 23 and reader.sha(files[reader.PREFIX + 'handoff-manifest.json']) == reader.MANIFEST)
expected = {reader.PREFIX + item['path'] for item in manifest['files']} | {reader.PREFIX + 'handoff-manifest.json', reader.PREFIX + 'ci_prototype.sh', '.github/workflows/minivec-score.yml', '.gitattributes'}
check('no extra/missing source members', set(files) == expected)
parent_data = files[reader.PREFIX + 'parent-source-manifest.json']
check('immutable original half manifest', reader.sha(parent_data) == reader.PARENT_MANIFEST)
parent = {x['path']: x for x in json.loads(parent_data)['files']}
for item in manifest['files']:
    data = files[reader.PREFIX + item['path']]
    check('manifest content ' + item['path'], reader.sha(data) == item['sha256'] and len(data) == item['bytes'])
    if item['relation_to_half_parent'] == 'unchanged':
        check('unchanged ancestor ' + item['path'], item['sha256'] == parent[item['path']]['sha256'] and item['bytes'] == parent[item['path']]['bytes'])
    elif item['relation_to_half_parent'] == 'changed':
        check('changed ancestor ' + item['path'], item['parent_sha256'] == parent[item['path']]['sha256'])
    else:
        check('new member ' + item['path'], item['relation_to_half_parent'] == 'added' and item['path'] not in parent and item['parent_sha256'] is None)
check('candidate bytes', reader.sha(files[reader.PREFIX + 'candidate_distance.h']) == reader.CANDIDATE_SHA)
check('oracle bytes reused unchanged', reader.sha(files[reader.PREFIX + 'oracle.bin']) == reader.ORACLE_SHA and len(files[reader.PREFIX + 'oracle.bin']) == 11425564)
proof = json.loads(files[reader.PREFIX + 'source-proof.json'])
reference = reader.blob(repo, proof['source_commit'], proof['source_git_path'])
check('reference actual original Git bytes', reference == files[reader.PREFIX + 'reference_distance.h'] and reader.sha(reference) == proof['reference_sha256'])
check('reference Git blob', hashlib.sha1(b'blob ' + str(len(reference)).encode() + b'\0' + reference).hexdigest() == proof['reference_git_blob'])
check('factor and independent experiment identity', proof['candidate_factor_exact'] == '268435457/1073741824' and proof['candidate_factor'] == '0.25L+0x1p-30L' and proof['parent_half_header_sha256'] == reader.HALF_HEADER and proof['experiment_id'] == plan['experiment_id'] == 'quarter-plus-margin-standalone-v1')
report = {'status': 'passed_source_identity_preflight_only', 'commit': args.commit, 'plan_sha256': args.plan_sha256, 'reader_sha256': reader.sha((W / 'analyze_quarter_margin_prototype.py').read_bytes()), 'checks': checks, 'check_count': len(checks), 'new_native_executions': 0, 'new_DB_runs': 0, 'new_performance_pairs': 0, 'actual_result_artifact_read': False, 'old_reader_modified': False}
(W / 'quarter-margin-reader-preflight.json').write_text(json.dumps(report, indent=2) + '\n', encoding='utf-8')
print(json.dumps({key: report[key] for key in ('status', 'check_count', 'reader_sha256', 'new_native_executions')}))
