"""Derive a separate strict reader; do not change the old reader or any result."""
from pathlib import Path

W = Path(__file__).resolve().parent
old = (W / 'analyze_tighter_bound_prototype.py').read_text(encoding='utf-8')
new = old.replace('Independent exact-source/resource/oracle/12-pair reader;',
                  'Independent quarter-plus-margin exact-source/resource/oracle/12-pair reader;')
new = new.replace('validation/iteration5-tighter-bound-prototype-preregistration.json',
                  'validation/iteration5-quarter-margin-prototype-preregistration.json')
new = new.replace('minivec/tools/tighter_bound/', 'minivec/tools/quarter_margin/')
new = new.replace('259b4cc06b2b5aaa0baf0680f5d60a4eacde48b26ea3225580fe250af66b761e',
                  '602bff53962b8b1711f1d2ee67431856c97e9d131e97b9a925bb0d400c7e1c70')
new = new.replace('tighter-bound-prototype-results', 'quarter-margin-prototype-results')
# The existing single prototype job is selected by the quarter marker; only
# artifact/source/output labels change, not the GitHub job's name.
new = new.replace("p['experiment_id']=='tighter-longdouble-certificate-prototype'",
                  "p['experiment_id']=='quarter-plus-margin-standalone-v1'")
new = new.replace("len(p['source_snapshot'])==18", "len(p['source_snapshot'])==27")
new = new.replace("len(manifest['files'])==14 and len({x['path'] for x in manifest['files']})==14",
                  "len(manifest['files'])==23 and len({x['path'] for x in manifest['files']})==23")
new = new.replace("'members':14", "'members':23")
new = new.replace("MASK=(1<<64)-1", """MASK=(1<<64)-1
EXPECTED_COMMIT='001aa6b279f3c1244a7b8dc01c5c7fcbd9cc455e'
EXPECTED_PLAN_SHA='e9a4ca2acd6b1174d6c9e8460d82881981270d201b679004b6f4c4048916feb8'
CANDIDATE_SHA='cfd6d6a2b111b2f9c72081bd33ba481343d375adb3b01405077e88516875284a'
ORACLE_SHA='74e1b99088943e073b5f4821844aabc7001a500ae2af9ef0c7dc309d8ed6262e'
PARENT_MANIFEST='259b4cc06b2b5aaa0baf0680f5d60a4eacde48b26ea3225580fe250af66b761e'
HALF_HEADER='bdcc9e587677b91c0e57a0da8dd63eda7160c62fb9121e22cf5db19d243bf7c7'

def frozen_binding(args):
    need(EXPECTED_COMMIT is not None and EXPECTED_PLAN_SHA is not None,'quarter reader awaiting frozen commit/plan; refuses evidence before binding')
    need(args.commit==EXPECTED_COMMIT and args.plan_sha256==EXPECTED_PLAN_SHA,'wrong quarter experiment binding')
""")
new = new.replace("    raw=args.plan.read_bytes();need(sha(raw)==args.plan_sha256,'frozen plan SHA differs')",
                  "    frozen_binding(args)\n    raw=args.plan.read_bytes();need(sha(raw)==args.plan_sha256,'frozen plan SHA differs')")
anchor = "    need(a.data('source-manifest.json')==f[PREFIX+'handoff-manifest.json'],'executed handoff differs')"
extra = """    expected_names={PREFIX+x['path'] for x in manifest['files']}|{PREFIX+'handoff-manifest.json',PREFIX+'ci_prototype.sh','.github/workflows/minivec-score.yml','.gitattributes'}
    need(set(f)==expected_names,'extra/missing committed quarter source input')
    parent_raw=f[PREFIX+'parent-source-manifest.json'];parent=readjson(parent_raw)
    need(sha(parent_raw)==PARENT_MANIFEST==manifest['parent_manifest_sha256'],'historical half source identity differs')
    parent_members={x['path']:x for x in parent['files']}
    for member in manifest['files']:
        name=member['path'];relation=member['relation_to_half_parent']
        if relation=='unchanged':need(member['sha256']==parent_members[name]['sha256'] and member['bytes']==parent_members[name]['bytes'],'claimed unchanged parent member differs')
        elif relation=='changed':need(member['parent_sha256']==parent_members[name]['sha256'],'changed member ancestry differs')
        else:need(relation=='added' and name not in parent_members and member['parent_sha256'] is None,'unknown member ancestry')
    need(sha(f[PREFIX+'oracle.bin'])==ORACLE_SHA and len(f[PREFIX+'oracle.bin'])==11425564,'frozen 6748-case oracle differs')
    history=readjson(f[PREFIX+'history.json']);prior=f[PREFIX+'inherited-tighter-only-attempt1-audit.json']
    need(sha(prior)==history['prior_root_oracle_failure']['audit_sha256'],'inherited failed audit differs')
    prior=readjson(prior)
    need(prior['status']=='verified_tool_oracle_semantics_error_no_performance_measurement' and prior['execution']['paired_performance_runs']==0 and history['old_micro_results_imported_as_new'] is False,'historical failure reclassified')
"""
assert new.count(anchor) == 1
new = new.replace(anchor, extra + anchor)
anchor = "    need(sha(f[PREFIX+'candidate_distance.h'])==proof['candidate_sha256'],'candidate source differs')"
replace = """    need(sha(f[PREFIX+'candidate_distance.h'])==proof['candidate_sha256']==CANDIDATE_SHA,'candidate source differs')
    need(proof['experiment_id']=='quarter-plus-margin-standalone-v1' and proof['parent_half_header_sha256']==HALF_HEADER and proof['candidate_factor']=='0.25L+0x1p-30L' and proof['candidate_factor_exact']=='268435457/1073741824','coefficient identity differs')
    need(proof['oracle_sha256']==ORACLE_SHA and proof['oracle_bytes']==11425564 and proof['oracle_cases']==6748,'source/oracle proof differs')
"""
assert new.count(anchor) == 1
new = new.replace(anchor, replace.rstrip())

# The frozen binary oracle is copied, not regenerated. Nothing else in the native
# build/run sequence or 3x4 paired timing protocol changes.
new = new.replace("       ('fixture-generation',None),('build-normal',normal+", "       ('build-normal',normal+")
new = new.replace("len(s['commands'])==len(commands)==23", "len(s['commands'])==len(commands)==22")
new = new.replace("    commands += [(f'micro-{name}-{i}'", "    need(s['fixture_generation_executed'] is False,'quarter oracle unexpectedly regenerated')\n    commands += [(f'micro-{name}-{i}'")
new = new.replace("        if argv is None:need(c['argv'][0].endswith('/python3') and c['argv'][1:]==['/prototype/make_fixtures.py','--output','/out/results/oracle.bin'],'oracle generator command differs')\n        else:need(c['argv']==argv,'actual compile/run flags differ '+name)",
                  "        need(c['argv']==argv,'actual compile/run flags differ '+name)")
new = new.replace("def audit(args):\n    raw=", "def audit(args):\n    frozen_binding(args)\n    raw=")
new = new.replace("    resource=resources(a,s);independent=oracle(a,s);n=native(a,s,f,independent['expected_native_check_count']);screen=measurements(a,s,p)",
"""    need(s['experiment_id']=='quarter-plus-margin-standalone-v1','old half result cannot be quarter result')
    need(a.data('results/oracle.bin')==f[PREFIX+'oracle.bin'] and a.data('results/oracle.json')==f[PREFIX+'oracle.json'],'actual copied oracle differs from frozen committed bytes')
    need(s['plan']=={'scenarios':list(SCENARIOS),'pairs_per_scenario':4,'orders':['AB','BA','AB','BA'],'rows':512,'repetitions_per_arm':64,'counter_instrumented_timing':False},'runner fixed plan differs')
    resource=resources(a,s);independent=oracle(a,s);n=native(a,s,f,independent['expected_native_check_count']);screen=measurements(a,s,p)""")
new = new.replace("'status':'verified_micro_evidence','resources':resource", "'status':'verified_micro_evidence','experiment_id':'quarter-plus-margin-standalone-v1','resources':resource")
new = new.replace("'No outliers removed. Unsupported/error attempts are preserved separately, not silently retried or counted as success.']}",
                  "'No outliers removed. Unsupported/error attempts are preserved separately, not silently retried or counted as success.',\n"
                  "      'The comparator is the canonical original kernel, not the historical half-bound kernel; cross-run ratios cannot establish quarter-versus-half gains.',\n"
                  "      'The new non-power-of-two multiplication may set FE_INEXACT. Guard/control preservation is distinct from complete sticky-fenv identity.',\n"
                  "      'Historical root oracle failure is retained as provenance and is not a new quarter result.']}" )
new = new.replace("'job_id':receipt.get('job_id'),'job_conclusion':j[0]['conclusion'] if j else None,'provided_jobs':len(jobs),'all_jobs_independently_enumerated':False}",
                  "'job_id':receipt.get('job_id'),'job_conclusion':j[0]['conclusion'] if j else None,'provided_jobs':len(jobs),'all_jobs_independently_enumerated':False,\n"
                  "       'job_id_independently_API_verified':bool(j),'API_scope':'Artifact API binds run/source/size/digest. Without a jobs API object, the coordinator-provided job ID and success conclusion are not independently API-established; raw CI exit and complete measurement evidence are separately checked.'}")

target = W / 'analyze_quarter_margin_prototype.py'
assert not target.exists(), 'refuse overwrite prepared reader'
target.write_text(new, encoding='utf-8', newline='\n')
print(target)
