# Quarter-plus-margin standalone screen

Decision: **passed for database integration investigation only**. No default adoption or official submission recommendation.

| Scenario | Wall C/B median | CPU C/B median | Wall median old → candidate (ms) | Worse wall/CPU pairs |
|---|---:|---:|---:|---:|
| fullmantissa128 | 0.763948 | 0.763941 | 5.322583 → 4.067848 | 0/4, 0/4 |
| fullmantissa512 | 0.345803 | 0.345793 | 70.138981 → 24.264684 | 0/4, 0/4 |
| grid128 | 1.005532 | 1.006422 | 3.615654 → 3.641402 | 4/4, 4/4 |

All 12 pairs remain. Both full-mantissa scenarios pass the frozen 5% / 3-of-4 / AB-and-BA requirements. Grid128 has four consistently slower pairs in each metric (8 negative metric entries); medians +0.5532% wall and +0.6422% CPU do not reach the frozen 2% guard. This is retained as negative evidence, not discarded as noise.

Untimed shadow integer fallback counts: 128 dimensions 45 → 10; 512 dimensions 161 → 39; grid 0 → 0. These are separate shadow counts, not measured production CPU fractions.

Verified: 27 committed input pins, 23 package members, raw ZIP API SHA/size and all 62 members, original Git reference, unchanged 6,748-case oracle independently recomputed, normal/sanitized 11,452,601 checks each, 4 ELF identities, 15 native executions and all 12 output checksums. Actual 1 CPU / 2 GiB / swap 0 constraints were checked before and after execution. DB runs and PGO builds: zero.

Comparison uses the canonical original scalar kernel, not the historical half-bound kernel. Do not derive quarter-versus-half gains from separate runs. This candidate can additionally set FE_INEXACT; it does not claim complete sticky-status equivalence.

API limitation: the supplied raw API response is an artifacts object only. It independently binds commit/run/artifact/size/digest; the coordinator-supplied job ID and job success are not separately established by a jobs API object. Raw CI exit and complete native/measurement evidence passed independently.

Source commit: `001aa6b279f3c1244a7b8dc01c5c7fcbd9cc455e`. Full absolute pairs and all negatives are preserved in the analysis and decision JSON.
