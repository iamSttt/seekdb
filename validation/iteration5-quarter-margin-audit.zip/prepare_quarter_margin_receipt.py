"""Preserve raw artifact API response and annotate supplied job provenance."""
import hashlib, json
from pathlib import Path

w = Path(__file__).resolve().parent
raw = (w / 'quarter-margin-api.json').read_bytes()
response = json.loads(raw)
assert set(response) == {'artifacts'} and len(response['artifacts']) == 1
artifact = response['artifacts'][0]
assert artifact['id'] == 14084205394 and artifact['workflow_run']['id'] == 43522172103
assert artifact['workflow_run']['head_sha'] == '001aa6b279f3c1244a7b8dc01c5c7fcbd9cc455e'
out = w / 'quarter-margin-api-receipt.json'
assert not out.exists()
receipt = {'commit': artifact['workflow_run']['head_sha'], 'run_id': artifact['workflow_run']['id'], 'job_id': 132218922969, 'artifact': artifact,
 'provenance': {'original_api_file': 'quarter-margin-api.json', 'original_api_bytes': len(raw), 'original_api_sha256': hashlib.sha256(raw).hexdigest(), 'artifact_object': 'unmodified JSON object from original artifacts[0]', 'job_id_source': 'coordinator supplied; no jobs API object provided', 'job_conclusion_independently_API_verified': False}}
out.write_text(json.dumps(receipt, indent=2) + '\n', encoding='utf-8')
print(out)
