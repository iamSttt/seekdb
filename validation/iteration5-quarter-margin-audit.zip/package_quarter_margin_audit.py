"""Compact verified result and immutable work-only audit bundle; no native execution."""
import hashlib, json, sys, zipfile
from pathlib import Path
from statistics import median

sys.dont_write_bytecode = True
from analyze_quant_batch_prototype import blob

w = Path(__file__).resolve().parent
repo = w / 'seekdb'
sha = lambda b: hashlib.sha256(b).hexdigest()
analysis_path = w / 'quarter-margin-independent-analysis.json'
analysis = json.loads(analysis_path.read_bytes())
assert analysis['status'] == 'verified_micro_evidence'
screen = analysis['screen']
summary = {}
for name, group in screen['groups'].items():
    summary[name] = {}
    for metric, values in group.items():
        summary[name][metric] = {key: values[key] for key in ('median','AB_median','BA_median','faster_pairs','candidate_worse_pairs')}
        summary[name][metric].update(
            baseline_median_ms=median(row['old'] for row in values['raw_pairs']) / 1e6,
            candidate_median_ms=median(row['candidate'] for row in values['raw_pairs']) / 1e6,
            paired_extra_ms=[(row['candidate'] - row['old']) / 1e6 for row in values['raw_pairs']])
decision = {
 'status': 'verified_standalone_screen_only', 'decision': screen['decision'],
 'api_binding': analysis['api_binding'], 'actual_host': 'AMD EPYC 9V74 80-Core Processor',
 'artifact_member_count': len(analysis['artifact_manifest']), 'source_inputs_verified': analysis['source_inputs_verified'],
 'resource': analysis['resources'], 'normal_and_sanitized_checks_each': analysis['native_evidence']['native_correctness_checks'],
 'independent_fixture_cases': analysis['independent_fixture_oracle']['cases'],
 'native_builds': 4, 'native_executions': 15, 'performance_pairs': 12, 'database_runs': 0, 'PGO_builds': 0,
 'ratios_candidate_over_canonical_original': summary,
 'untimed_shadow': screen['raw_diagnostics'],
 'primary_failed_metrics': screen['primary_failed_metrics'], 'grid_guard_triggers': screen['grid_guard_triggers'],
 'all_negative_pair_metrics': screen['all_negative_pair_metrics'], 'negative_pair_metric_count': len(screen['all_negative_pair_metrics']),
 'eligible_for_database_integration_investigation': screen['eligible_for_database_integration_investigation'],
 'default_adopted': False, 'official_submission_recommended': False, 'formal_submission_performed': False, 'official_score_prediction': None,
 'analysis': {'path': analysis_path.name, 'bytes': analysis_path.stat().st_size, 'sha256': sha(analysis_path.read_bytes())},
 'limitations': analysis['limitations'],
}
decision_path = w / 'quarter-margin-independent-decision.json'
assert not decision_path.exists()
decision_path.write_text(json.dumps(decision, indent=2) + '\n', encoding='utf-8')
lines = ['# Quarter-plus-margin standalone screen', '',
 'Decision: **passed for database integration investigation only**. No default adoption or official submission recommendation.', '',
 '| Scenario | Wall C/B median | CPU C/B median | Wall median old → candidate (ms) | Worse wall/CPU pairs |',
 '|---|---:|---:|---:|---:|']
for name, row in summary.items():
    wall, cpu = row['wall_ns'], row['thread_cpu_ns']
    lines.append(f"| {name} | {wall['median']:.6f} | {cpu['median']:.6f} | {wall['baseline_median_ms']:.6f} → {wall['candidate_median_ms']:.6f} | {wall['candidate_worse_pairs']}/4, {cpu['candidate_worse_pairs']}/4 |")
lines += ['',
 'All 12 pairs remain. Both full-mantissa scenarios pass the frozen 5% / 3-of-4 / AB-and-BA requirements. Grid128 has four consistently slower pairs in each metric (8 negative metric entries); medians +0.5532% wall and +0.6422% CPU do not reach the frozen 2% guard. This is retained as negative evidence, not discarded as noise.', '',
 'Untimed shadow integer fallback counts: 128 dimensions 45 → 10; 512 dimensions 161 → 39; grid 0 → 0. These are separate shadow counts, not measured production CPU fractions.', '',
 'Verified: 27 committed input pins, 23 package members, raw ZIP API SHA/size and all 62 members, original Git reference, unchanged 6,748-case oracle independently recomputed, normal/sanitized 11,452,601 checks each, 4 ELF identities, 15 native executions and all 12 output checksums. Actual 1 CPU / 2 GiB / swap 0 constraints were checked before and after execution. DB runs and PGO builds: zero.', '',
 'Comparison uses the canonical original scalar kernel, not the historical half-bound kernel. Do not derive quarter-versus-half gains from separate runs. This candidate can additionally set FE_INEXACT; it does not claim complete sticky-status equivalence.', '',
 'API limitation: the supplied raw API response is an artifacts object only. It independently binds commit/run/artifact/size/digest; the coordinator-supplied job ID and job success are not separately established by a jobs API object. Raw CI exit and complete native/measurement evidence passed independently.', '',
 'Source commit: `001aa6b279f3c1244a7b8dc01c5c7fcbd9cc455e`. Full absolute pairs and all negatives are preserved in the analysis and decision JSON.']
(w / 'quarter-margin-independent-decision.md').write_text('\n'.join(lines) + '\n', encoding='utf-8')
names = [
 'analyze_quarter_margin_prototype.py','analyze_tighter_bound_prototype.py','analyze_quant_batch_prototype.py','analyze_crc_root.py',
 'prepare_quarter_micro_reader.py','check_quarter_micro_reader.py','quarter-margin-reader-preflight.json',
 'prepare_quarter_margin_receipt.py','quarter-margin-api.json','quarter-margin-api-receipt.json',
 'quarter-margin-independent-analysis.json','quarter-margin-independent-decision.json','quarter-margin-independent-decision.md',
 'package_quarter_margin_audit.py',
]
files = {name: (w / name).read_bytes() for name in names}
commit = analysis['api_binding']['commit']
gitpaths = ['validation/iteration5-quarter-margin-prototype-preregistration.json']
gitpaths += ['minivec/tools/quarter_margin/' + name for name in ('source-proof.json','handoff-manifest.json','parent-source-manifest.json','PROOF.md','proof-exact-rational.json','history.json','inherited-tighter-only-attempt1-audit.json')]
for path in gitpaths:
    files['git-source/' + path] = blob(repo, commit, path)
manifest = {
 'status': 'verified_work_only_audit_bundle', 'source_commit': commit,
 'raw_archive': {'path':'validation/iteration5-quarter-margin-raw.zip','bytes':2808622,'sha256':'04cb55eaf78e489fa52bf0910c039eb10fa406942deedc20171e411f75e54877','included_in_this_audit_zip':False},
 'files': {name:{'bytes':len(data),'sha256':sha(data)} for name,data in sorted(files.items())},
 'replay_note': 'Use the separate exact raw archive plus Git source objects at the fixed commit. This audit bundle does not duplicate raw ELF/oracle members.',
 'new_native_or_DB_runs_by_audit':0,
}
files['audit-manifest.json'] = (json.dumps(manifest, indent=2) + '\n').encode()
archive = w / 'quarter-margin-independent-audit.zip'
assert not archive.exists()
with zipfile.ZipFile(archive, 'w', compression=zipfile.ZIP_DEFLATED, compresslevel=9) as out:
    for name,data in sorted(files.items()):
        info = zipfile.ZipInfo(name, date_time=(2026,11,14,0,0,0)); info.compress_type = zipfile.ZIP_DEFLATED
        out.writestr(info, data, compresslevel=9)
with zipfile.ZipFile(archive) as check:
    assert set(check.namelist()) == set(files)
    assert all(check.read(name) == data for name,data in files.items())
receipt = {'archive':str(archive),'bytes':archive.stat().st_size,'sha256':sha(archive.read_bytes()),'members':len(files),'decision':screen['decision'],'negative_pair_metric_count':len(screen['all_negative_pair_metrics']), 'analysis_sha256':sha(analysis_path.read_bytes()),'decision_sha256':sha(decision_path.read_bytes()),'new_native_or_DB_runs':0}
(w / 'quarter-margin-independent-audit-receipt.json').write_text(json.dumps(receipt, indent=2) + '\n', encoding='utf-8')
print(json.dumps(receipt))
