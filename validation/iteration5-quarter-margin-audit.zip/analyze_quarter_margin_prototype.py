"""Independent quarter-plus-margin exact-source/resource/oracle/12-pair reader; never runs native code."""
import argparse,ast,hashlib,json,math,re,struct
from fractions import Fraction
from pathlib import Path
from statistics import median
from analyze_quant_batch_prototype import Archive,need,sha,readjson,blob
from analyze_crc_root import verify_archive

PLAN='validation/iteration5-quarter-margin-prototype-preregistration.json'
PREFIX='minivec/tools/quarter_margin/'
MANIFEST='602bff53962b8b1711f1d2ee67431856c97e9d131e97b9a925bb0d400c7e1c70'
IMAGE='gcc:13.3.0-bookworm@sha256:1d71f0f3450214bef38fe09e6f610fb6cca90cf97b43f4ce845bfc32a4168818'
SCENARIOS=('fullmantissa128','fullmantissa512','grid128')
MASK=(1<<64)-1
EXPECTED_COMMIT='001aa6b279f3c1244a7b8dc01c5c7fcbd9cc455e'
EXPECTED_PLAN_SHA='e9a4ca2acd6b1174d6c9e8460d82881981270d201b679004b6f4c4048916feb8'
CANDIDATE_SHA='cfd6d6a2b111b2f9c72081bd33ba481343d375adb3b01405077e88516875284a'
ORACLE_SHA='74e1b99088943e073b5f4821844aabc7001a500ae2af9ef0c7dc309d8ed6262e'
PARENT_MANIFEST='259b4cc06b2b5aaa0baf0680f5d60a4eacde48b26ea3225580fe250af66b761e'
HALF_HEADER='bdcc9e587677b91c0e57a0da8dd63eda7160c62fb9121e22cf5db19d243bf7c7'

def frozen_binding(args):
    need(EXPECTED_COMMIT is not None and EXPECTED_PLAN_SHA is not None,'quarter reader awaiting frozen commit/plan; refuses evidence before binding')
    need(args.commit==EXPECTED_COMMIT and args.plan_sha256==EXPECTED_PLAN_SHA,'wrong quarter experiment binding')


def api(receipt,raw,commit):
    a=receipt['artifact'];need(receipt['commit']==a['workflow_run']['head_sha']==commit and receipt['run_id']==a['workflow_run']['id'],'API run/source differs')
    need(a['name']=='quarter-margin-prototype-results' and a['size_in_bytes']==len(raw) and a['digest']=='sha256:'+sha(raw) and a['expired'] is False,'API artifact differs')
    need(a['url']=='https://api.github.com/repos/iamSttt/seekdb/actions/artifacts/'+str(a['id']),'API repository differs')
    jobs=receipt.get('jobs',{}).get('jobs',[]);j=[j for j in jobs if j['id']==receipt.get('job_id')]
    if jobs:need(len(j)==1 and j[0]['run_id']==receipt['run_id'] and j[0]['name']=='tighter-bound-prototype' and j[0]['status']=='completed','API requested job differs')
    return {'commit':commit,'run_id':receipt['run_id'],'artifact_id':a['id'],'artifact_sha256':sha(raw),'artifact_bytes':len(raw),
       'job_id':receipt.get('job_id'),'job_conclusion':j[0]['conclusion'] if j else None,'provided_jobs':len(jobs),'all_jobs_independently_enumerated':False,
       'job_id_independently_API_verified':bool(j),'API_scope':'Artifact API binds run/source/size/digest. Without a jobs API object, the coordinator-provided job ID and success conclusion are not independently API-established; raw CI exit and complete measurement evidence are separately checked.'}

def sources(a,args):
    frozen_binding(args)
    raw=args.plan.read_bytes();need(sha(raw)==args.plan_sha256,'frozen plan SHA differs')
    need(raw==blob(args.repo,args.commit,PLAN),'plan is not exact committed file');p=readjson(raw)
    need(p['experiment_id']=='quarter-plus-margin-standalone-v1' and p['default_adoption'] is False and p['new_native_executions_observed']==0,'prereg scope differs')
    f={}
    need(len(p['source_snapshot'])==27,'source input inventory differs')
    for name,item in p['source_snapshot'].items():
        b=blob(args.repo,args.commit,name);need(len(b)==item['bytes'] and sha(b)==item['sha256'],'exact source differs '+name);f[name]=b
    for name,item in p['proofs'].items():
        b=blob(args.repo,args.commit,name);need(len(b)==item['bytes'] and sha(b)==item['sha256'],'mathematical/static proof differs')
    manifest=readjson(f[PREFIX+'handoff-manifest.json']);need(sha(f[PREFIX+'handoff-manifest.json'])==MANIFEST==p['prototype_manifest_sha256'],'handoff differs')
    need(len(manifest['files'])==23 and len({x['path'] for x in manifest['files']})==23,'handoff inventory')
    for item in manifest['files']:
        b=f[PREFIX+item['path']];need(len(b)==item['bytes'] and sha(b)==item['sha256'],'handoff member differs')
    expected_names={PREFIX+x['path'] for x in manifest['files']}|{PREFIX+'handoff-manifest.json',PREFIX+'ci_prototype.sh','.github/workflows/minivec-score.yml','.gitattributes'}
    need(set(f)==expected_names,'extra/missing committed quarter source input')
    parent_raw=f[PREFIX+'parent-source-manifest.json'];parent=readjson(parent_raw)
    need(sha(parent_raw)==PARENT_MANIFEST==manifest['parent_manifest_sha256'],'historical half source identity differs')
    parent_members={x['path']:x for x in parent['files']}
    for member in manifest['files']:
        name=member['path'];relation=member['relation_to_half_parent']
        if relation=='unchanged':need(member['sha256']==parent_members[name]['sha256'] and member['bytes']==parent_members[name]['bytes'],'claimed unchanged parent member differs')
        elif relation=='changed':need(member['parent_sha256']==parent_members[name]['sha256'],'changed member ancestry differs')
        else:need(relation=='added' and name not in parent_members and member['parent_sha256'] is None,'unknown member ancestry')
    need(sha(f[PREFIX+'oracle.bin'])==ORACLE_SHA and len(f[PREFIX+'oracle.bin'])==11425564,'frozen 6748-case oracle differs')
    history=readjson(f[PREFIX+'history.json']);prior=f[PREFIX+'inherited-tighter-only-attempt1-audit.json']
    need(sha(prior)==history['prior_root_oracle_failure']['audit_sha256'],'inherited failed audit differs')
    prior=readjson(prior)
    need(prior['status']=='verified_tool_oracle_semantics_error_no_performance_measurement' and prior['execution']['paired_performance_runs']==0 and history['old_micro_results_imported_as_new'] is False,'historical failure reclassified')
    need(a.data('source-manifest.json')==f[PREFIX+'handoff-manifest.json'],'executed handoff differs')
    need(a.json('source-verification.json')=={'status':'verified','members':23,'manifest_sha256':MANIFEST,'ci_wrapper_sha256':sha(f[PREFIX+'ci_prototype.sh'])},'wrapper source proof differs')
    proof=readjson(f[PREFIX+'source-proof.json']);ref=blob(args.repo,proof['source_commit'],proof['source_git_path'])
    need(ref==f[PREFIX+'reference_distance.h'] and sha(ref)==proof['reference_sha256'] and hashlib.sha1(b'blob '+str(len(ref)).encode()+b'\0'+ref).hexdigest()==proof['reference_git_blob'],'original production reference differs')
    need(sha(f[PREFIX+'candidate_distance.h'])==proof['candidate_sha256']==CANDIDATE_SHA,'candidate source differs')
    need(proof['experiment_id']=='quarter-plus-margin-standalone-v1' and proof['parent_half_header_sha256']==HALF_HEADER and proof['candidate_factor']=='0.25L+0x1p-30L' and proof['candidate_factor_exact']=='268435457/1073741824','coefficient identity differs')
    need(proof['oracle_sha256']==ORACLE_SHA and proof['oracle_bytes']==11425564 and proof['oracle_cases']==6748,'source/oracle proof differs')
    actual={}
    for line in a.data('input-sha256.txt').decode().splitlines():
        h,name=line.split(maxsplit=1);need(name not in actual,'duplicate source input');actual[name]=h
    need(actual=={n:sha(b) for n,b in f.items() if n!='.gitattributes'},'executed Git inputs differ')
    need(a.data('harness-commit.txt').decode().strip()==args.commit,'actual harness commit differs')
    wrapper=f[PREFIX+'ci_prototype.sh'].decode();entries=re.findall(r'cat > "\$output/container-entry.py" <<\x27PY\x27\n(.*?)\nPY\n',wrapper,re.S)
    need(len(entries)==1 and a.data('container-entry.py')==(entries[0]+'\n').encode(),'executed container entry differs')
    return p,f

def resources(a,s):
    cpu=int(a.data('requested-cpu.txt'));need(cpu>=0,'CPU invalid')
    before=a.json('resource-preflight.json');after=a.json('resource-postflight.json')
    need(before['status']=='verified' and before['native_started'] is False and before['database_runs']==before['pgo_builds']==0 and before['affinity']==[cpu],'real pre-native cap proof absent')
    need(after['status']=='verified' and after['runner_exit_code']==0 and after['affinity']==[cpu],'real post-run cap proof absent')
    for where in ('preflight-','results/'):
        q,period=map(int,a.data(where+'cpu-max.txt').decode().split());need(q==period and period>0,'actual CPU quota differs')
        need(a.data(where+'memory-max.txt').strip()==b'2147483648' and a.data(where+'memory-swap-max.txt').strip()==b'0','actual memory/swap differs')
        status=dict(x.split(':',1) for x in a.data(where+'proc-status.txt').decode().splitlines() if ':' in x)
        need(status['Cpus_allowed_list'].strip()==str(cpu),'actual driver affinity differs')
    for name,value in before['observed'].items():need(value==a.data('preflight-'+name+'.txt').decode().strip(),'preflight raw snapshot differs')
    q,period=map(int,after['cpu.max'].split());need(q==period and period>0 and after['memory.max']=='2147483648' and after['memory.swap.max']=='0','postflight actual caps differ')
    need(s['affinity']=={'before':[cpu],'selected':[cpu]} and not s.get('unavailable_resource_files'),'runner affinity missing')
    need(a.json('resource-verification.json')=={'status':'verified','cpu_quota':q,'cpu_period':period,'memory_max':2147483648,'swap_max':0,'cpu_affinity':[cpu],'database_runs':0,'pgo_builds':0,'native_compilations_completed':4,'native_executions_completed':15},'wrapper resource summary differs')
    start,end,im=[a.json(n)[0] for n in ('container-start-inspect.json','container-final-inspect.json','tooling-image-inspect.json')]
    need(start['Id']==end['Id']==a.data('container-id.txt').decode().strip() and start['Image']==end['Image']==im['Id'],'container/image identity differs')
    need('gcc@'+IMAGE.split('@')[1] in im['RepoDigests'],'toolchain digest differs')
    need(end['State']['ExitCode']==0 and not end['State']['OOMKilled'] and not end['State']['Running'],'container failed/OOM/incomplete')
    for obj in (start,end):
        h=obj['HostConfig'];need(h['NetworkMode']=='none' and h['CpusetCpus']==str(cpu) and h['NanoCpus']==1000000000 and h['Memory']==h['MemorySwap']==2147483648 and h['PidsLimit']==128,'Docker resources differ')
        mounts={x['Destination']:x for x in obj['Mounts']};need(set(mounts)=={'/prototype','/out'} and mounts['/prototype']['RW'] is False and mounts['/out']['RW'] is True,'source/output mounts differ')
        need(obj['Config']['Cmd']==['bash','-c','set -euo pipefail; command -v python3; exec python3 /out/container-entry.py'],'container command differs')
    return {'actual_cpu':cpu,'cpu_max':[q,period],'memory_max':2147483648,'swap_max':0,'container_id':end['Id'],'toolchain_image_id':im['Id'],
      'scope':'Live parent cgroup/affinity checked before and after native runner; runner/children inherit the constrained container. No per-native-process resource traces.'}

def integer(bits):
    e=(bits>>23)&255;need(e!=255,'nonfinite independent fixture')
    n=((bits&0x7fffff)|(0x800000 if e else 0))<<(e-1 if e else 0)
    return -n if bits>>31 else n

def oracle(a,s):
    raw=a.data('results/oracle.bin');meta=a.json('results/oracle.json');need(meta==s['oracle'] and meta['sha256']==sha(raw) and meta['bytes']==len(raw),'oracle identity differs')
    need(raw[:8]==b'MVTLB1\0\0','oracle magic');count=struct.unpack_from('<I',raw,8)[0];at=12;kinds={};sum_n=0;max_n=0
    need(count==6748==meta['cases'],'fixture case inventory differs')
    for _ in range(count):
        n,expected,kind=struct.unpack_from('<IQI',raw,at);at+=16
        need(n<=262144 and kind in (0,1,2) and at+8*n<=len(raw),'fixture bounds')
        lhs=struct.unpack_from('<'+'I'*n,raw,at);rhs=struct.unpack_from('<'+'I'*n,raw,at+4*n);at+=8*n
        total=sum((integer(x)-integer(y))**2 for x,y in zip(lhs,rhs))
        actual=struct.unpack('<Q',struct.pack('<d',float(Fraction(total,1<<298))))[0]
        need(actual==expected,'independent Fraction expected bits differ')
        kinds[str(kind)]=kinds.get(str(kind),0)+1;sum_n+=n;max_n=max(max_n,n)
    need(at==len(raw) and kinds==meta['kinds']=={'0':6558,'1':180,'2':10} and max_n==meta['maximum_dimension']==262144,'fixture tail/kind inventory differs')
    checks=57+20*count+8*sum_n
    return {'cases':count,'kinds':kinds,'maximum_dimension':max_n,'sha256':sha(raw),'independently_recomputed_expected_bits':count,'expected_native_check_count':checks}

def native(a,s,f,expected_checks):
    need(s['database_runs']==s['pgo_builds']==0 and s['native_compilation_attempts']==s['native_compilations_completed']==4 and s['native_execution_attempts']==s['native_executions_completed']==15,'native execution inventory differs')
    need(s['source_sha256']=={n[len(PREFIX):]:sha(b) for n,b in f.items() if n.startswith(PREFIX)},'actual mounted source inventory differs')
    need(s['source_proof']==readjson(f[PREFIX+'source-proof.json']),'source proof differs')
    need(a.data('results/compiler-version.log').strip()==a.data('preflight-compiler-version.txt').strip()==b'13.3.0' and s['compiler']==a.data('results/compiler.log').decode().splitlines()[0],'compiler version differs')
    flags=['g++','-std=c++17','-fno-math-errno','-pthread'];normal=flags+['-O3'];san=flags+['-O1','-g','-fno-omit-frame-pointer','-fsanitize=address,undefined','-no-pie']
    commands=[('compiler',['g++','--version']),('compiler-version',['g++','-dumpfullversion']),('cpu',['lscpu']),
       ('build-normal',normal+['/prototype/test_tighter_bound.cpp','-o','/out/results/normal']),('normal',['/out/results/normal','/out/results/oracle.bin']),
       ('build-sanitized',san+['/prototype/test_tighter_bound.cpp','-o','/out/results/sanitized']),('sanitized',['/out/results/sanitized','/out/results/oracle.bin']),
       ('build-diagnostic',normal+['-I/out/results/shadow','/prototype/diagnostic_counts.cpp','-o','/out/results/diagnostic']),('diagnostic',['/out/results/diagnostic']),
       ('build-micro',normal+['/prototype/benchmark_tighter_bound.cpp','-o','/out/results/micro'])]
    need(s['fixture_generation_executed'] is False,'quarter oracle unexpectedly regenerated')
    commands += [(f'micro-{name}-{i}',['/out/results/micro',name,'AB' if i%2==0 else 'BA']) for i in range(4) for name in SCENARIOS]
    need(len(s['commands'])==len(commands)==22,'actual command inventory differs')
    for c,(name,argv) in zip(s['commands'],commands):
        need(c['name']==name and c['exit_code']==0 and 'status' not in c,'command failed/timeout')
        need(c['argv']==argv,'actual compile/run flags differ '+name)
        need('results/'+name+'.log' in a.inventory,'command log absent')
    for mode in ('normal','sanitized'):
        text=a.data('results/'+mode+'.log').decode()
        need(re.findall(r'^tighter_bound_checks=(\d+)$',text,re.M)==[str(expected_checks)] and text.splitlines().count('tighter_bound=PASS')==1,'native oracle count/marker differs')
        need(re.findall(r'^tighter_bound_cases=(\d+) midpoint_fixtures=(\d+) rescue_fixtures=(\d+)$',text,re.M)==[('6748','180','10')],'native fixture coverage differs')
        need(not any(x in text for x in ('ERROR: AddressSanitizer','runtime error:','FAIL ')),'native diagnostic failure')
    need(s['correctness_checks']=={'normal':expected_checks,'sanitized':expected_checks},'normal/san summary count differs')
    binaries={}
    for name in ('normal','sanitized','diagnostic','micro'):
        raw=a.data('results/'+name);need(raw[:6]==b'\x7fELF\x02\x01' and int.from_bytes(raw[18:20],'little')==62,'ELF class differs');binaries[name]=sha(raw)
    need(binaries==s['binary_sha256'],'actual four ELF identity differs')
    # Reproduce only the frozen text transform, never execute diagnostic code.
    tree=ast.parse(f[PREFIX+'run_linux.py']);node=next(n for n in tree.body if isinstance(n,ast.FunctionDef) and n.name=='shadow_header')
    namespace={'require':need};exec(compile(ast.Module(body=[node],type_ignores=[]),'frozen-shadow-transform','exec'),namespace)
    shadow={}
    for old,new in (('reference_distance.h','reference_shadow.h'),('candidate_distance.h','candidate_shadow.h')):
        data=namespace['shadow_header'](f[PREFIX+old].decode()).encode();need(data==a.data('results/shadow/'+new),'shadow counter source differs');shadow[new]=sha(data)
    data=f[PREFIX+'comparison.h'].decode().replace('reference_distance.h','reference_shadow.h').replace('candidate_distance.h','candidate_shadow.h').encode()
    need(data==a.data('results/shadow/shadow_comparison.h'),'shadow comparison differs');shadow['shadow_comparison.h']=sha(data)
    need(shadow==s['shadow_source_sha256'],'shadow source identity differs')
    return {'binary_sha256':binaries,'native_correctness_checks':expected_checks,'native_builds':4,'native_executions':15,'shadow_source_sha256':shadow,'DB_runs':0,'PGO_builds':0}

def micro_corpus(name):
    dim=512 if name=='fullmantissa512' else 128;grid=name=='grid128';state=0x714cc63bb4f10829^dim^(0xa5 if grid else 0)
    def next64():
        nonlocal state
        state=(state+0x9e3779b97f4a7c15)&MASK;z=state
        z=((z^(z>>30))*0xbf58476d1ce4e5b9)&MASK;z=((z^(z>>27))*0x94d049bb133111eb)&MASK
        return z^(z>>31)
    def value():
        x=next64()
        if grid:
            n=x%49141-24570;bits=struct.unpack('<I',struct.pack('<f',n/4096))[0];return bits,n<<14
        exponent=124+((x>>24)%5);mant=x&0x7fffff;bits=((x>>63)<<31)|(exponent<<23)|mant
        n=(mant|0x800000)<<(exponent-124);return bits,-n if x>>63 else n
    aa=[];bb=[];total=0;checksum=0
    for i in range(512*dim):
        a,x=value();b,y=value();aa.append(a);bb.append(b);total+=(x-y)**2
        if (i+1)%dim==0:
            checksum=(checksum+struct.unpack('<Q',struct.pack('<d',float(Fraction(total,1<<52))))[0])&MASK;total=0
    h=1469598103934665603
    for vals in (aa,bb):
        for raw in vals:
            for i in range(4):h=((h^((raw>>(8*i))&255))*1099511628211)&MASK
    return {'dimension':dim,'dataset_fnv64':f'{h:016x}','expected_checksum':f'{(checksum*64)&MASK:016x}'}

def measurements(a,s,p):
    diagnostics=[readjson(x) for x in a.data('results/diagnostic.log').splitlines() if x]
    need(diagnostics==s['diagnostic'] and [x['scenario'] for x in diagnostics]==list(SCENARIOS)+['analytic_midpoint_rescue_not_timed'],'diagnostic raw inventory differs')
    natural={}
    for d in diagnostics:
        old,new=d['old'],d['candidate'];n=1 if d['scenario'].startswith('analytic_') else 512
        need(set(old)==set(new)=={'calls','old_cert','tight_rescue','integer'} and all(type(v) is int and v>=0 for side in (old,new) for v in side.values()),'invalid diagnostic count')
        need(old['calls']==new['calls']==n and old['old_cert']==new['old_cert'] and old['tight_rescue']==0 and old['old_cert']+old['integer']==n and new['old_cert']+new['tight_rescue']+new['integer']==n and old['integer']==new['tight_rescue']+new['integer'],'counter conservation differs')
        if d['scenario']=='grid128':need(old['integer']==0,'grid old path has unexpected fallback')
        if d['scenario'].startswith('analytic_'):need(old['integer']==new['tight_rescue']==1,'analytic rescue fixture failed')
        else:natural[d['scenario']]=new['tight_rescue']
    pairs=[];corpora={name:micro_corpus(name) for name in SCENARIOS}
    for i in range(4):
        for name in SCENARIOS:
            row=readjson(a.data(f'results/micro-{name}-{i}.log'));row['pair']=i
            need(row['scenario']==name and row['order']==('AB' if i%2==0 else 'BA') and row['rows']==512 and row['dimension']==corpora[name]['dimension'] and row['repetitions']==64 and row['counter_instrumented'] is False,'micro plan differs')
            need(row['dataset_fnv64']==corpora[name]['dataset_fnv64'],'independent dataset fingerprint differs')
            need([m['role'] for m in row['measurements']]==['old','candidate'],'micro role inventory differs')
            for m in row['measurements']:
                need(m['checksum']==corpora[name]['expected_checksum'],'independent complete-scan checksum differs')
                need(all(type(m[k]) is int and m[k]>0 for k in ('wall_ns','thread_cpu_ns')),'invalid timing')
                need(all(type(m[k]) is int and m[k]>=0 for k in ('minor_faults','major_faults','voluntary_switches','involuntary_switches')),'invalid fault/context counter')
            pairs.append(row)
    need(pairs==s['pairs'],'raw twelve pair logs differ from summary')
    groups={};negative=[];failed=[];guards=[]
    rule=p['screen']['fullmantissa128_and512_separately']
    need(rule=={'metrics':'wall and thread CPU separately','median_ratio_max':0.95,'strictly_faster_pairs_min':3,'AB_median_strictly_below':1.0,'BA_median_strictly_below':1.0},'frozen screen rule mismatch')
    for name in SCENARIOS:
        rows=[x for x in pairs if x['scenario']==name];groups[name]={}
        for metric in ('wall_ns','thread_cpu_ns'):
            ratios=[x['measurements'][1][metric]/x['measurements'][0][metric] for x in rows]
            stats={'ratios':ratios,'median':median(ratios),'AB_median':median(ratios[::2]),'BA_median':median(ratios[1::2]),'faster_pairs':sum(r<1 for r in ratios),'candidate_worse_pairs':sum(r>1 for r in ratios),'raw_pairs':[{'pair':x['pair'],'order':x['order'],'old':x['measurements'][0][metric],'candidate':x['measurements'][1][metric]} for x in rows]}
            need(s['groups'][name][metric]=={'candidate_over_old':ratios,'median':stats['median'],'candidate_worse_pairs':stats['candidate_worse_pairs']},'runner arithmetic differs')
            groups[name][metric]=stats
            for x,ratio in zip(stats['raw_pairs'],ratios):
                if ratio>1:negative.append({'scenario':name,'metric':metric,'ratio':ratio,**x})
            if name=='grid128':
                if all(stats[k]>1.02 for k in ('median','AB_median','BA_median')):guards.append({'scenario':name,'metric':metric})
            else:
                conditions={'median':stats['median']<=rule['median_ratio_max'],'faster':stats['faster_pairs']>=rule['strictly_faster_pairs_min'],'AB':stats['AB_median']<rule['AB_median_strictly_below'],'BA':stats['BA_median']<rule['BA_median_strictly_below']}
                if not all(conditions.values()):failed.append({'scenario':name,'metric':metric,'conditions':conditions})
    mechanism=all(natural[x]>0 for x in SCENARIOS[:2]);eligible=mechanism and not failed and not guards
    return {'pairs':pairs,'groups':groups,'corpus_reproduction':corpora,'raw_diagnostics':diagnostics,'positive_natural_rescue':mechanism,'natural_rescue_counts':natural,'primary_failed_metrics':failed,'grid_guard_triggers':guards,'all_negative_pair_metrics':negative,
       'eligible_for_database_integration_investigation':eligible,'automatic_adoption':False,'official_score_prediction':None,
       'decision':'mechanism_screen_passed_DB_investigation_only' if eligible else 'mechanism_screen_not_passed_no_DB_gain_claim'}

def audit(args):
    frozen_binding(args)
    raw=args.archive.read_bytes();a=Archive(raw);receipt=readjson(args.receipt.read_bytes());binding=api(receipt,raw,args.commit)
    verify_archive(args.input,args.archive,binding['artifact_sha256'],len(raw));p,f=sources(a,args)
    ci=a.json('ci-status.json');need(ci['database_runs']==ci['pgo_builds']==ci['container_builds']==0,'wrapper DB/rootPGO claim differs')
    base={'api_binding':binding,'plan_sha256':args.plan_sha256,'source_inputs_verified':len(f),'artifact_manifest':a.inventory,'new_native_executions_by_reader':0,'new_database_runs_by_reader':0,'formal_submission':False,'automatic_adoption':False}
    if ci['exit_code']!=0 or binding['job_conclusion'] not in (None,'success'):
        return {**base,'status':'verified_failed_or_incomplete_attempt','CI_status':ci,'partial_runner_summary':a.json('results/summary.json') if 'results/summary.json' in a.inventory else None,'performance_screen_evaluated':False}
    need(a.json('runner-exit.json')=={'exit_code':0,'database_runs':0,'pgo_builds':0},'runner failed')
    s=a.json('results/summary.json');need(s['status']=='correctness_and_micro_completed','runner incomplete')
    need(s['experiment_id']=='quarter-plus-margin-standalone-v1','old half result cannot be quarter result')
    need(a.data('results/oracle.bin')==f[PREFIX+'oracle.bin'] and a.data('results/oracle.json')==f[PREFIX+'oracle.json'],'actual copied oracle differs from frozen committed bytes')
    need(s['plan']=={'scenarios':list(SCENARIOS),'pairs_per_scenario':4,'orders':['AB','BA','AB','BA'],'rows':512,'repetitions_per_arm':64,'counter_instrumented_timing':False},'runner fixed plan differs')
    resource=resources(a,s);independent=oracle(a,s);n=native(a,s,f,independent['expected_native_check_count']);screen=measurements(a,s,p)
    return {**base,'status':'verified_micro_evidence','experiment_id':'quarter-plus-margin-standalone-v1','resources':resource,'independent_fixture_oracle':independent,'native_evidence':n,'screen':screen,
      'limitations':['Twelve standalone scalar-call pairs without PGO/SQL/index/TopK/storage; no official-score or database throughput conclusion.',
      'Counters belong to separate untimed shadow ELF. They are not production CPU percentages; artificial rescue fixture never enters micro timing.',
      'Raw fixture expected bits and micro checksums are independently recomputed; native results are established by the Git-bound test assertions/logs and ELF identities, not offline execution.',
      'No outliers removed. Unsupported/error attempts are preserved separately, not silently retried or counted as success.',
      'The comparator is the canonical original kernel, not the historical half-bound kernel; cross-run ratios cannot establish quarter-versus-half gains.',
      'The new non-power-of-two multiplication may set FE_INEXACT. Guard/control preservation is distinct from complete sticky-fenv identity.',
      'Historical root oracle failure is retained as provenance and is not a new quarter result.']}

def main():
    ap=argparse.ArgumentParser(description=__doc__)
    for name in ('input','archive','receipt','plan','output'):ap.add_argument('--'+name,type=Path,required=True)
    ap.add_argument('--repo',type=Path,default=Path(__file__).resolve().parent/'seekdb');ap.add_argument('--commit',required=True);ap.add_argument('--plan-sha256',required=True)
    args=ap.parse_args();need(not args.output.exists(),'refuse overwrite existing audit');need(re.fullmatch('[0-9a-f]{40}',args.commit) and re.fullmatch('[0-9a-f]{64}',args.plan_sha256),'full immutable identity required')
    try:result=audit(args)
    except Exception as exc:
        args.output.with_suffix('.reader-error.json').write_text(json.dumps({'status':'evidence_not_verified','error':str(exc),'new_native_runs':0,'new_DB_runs':0},indent=2)+'\n');raise
    args.output.write_text(json.dumps(result,indent=2,allow_nan=False)+'\n',encoding='utf8')
    print(json.dumps({'status':result['status'],'decision':result.get('screen',{}).get('decision'),'negative_pair_metrics':len(result.get('screen',{}).get('all_negative_pair_metrics',[]))}))

if __name__=='__main__':main()
