This archive records a diagnostic, not a release-candidate performance pass. Original failed attempt remains separately archived.
Replay: python audit/analyze_exact_cost_diagnostic.py --repo <seekdb Git checkout> --archive <iteration5-exact-cost-attempt2-raw.zip> --receipt audit/exact-cost-attempt2-api-receipt.json --output <new analysis.json>
The Git checkout must contain the pinned source commits and validation/iteration4-bulk-loop-raw.zip; all inputs are SHA-checked. Reader invokes only Git and pure Python source generation, never DB/native programs.
Original raw archive retains actual program bytes, all samples, timing totals, compiler/source proofs and cgroup observations. Partial API jobs page is explicitly reported.
Direct process returncode fields are null: normal-exit assertion is source-bound to Session.shutdown before stop clears proc. Response hashes are available; raw numeric query rows are not.
