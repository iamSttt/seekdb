"""Prepare diagnostic evidence and material preview; --apply needs parent review."""
import argparse
import copy
import hashlib
import importlib.util
import io
import json
from pathlib import Path
import subprocess
import zipfile

BASE='7110a581586fa757cbab5004efc9afce4e910bd99bfb0d782ac9f5446e550e9a'
COMMIT='f779e6b27c13e50706fc6a4c2ff8e49c778417b1'
RAW='validation/iteration5-exact-cost-attempt2-raw.zip'
RAW_SHA='e1eabf97e4b4e69aa1ffddc344a2479a037f3892755c0744e65d21c4e25e5374'
AUDIT='validation/iteration5-exact-cost-attempt2-audit.zip'
PREREG='validation/iteration5-exact-cost-preregistration.json'
ERRATUM='validation/iteration5-exact-cost-launcher-erratum.json'

def sha(b):return hashlib.sha256(b).hexdigest()
def enc(x):return (json.dumps(x,ensure_ascii=False,separators=(',',':'),allow_nan=False)+'\n').encode('utf8')
def need(ok,message):
    if not ok:raise ValueError(message)
def git(repo,path):return subprocess.check_output(['git','-c','safe.directory='+repo.as_posix(),'-C',str(repo),'show',COMMIT+':'+path])

def main():
    parser=argparse.ArgumentParser();parser.add_argument('--apply',action='store_true');args=parser.parse_args()
    w=Path(__file__).resolve().parent;repo=w/'seekdb';prior=(repo/'conversation.json').read_bytes()
    need(sha(prior)==BASE and prior==(repo/'agent/conversation.json').read_bytes(),'material source drift')
    old=json.loads(prior);need(len(old['messages'])==144 and len(old['experiments'])==57,'inventory')
    raw=(repo/RAW).read_bytes();need(len(raw)==2996790 and sha(raw)==RAW_SHA,'raw mismatch')
    analysis_raw=(w/'exact-cost-attempt2-independent-analysis.json').read_bytes();analysis=json.loads(analysis_raw)
    reader=(w/'analyze_exact_cost_diagnostic.py').read_bytes()
    need(analysis['status']=='verified_diagnostic_evidence' and analysis['reader_sha256']==sha(reader),'independent audit not frozen')
    api=analysis['api'];binding=analysis['binding'];diag=analysis['diagnosis']
    need(api['commit']==COMMIT and api['run_id']==43499346006 and api['artifact_id']==14073157259 and api['artifact_sha256']==RAW_SHA,'run binding')
    need(diag['completed_first_lifecycles']==2 and diag['completed_requests_per_program']==1303 and diag['queries_per_program']==1000,'completion')
    preflight=json.loads((w/'exact-cost-reader-preflight.json').read_bytes())
    need(preflight['status']=='passed' and preflight['count']==12 and preflight['reader_sha256']==sha(reader),'reader checks')
    groups=diag['grouped_raw_counts_and_samples'];query_groups=[groups[x] for x in ['unfiltered_query','filtered_query']]
    calls={k:sum(g['metrics'][k]['calls'] for g in query_groups) for k in query_groups[0]['metrics']}
    events={k:sum(g['events'][k] for g in query_groups) for k in query_groups[0]['events']}
    need(calls['scalar_distance']==calls['long_double_certificate']==40100 and calls['integer_exact']==4800,'distance counters')
    need(events['int8_kernel_calls']==5490000 and events['int8_rejected']==5334804,'int8 counters')
    decision={'status':'diagnostic_completed_cost_decomposition_insufficient','experiment_id':'exact-distance-cost-diagnostic',
      'source_commit':COMMIT,'run_id':api['run_id'],'artifact_id':api['artifact_id'],'raw':{'path':RAW,'bytes':len(raw),'sha256':RAW_SHA},
      'independent_analysis_sha256':sha(analysis_raw),'reader_sha256':sha(reader),'reader_preflight_checks':12,
      'actual_binary_sha256':binding['binary_sha256'],'completed_first_lifecycles':2,'requests_per_program':1303,'queries_per_program':1000,
      'source_identity':binding,'raw_phase_groups':groups,'combined_query_calls':calls,'combined_query_events':events,
      'empty_timer_probe':diag['empty_timer_probe'],
      'interpretation':[
        'The direct counters establish repeated int8 filtering and 40100 scalar/long-double calls with4800 integer fallbacks on this serial synthetic workload.',
        'Short-kernel samples are close to the641ns empty-timer median. Periodic samples contain clock/counting/layout/logging perturbation and alias risk; they do not establish a reliable production CPU cost breakdown.',
        'Preserve all raw samples including SQL parsing/CRC and filtered/unfiltered split. Do not sum inclusive components, extrapolate production percentages, subtract timer medians, or compare non-PGO diagnostic latency with retained PGO latency as a speedup.',
        'The coordinator deferred compensated long-double work and selected a separate eight-consecutive-row integer-filter prototype for investigation. This selection is an assistant hypothesis, not an implemented production change or a measured performance result.'
      ],
      'limits':diag['limitations']+[diag['exit_evidence']['normal_exit_basis'],api['API_scope']],
      'response_evidence':'Every execute response SHA agrees across two programs. Three numeric oracle assertions at indices0/1/999 are Git-bound runner checks; row payloads are not archived for offline numeric re-execution.',
      'attempt1_preserved':{'status':'failed_before_ready','SQL_requests':0,'first_lifecycles':0,'source_commit':'89fbe16b9bfb841d91ba37fefe13b87ac7044466'},
      'reader_development':'First attempt2 reader required numeric exit0; frozen Session.shutdown already validates exit0 then clears proc, so the added late field is null. Original reader rejection retained; corrected interpretation is not a database retry.',
      'resources':'Actual1 logicalCPU,2GiB memory,swap0 and parse/query=1. These are diagnostic constraints, not verified official evaluator configuration.',
      'performance_candidate_passed':False,'selected_runtime_changed':False,'formal_submission':False,'new_DB_runs_by_reader':0}
    files={}
    for name in ['exact-cost-attempt2-api-receipt.json','exact-cost-attempt2-independent-analysis.json','analyze_exact_cost_diagnostic.py',
       'exact-cost-attempt2-reader-first-rejection.json','check_exact_cost_reader.py','exact-cost-reader-preflight.json',Path(__file__).name]:
        files['audit/'+name]=(w/name).read_bytes()
    files['decision.json']=enc(decision)
    plan_raw=git(repo,PREREG);plan=json.loads(plan_raw);files['frozen/'+PREREG]=plan_raw;files['frozen/'+ERRATUM]=git(repo,ERRATUM)
    need(sha(plan_raw)==binding['original_prereg_sha256'] and sha(files['frozen/'+ERRATUM])=='6f0c6cc5dba3cf8d914192651b5bd1e93c34a2270398787ad31d52d44b13bbe7','prereg/erratum')
    for name in plan['source_tool_snapshot']:files['frozen/minivec/tools/exact_cost/'+name]=git(repo,'minivec/tools/exact_cost/'+name)
    for name in plan['shared_tool_snapshot']:files['frozen/'+name]=git(repo,name)
    files['README.txt']=(
      'This archive records a diagnostic, not a release-candidate performance pass. Original failed attempt remains separately archived.\n'
      'Replay: python audit/analyze_exact_cost_diagnostic.py --repo <seekdb Git checkout> --archive <iteration5-exact-cost-attempt2-raw.zip> --receipt audit/exact-cost-attempt2-api-receipt.json --output <new analysis.json>\n'
      'The Git checkout must contain the pinned source commits and validation/iteration4-bulk-loop-raw.zip; all inputs are SHA-checked. Reader invokes only Git and pure Python source generation, never DB/native programs.\n'
      'Original raw archive retains actual program bytes, all samples, timing totals, compiler/source proofs and cgroup observations. Partial API jobs page is explicitly reported.\n'
      'Direct process returncode fields are null: normal-exit assertion is source-bound to Session.shutdown before stop clears proc. Response hashes are available; raw numeric query rows are not.\n'
    ).encode()
    manifest={'scope':'Successful exact-cost diagnostic; no candidate adoption/official submission','source_commit':COMMIT,
      'raw':{'path':RAW,'bytes':len(raw),'sha256':RAW_SHA},'files':{n:{'bytes':len(b),'sha256':sha(b)} for n,b in sorted(files.items())}}
    out=io.BytesIO()
    with zipfile.ZipFile(out,'w',zipfile.ZIP_DEFLATED,compresslevel=9) as z:
        for name,b in sorted({**files,'manifest.json':enc(manifest)}.items()):
            info=zipfile.ZipInfo(name,(2026,11,14,0,0,0));info.external_attr=0o100644<<16;z.writestr(info,b,compress_type=zipfile.ZIP_DEFLATED,compresslevel=9)
    audit=out.getvalue()
    with zipfile.ZipFile(io.BytesIO(audit)) as z:
        need(len(z.namelist())==len(files)+1,'audit inventory')
        for name,b in files.items():need(z.read(name)==b,'archive member changed')
    new=copy.deepcopy(old);e=new['experiments'][-1];need(e['id']=='exact-distance-cost-diagnostic','wrong experiment')
    e.update(status='diagnostic_completed_short_kernel_costs_unresolved',first_lifecycles_executed=2,
      new_non_PGO_database_builds_executed=2,retry_first_lifecycles_executed=2,
      failure_message='assistant-exact-cost-launcher-failure',result_message='assistant-exact-cost-diagnostic-result')
    e['artifacts'] += [{'path':RAW,'sha256':RAW_SHA},{'path':AUDIT,'sha256':sha(audit)}]
    new['messages'].append({'id':'assistant-exact-cost-diagnostic-result','role':'assistant','content':
      '诊断重试完成：两程序各1个首生命周期/1303请求/1000 exact查询，逐响应hash一致；3项oracle为绑定源码的运行断言，原档未留行值供离线重算。实际单CPU/2GiB/swap0、parse/query=1通过；累计2次非PGO构建，PGO为0，首轮启动失败保留。查询计数scalar/longdouble40100、integer4800、int8 kernel5490000/reject5334804。空计时中位641ns，短函数样本同量级，成本分解不足，不能外推生产CPU占比/提速/得分。直接退出码字段为null，正常退出依赖已绑定shutdown断言；reader首次拒绝及修正留档。下一8行整数批处理仅assistant待验证方向，无采用结论；R不变，未正式提交。'})
    need(new['messages'][:-1]==old['messages'] and new['experiments'][:-1]==old['experiments'][:-1],'old messages/results changed')
    need({k:v for k,v in old.items() if k not in ('messages','experiments')}=={k:v for k,v in new.items() if k not in ('messages','experiments')},'root/user manifest changed')
    need([x for x in new['messages'] if x['role']=='user']==[x for x in old['messages'] if x['role']=='user'],'user changed')
    material=enc(new);need(len(material)<=131072,'material too large')
    spec=importlib.util.spec_from_file_location('exact_material_validator',repo/'minivec/tools/validate_iteration_material.py');check=importlib.util.module_from_spec(spec);spec.loader.exec_module(check)
    check.validate(repo);check.check_structure(new,new)
    receipt={'status':'preview_only','source_sha256':BASE,'material_bytes':len(material),'material_sha256':sha(material),'remaining_bytes':131072-len(material),
      'messages':len(new['messages']),'users':49,'experiments':57,'audit_bytes':len(audit),'audit_sha256':sha(audit),'audit_member_count':len(files),
      'decision_sha256':sha(enc(decision)),'old_user_messages_results_unchanged':True,'new_DB_runs':0,'new_compilations':0,'git_mutations':0,
      'changed_fields':['experiments[56].status','experiments[56].first_lifecycles_executed','experiments[56].new_non_PGO_database_builds_executed',
        'experiments[56].retry_first_lifecycles_executed','experiments[56].failure_message','experiments[56].result_message','experiments[56].artifacts[4:6]','messages[144]']}
    for name,b in [('exact-cost-attempt2-decision.json',enc(decision)),('exact-cost-attempt2-audit.zip',audit),('exact-cost-success-material-preview.json',material)]:
        (w/name).write_bytes(b)
    if args.apply:
        need(sha((repo/'conversation.json').read_bytes())==BASE and (repo/'agent/conversation.json').read_bytes()==prior,'material changed before apply')
        dest=repo/AUDIT;need(not dest.exists(),'audit destination already exists');dest.write_bytes(audit)
        try:
            (repo/'conversation.json').write_bytes(material);(repo/'agent/conversation.json').write_bytes(material)
            receipt['validation']=check.validate(repo);receipt['status']='applied'
        except BaseException:
            (repo/'conversation.json').write_bytes(prior);(repo/'agent/conversation.json').write_bytes(prior);dest.unlink();raise
    (w/'exact-cost-success-material-receipt.json').write_bytes(enc(receipt));print(json.dumps(receipt,indent=2))

if __name__=='__main__':main()
