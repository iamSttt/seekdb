"""Offline mutation checks of the independent exact-cost reader; no DB/build."""
import copy
import hashlib
import importlib.util
import json
from pathlib import Path

def main():
    w=Path(__file__).resolve().parent
    p=w/'analyze_exact_cost_diagnostic.py'
    spec=importlib.util.spec_from_file_location('exact_reader',p);m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m)
    a=m.Archive((w/'seekdb/validation/iteration5-exact-cost-attempt2-raw.zip').read_bytes())
    report=a.json('measurements.json');records=a.json('diagnostic-records.json');requests=report['runs'][1]['requests']
    source=m.blob(w/'seekdb','f779e6b27c13e50706fc6a4c2ff8e49c778417b1','minivec/tools/benchmark_iteration.py')
    _,expected=m.workload({'minivec/tools/benchmark_iteration.py':source})
    m.diagnostic_records(records,requests,expected);checks=['real_record_inventory_and_periodic_samples']
    q=next(i for i,r in enumerate(records) if r['metrics']['long_double_certificate']['calls'])
    def bad(name,change):
        altered=copy.deepcopy(records);change(altered)
        try:m.diagnostic_records(altered,requests,expected)
        except ValueError:checks.append(name)
        else:raise AssertionError('accepted corrupt '+name)
    bad('reject_missing_record',lambda r:r.pop())
    bad('reject_sequence',lambda r:r[0].__setitem__('sequence',2))
    bad('reject_periodic_sample_count',lambda r:r[q]['metrics']['long_double_certificate'].__setitem__('samples',r[q]['metrics']['long_double_certificate']['samples']+1))
    bad('reject_distance_units',lambda r:r[q]['metrics']['scalar_distance'].__setitem__('units',1))
    bad('reject_branch_imbalance',lambda r:r[q]['events'].__setitem__('long_double_certified',r[q]['events']['long_double_certified']+1))
    bad('reject_negative_cpu',lambda r:r[q].__setitem__('thread_cpu_ns',-1))
    bad('reject_unsampled_cpu',lambda r:r[q]['metrics']['scalar_distance'].__setitem__('sample_cpu_ns',1))
    cap=copy.deepcopy(report['runs'][0]['cgroup']['after']);m.cap(cap);checks.append('real_cap')
    for field,value in [('memory.max','4294967296'),('memory.swap.max','max'),('cpu.max','200000 100000')]:
        altered=copy.deepcopy(cap);altered[field]=value
        try:m.cap(altered)
        except ValueError:checks.append('reject_'+field)
        else:raise AssertionError('accepted corrupt '+field)
    result={'status':'passed','checks':checks,'count':len(checks),'reader_sha256':hashlib.sha256(p.read_bytes()).hexdigest(),'new_DB_runs':0,'new_compilations':0,'scope':'Offline real-record replay and controlled corruptions only; not an independent database oracle replay.'}
    (w/'exact-cost-reader-preflight.json').write_text(json.dumps(result,indent=2)+'\n',encoding='utf8')
    print(json.dumps(result))

if __name__=='__main__':main()
