"""Independent read-only exact-cost evidence reader; no DB or native code execution."""
import argparse
import ast
from array import array
import hashlib
import heapq
import io
import json
import math
from pathlib import Path, PurePosixPath
import re
import random
import shlex
import subprocess
import zipfile

FIRST_COMMIT='89fbe16b9bfb841d91ba37fefe13b87ac7044466'
FIRST_RUN=43498082455
PREREG='validation/iteration5-exact-cost-preregistration.json'
PREREG_SHA='f79a3180a8829a7137c140f42ed5847c980fad06b09517c8c13d6ec0cfbbe24b'
R_SHA='acddca115ab183bfc6419e27c9e3383cfd1a9046e3897e5ea516cd7bc0f29f54'
R_ARCHIVE='validation/iteration4-bulk-loop-raw.zip'
R_ARCHIVE_SHA='88e4a73af9d333b08a6db817a78c7cb06357fcfddc05eee1b31c2a065aebfef2'
COMPILER='gcc:13.3.0-bookworm@sha256:1d71f0f3450214bef38fe09e6f610fb6cca90cf97b43f4ce845bfc32a4168818'
ERRATUM='validation/iteration5-exact-cost-launcher-erratum.json'
ERRATUM_SHA='6f0c6cc5dba3cf8d914192651b5bd1e93c34a2270398787ad31d52d44b13bbe7'
METRICS={'scalar_distance':0,'long_double_certificate':256,'integer_exact':256,'int8_bound':256,
  'float_bound_context':256,'double_bound':256,'sql_parse':1,'crc_update':16}
EVENTS={'long_double_certified','scalar_to_integer','integer_nonfinite','int8_invalid_or_disabled','int8_cap_unusable',
  'int8_kernel_calls','int8_rejected','float_invalid_or_disabled','float_kernel_calls','float_rejected','double_rejected'}

def need(ok,message):
    if not ok:raise ValueError(message)
def digest(data):return hashlib.sha256(data).hexdigest()
def readjson(data):return json.loads(data.decode('utf8'),parse_constant=lambda _:(_ for _ in ()).throw(ValueError('nonfinite JSON')))
def blob(repo,commit,name):
    data=subprocess.check_output(['git','-c','safe.directory='+repo.as_posix(),'-C',str(repo),'show',commit+':'+name])
    oid=subprocess.check_output(['git','-c','safe.directory='+repo.as_posix(),'-C',str(repo),'rev-parse',commit+':'+name],text=True).strip()
    need(hashlib.sha1(b'blob '+str(len(data)).encode()+b'\0'+data).hexdigest()==oid,'Git blob mismatch '+name)
    return data
def counters(text):return {row.split()[0]:int(row.split()[1]) for row in text.splitlines() if len(row.split())==2}
def elf(data):need(data[:6]==b'\x7fELF\x02\x01' and int.from_bytes(data[18:20],'little')==62,'not x86-64 ELF')

class Archive:
    def __init__(self,data):
        self.z=zipfile.ZipFile(io.BytesIO(data));names=self.z.namelist()
        need(len(names)==len(set(names)) and len(names)<1000,'duplicate/excess artifact names')
        self.inventory={}
        for name in names:
            p=PurePosixPath(name);need(not p.is_absolute() and '..' not in p.parts and '\\' not in name,'unsafe ZIP path')
            if name.endswith('/'):continue
            info=self.z.getinfo(name);need(info.file_size<250_000_000,'excess member')
            b=self.z.read(name);self.inventory[name]={'bytes':len(b),'sha256':digest(b)}
    def data(self,name):return self.z.read(name)
    def json(self,name):return readjson(self.data(name))

def api_binding(receipt,raw):
    commit=receipt['head_sha'];run=receipt['run_id'];items=receipt['artifacts_api_response']['artifacts']
    found=[x for x in items if x['id']==receipt['artifact_id']];need(len(found)==1,'artifact API identity')
    artifact=found[0]
    need(artifact['name']=='exact-cost-diagnostic' and artifact['expired'] is False,'wrong/expired artifact')
    need(artifact['workflow_run']['id']==run and artifact['workflow_run']['head_sha']==commit,'API run/source mismatch')
    need(artifact['digest']=='sha256:'+digest(raw) and artifact['size_in_bytes']==len(raw),'API digest/size mismatch')
    need(receipt['expected_sha256']==digest(raw) and receipt['expected_bytes']==len(raw),'download receipt mismatch')
    jobs=receipt['jobs_api_response']['jobs'];selected=[j for j in jobs if j['conclusion']!='skipped']
    need(0<len(jobs)<=35 and len(selected)==1 and selected[0]['name']=='exact-cost-diagnostic','provided job-page selection differs')
    need(all(j['run_id']==run and j['status']=='completed' for j in jobs),'unfinished/mismatched job')
    return {'commit':commit,'run_id':run,'artifact_id':artifact['id'],'artifact_sha256':digest(raw),'artifact_bytes':len(raw),
      'conclusion':selected[0]['conclusion'],'job_id':selected[0]['id'],'provided_jobs':len(jobs),'provided_selected_jobs':1,
      'provided_skipped_jobs':len(jobs)-1,'API_all_jobs_enumerated':len(jobs)==35,
      'API_scope':'Provided jobs page only; absence from a partial page does not prove other jobs were skipped.' if len(jobs)<35 else 'All35 workflow jobs provided.'}

def source_binding(repo,commit,a):
    prereg_raw=blob(repo,FIRST_COMMIT,PREREG);need(digest(prereg_raw)==PREREG_SHA,'original prereg differs')
    plan=readjson(prereg_raw);proof=a.json('programs/source-proof.json')
    need(proof['pgo'] is False and proof['archive_sha256']==R_ARCHIVE_SHA and proof['archive_bytes']==49685962,'source scope differs')
    need(proof['runtime_source_commit']=='e020fdeb67dd8b64b77f0f8c2905f137f0112bba' and proof['retained_binary_sha256']==R_SHA,'R identity')
    source_tools={name:blob(repo,commit,'minivec/tools/exact_cost/'+name) for name in plan['source_tool_snapshot']}
    if commit==FIRST_COMMIT:
        for name,data in source_tools.items():need(digest(data)==plan['source_tool_snapshot'][name]['sha256'],'tool differs from first prereg '+name)
    else:
        err_raw=blob(repo,commit,ERRATUM);need(digest(err_raw)==ERRATUM_SHA,'retry erratum differs')
        err=readjson(err_raw);need(err['original_preregistration']['sha256']==PREREG_SHA,'retry original plan')
        need(set(err['changes'])=={'run.py','preflight.py','preflight.json','handoff-manifest.json'},'retry scope widened')
        for name,data in source_tools.items():
            expected=err['changes'][name]['new_sha256'] if name in err['changes'] else plan['source_tool_snapshot'][name]['sha256']
            need(digest(data)==expected,'unfrozen retry tool '+name)
    shared={name:blob(repo,commit,name) for name in plan['shared_tool_snapshot']}
    for name,data in shared.items():need(digest(data)==plan['shared_tool_snapshot'][name]['sha256'],'shared input drift '+name)
    runtime_tools={name:digest(data) for name,data in source_tools.items() if name.endswith(('.py','.sh','.h','.cpp'))}
    need(proof['tools']==runtime_tools,'source proof tool hashes differ')
    historical_raw=blob(repo,commit,R_ARCHIVE)
    need(len(historical_raw)==49685962 and digest(historical_raw)==R_ARCHIVE_SHA,'fixed R raw differs')
    with zipfile.ZipFile(io.BytesIO(historical_raw)) as z:
        members={x['path']:x for x in readjson(z.read('hashes.json'))['artifacts']}
        def prior(name):
            data=z.read(name);p=members[name];need(len(data)==p['bytes'] and digest(data)==p['sha256'],'R manifest member '+name);return data
        context=readjson(prior('context.json'))['profile_source_proof']['baseline']
        need(context['source_sha256']==proof['original_source_sha256'] and len(context['source_sha256'])==20,'original20 inventory')
        tree=ast.parse(source_tools['prepare.py'].decode());defs=[x for x in tree.body if isinstance(x,ast.FunctionDef) and x.name in ('need','replace','patch')]
        ns={};exec(compile(ast.Module(body=defs,type_ignores=[]),'<Git-bound pure source patch>','exec'),ns)
        for name,h in context['source_sha256'].items():
            original=prior('baseline-pgo/built-source/'+name);need(digest(original)==h,'original source hash '+name)
            expected=ns['patch'](name,original.decode()).encode() if name in ('main.cpp','distance.h','quantized_bound.h','sql.cpp','db.cpp') else original
            actual=a.data('programs/src/'+name)
            need(actual==expected and digest(actual)==proof['instrumented_source_sha256'][name],'shadow replay differs '+name)
        need(a.data('programs/retained-minivec')==prior('baseline-pgo/minivec'),'retained program bytes differ')
        need(a.data('programs/third_party/json.hpp')==prior('baseline-pgo/built-third-party/json.hpp'),'third-party source differs')
    need(a.data('programs/src/cost_diagnostic.h')==source_tools['cost_diagnostic.h'],'diagnostic header differs')
    need(a.data('programs/timer_overhead.cpp')==source_tools['timer_overhead.cpp'],'timer source differs')
    binaries={}
    log=a.data('compile.log').decode();need('g++ (GCC) 13.3.0' in log,'compiler version')
    flags=re.findall(r'^compiler_flags=(.*)$',log,re.M);need(len(flags)==1,'flags log')
    flags=shlex.split(flags[0]);need(flags==proof['compiler_flags'] and not any('profile' in f or 'fast-math' in f for f in flags),'non-PGO flags differ')
    need(a.data('compiler-image.txt').decode().strip()==COMPILER,'compiler image ref')
    inspection=a.json('compiler-inspect.json');need(len(inspection)==1 and any(COMPILER.split('@')[1] in d for d in inspection[0]['RepoDigests']),'compiler image digest')
    for name in ('retained-minivec','diagnostic-minivec','timer-overhead'):
        b=a.data('programs/'+name);elf(b);h=digest(b);need(re.search(r'^'+h+r'\s+'+re.escape(name)+r'$',log,re.M),'compile ELF hash '+name);binaries[name]=h
    need(binaries['retained-minivec']==R_SHA,'retained SHA')
    launcher=a.data('cgroup_exec');elf(launcher)
    launcher_log=a.data('launcher-sha256.txt').decode()
    need(digest(shared['minivec/tools/cgroup_exec.c']) in launcher_log and digest(launcher) in launcher_log,'launcher build hash')
    return plan,proof,source_tools,shared,{'binary_sha256':binaries,'instrumented_source_files':5,'source_files_verified':20,
      'shared_tool_files_verified':len(shared),'tool_files_verified':len(source_tools),'new_non_PGO_database_builds':1,'new_PGO_builds':0,
      'original_prereg_sha256':PREREG_SHA,'source_proof_sha256':digest(a.data('programs/source-proof.json'))}

def audit_failure(a,report,source_tools,shared):
    need(report['status']=='failed' and report['error']=='ProtocolError: database exited before response','unexpected failure')
    need(len(report['runs'])==1 and report['runs'][0]['role']=='retained','failure run count/role')
    run=report['runs'][0];need(run['binary_sha256']==R_SHA and run['requests']==[] and 'ready' not in run,'nonzero observed request/ready')
    need(a.data('retained-stderr.log')==b'' and run['stderr_bytes']==0 and run['stderr_sha256']==digest(b''),'stderr differs')
    need('diagnostic-stderr.log' not in a.inventory and 'diagnostic-records.json' not in a.inventory,'unexpected diagnostic execution')
    group=run['cgroup'];need('/minivec-exact-cost-' in group['path'],'failure cgroup naming differs')
    launcher=shared['minivec/tools/cgroup_exec.c'].decode();runner=source_tools['run.py'].decode()
    need('const char prefix[]="/sys/fs/cgroup/minivec-report-";' in launcher and 'return 64;' in launcher,'launcher restriction differs')
    need("parent=small.CGROOT/('minivec-exact-cost-'" in runner,'failed runner prefix differs')
    for label in ('before','immediately_after','after'):
        caps=group[label]
        need(caps['cpu.max']=='100000 100000' and caps['memory.max']=='2147483648' and caps['memory.swap.max']=='0','empty cgroup cap')
        need(counters(caps['cpu.stat'])['usage_usec']==0 and caps['memory.peak']=='0' and not caps['cgroup.procs'],'DB entered cgroup or consumed resources')
    need(group['resource_delta']['cpu_stat_delta']['usage_usec']==0 and not any(group['oom_events_delta'].values()),'failure resource delta')
    need(group['timeout'] is False and group['request_timeout_observed'] is False,'timeout differs')
    need('session.start()' in a.data('measurements.log').decode(),'failure stage log')
    return {'status':'verified_failed_before_ready','ready_programs':0,'first_lifecycles_completed':0,'requests_completed':0,'queries_completed':0,
      'diagnostic_records':0,'causal_source_finding':'Runner parent is outside the launchers fixed allowed prefix; this path deterministically returns64 before open/exec. Transport did not persist child exit status, so64 is source-derived, not a measured exit code.',
      'resource_scope':'Empty intended cgroup limits were written/read back; no actual database placement, affinity or resource-run claim is available.',
      'cost_measurements_available':False,'response_oracle_comparisons_completed':0}

def cpus(value):
    need(isinstance(value,str) and bool(value),'CPU set missing');result=set()
    for item in value.split(','):
        need(re.fullmatch(r'\d+(?:-\d+)?',item),'CPU list syntax')
        parts=list(map(int,item.split('-')));a,b=parts[0],parts[-1];need(a<=b<=1048575,'CPU range')
        result.update(range(a,b+1))
    return result

def cap(snapshot):
    need(snapshot['cpu.max']=='100000 100000' and snapshot['memory.max']=='2147483648' and snapshot['memory.swap.max']=='0','observed caps differ')

def task_evidence(snapshot,pid,cpu):
    need(not snapshot.get('native_tasks_error') and not snapshot.get('task_read_errors'),'incomplete task evidence')
    tasks=snapshot['native_tasks'];need(len(tasks)==1,'not exactly one native task')
    task=tasks[0];need(task['main'] is True and task['tid']==pid and cpus(task['cpus_allowed_list'])=={cpu},'native task identity/affinity')

def workload(shared):
    tree=ast.parse(shared['minivec/tools/benchmark_iteration.py'].decode())
    names={'encoded','vector_literal','squared_distance','query_mode_for','make_workload'}
    nodes=[x for x in tree.body if isinstance(x,ast.FunctionDef) and x.name in names]
    need(len(nodes)==5,'generator function inventory')
    ns={'array':array,'math':math,'random':random,'hashlib':hashlib,'heapq':heapq,'json':json,'require':need}
    exec(compile(ast.Module(body=nodes,type_ignores=[]),'<Git-bound SQL generation only>','exec'),ns)
    w=ns['make_workload']((10000,128,0,0,10,True),7319,1000,100,10,query_mode='exact')
    requests=[('create',None,w['create'])]
    for sql,count in w['inserts']:
        need(count==100,'batch count differs');requests += [('begin',None,'BEGIN;'),('insert',None,sql),('commit',None,'COMMIT;')]
    requests.append(('index',None,'CREATE VECTOR INDEX docs_v ON docs(v);'))
    requests.extend(('filtered_query' if i%2 else 'unfiltered_query',i,sql) for i,sql in enumerate(w['queries']))
    requests.append(('shutdown',None,None));need(len(requests)==1303,'workload request count')
    return w,requests

def add_record(target,record):
    target['requests']+=1;target['thread_cpu_ns']+=record['thread_cpu_ns']
    for name,n in record['events'].items():target['events'][name]=target['events'].get(name,0)+n
    for name,item in record['metrics'].items():
        metric=target['metrics'].setdefault(name,{'calls':0,'units':0,'samples':0,'sample_cpu_ns':0,'sample_stride':item['sample_stride']})
        for key in ('calls','units','samples','sample_cpu_ns'):metric[key]+=item[key]

def empty_group():return {'requests':0,'thread_cpu_ns':0,'metrics':{},'events':{}}

def diagnostic_records(records,requests,expected):
    need(len(records)==len(requests)==1303,'record/request count')
    totals={name:0 for name in METRICS};phases={};groups={};negative_sampling_notes=[]
    for i,(record,request,(_,_,sql)) in enumerate(zip(records,requests,expected)):
        need(type(record['sequence']) is int and record['sequence']==i+1==request['sequence'],'record sequence')
        metrics=record['metrics'];events=record['events']
        need(set(metrics)==set(METRICS) and set(events)==EVENTS,'counter inventory')
        need(type(record['thread_cpu_ns']) is int and record['thread_cpu_ns']>=0,'thread CPU')
        need(all(type(v) is int and v>=0 for v in events.values()),'event integer range')
        for name,m in metrics.items():
            need(set(m)=={'calls','units','samples','sample_cpu_ns','sample_stride'},'metric schema')
            need(all(type(v) is int and v>=0 for v in m.values()),'metric integer range')
            stride=METRICS[name];need(m['sample_stride']==stride,'sampling stride')
            wanted=((totals[name]+m['calls'])//stride-totals[name]//stride) if stride else 0
            need(m['samples']==wanted,'periodic samples do not reconcile '+name)
            totals[name]+=m['calls'];need(m['samples']>0 or m['sample_cpu_ns']==0,'unsampled CPU')
            if name not in ('sql_parse','crc_update'):need(m['units']==128*m['calls'],'distance coordinate units')
        call=lambda name:metrics[name]['calls']
        need(call('scalar_distance')==call('long_double_certificate')==events['long_double_certified']+events['scalar_to_integer'],'scalar/longdouble conservation')
        need(call('integer_exact')==events['scalar_to_integer'] and events['integer_nonfinite']==0,'integer fallback conservation')
        need(call('int8_bound')==events['int8_invalid_or_disabled']+events['int8_cap_unusable']+events['int8_kernel_calls'],'quant branches')
        need(events['int8_rejected']<=events['int8_kernel_calls'],'quant rejects')
        need(call('float_bound_context')==events['float_invalid_or_disabled']+events['float_kernel_calls'],'float branches')
        need(events['float_rejected']<=events['float_kernel_calls'] and call('double_bound')==0 and events['double_rejected']==0,'default finite double branch')
        need(call('sql_parse')==int(sql is not None) and metrics['sql_parse']['units']==(len(sql.encode()) if sql else 0),'parse calls/SQL bytes')
        phase=request['phase'];add_record(phases.setdefault(phase,empty_group()),record)
        group='ingest' if phase in ('begin','insert','commit') else phase
        add_record(groups.setdefault(group,empty_group()),record)
    return phases,groups,totals

def audit_success(a,report,binding,shared):
    need(report['status']=='passed' and 'error' not in report and len(report['runs'])==2,'success status/run count')
    need([r['role'] for r in report['runs']]==['retained','diagnostic'],'fixed program order')
    env={'MVDB_QUERY_THREADS':'1','MVDB_PARSE_THREADS':'1'}
    need(report['runtime_environment']==env and report['db_cpus']==[min(report['host']['driver_affinity'])],'runtime policy/CPU selection')
    cpu=report['db_cpus'][0];work,expected=workload(shared)
    need(report['workload']=={'scenario':'standard10k','rows':10000,'dimension':128,'queries':1000,'batch_size':100,'k':10,
        'seed':7319,'query_mode':'exact','sql_sha256':work['sha256'],'half_equality_filtered':True},'workload hash/config')
    for run in report['runs']:
        role=run['role'];program=role+'-minivec';binary_sha=binding['binary_sha256'][program]
        need(run['binary_sha256']==binary_sha and run['ready']['binary_sha256']==binary_sha,'actual ELF differs')
        ready=run['ready'];pid=ready['pid'];need(ready['exe'].endswith('/programs/'+program) and ready['runtime_environment']==env,'ready actual exe/environment')
        need(ready['members']==[pid],'ready cgroup placement');task_evidence(ready['tasks'],pid,cpu)
        g=run['cgroup'];need(not g['timeout'] and not g.get('request_timeout_observed') and not g.get('watchdog_error') and not g.get('cleanup_kill_required') and not g.get('execution_error'),'timeout/unclean process')
        need('protocol_process_returncode' in run and run['protocol_process_returncode'] in (None,0),'recorded nonzero exit')
        if run['protocol_process_returncode'] is None:
            transport=shared['protocol_check/_transport.py'].decode()
            need('if extra or self.proc.returncode:' in transport and 'extra stdout or nonzero exit after shutdown' in transport and 'self.proc = None' in transport,
                 'null exit field lacks pinned shutdown/stop contract')
        need(not any(g['oom_events_delta'].values()),'OOM')
        for label in ('before','immediately_after','after'):cap(g[label])
        need(not g['before']['cgroup.procs'] and not g['after']['cgroup.procs'],'cgroup not initially/finally empty')
        for parent in g['ancestor_constraints']:
            for key,limit in [('memory.max',2147483648),('memory.swap.max',0)]:
                value=parent[key]
                if isinstance(value,dict):need(parent['path']=='/sys/fs/cgroup' and set(value)=={'unavailable'},'unknown nonroot parent cap')
                else:need(value=='max' or int(value)>=limit,'parent tighter cap')
            q=parent['cpu.max']
            if isinstance(q,dict):need(parent['path']=='/sys/fs/cgroup' and set(q)=={'unavailable'},'unknown ancestor quota')
            else:
                quota,period=q.split();need(quota=='max' or int(quota)>=int(period),'parent CPU<1')
        b,c=counters(g['before']['cpu.stat']),counters(g['after']['cpu.stat'])
        need(g['resource_delta']['cpu_stat_delta']=={k:v-b.get(k,0) for k,v in c.items()},'whole CPU delta')
        need(g['resource_delta']['memory_peak_bytes']==int(g['after']['memory.peak']),'memory peak')
        snapshots=run['phase_snapshots'];need([p['phase'] for p in snapshots]==['before_ingest','after_ingest','after_index','after_query'],'phase inventory')
        for p in snapshots:
            cap(p['cgroup']);need(set(map(int,p['cgroup']['cgroup.procs'].split()))=={pid},'phase membership');task_evidence(p['tasks'],pid,cpu)
        requests=run['requests'];need(len(requests)==1303,'request count')
        for i,(request,(phase,idx,_)) in enumerate(zip(requests,expected)):
            need(request['sequence']==i+1 and request['phase']==phase and request['query_index']==idx and request['search_mode']=='exact','request/mode schedule')
            need(type(request['wall_seconds']) in (int,float) and math.isfinite(request['wall_seconds']) and request['wall_seconds']>=0,'request time')
            h=request['response_sha256'];need(h is None if phase=='shutdown' else isinstance(h,str) and re.fullmatch('[a-f0-9]{64}',h),'response hash')
        need(run['sampled_oracle_indices']==[0,1,999] and run['all_query_responses_compared_to_retained'] is True,'oracle execution claim')
        log=a.data(role+'-stderr.log');need(len(log)==run['stderr_bytes'] and digest(log)==run['stderr_sha256'],'stderr binding')
    r,d=report['runs'];need(r['response_sha256']==d['response_sha256'],'transcript hash comparison')
    need([q['response_sha256'] for q in r['requests']]==[q['response_sha256'] for q in d['requests']],'per-execute hashes differ')
    log=a.data('diagnostic-stderr.log').decode();records=[readjson(line[len('MVDB_COST_DIAG '):].encode()) for line in log.splitlines() if line.startswith('MVDB_COST_DIAG ')]
    need(records==a.json('diagnostic-records.json'),'JSON records differ from actual stderr')
    phases,groups,totals=diagnostic_records(records,d['requests'],expected)
    for name,p in phases.items():
        observed=report['diagnostic_summary'][name]
        need(p['requests']==observed['requests'] and p['thread_cpu_ns']==observed['thread_cpu_ns'] and p['events']==observed['events'],'runner phase sums')
        for metric,value in p['metrics'].items():
            need(all(observed['metrics'][metric][key]==val for key,val in value.items()),'runner raw metric sums')
    overhead=a.json('timer-overhead.json');need(overhead==report['timer_empty_overhead'],'empty timer report')
    need(overhead['count']==20000 and overhead['clock']=='CLOCK_THREAD_CPUTIME_ID' and overhead['subtracted'] is False and 0<=overhead['min_ns']<=overhead['median_ns']<=overhead['p95_ns'],'timer probe values')
    return {'status':'verified_two_first_lifecycles','completed_first_lifecycles':2,'completed_requests_per_program':1303,'queries_per_program':1000,
      'actual_phase_counter_sums':phases,'grouped_raw_counts_and_samples':groups,'metric_call_totals':totals,'empty_timer_probe':overhead,
      'performance_ratios_computed':False,'production_CPU_percentages_computed':False,
      'exit_evidence':{'direct_exit_status_fields':[x['protocol_process_returncode'] for x in report['runs']],
        'normal_exit_basis':'Pinned Session.shutdown validates zero exit/no extra stdout before stop clears proc; completed shutdown requests plus empty clean cgroups. The later finally field is null, not an observed numeric exit code.'},
      'limitations':['Component CPU samples are inclusive, periodic and perturbed; neither sums nor extrapolated production CPU percentages are justified.',
        'Archive contains response hashes rather than rows: offline reader verifies per-response equality and Git-bound oracle assertions, not an independent replay of the three numeric oracle responses.',
        'Forced serial non-PGO shadow is not automatic-policy production performance; no release/adoption or formal-score conclusion.']}

def audit(args):
    repo=args.repo.resolve();raw=args.archive.read_bytes();receipt=readjson(args.receipt.read_bytes());api=api_binding(receipt,raw)
    if api['commit']==FIRST_COMMIT:need(api['run_id']==FIRST_RUN,'first-attempt run/source mismatch')
    a=Archive(raw);plan,proof,tools,shared,binding=source_binding(repo,api['commit'],a)
    report=a.json('measurements.json');need(report['source_proof_sha256']==binding['source_proof_sha256'],'measurement source identity')
    need(report['runtime_source_commit']==proof['runtime_source_commit'],'measurement source commit')
    tools_map=report['tool_sha256']
    for name,h in {**{k:digest(v) for k,v in shared.items() if k in ('minivec/tools/benchmark_iteration.py','minivec/tools/small_compute.py','protocol_check/_transport.py','protocol_check/config.json')},
                  **{'minivec/tools/exact_cost/'+k:digest(v) for k,v in tools.items() if k.endswith(('.py','.h','.cpp'))}}.items():
        found=[v for p,v in tools_map.items() if p.endswith('/'+name)];need(found==[h],'runtime tool identity '+name)
    need(any(p.endswith('/cgroup_exec') and h==digest(a.data('cgroup_exec')) for p,h in tools_map.items()),'runtime launcher identity')
    if api['conclusion']=='failure' and api['commit']==FIRST_COMMIT:
        outcome={'failure':audit_failure(a,report,tools,shared),'original_runner_error':report['error'],'empty_timer_probe_only':a.json('timer-overhead.json')};status='verified_failure_evidence'
    else:
        need(api['conclusion']=='success','retry failed/incomplete: preserve raw, no successful diagnosis claimed')
        outcome={'diagnosis':audit_success(a,report,binding,shared)};status='verified_diagnostic_evidence'
    return {'status':status,'api':api,'binding':binding,**outcome,
      'artifact_manifest':a.inventory,'new_DB_runs_by_reader':0,'new_compilations_by_reader':0,
      'performance_candidate_passed':False,'production_CPU_percentages':None,'selected_runtime_changed':False,'formal_submission':False,
      'reader_sha256':digest(Path(__file__).read_bytes()),'api_receipt_sha256':digest(args.receipt.read_bytes())}

def main():
    p=argparse.ArgumentParser();p.add_argument('--repo',type=Path,default=Path(__file__).resolve().parent/'seekdb');p.add_argument('--archive',type=Path,required=True)
    p.add_argument('--receipt',type=Path,required=True);p.add_argument('--output',type=Path,required=True);args=p.parse_args()
    try:result=audit(args)
    except BaseException as exc:
        args.output.write_text(json.dumps({'status':'reader_failed_evidence_not_verified','error':str(exc),'new_DB_runs_by_reader':0},indent=2)+'\n',encoding='utf8');raise
    args.output.write_text(json.dumps(result,indent=2,allow_nan=False)+'\n',encoding='utf8')
    print(json.dumps({'status':result['status'],'artifact_sha256':result['api']['artifact_sha256'],'failure':result.get('failure'),
      'completed_lifecycles':result.get('diagnosis',{}).get('completed_first_lifecycles',0)},indent=2))

if __name__=='__main__':main()
