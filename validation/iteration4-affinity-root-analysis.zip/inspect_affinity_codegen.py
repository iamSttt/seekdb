"""Bounded offline stripped-ELF shape check. No execution or causal attribution."""
import hashlib,json,sys
from pathlib import Path
W=Path(__file__).resolve().parent
sys.path.insert(0,str(W/'elf-inspection-deps'))
from elftools.elf.elffile import ELFFile
from elftools.dwarf.callframe import FDE
from capstone import Cs,CS_ARCH_X86,CS_MODE_64,CS_GRP_CALL,CS_GRP_JUMP
from capstone.x86_const import X86_OP_IMM,X86_OP_REG,X86_OP_MEM,X86_REG_RIP
from inspect_bulk_pgo_mechanism import parse_nm
sha=lambda b:hashlib.sha256(b).hexdigest()
class E:
 def __init__(self,p):
  self.p=p;self.f=p.open('rb');self.e=ELFFile(self.f)
  self.loads=[s for s in self.e.iter_segments() if s['p_type']=='PT_LOAD']
  self.ranges=[(x['initial_location'],x['address_range']) for x in self.e.get_dwarf_info().EH_CFI_entries() if isinstance(x,FDE)]
 def read(self,a,n):
  for s in self.loads:
   if s['p_vaddr']<=a and a+n<=s['p_vaddr']+s['p_filesz']:
    self.f.seek(s['p_offset']+a-s['p_vaddr']);return self.f.read(n)
  raise ValueError(hex(a))
 def section(self,a):
  for s in self.e.iter_sections():
   if s['sh_addr'] and s['sh_addr']<=a<s['sh_addr']+s['sh_size']:return s.name
  return 'unknown'

def decode(e,a,n):
 md=Cs(CS_ARCH_X86,CS_MODE_64);md.detail=True
 raw=e.read(a,n);ins=list(md.disasm(raw,a))
 if sum(x.size for x in ins)!=n:return None
 shape=[];refs=[]
 for i in ins:
  ops=[]
  for op in i.operands:
   if op.type==X86_OP_REG:ops.append(i.reg_name(op.reg))
   elif op.type==X86_OP_IMM:
    v=op.imm
    if i.group(CS_GRP_CALL) or i.group(CS_GRP_JUMP):
     if a<=v<a+n:ops.append('self+'+str(v-a))
     else:ops.append('external:'+e.section(v));refs.append({'at':i.address-a,'kind':i.mnemonic,'target':hex(v)})
    elif e.section(v)!='unknown':ops.append('absolute:'+e.section(v));refs.append({'at':i.address-a,'kind':'address','target':hex(v)})
    else:ops.append(str(v))
   elif op.type==X86_OP_MEM:
    m=op.mem
    if m.base==X86_REG_RIP:
     v=i.address+i.size+m.disp;ops.append('rip:'+str(op.size)+':'+e.section(v));refs.append({'at':i.address-a,'kind':'rip','target':hex(v)})
    else:ops.append('mem:'+str(op.size)+':'+str((i.reg_name(m.base),i.reg_name(m.index),m.scale,m.disp)))
   else:ops.append('type:'+str(op.type))
  shape.append(i.mnemonic+' '+','.join(ops))
 return {'sha256':sha(raw),'instructions':len(ins),'shape':shape,'refs':refs}

P=W/'performance/affinity-root-b74a1b7/small-compute-root/programs'
a=E(P/'retained/submitted-source-minivec');b=E(P/'actual-image-minivec')
assert sha(a.p.read_bytes())=='acddca115ab183bfc6419e27c9e3383cfd1a9046e3897e5ea516cd7bc0f29f54'
assert sha(b.p.read_bytes())=='bdb0197c78ebeac0507d5dc7816b15281614684688f8ead35af81543b0584dcd'
baseline_root=W/'performance/bulk-loop-c3d421e/baseline-pgo'
assert (baseline_root/'minivec').read_bytes()==a.p.read_bytes()
context=json.loads((baseline_root.parent/'context.json').read_bytes())['profile_source_proof']['baseline']
assert sha((baseline_root/'training/unstripped-minivec').read_bytes())==context['unstripped_binary_sha256']
assert sha((baseline_root/'training/symbols.txt').read_bytes())==context['layout_sha256']['symbols.txt']
un=E(baseline_root/'training/unstripped-minivec')
for n in ('.text','.rodata'):
 assert un.e.get_section_by_name(n).data()==a.e.get_section_by_name(n).data()
nm=parse_nm(baseline_root/'training/symbols.txt')
prior=json.loads((W/'bulk-loop-codegen-inspection.json').read_bytes())
targets={k:{'name':v['name'],'address':v['address'],'bytes':v['bytes']} for k,v in prior['roles']['baseline']['scan_chain'].items()}
for name,r in nm.items():
 if (name.startswith(('mvdb::JsonRowWriter::','mvdb::execute_json(','mvdb::distance_l2(','mvdb::Database::scan_vectors(','emit_json_text(','json_request(')) or
     (name.startswith('mvdb::execute_impl(') and '::operator()(mvdb::Row const&' in name)) and '[clone' not in name:
  targets[name]={'name':name,**r}
cache={};results={}
for label,r in targets.items():
 old=decode(a,r['address'],r['bytes']);assert old
 candidates=[(addr,size) for addr,size in b.ranges if size==r['bytes']]
 matches=[]
 for addr,size in candidates:
  if (addr,size) not in cache:cache[addr,size]=decode(b,addr,size)
  new=cache[addr,size]
  if new and new['shape']==old['shape']:
   matches.append({'address':hex(addr),'bytes':size,'instructions':new['instructions'],'raw_bytes_identical':new['sha256']==old['sha256'],'candidate_sha256':new['sha256'],'references':new['refs']})
 results[label]={'baseline':r,'baseline_sha256':old['sha256'],'baseline_instruction_count':old['instructions'],'baseline_references':old['refs'],'same_size_fde_count':len(candidates),'shape_match_count':len(matches),'matches':matches,'status':'unique_address_insensitive_shape_match' if len(matches)==1 else 'unknown_ambiguous_or_changed'}
out={'status':'bounded_offline_inspection','runtime_executions':0,'baseline_sha256':sha(a.p.read_bytes()),'candidate_sha256':sha(b.p.read_bytes()),'limitations':['Candidate is stripped. FDE boundaries and old symbol mapping are used; matching masks external call targets and RIP/absolute addresses. Shape identity is not semantic identity, target identity or performance causality.','No new PGO counters available; no claim that training profile or selected path cost is unchanged.','Negative measurements remain negative; this check cannot dismiss them as noise.'], 'sections':{role:{n:{'address':hex(e.e.get_section_by_name(n)['sh_addr']),'bytes':e.e.get_section_by_name(n)['sh_size'],'sha256':sha(e.e.get_section_by_name(n).data())} for n in ('.text','.rodata','.eh_frame','.data','.bss')} for role,e in [('baseline',a),('candidate',b)]},'functions':results}
(W/'affinity-root-codegen-inspection.json').write_text(json.dumps(out,indent=2)+'\n')
print(json.dumps({k:{'bytes':v['baseline']['bytes'],'instructions':v['baseline_instruction_count'],'matches':v['shape_match_count'],'raw_same':[m['raw_bytes_identical'] for m in v['matches']]} for k,v in results.items()}))
