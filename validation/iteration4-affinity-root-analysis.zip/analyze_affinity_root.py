"""Read-only independent audit of actual-root 12+8 pair affinity candidate evidence.

Never executes a database or changes an archive. Recreates deterministic input and
oracle content from Git-verified Python generators solely to compare workload hashes.
"""
import argparse
import ast
from functools import lru_cache
import hashlib
import importlib
import json
import math
from pathlib import Path, PurePosixPath
import re
from statistics import median
import subprocess
import sys
import tempfile
import zipfile

BASE = 'e020fdeb67dd8b64b77f0f8c2905f137f0112bba'
BASE_BINARY = 'acddca115ab183bfc6419e27c9e3383cfd1a9046e3897e5ea516cd7bc0f29f54'
FLAGS = ['-DMVDB_ENABLE_SPILL_FILTER', '-DMVDB_ENABLE_TYPED_JSON', '-DMVDB_TYPED_WIDE_VECTOR_ONLY', '-DMVDB_MULTI_POSTING_REUSE_ONLY']
COMPILER = 'gcc:13.3.0-bookworm@sha256:1d71f0f3450214bef38fe09e6f610fb6cca90cf97b43f4ce845bfc32a4168818'
CASES = ('standard10k', 'resident30k', 'filter60k', 'spill_high_q1', 'spill_high_q16', 'wide768')
PROTECTION = ('standard10k', 'resident30k', 'spill_high_q16', 'wide768')
TOOLS = {'minivec/tools/small_compute.py', 'minivec/tools/benchmark_iteration.py',
         'minivec/tools/benchmark_index_delta.py', 'minivec/tools/benchmark_write_query.py',
         'minivec/tools/benchmark_projection.py', 'minivec/tests/json_protocol.py',
         'protocol_check/_transport.py', 'protocol_check/config.json'}
LABELS = {'narrow_top10', 'wide_top10', 'narrow_large4096', 'wide_large4096', 'narrow_all', 'wide_all', 'wide_distance10'}
GATES = {'root_docker_build', 'startup_affinity_and_explicit_override_11_cases',
         'image_official_handshake_and_public_cases', 'source_official_handshake_and_public_cases',
         'live_stdin_errors_utf8_fragment_shutdown_restart_commit_sigkill', 'make_test',
         'native_spill_cache_budget_writer_and_54_utf8_cases', 'actual_image_54_utf8_atomicity_cases',
         'selected_spill_and_utf8_asan_ubsan', 'parser_ownership_serial_parallel_and_quantized_bound_asan_ubsan',
         'image_binary_json_and_exact_topk_serial_parallel', 'eight_wal_failure_cases_asan_ubsan',
         'query_pool_both_modes_asan_ubsan', 'cross_table_spill_asan_ubsan', 'full_binary_json_ubsan',
         'index_budget_and_resident_update_asan_ubsan', 'compound_reuse_diagnostic_and_sanitizer'}
INPUT_PATHS = ('Dockerfile', '.dockerignore', 'minivec/src', 'minivec/third_party',
               'minivec/Makefile', 'minivec/tests', 'minivec/tools/ci_score.sh',
               'minivec/tools/ci_final_performance.sh', 'minivec/tools/pgo/train.cpp',
               'minivec/tools/pgo/run-training.sh', 'STDIO_PROTOCOL.md', 'protocol_check', 'mysqltest')


def require(value, message):
    if not value: raise ValueError(message)


def digest(raw): return hashlib.sha256(raw).hexdigest()
def sha(path): return digest(path.read_bytes())
def read(path): return json.loads(path.read_bytes())


@lru_cache(maxsize=None)
def git(repo, *args):
    return subprocess.check_output(['git', '-c', 'safe.directory=' + repo.as_posix(), '-C', str(repo), *args])


def blob(repo, commit, path): return git(repo, 'show', commit + ':' + path)


def safe_name(name):
    p = PurePosixPath(name)
    require(name and not p.is_absolute() and p.as_posix() == name and
            not any(x in ('.', '..') for x in p.parts) and
            not any(x in name for x in ('\\', ':', '\0')), 'unsafe path: ' + name)


def verify_archive(root, archive, expected_sha, expected_bytes):
    require(archive.stat().st_size == expected_bytes and sha(archive) == expected_sha, 'artifact API identity differs')
    with zipfile.ZipFile(archive) as z:
        items = z.infolist(); names = [i.filename for i in items]
        require(len(names) == len(set(names)) and len(names) < 1000 and
                sum(i.file_size for i in items) < 512 * 1024**2, 'archive bounds/duplicates')
        for item in items:
            safe_name(item.filename)
            require(not item.is_dir() and (item.external_attr >> 16) & 0o170000 != 0o120000, 'directory/symlink archive entry')
        require(set(names) == {p.relative_to(root).as_posix() for p in root.rglob('*') if p.is_file()}, 'extracted file inventory differs')
        for name in names: require(digest(z.read(name)) == sha(root / name), 'extracted bytes differ: ' + name)
    return len(names)


def cpus(text):
    values = set()
    for part in text.split(','):
        require(re.fullmatch(r'[0-9]+(?:-[0-9]+)?', part) is not None, 'invalid observed CPU mask')
        ends = part.split('-'); first, last = int(ends[0]), int(ends[-1])
        require(0 <= first <= last < 1048576, 'invalid CPU bounds')
        new = set(range(first, last + 1)); require(not new.intersection(values), 'duplicate CPU'); values.update(new)
    return values


def counters(raw): return {p[0]: int(p[1]) for line in raw.splitlines() if len(p := line.split()) == 2}


def io_counters(raw):
    return {parts[0]: {key: int(value) for key, value in (p.split('=', 1) for p in parts[1:])}
            for line in raw.splitlines() if (parts := line.split())}


def timings(run):
    if 'phase_seconds' in run:
        out = dict(run['phase_seconds'])
        for phase, record in run['query'].items():
            samples = record['per_request_seconds']
            for name, sub in (('first', samples[:1]), ('front64', samples[:64]), ('after64', samples[64:])):
                if sub: out[phase + '/' + name] = math.fsum(sub)
        return out
    return {**{'lifecycle/' + k: v for k, v in run['lifecycle_seconds'].items()},
            **{'query/' + k: v['wall_seconds'] for k, v in run['phases'].items()},
            'accounted_timer_sum': math.fsum(run['lifecycle_seconds'].values()) + math.fsum(x['wall_seconds'] for x in run['phases'].values())}


def startup_cases(root, repo, commit):
    data = read(root / 'query-startup-policy.json')
    expected = [
        ('automatic single CPU retains real worker and calibration', 1, {}, {'threshold': '9223372036854775807', 'mode': '2', 'min_rows': '9223372036854775807', 'threads_before': '1', 'threads_after': '2', 'wanted': '0'}),
        ('automatic two CPUs unchanged', 2, {'MVDB_WAKE_US_OVERRIDE': '0'}, {'threshold': '<unset>', 'mode': '2', 'min_rows': '1024', 'wanted': '1'}),
        ('explicit force remains force on one CPU', 1, {'MVDB_QUERY_THREADS': '2', 'MVDB_WAKE_US_OVERRIDE': '0'}, {'threshold': '<unset>', 'mode': '1', 'wanted': '1'}),
        ('explicit serial still avoids worker and calibration', 1, {'MVDB_QUERY_THREADS': '1'}, {'threshold': '<unset>', 'mode': '0', 'threads_before': '1', 'threads_after': '1', 'wanted': '0'}),
        ('explicit threshold remains effective', 1, {'MVDB_QUERY_FANOUT_ROWS': '0', 'MVDB_WAKE_US_OVERRIDE': '0'}, {'threshold': '0', 'mode': '2', 'min_rows': '0', 'wanted': '1'}),
        ('explicit empty thread value retains prior default', 1, {'MVDB_QUERY_THREADS': '', 'MVDB_WAKE_US_OVERRIDE': '0'}, {'threshold': '<unset>', 'mode': '2', 'min_rows': '1024', 'wanted': '1'}),
        ('explicit empty threshold retains prior default', 1, {'MVDB_QUERY_FANOUT_ROWS': '', 'MVDB_WAKE_US_OVERRIDE': '0'}, {'threshold': '', 'mode': '2', 'min_rows': '1024', 'wanted': '1'}),
        ('single-thread override remains strongest', 1, {'MVDB_SINGLE_THREAD': '1', 'MVDB_QUERY_THREADS': '2'}, {'threshold': '<unset>', 'mode': '0', 'threads_after': '1', 'wanted': '0'}),
        ('explicit single-thread zero retains prior default', 1, {'MVDB_SINGLE_THREAD': '0', 'MVDB_WAKE_US_OVERRIDE': '0'}, {'threshold': '<unset>', 'mode': '2', 'min_rows': '1024', 'wanted': '1'}),
        ('parser override is neither rewritten nor blocking', 1, {'MVDB_PARSE_THREADS': '2'}, {'threshold': '9223372036854775807', 'parse': '2', 'mode': '2', 'threads_after': '2', 'wanted': '0'}),
        ('affinity read failure preserves default', 1, {'MVDB_WAKE_US_OVERRIDE': '0'}, {'threshold': '<unset>', 'mode': '2', 'min_rows': '1024', 'wanted': '1'})]
    require(data['status'] == 'passed' and data['case_count'] == len(data['cases']) == 11, 'startup gate incomplete')
    require(set(data['source_file_sha256']) == {'query_startup_policy.h', 'query_pool.h'}, 'startup source inventory')
    for name, h in data['source_file_sha256'].items(): require(digest(blob(repo, commit, 'minivec/src/' + name)) == h, 'startup source mismatch')
    for item, (name, count, env, observed) in zip(data['cases'], expected):
        require(item['name'] == name and len(set(item['affinity'])) == count and item['environment'] == env, 'startup case identity differs')
        require(all(item['observed'][k] == v for k, v in observed.items()), 'startup expectation fails: ' + name)
    return data


def training_log(root, repo, commit):
    text = (root / 'docker-build.log').read_text(encoding='utf8')
    require(COMPILER in text and COMPILER.encode() in blob(repo, commit, 'Dockerfile'), 'compiler pin missing')
    records = []
    for line in text.splitlines():
        if '{' not in line: continue
        try: data = json.loads(line[line.index('{'):])
        except json.JSONDecodeError: continue
        if isinstance(data, dict) and 'actual_file' in data and 'expected_file' in data: records.append(data)
    expected = {(f'responses-{t}-{p}.jsonl', f'phase-{p}.expected.jsonl', [951, 41, 14][p]) for t in (1, 2) for p in range(3)}
    require(len(records) == 6 and {(r['actual_file'], r['expected_file'], r['responses']) for r in records} == expected and
            all(r['status'] == 'passed' for r in records), 'six PGO training oracle records missing')
    profiles = re.findall(r'\b([0-9a-f]{64})\s+(/pgo/minivec-[A-Za-z_]+\.gcda)', text)
    require(len(profiles) == 6 and {p for _, p in profiles} == {'/pgo/minivec-' + n + '.gcda' for n in ('db', 'exec', 'flat_index', 'main', 'sql', 'value')}, 'PGO profile inventory differs')
    for p in ('minivec/tools/pgo/train.cpp', 'minivec/tools/pgo/run-training.sh', 'Dockerfile'):
        require(blob(repo, commit, p) == blob(repo, BASE, p), 'training/build policy changed: ' + p)
    return {'oracle': records, 'profile_hashes_from_build_log': dict((p, h) for h, p in profiles),
            'scope': 'Build log records six independent oracle successes and six profile digests; release artifact does not include raw gcda bytes.'}


def reproduce_workloads(repo, commit):
    # Workload generation is pure Python. No binary is launched and no measured
    # timer is reused; temporary paths mirror the Git source layout for imports.
    with tempfile.TemporaryDirectory(prefix='mvdb-workload-audit-') as td:
        tree = Path(td)
        for path in TOOLS:
            target = tree / path; target.parent.mkdir(parents=True, exist_ok=True); target.write_bytes(blob(repo, commit, path))
        sys.dont_write_bytecode = True
        sys.path.insert(0, str(tree / 'minivec/tools'))
        try:
            harness = importlib.import_module('small_compute')
            base = importlib.import_module('benchmark_iteration')
            writes = importlib.import_module('benchmark_write_query')
            projection = importlib.import_module('benchmark_projection')
            result = {}
            for name in CASES:
                work = harness.workload(name, base, writes, projection)
                result[name] = harness.workload_identity(name, work, base)
                del work
        finally:
            sys.path.remove(str(tree / 'minivec/tools'))
    return result


def workload_reference(repo, commit, archive, local):
    # The old Linux control is an independently audited artifact with a fixed API
    # digest. SQL hashes reproduce locally. Some float-oracle JSON bytes differ
    # between Windows and Linux; preserve that limitation instead of inventing a
    # cross-platform byte-for-byte oracle verification.
    require(archive.stat().st_size == 1388817 and sha(archive) == '9b57525ab07fb23865aadb969d5c929a470eadd4a16fb98ab4434bd8db053957', 'Linux reference artifact differs')
    with zipfile.ZipFile(archive) as z:
        raw = z.read('measurements.json'); manifest = json.loads(z.read('hashes.json'))['artifacts']
        record = next(x for x in manifest if x['path'] == 'measurements.json')
        require(len(raw) == record['bytes'] and digest(raw) == record['sha256'], 'Linux reference measurement differs')
        previous = json.loads(raw)
    require(previous['status'] == 'passed' and previous['completed_pairs'] == 12, 'Linux reference incomplete')
    old = 'b2d7796d002bdbf9a6d1668eb35f1573a642dcb8'
    for path in TOOLS - {'minivec/tools/small_compute.py'}:
        require(blob(repo, old, path) == blob(repo, commit, path), 'workload generator/dependency changed: ' + path)
    for name in ('workload', 'workload_identity'):
        def definition(revision):
            tree = ast.parse(blob(repo, revision, 'minivec/tools/small_compute.py').decode())
            return ast.dump(next(node for node in tree.body if isinstance(node, ast.FunctionDef) and node.name == name), include_attributes=False)
        require(definition(old) == definition(commit), 'workload identity implementation changed')
    expected = {x['scenario']: x for x in previous['workloads']}; differences = []
    require(tuple(expected) == CASES, 'Linux reference workload inventory differs')
    for name, item in local.items():
        require({k: v for k, v in item.items() if k != 'sha256'} == {k: v for k, v in expected[name].items() if k != 'sha256'}, 'SQL generator or workload parameters do not reproduce')
        if item != expected[name]: differences.append(name)
    require(set(differences) <= {'resident30k', 'filter60k'}, 'unexpected local full-content hash difference')
    return expected, {'linux_reference_artifact_sha256': sha(archive), 'linux_reference_commit': old,
        'linux_reference_measurement_sha256': digest(raw), 'linux_expected_workload_identities': expected,
        'local_recomputed_workload_identities': local, 'all_sql_generator_hashes_and_parameters_match': True,
        'local_complete_content_hash_mismatch_scenarios': differences,
        'scope': 'The same Linux full-content hash is required in new 1/2-CPU measurements. Windows SQL hashes and parameters match all six scenarios; full float-oracle content is not claimed byte-identical across operating systems for the listed mismatches.'}


def verify_measurements(data, count, cases, programs, ids, proof, workloads):
    expected = [{'scenario': n, 'seed': 7319, 'pair_index': i, 'order': ['baseline', 'candidate'] if i == 0 else ['candidate', 'baseline']} for n in cases for i in range(2)]
    require(data['status'] == 'passed' and data['expected_pairs'] == data['completed_pairs'] == len(data['pairs']) == len(expected), 'measurement incomplete')
    require(data['plan'] == expected and [{k: p[k] for k in ('scenario', 'seed', 'pair_index', 'order')} for p in data['pairs']] == expected, 'measurement plan mismatch')
    require(data['comparison_kind'] == 'whole_version_diagnostic' and data['official_score'] is None and data['official_binary_identity_known'] is False, 'scope mismatch')
    require(data['identity_record_sha256'] == sha(programs / 'identities.json'), 'identity JSON mismatch')
    require(data['workloads'] == [workloads[n] for n in cases], 'regenerated workload/oracle hash mismatch')
    require(data['db_cpu_count'] == count and len(set(data['db_cpus'])) == count and data['protection_only'] == (count == 2), 'CPU plan mismatch')
    require(set(data['db_cpus']).issubset(set(data['host']['driver_affinity'])), 'CPU selection outside inherited driver affinity')
    require(data['requested_limits'] == {'cpu_quota_us': count * 100000, 'cpu_period_us': 100000, 'memory_max': None, 'swap_max': None}, 'resource request mismatch')
    require(data['launcher_sha256'] == sha(programs.parent / 'cgroup_exec'), 'actual launcher differs')
    seen = {}
    for path, h in data['tool_hashes'].items():
        names = [name for name in TOOLS if path.endswith('/' + name)]
        require(len(names) == 1 and names[0] not in seen, 'tool path inventory mismatch')
        name = names[0]; seen[name] = h; require(proof['harness_file_sha256'][name] == h, 'executed tool differs from Git proof')
    require(set(seen) == TOOLS, 'tool set incomplete')
    for role in ('baseline', 'candidate'):
        item = data['identities'][role]
        for key in ('binary_sha256', 'source_commit', 'evidence_sha256', 'environment'):
            require(item[key] == ids[role][key], 'measured role identity mismatch')
        require(item['environment'] == {}, 'unexpected runtime override')
    details, grouped = [], {}
    for pair in data['pairs']:
        name = pair['scenario']; require(pair['all_responses_identical'] is True, 'output equivalence absent')
        b, c = pair['baseline'], pair['candidate']; detail = {k: pair[k] for k in ('scenario', 'seed', 'pair_index', 'order')}; detail['sides'] = {}
        for role, run in (('baseline', b), ('candidate', c)):
            g, adapter, policy = run['cgroup'], run['adapter'], run['thread_policy_observations']
            require(run['declared_environment'] == {}, 'run override differs')
            require(not g['timeout'] and not g.get('request_timeout_observed') and not g.get('cleanup_kill_required') and not g.get('watchdog_error') and not any(g['oom_events_delta'].values()), 'timeout/OOM/process failure')
            for when in ('before', 'after'):
                require(g[when]['cpu.max'].split() == [str(count * 100000), '100000'], 'actual quota differs')
                require(g[when]['memory.max'] == g[when]['memory.swap.max'] == 'max', 'own cgroup memory override unexpected')
            require(not g['after']['cgroup.procs'].strip(), 'live DB remains')
            ready = adapter['ready_memberships']; require(len(ready) == (1 if name == 'wide768' else 2), 'ready/restart evidence missing')
            for item in ready:
                require(item['pid'] in item['members'] and item['driver_pid'] not in item['members'] and
                        item['actual_exe'] == data['identities'][role]['binary'] and cpus(item['cpus_allowed_list']) == set(data['db_cpus']), 'actual executable/cgroup/affinity mismatch')
            phases = adapter['phase_cgroups']; require(len(phases) == (14 if name == 'wide768' else 15 if name.startswith('spill_') else 7), 'phase observations missing')
            for phase in phases:
                require(not phase.get('native_tasks_error') and not phase.get('task_read_errors') and phase['native_tasks'] and sum(t['main'] for t in phase['native_tasks']) == 1, 'native task evidence missing')
                require(all(cpus(t['cpus_allowed_list']) == set(data['db_cpus']) for t in phase['native_tasks']), 'native task affinity drift')
            before, after = counters(g['before']['cpu.stat']), counters(g['after']['cpu.stat'])
            require(g['resource_delta']['cpu_stat_delta'] == {k: v - before.get(k, 0) for k, v in after.items()} and
                    g['resource_delta']['memory_peak_bytes'] == int(g['after']['memory.peak']), 'resource arithmetic differs')
            ib, ia = io_counters(g['before']['io.stat']), io_counters(g['after']['io.stat'])
            require(g['resource_delta']['io_stat_delta'] == {dev: {k: v - ib.get(dev, {}).get(k, 0) for k, v in fields.items()} for dev, fields in ia.items()}, 'device IO counter arithmetic differs')
            require(policy['stderr_complete'] is True and policy['requested_query_threads'] == 'automatic', 'policy observations incomplete')
            logs = policy['fanout_log_lines']; wake = [x for x in logs if '(measured, median of 200 handshakes)' in x]
            require(len(wake) == len(ready), 'real startup calibration missing')
            marker = 'single-CPU affinity; adaptive query fanout disabled, startup calibration retained'
            if count == 1 and role == 'candidate':
                require(sum(marker in line for line in logs) == len(ready) and not any('-> 2 threads' in x for x in logs), 'single CPU candidate policy not observed')
            else: require(not any(marker in x for x in logs), 'unexpected affinity default activation')
            cpu_intervals = {}
            by_phase = {x['phase']: x for x in phases}
            for start, end in (('after_index_build', 'query_before_update'), ('after_restart', 'query_after_restart')):
                if start in by_phase and end in by_phase:
                    left, right = by_phase[start], by_phase[end]
                    old = {(t['tid'], t['starttime_ticks']): t['cpu_ticks'] for t in left['native_tasks']}
                    cpu_intervals[end] = {'start': start, 'end': end, 'cpu_usage_usec': counters(right['cpu.stat'])['usage_usec'] - counters(left['cpu.stat'])['usage_usec'],
                        'nonmain_cpu_ticks_delta': sum(t['cpu_ticks'] - old.get((t['tid'], t['starttime_ticks']), 0) for t in right['native_tasks'] if not t['main']),
                        'scope': 'Includes restart ID/vector/payload verification.' if start == 'after_restart' else 'Post-index snapshot through first query phase; excludes restart verification.',
                        'nonmain_scope': 'All nonmain native tasks, not exclusively a named query worker.'}
            detail['sides'][role] = {'resources': g['resource_delta'], 'policy': policy, 'cpu_intervals': cpu_intervals}
        if name == 'wide768':
            for run in (b, c):
                require(run['status'] == 'passed' and set(run['phases']) == LABELS, 'projection phase schema differs')
                for phase in run['phases'].values():
                    require(len(phase['requests']) == 3 and phase['independent_oracle'] and phase['wall_seconds'] == sum(r['seconds'] for r in phase['requests']), 'projection oracle/timer evidence missing')
            for label in LABELS:
                require([(r['response_sha256'], r['response_bytes']) for r in b['phases'][label]['requests']] == [(r['response_sha256'], r['response_bytes']) for r in c['phases'][label]['requests']], 'projection responses differ')
        else:
            require(b['response_sha256'] == c['response_sha256'], 'lifecycle responses differ')
            for run in (b, c):
                if name.startswith('spill_'):
                    require(run['real_spill_observed'] is True and run['correctness']['all_query_responses_independent_oracle'] is True and len(run['write_cycles']) == 4 and len(run['query']) == 6 and
                            all(len(q['per_request_seconds']) == (16 if name.endswith('q16') else 1) for q in run['query'].values()), 'spill independent oracle/counts missing')
                    require(run['correctness']['all_restarted_ids_checked'] == 5000 and run['correctness']['all_mutated_payloads_and_tombstones_checked'] == [0, 1, 7, 1007], 'spill restart verification missing')
                else:
                    require(set(run['query']) == {'query_before_update', 'query_after_restart'} and all(len(q['per_request_seconds']) == 1000 for q in run['query'].values()) and
                            run['correctness']['sampled_topk_oracle_queries'] == [0, 1, 999], 'resident oracle/counts missing')
                    rows = workloads[name]['rows']
                    require(run['correctness']['all_restarted_ids_checked'] == rows and run['correctness']['restarted_vector_ids_checked'] == [0, 1, rows // 2, rows - 1], 'resident restart verification missing')
        bv, cv = timings(b), timings(c); require(set(bv) == set(cv), 'phase timers differ')
        for phase in bv:
            require(math.isfinite(bv[phase]) and math.isfinite(cv[phase]) and bv[phase] >= 0 and cv[phase] > 0, 'invalid measured timer')
            grouped.setdefault(name, {}).setdefault(phase, []).append({'pair_index': pair['pair_index'], 'order': pair['order'], 'baseline_seconds': bv[phase], 'candidate_seconds': cv[phase], 'baseline_over_candidate': bv[phase] / cv[phase], 'candidate_slower': cv[phase] > bv[phase]})
        details.append(detail)
    summary = {name: {phase: {'raw_pairs': rows, 'median_baseline_over_candidate': median(r['baseline_over_candidate'] for r in rows), 'candidate_slower_pairs': sum(r['candidate_slower'] for r in rows)} for phase, rows in phases.items()} for name, phases in grouped.items()}
    require(summary == data['summary'], 'independent summary arithmetic differs')
    return {'verified_pairs': len(expected), 'summary': summary, 'resources_and_policy': details,
            'host': data['host'], 'db_cpus': data['db_cpus'], 'ancestor_constraints': data['pairs'][0]['baseline']['cgroup']['ancestor_constraints']}


def audit(args):
    root, repo, commit = args.input.resolve(), args.repo.resolve(), args.commit
    file_count = verify_archive(root, args.archive.resolve(), args.artifact_sha256, args.artifact_bytes)
    gates, final = read(root / 'root-gates-summary.json'), read(root / 'verification-summary.json')
    require(gates['passed'] is True and set(gates['checks']) == GATES and all(x is True for x in gates['checks'].values()), 'root gates incomplete')
    require(final['passed'] is True and set(final['checks']) == GATES | {'actual_root_small_compute_20_pairs'} and all(x is True for x in final['checks'].values()), 'combined root gates incomplete')
    require(gates['runtime_commit'] == final['runtime_commit'] == commit == (root / 'runtime-commit.txt').read_text().strip(), 'root commit mismatch')
    require(gates['selected_feature_flags'] == final['selected_feature_flags'] == FLAGS, 'retained default flags differ')
    small = root / 'small-compute-root'; programs = small / 'programs'; proof = read(programs / 'root-proof.json')
    manifest = read(small / 'hashes.json')['artifacts']; paths = [x['path'] for x in manifest]
    require(len(paths) == len(set(paths)) and set(paths) == {p.relative_to(small).as_posix() for p in small.rglob('*') if p.is_file()} - {'hashes.json'}, 'small-root artifact manifest mismatch')
    for item in manifest:
        safe_name(item['path']); p = small / item['path']; require(p.stat().st_size == item['bytes'] and sha(p) == item['sha256'], 'small-root member differs')
    candidate = sha(programs / 'actual-image-minivec'); image = (root / 'image-id.txt').read_text().strip()
    require(re.fullmatch(r'sha256:[0-9a-f]{64}', image) is not None and image == gates['image_id'] == final['image_id'] == proof['image_id'], 'actual image ID mismatch')
    inspect = read(root / 'image-inspect.json'); require(len(inspect) == 1 and inspect[0]['Id'] == image, 'image inspection mismatch')
    require(candidate == proof['binary_sha256'] == gates['image_binary_sha256'] == final['image_binary_sha256'] == (root / 'image-binary-sha256.txt').read_text().split()[0], 'actual root image program differs')
    require(proof['status'] == 'verified' and proof['source_commit'] == commit and proof['feature_flags'] == FLAGS and proof['harness_matches_git'] is True, 'root proof scope mismatch')
    require(sha(programs / 'root-gates-summary.json') == sha(root / 'root-gates-summary.json') == proof['root_gate_summary_sha256'], 'pre-performance root gates changed')
    require(sha(programs / 'root-input-sha256.txt') == sha(root / 'input-sha256.txt') == proof['root_input_manifest_sha256'], 'root input manifest changed')
    inputs = {}
    for line in (root / 'input-sha256.txt').read_text().splitlines():
        h, path = line.split(maxsplit=1); path = path.lstrip('*'); safe_name(path); require(path not in inputs, 'duplicate source input'); inputs[path] = h
    expected_inputs = set(git(repo, 'ls-tree', '-r', '--name-only', commit, '--', *INPUT_PATHS).decode().splitlines())
    require(set(inputs) == expected_inputs and inputs == proof['root_input_sha256'], 'complete root input inventory differs')
    for path, h in inputs.items(): require(digest(blob(repo, commit, path)) == h, 'root input not bound to Git: ' + path)
    for path, h in proof['harness_file_sha256'].items(): require(digest(blob(repo, commit, path)) == h, 'harness not bound to Git: ' + path)
    require(TOOLS.issubset(proof['harness_file_sha256']), 'missing actual imported harness proof')
    ids = read(programs / 'identities.json'); require(set(ids) == {'baseline', 'candidate'}, 'identity role inventory differs')
    for role, item in ids.items():
        safe_name(item['binary']); safe_name(item['evidence_file'])
        require(sha(programs / item['binary']) == item['binary_sha256'] and sha(programs / item['evidence_file']) == item['evidence_sha256'] and item['environment'] == {}, 'immutable binary/proof changed')
    require(ids['candidate']['binary_sha256'] == candidate and ids['candidate']['source_commit'] == commit and ids['baseline']['binary_sha256'] == BASE_BINARY and ids['baseline']['source_commit'] == BASE, 'expected version contrast differs')
    retained = read(programs / 'retained/provenance.json')
    require(retained['status'] == 'verified' and retained['binary_sha256'] == BASE_BINARY and retained['source_commit'] == BASE and retained['harness_matches_git'] is True and retained['harness_commit'] == commit and retained['new_pgo_builds'] == 0, 'retained old PGO identity differs')
    require(retained['retained_archive_sha256'] == '88e4a73af9d333b08a6db817a78c7cb06357fcfddc05eee1b31c2a065aebfef2' and
            retained['retained_archive_bytes'] == 49685962 and retained['compiler_image'] == COMPILER and retained['feature_flags'] == FLAGS, 'retained compiler/archive policy differs')
    baseline_inputs = set(git(repo, 'ls-tree', '-r', '--name-only', BASE, '--', 'minivec/src').decode().splitlines()) | {'minivec/tools/pgo/train.cpp', 'minivec/tools/pgo/run-training.sh'}
    require(set(retained['source_and_training_sha256']) == baseline_inputs, 'retained engine/training inventory incomplete')
    for path, h in retained['source_and_training_sha256'].items(): require(digest(blob(repo, BASE, path)) == h, 'retained source/training Git mismatch')
    require(digest((programs / 'retained/prior-context.json').read_bytes()) == retained['retained_context_sha256'], 'retained prior context changed')
    starter = startup_cases(root, repo, commit); training = training_log(root, repo, commit)
    for variant in ('image', 'source'):
        for phase, count in (('handshake', 1), ('public', 20)):
            public = read(root / (variant + '-' + phase) / 'result.json')
            require(public['passed'] is True and len(public['cases']) == count and all(x['status'] == 'PASS' for x in public['cases']), 'public protocol gate missing')
    utf8 = read(root / 'image-binary-utf8.json')
    expected_utf8 = {(raw, dim, path) for raw in ('ff', 'c080', 'eda080', 'e4b8', 'f4908080', '80') for dim in (None, 127, 128) for path in ('ORDER BY id LIMIT 10', 'unbounded', 'ORDER BY id LIMIT 4096')}
    require(utf8['status'] == 'passed' and len(utf8['checks']) == 54 and {(x['malformed_hex'], x['projected_vector_dimension'], x['path']) for x in utf8['checks']} == expected_utf8 and all(x['status'] == 'passed' for x in utf8['checks']), 'actual image UTF8 gate incomplete')
    overall = read(small / 'summary.json')
    require(overall == final['small_compute'] and overall['status'] == 'passed' and overall['exit_code'] == 0 and overall['expected_pairs'] == overall['completed_pairs'] == 20 and overall['new_pgo_builds'] == 1 and overall['candidate_binary_sha256'] == candidate and overall['candidate_image_id'] == image and overall['candidate_source_commit'] == commit, '20-pair root summary binding mismatch')
    local_workloads = reproduce_workloads(repo, commit)
    expected_workloads, workload_proof = workload_reference(repo, commit, args.linux_reference_archive.resolve(), local_workloads)
    measurements = {str(count): verify_measurements(read(small / f'measurements-{count}cpu.json'), count, cases, programs, ids, proof, expected_workloads) for count, cases in ((1, CASES), (2, PROTECTION))}
    negatives, coherent_protection = [], []
    for count, report in measurements.items():
        for scenario, phases in report['summary'].items():
            for phase, entry in phases.items():
                if entry['candidate_slower_pairs'] or entry['median_baseline_over_candidate'] < 1:
                    negatives.append({'cpu_count': int(count), 'scenario': scenario, 'phase': phase, **entry})
                if count == '2' and entry['candidate_slower_pairs'] == 2:
                    coherent_protection.append({'scenario': scenario, 'phase': phase, **entry})
    return {'status': 'verified', 'verified_pairs': 20, 'source_commit': commit, 'baseline_source_commit': BASE,
            'baseline_binary_sha256': BASE_BINARY, 'candidate_binary_sha256': candidate, 'candidate_image_id': image,
            'artifact_sha256': args.artifact_sha256, 'artifact_files': file_count, 'root_git_input_count': len(inputs),
            'harness_git_files': len(proof['harness_file_sha256']), 'root_gates': gates['checks'], 'startup_cases': starter,
            'root_pgo_evidence': training, 'workload_identity_audit': workload_proof,
            'measurements': measurements, 'all_negative_or_mixed_phases': negatives,
            'two_cpu_both_orders_slower': coherent_protection,
            'actual_cpu_model': (small / 'lscpu.txt').read_text(),
            'automatic_adoption': False, 'official_score': None,
            'limitations': ['Two pairs per scenario at one seed; no confidence interval or formal score conversion.',
                'All ratios compare baseline and candidate within the same run; no ratio multiplication across different hosts or prior experiments.',
                'Version contrast includes compiler/PGO/layout effects, not a pure startup-policy ablation.',
                'Two-CPU protection uses logical CPU affinity and quota; physical-core topology is not established.',
                'Root PGO logs are audited but raw gcda profile bytes are not in the release artifact.',
                'Input/oracle generation is repeated in Windows. SQL hashes/parameters match all scenarios; two complete float-oracle content hashes differ locally, so new Linux evidence must match the fixed prior Linux hashes. No local database run or absent raw response-body reconstruction is claimed.',
                'Every negative timing phase remains visible. Coherent two-CPU protection regressions require rejection or explanation before default adoption.']}


def main():
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument('--input', type=Path, required=True); p.add_argument('--archive', type=Path, required=True)
    p.add_argument('--repo', type=Path, default=Path(__file__).resolve().parent / 'seekdb')
    p.add_argument('--linux-reference-archive', type=Path, default=Path(__file__).resolve().parent / 'performance/no-fanout-b2d7796.zip')
    p.add_argument('--commit', required=True); p.add_argument('--artifact-sha256', required=True)
    p.add_argument('--artifact-bytes', type=int, required=True); p.add_argument('--output', type=Path, required=True)
    args = p.parse_args(); require(not args.output.exists(), 'refuse overwrite')
    require(not args.output.resolve().is_relative_to(args.input.resolve()), 'analysis must be outside evidence tree')
    require(re.fullmatch('[0-9a-f]{40}', args.commit) is not None and re.fullmatch('[0-9a-f]{64}', args.artifact_sha256) is not None, 'invalid expected identity')
    result = audit(args)
    args.output.write_text(json.dumps(result, ensure_ascii=False, indent=2, allow_nan=False) + '\n', encoding='utf8')
    print(json.dumps({'status': result['status'], 'verified_pairs': result['verified_pairs'],
                      'candidate_binary_sha256': result['candidate_binary_sha256'],
                      'two_cpu_both_orders_slower_phases': len(result['two_cpu_both_orders_slower']),
                      'output': str(args.output)}))


if __name__ == '__main__': main()
