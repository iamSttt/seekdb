"""Narrow hidden-source recovery check; never modifies actual evidence or runs DB."""
import json
from pathlib import Path
import tempfile
import analyze_highest_compare as audit

ROOT = Path(__file__).resolve().parent
REPO = ROOT / 'seekdb'
checks = []
entry = {'path': audit.RECOVERABLE_SOURCE, 'bytes': 100,
         'sha256': 'dd9b806988a5bcc72875b9cee43b90025efa58b75770ba975d9347584d8444ce'}
def test(name, item, artifact_sha, commit, expected):
    with tempfile.TemporaryDirectory(prefix='highest-source-recovery-') as td:
        directory = Path(td)
        (directory / 'hashes.json').write_text(json.dumps({'artifacts': [item]}), encoding='utf8')
        try:
            virtual, report = audit.manifest_with_exact_source_recovery(directory, REPO, commit, artifact_sha)
        except ValueError as error:
            assert not expected, str(error)
            checks.append({'check': name, 'status': 'passed', 'rejection': str(error)})
        else:
            assert expected
            assert set(virtual) == {audit.RECOVERABLE_SOURCE} and report['raw_source_archive_complete'] is False
            assert not (directory / audit.RECOVERABLE_SOURCE).exists()
            checks.append({'check': name, 'status': 'passed', 'physical_source_created': False})

test('known_exact_missing_source_in_memory_only', entry, audit.RECOVERY_ARTIFACT_SHA, audit.RECOVERY_COMMIT, True)
test('wrong_raw_artifact_identity_rejected', entry, '0' * 64, audit.RECOVERY_COMMIT, False)
test('wrong_harness_commit_rejected', entry, audit.RECOVERY_ARTIFACT_SHA, '0' * 40, False)
test('missing_binary_never_recovered', entry | {'path': 'programs/ee/minivec'}, audit.RECOVERY_ARTIFACT_SHA, audit.RECOVERY_COMMIT, False)
test('missing_other_source_never_recovered', entry | {'path': 'ee-context/minivec/src/vector.cpp'}, audit.RECOVERY_ARTIFACT_SHA, audit.RECOVERY_COMMIT, False)
test('manifest_hash_tamper_rejected', entry | {'sha256': '0' * 64}, audit.RECOVERY_ARTIFACT_SHA, audit.RECOVERY_COMMIT, False)
root = ROOT / 'performance/highest-95afba3'
virtual, report = audit.manifest_with_exact_source_recovery(root, REPO, audit.RECOVERY_COMMIT, audit.RECOVERY_ARTIFACT_SHA)
verified = audit.original_ee(root, REPO, audit.RECOVERY_COMMIT, audit.read(root / 'prepare-proof.json'), virtual)
assert verified['verified_context_files'] == 24 and not (root / audit.RECOVERABLE_SOURCE).exists()
checks.append({'check': 'actual_remaining_members_and_full_EE_object_chain_verified', 'status': 'passed'})
result = {'status': 'passed', 'checks': checks, 'database_executions': 0,
          'raw_artifact_or_extraction_modified': False, 'source_recovery': report,
          'reader_sha256': audit.sha(ROOT / 'analyze_highest_compare.py')}
(ROOT / 'highest-source-recovery-preflight.json').write_text(json.dumps(result, ensure_ascii=False, indent=2)+'\n', encoding='utf8')
print(json.dumps({'status': 'passed', 'checks': len(checks), 'database_executions': 0}))
