"""Pure Python provenance and fail-closed preflight; zero database executions."""
from copy import deepcopy
import hashlib
import json
from pathlib import Path
import sys
import tempfile

import analyze_highest_compare as audit

ROOT = Path(__file__).resolve().parent
REPO = ROOT / 'seekdb'
COMMIT = '95afba3993cb21cdce32acf2502312262b8ae9ac'
sys.path.insert(0, str(REPO / 'minivec/tools'))
import prepare_highest_compare as preparation

checks = []
def passed(name): checks.append({'check': name, 'status': 'passed'})
def rejected(name, fn):
    try: fn()
    except (ValueError, KeyError, FileNotFoundError) as error:
        checks.append({'check': name, 'status': 'passed', 'rejected_reason': str(error)})
    else: raise AssertionError('invalid evidence accepted: ' + name)

with tempfile.TemporaryDirectory(prefix='highest-reader-provenance-') as td:
    root = Path(td)
    # Windows checkout CRLF bytes differ from committed Linux tool blobs. This
    # preflight uses immutable archives/Git inputs, not a claimed Linux checkout.
    manifest, manifest_raw, source_files = preparation.ee_source(REPO / preparation.EE_ARCHIVE)
    for name, raw in source_files.items():
        target = root / 'ee-context' / name; target.parent.mkdir(parents=True, exist_ok=True); target.write_bytes(raw)
    (root / 'ee-source-manifest.json').write_bytes(manifest_raw)
    prep = {'ee_source_commit': audit.EE, 'ee_source_tree': audit.EE_TREE,
        'ee_archive_sha256': audit.EE_ARCHIVE_SHA, 'ee_source_manifest_sha256': audit.digest(manifest_raw),
        'ee_source_sha256': {name: audit.digest(raw) for name, raw in source_files.items()},
        'crc_archive_sha256': audit.CRC_ARCHIVE_SHA,
        'imported': preparation.import_crc(REPO, root)}
    audit.original_ee(root, REPO, COMMIT, prep); passed('actual_EE_24_Git_inputs')
    audit.imported_programs(root, REPO, COMMIT, prep); passed('actual_R_C_archived_bytes_and_source')
    path = root / 'ee-context/minivec/src/vector.cpp'; raw = path.read_bytes(); path.unlink()
    rejected('missing_original_vector_cpp', lambda: audit.original_ee(root, REPO, COMMIT, prep)); path.write_bytes(raw)
    path.write_bytes(raw + b'\n')
    rejected('changed_original_vector_cpp', lambda: audit.original_ee(root, REPO, COMMIT, prep)); path.write_bytes(raw)
    extra = root / 'ee-context/minivec/src/unexpected.cpp'; extra.write_bytes(b'')
    rejected('extra_wildcard_compilation_input', lambda: audit.original_ee(root, REPO, COMMIT, prep)); extra.unlink()
    path = root / 'programs/crc/minivec'; raw = path.read_bytes(); path.write_bytes(raw[:-1])
    rejected('wrong_imported_CRC_binary', lambda: audit.imported_programs(root, REPO, COMMIT, prep)); path.write_bytes(raw)
    path = root / 'programs/retained/original-proof.json'; raw = path.read_bytes(); path.unlink()
    rejected('missing_retained_original_proof', lambda: audit.imported_programs(root, REPO, COMMIT, prep)); path.write_bytes(raw)

old = ROOT / 'performance/crc-root-780be2c/small-compute-root'
assert old.is_dir(), 'prior immutable telemetry required for schema regression preflight'
programs = old / 'programs'; ids = audit.read(programs / 'identities.json'); proof = audit.read(programs / 'root-proof.json')
one = audit.read(old / 'measurements-1cpu.json')
workloads = {item['scenario']: item for item in one['workloads']}
for count, cases in ((1, audit.core.CASES), (2, audit.core.PROTECTION)):
    data = audit.read(old / f'measurements-{count}cpu.json')
    audit.core.verify_measurements(data, count, cases, programs, ids, proof, workloads)
    extra = audit.summarize_extra(data)
    assert set(extra) == set(cases)
    assert all('first_lifetime_no_restart' in entry and 'whole_cgroup_cpu_usec' in entry for entry in extra.values())
    passed('prior_actual_' + str(count) + 'cpu_schema_and_lifecycle_arithmetic_only')

def verify_changed(fn):
    changed = deepcopy(one); fn(changed)
    audit.core.verify_measurements(changed, 1, audit.core.CASES, programs, ids, proof, workloads)
rejected('missing_pair', lambda: verify_changed(lambda d: d['pairs'].pop()))
rejected('mixed_mode_policy', lambda: verify_changed(lambda d: d.__setitem__('query_mode_policy', 'mixed')))
rejected('wrong_memory_limit', lambda: verify_changed(lambda d: d['pairs'][0]['candidate']['cgroup']['before'].__setitem__('memory.max', '1073741824')))
rejected('wrong_actual_executable', lambda: verify_changed(lambda d: d['pairs'][0]['candidate']['adapter']['ready_memberships'][0].__setitem__('actual_exe', '/unbound/program')))

report = {'status': 'passed', 'checks': checks, 'database_executions': 0, 'new_performance_pairs': 0,
    'scope': 'Actual archived EE sources and R/C programs are read-only verified. Existing CRC telemetry only exercises reader schema/arithmetic. No highest-compare measurement has been executed by this preflight.',
    'reader_sha256': audit.sha(ROOT / 'analyze_highest_compare.py'),
    'reused_core_reader_sha256': audit.sha(ROOT / 'analyze_crc_root.py')}
(ROOT / 'highest-reader-preflight.json').write_text(json.dumps(report, ensure_ascii=False, indent=2) + '\n', encoding='utf8')
print(json.dumps({'status': 'passed', 'checks': len(checks), 'database_executions': 0, 'new_performance_pairs': 0}))
