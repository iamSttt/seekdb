"""Offline retained ELF/PGO inspection, not runtime or causal performance proof."""
import bisect
from collections import Counter, defaultdict
import difflib
import hashlib
import json
from pathlib import Path
import re
import struct
import sys

HERE = Path(__file__).resolve().parent
sys.path.insert(0, str(HERE / 'elf-inspection-deps'))
from elftools.elf.elffile import ELFFile
from capstone import Cs, CS_ARCH_X86, CS_MODE_64, CS_GRP_CALL, CS_GRP_JUMP
from capstone.x86_const import X86_OP_IMM, X86_OP_REG, X86_OP_MEM, X86_REG_RIP

COUNTERS = ['arcs', 'interval', 'pow2', 'topn', 'indirect_call', 'average', 'ior', 'time_profiler']
ROOTS = {'old_B': 'bulk-typed-c562aa2/baseline-pgo', 'old_C': 'bulk-typed-c562aa2/bulk-pgo',
         'new_B': 'bulk-guard-85cded3/baseline-pgo', 'new_C': 'bulk-guard-85cded3/bulk-pgo'}

def sha(b): return hashlib.sha256(b).hexdigest()

class Elf:
    def __init__(self, path):
        self.file = path.open('rb'); self.elf = ELFFile(self.file)
        self.symbols = list(self.elf.get_section_by_name('.symtab').iter_symbols())
        self.named = {s.name:s for s in self.symbols if s.name}
        self.loads = [s for s in self.elf.iter_segments() if s['p_type']=='PT_LOAD']
        self.refs = sorted((s['st_value'],s['st_size'],s.name) for s in self.symbols
                           if s['st_value'] and s['st_size'] and s['st_info']['type'] in ('STT_FUNC','STT_OBJECT'))
        self.starts = [x[0] for x in self.refs]
    def read(self, address, size):
        for segment in self.loads:
            start=segment['p_vaddr']; length=segment['p_filesz']
            if start<=address and address+size<=start+length:
                self.file.seek(segment['p_offset']+address-start); return self.file.read(size)
        raise ValueError('ELF address not backed by file: '+hex(address))
    def string(self,address):
        result=bytearray()
        for i in range(4096):
            b=self.read(address+i,1)
            if b==b'\0':return result.decode()
            result+=b
        raise ValueError('unbounded ELF string')
    def reference(self,address,current):
        start,end,name=current
        if start<=address<end:return 'self+'+hex(address-start)
        at=bisect.bisect_right(self.starts,address)-1
        for p in range(at,max(-1,at-12),-1):
            base,size,name=self.refs[p]
            if base<=address<base+size:return name+'+'+hex(address-base)
        for section in self.elf.iter_sections():
            if section['sh_addr']<=address<section['sh_addr']+section['sh_size'] and section['sh_addr']:
                return section.name+'+'+hex(address-section['sh_addr'])
        return hex(address)
    def gcov_functions(self):
        result={}
        for s in self.symbols:
            if not s.name.startswith('__gcov_.'):continue
            key,ident,line,cfg=struct.unpack('<QIII',self.read(s['st_value'],20))
            filename_ptr=struct.unpack('<Q',self.read(key+24,8))[0]
            unit=Path(self.string(filename_ptr)).name
            k=(unit,ident,line,cfg)
            assert k not in result or result[k]==s.name
            result[k]=s.name[len('__gcov_.'):]
        return result

def gcda(path,names):
    data=path.read_bytes(); magic,version,stamp,checksum=struct.unpack_from('<4I',data)
    assert magic==0x67636461 and version==0x4233332a, 'require GCC13.3 little-endian data'
    offset=16; current=None; functions=[]; summaries=[]
    while offset<len(data):
        tag=struct.unpack_from('<I',data,offset)[0];offset+=4
        if tag==0:assert offset==len(data);break
        length=struct.unpack_from('<i',data,offset)[0];offset+=4
        assert abs(length)<1000000
        body=data[offset:offset+max(length,0)];offset+=max(length,0)
        assert len(body)==max(length,0)
        if tag==0xa1000000:
            assert length==8;summaries.append(list(struct.unpack('<2I',body)));continue
        if tag==0x01000000:
            if length==0:current=None;continue
            assert length==12
            ident,line,cfg=struct.unpack('<3I',body)
            name=names[(path.name,ident,line,cfg)]
            current={'name':name,'ident':ident,'line_checksum':line,'cfg_checksum':cfg,'counters':{}}
            functions.append(current);continue
        counter=(tag-0x01a10000)//0x20000
        assert tag==0x01a10000+counter*0x20000 and 0<=counter<len(COUNTERS) and current is not None
        assert length%8==0
        values=list(struct.unpack('<'+'q'*(length//8),body)) if length>=0 else [0]*(-length//8)
        current['counters'][COUNTERS[counter]]=values
    assert offset==len(data)
    return {'header':{'stamp':stamp,'checksum':checksum,'summary_runs_summax':summaries},'functions':functions,'sha256':sha(data)}

def parse_nm(path):
    result={}
    for line in path.read_text().splitlines():
        m=re.match(r'([0-9a-f]+) ([0-9a-f]+) ([A-Za-z]) (.*)',line)
        if m and m[3] in 'tTwW':result[m[4]]={'address':int(m[1],16),'bytes':int(m[2],16)}
    return result

def relevant(name):
    if 'mvdb::execute_impl(' in name: return True
    return (name.startswith(('mvdb::Database::scan_vectors(', 'mvdb::execute_impl(', 'mvdb::query_fanout_',
                             'mvdb::query_pool_detail::', 'mvdb::FlatIndex::posting_span(', 'mvdb::FlatIndex::integer_posting('))
            and '::{' not in name) or name.startswith(('mvdb::distance_', 'mvdb::quantized_', 'mvdb::QuantizedQueryBound::', 'mvdb::DistanceBoundContext::'))

def disassemble(elf,record):
    address,size=record['address'],record['bytes'];code=elf.read(address,size)
    md=Cs(CS_ARCH_X86,CS_MODE_64);md.detail=True
    instructions=list(md.disasm(code,address));assert sum(i.size for i in instructions)==size
    normalized=[];display=[]
    for i in instructions:
        operands=[]
        for op in i.operands:
            if op.type==X86_OP_REG: operands.append(i.reg_name(op.reg))
            elif op.type==X86_OP_IMM:
                value=op.imm
                operands.append(elf.reference(value,(address,address+size,'')) if i.group(CS_GRP_CALL) or i.group(CS_GRP_JUMP) or 0x400000<=value<0x700000 else str(value))
            elif op.type==X86_OP_MEM:
                mem=op.mem
                if mem.base==X86_REG_RIP:operands.append('mem'+str(op.size)+':'+elf.reference(i.address+i.size+mem.disp,(address,address+size,'')))
                else:operands.append('mem'+str(op.size)+':'+str((i.reg_name(mem.base),i.reg_name(mem.index),mem.scale,mem.disp)))
            else:operands.append('type'+str(op.type))
        normalized.append(i.mnemonic+' '+','.join(operands))
        display.append(hex(i.address-address)+' '+i.mnemonic+' '+i.op_str)
    return normalized,display,sha(code)

def compare_profiles(a,b):
    all_changes=[];summary={}
    for unit in a:
        af={f['name']:f for f in a[unit]['functions']};bf={f['name']:f for f in b[unit]['functions']}
        counts=Counter();changed=[]
        for name in sorted(af.keys()&bf.keys()):
            x,y=af[name],bf[name]
            if x['cfg_checksum']!=y['cfg_checksum']:
                changed.append({'name':name,'cfg_changed':True});counts['cfg_changed']+=1;continue
            for kind in sorted(x['counters'].keys()|y['counters'].keys()):
                u,v=x['counters'].get(kind,[]),y['counters'].get(kind,[])
                if u!=v:
                    counts[kind+'_functions_changed']+=1
                    differences=[{'index':i,'before':left,'after':right} for i,(left,right) in enumerate(zip(u,v)) if left!=right]
                    changed.append({'name':name,'kind':kind,'lengths':[len(u),len(v)],'differences':differences})
        summary[unit]={'function_counts':[len(af),len(bf)],'common_functions':len(af.keys()&bf.keys()),
                       'added':sorted(bf.keys()-af.keys()),'removed':sorted(af.keys()-bf.keys()),'changed':dict(counts)}
        all_changes.append({'unit':unit,'differences':changed})
    return {'summary':summary,'all_changed_counters':all_changes}

def main():
    data={};profiles={};elfs={};symbols={};nms={}
    for role,relative in ROOTS.items():
        root=HERE/'performance'/relative;training=root/'training'
        context=json.loads((root.parent/'context.json').read_text())['profile_source_proof']['baseline' if role.endswith('B') else 'bulk']
        assert sha((root/'minivec').read_bytes())==context['binary_sha256']
        for name,expected in context['layout_sha256'].items():
            assert sha((training/name).read_bytes())==expected
        for name,expected in context['source_sha256'].items():
            assert sha((root/'built-source'/name).read_bytes())==expected
        for name,expected in context['training_source_sha256'].items():
            assert sha((training/name).read_bytes())==expected
        for name,expected in context['training_corpus_sha256'].items():
            assert sha((training/'corpus'/name).read_bytes())==expected
        for name,key in [('unstripped-minivec','unstripped_binary_sha256'),('instrumented-minivec','instrumented_binary_sha256')]:
            assert sha((training/name).read_bytes())==context[key]
        elfs[role]=Elf(training/'unstripped-minivec');instrumented=Elf(training/'instrumented-minivec')
        names=instrumented.gcov_functions();nms[role]=parse_nm(training/'symbols.txt')
        profiles[role]={p.name:gcda(p,names) for p in sorted((training/'profile-data').glob('*.gcda'))}
        for unit,p in profiles[role].items():assert p['sha256']==context['profile_sha256'][unit]
        symbols[role]={name:info for name,info in nms[role].items() if relevant(name)}
        data[role]={'source_commit':context['source_commit'],'binary_sha256':context['binary_sha256'],
                    'input_context_sha256':sha((root.parent/'context.json').read_bytes()),
                    'source_sha256':context['source_sha256'],
                    'training_source_sha256':context['training_source_sha256'],
                    'training_corpus_sha256':context['training_corpus_sha256'],
                    'feature_flags':context['feature_flags'],
                    'instrumented_binary_sha256':context['instrumented_binary_sha256'],
                    'unstripped_binary_sha256':context['unstripped_binary_sha256'],
                    'layout_sha256':context['layout_sha256'],
                    'profile_sha256':context['profile_sha256'],
                    'symbol_listing_sha256':sha((training/'symbols.txt').read_bytes()),
                    'sections':{s.name:{'bytes':s['sh_size'],'address':hex(s['sh_addr'])} for s in elfs[role].elf.iter_sections() if s.name in ('.text','.rodata','.eh_frame','.data','.bss')},
                    'functions':symbols[role], 'gcda_header':{u:v['header'] for u,v in profiles[role].items()}}
        data[role]['projection_predicate_disassembly']={
            name:{'symbol':info,'normalized':disassemble(elfs[role],info)[0],
                  'disassembly':disassemble(elfs[role],info)[1]}
            for name,info in symbols[role].items()
            if '::{lambda(mvdb::execute_impl' in name and '::Item const&)#' in name}
        data[role]['selected_profile_functions']={
            f['name']:{'unit':unit,'cfg_checksum':f['cfg_checksum'],'counters':f['counters'],
                       'arcs_json_sha256':sha(json.dumps(f['counters'].get('arcs',[])).encode())}
            for unit,parsed in profiles[role].items() for f in parsed['functions']
            if ('execute_impl' in f['name'] and 'ENKUljE_clEj' in f['name'])
            or f['name'].startswith(('_ZN4mvdb19QuantizedQueryBound10initialize',
                                     '_ZNK4mvdb20DistanceBoundContext18definitely_greater',
                                     '_ZN4mvdb16query_fanout_run'))}
    comparisons={}
    diffs={}
    for left,right in [('old_B','new_B'),('new_B','new_C'),('old_C','new_C')]:
        key=left+'__'+right;out=[]
        for name in sorted(symbols[left].keys()&symbols[right].keys()):
            a=symbols[left][name];b=symbols[right][name]
            aa,ad,ah=disassemble(elfs[left],a);bb,bd,bh=disassemble(elfs[right],b)
            same=aa==bb
            out.append({'name':name,'before':a,'after':b,'raw_bytes_identical':ah==bh,'normalized_instruction_sequence_identical':same,
                        'instruction_counts':[len(aa),len(bb)],'normalized_matching_ratio':difflib.SequenceMatcher(a=aa,b=bb,autojunk=False).ratio()})
            if not same:
                diffs[key+' / '+name]={'normalized_diff':list(difflib.unified_diff(aa,bb,n=2)),
                                       'before_disassembly':ad,'after_disassembly':bd}
        comparisons[key]={'functions':out,'profile':compare_profiles(profiles[left],profiles[right])}
    report={'status':'offline_inspection_completed','not_runtime_or_causal_proof':True,
            'parser_scope':'GCC13.3 little-endian gcda records, every function matched via retained instrumented ELF gcov_fn_info. Arc arrays cannot be mapped to source CFG edges without .gcno; no dynamic branch-miss/cache measurements.',
            'source_references':['https://raw.githubusercontent.com/gcc-mirror/gcc/releases/gcc-13.3.0/gcc/gcov-io.h',
                                 'https://raw.githubusercontent.com/gcc-mirror/gcc/releases/gcc-13.3.0/gcc/gcov-counter.def',
                                 'https://raw.githubusercontent.com/gcc-mirror/gcc/releases/gcc-13.3.0/libgcc/libgcov.h',
                                 'https://raw.githubusercontent.com/gcc-mirror/gcc/releases/gcc-13.3.0/libgcc/libgcov-driver.c'],
            'normalization_limit':'Direct branch/call and RIP-relative targets are resolved to named symbols or section offsets, not a formal semantic equivalence proof. All decoded function bytes were consumed. Non-normalized data/pointer table contents remain separate inputs.',
            'roles':data,'comparisons':comparisons}
    (HERE/'bulk-pgo-mechanism-inspection.json').write_text(json.dumps(report,indent=2)+'\n')
    (HERE/'bulk-pgo-disassembly-diffs.json').write_text(json.dumps(diffs,indent=2)+'\n')
    print(json.dumps({'status':report['status'],'functions':{k:len(v) for k,v in symbols.items()},'changed_disassemblies':len(diffs)}))

if __name__=='__main__':main()
