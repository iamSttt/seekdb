"""Package only frozen offline evidence. Does not compile or benchmark the DB."""
import hashlib
import json
from pathlib import Path
import zipfile

HERE = Path(__file__).resolve().parent
REPO = HERE / 'seekdb'
OUT = REPO / 'validation/iteration4-bulk-codegen.zip'
assert not OUT.exists(), 'Refuse to overwrite frozen archive'
sha = lambda b: hashlib.sha256(b).hexdigest()
files = {}
def add(path, name):
    assert name not in files
    files[name] = path.read_bytes()

for name in ['inspect_bulk_pgo_mechanism.py', 'bulk-pgo-mechanism-inspection.json',
             'bulk-pgo-disassembly-diffs.json', 'bulk-pgo-mechanism-report.md',
             'condense_bulk_guard_results.py', 'bulk-loop-cpp-static-validation.json',
             'package_bulk_codegen.py']:
    add(HERE / name, 'work/' + name)

report = json.loads(files['work/bulk-pgo-mechanism-inspection.json'])
assert report['status'] == 'offline_inspection_completed'
assert report['roles']['old_B']['binary_sha256'] == report['roles']['new_B']['binary_sha256']
assert report['roles']['old_B']['unstripped_binary_sha256'] == report['roles']['new_B']['unstripped_binary_sha256']
for pair in ['new_B__new_C', 'old_C__new_C']:
    comp = report['comparisons'][pair]
    assert sum(not v['normalized_instruction_sequence_identical'] for v in comp['functions']) == 2
    assert comp['profile']['summary']['minivec-flat_index.gcda']['changed'] == {'time_profiler_functions_changed': 34}
assert all(v['normalized_instruction_sequence_identical'] for v in report['comparisons']['old_B__new_B']['functions'])
assert [len(report['roles'][r]['projection_predicate_disassembly']) for r in ['old_B','old_C','new_B','new_C']] == [0,2,0,2]

roots = {'old_B': 'bulk-typed-c562aa2/baseline-pgo', 'old_C': 'bulk-typed-c562aa2/bulk-pgo',
         'new_B': 'bulk-guard-85cded3/baseline-pgo', 'new_C': 'bulk-guard-85cded3/bulk-pgo'}
for role, relative in roots.items():
    root = HERE / 'performance' / relative
    for name in ['exec.cpp','query_pool.h','flat_index.cpp','distance.h','quantized_bound.h']:
        add(root/'built-source'/name, 'retained/'+role+'/built-source/'+name)
    for name in ['symbols.txt','sections.txt','train.cpp','run-training.sh']:
        add(root/'training'/name, 'retained/'+role+'/training/'+name)
    for file in sorted((root/'training/profile-data').glob('*.gcda')):
        add(file, 'retained/'+role+'/training/profile-data/'+file.name)
for folder in ['bulk-typed-c562aa2','bulk-guard-85cded3']:
    add(HERE/'performance'/folder/'context.json','retained/'+folder+'-context.json')

raw_refs = {}
for name, expected in {
    'iteration4-bulk-raw.zip':'dc8564b66324e27a7285093f184c223148261937bb5473457720b7f152c15930',
    'iteration4-bulk-guard-raw.zip':'44420c714d59c1f98fa32879c917351ca02175aac474eb318217a068b69b31fd'
}.items():
    p=REPO/'validation'/name
    actual=sha(p.read_bytes()); assert actual == expected
    raw_refs[name]={'sha256':actual,'bytes':p.stat().st_size}
files['raw-artifact-references.json']=(json.dumps(raw_refs,indent=2)+'\n').encode()
files['requirements.txt']=b'capstone==5.0.3\npyelftools==0.32\n'

review={
    'status':'readonly_source_peer_ready_not_linux_compiled',
    'source_parent':'85cded31d28192f30b4177ed226384ec8d0ffd95',
    'reviewed_file':'minivec/src/exec.cpp',
    'reviewed_sha256':sha((REPO/'minivec/src/exec.cpp').read_bytes()),
    'findings':[],
    'scope':['Only bulk-on any_of lowering changes to an explicit for loop.',
             'False returns become continue; true returns set the flag and break.',
             'Distance/scalar and dimensions >=128 or <16 precede all bulk metadata checks.',
             'LIMIT then WHERE then live-key count and diagnostic increments retain short-circuit order.',
             'Macro-off any_of and rendering/UTF8/error paths remain unchanged.'],
    'limitations':['No local Linux compilation or new generated-machine-code proof.',
                   'Helper call removal and performance must be verified on the next actual PGO binary.']
}
assert review['reviewed_sha256']=='5df5394117480f8b5ce695141840afea84f237113162ef7d9c18b2224e7d3975'
files['work/bulk-loop-readonly-peer.json']=(json.dumps(review,indent=2)+'\n').encode()
files['README.md']=b'''# Offline bulk PGO/codegen evidence

This auxiliary archive contains an assistant's offline inspection, not new database tests or a performance result. Start with work/bulk-pgo-mechanism-report.md. Full normalized comparisons, changed counters, helper disassembly, and selected unchanged arc arrays are in the JSON files. Source snapshots, symbol/section listings and raw gcda records are retained here; large ELF programs and all original measurements stay in the two immutable raw ZIPs identified by raw-artifact-references.json.

To reproduce: extract this ZIP into an empty directory; extract iteration4-bulk-raw.zip into work/performance/bulk-typed-c562aa2/ and iteration4-bulk-guard-raw.zip into work/performance/bulk-guard-85cded3/. Install requirements.txt (either into work/elf-inspection-deps/ with pip --target or into the active Python environment), then run python work/inspect_bulk_pgo_mechanism.py. Its dependencies are capstone 5.0.3 and pyelftools 0.32, not repository runtime dependencies. The tool validates context hashes for its inputs; full artifact manifest verification belongs to the separately archived performance readers. No DB execution is performed by this tool.

GCC13.3 gcda is a version-specific private format. Functions are matched to instrumented ELF gcov_fn_info records. No .gcno source-edge map or hardware counters were available. time_profiler means first-invocation order, not elapsed time. Normalized disassembly equality is not formal semantic equivalence. The concrete finding is two outlined predicate calls along the two-item id+distance SELECT path; both old and new bulk candidates outline helpers. This does not explain the regression magnitude or prove a speedup from the next loop candidate.

work/condense_bulk_guard_results.py is root's pure summary reproduction script, distinct from summarize_bulk_guard.py in the separate analysis archive. Run it with --analysis <frozen bulk-guard-analysis.json> --output <new file>. The output path must not already exist. This auxiliary archive does not change the frozen analysis ZIP. The quantization adoption assessment in that analysis archive was manually assembled from evaluation fields and analysis; no separate generation script was supplied for that assessment. This statement is provenance, not an independent recomputation of it.

work/bulk-loop-readonly-peer.json records the later source-only explicit-loop review. It is not a new binary test or a claim that the compiler removed the calls. Production defaults remain unchanged. The archive does not include or endorse an enabled bulk default.

MANIFEST.json hashes every member except itself. Validate names, sizes and SHA-256 before reuse. package_bulk_codegen.py records the packaging recipe, but deliberately refuses overwriting this frozen archive.
'''
manifest={name:{'bytes':len(data),'sha256':sha(data)} for name,data in sorted(files.items())}
files['MANIFEST.json']=(json.dumps(manifest,indent=2)+'\n').encode()
with zipfile.ZipFile(OUT,'w',zipfile.ZIP_DEFLATED,compresslevel=9) as z:
    for name,data in sorted(files.items()):
        info=zipfile.ZipInfo(name,(2026,11,13,0,0,0)); info.compress_type=zipfile.ZIP_DEFLATED
        z.writestr(info,data)
with zipfile.ZipFile(OUT) as z:
    assert len(z.namelist())==len(set(z.namelist()))==len(files)
    assert z.testzip() is None
    assert set(z.namelist())==set(manifest)|{'MANIFEST.json'}
    for name,expected in manifest.items():
        data=z.read(name)
        assert len(data)==expected['bytes'] and sha(data)==expected['sha256']
proof={'status':'frozen_offline_archive_verified','archive':str(OUT.relative_to(HERE)),
       'bytes':OUT.stat().st_size,'sha256':sha(OUT.read_bytes()),'members':len(files),
       'manifest_members':len(manifest),'zip_crc_and_all_member_sha_verified':True,
       'runtime_executions':0,'raw_artifact_references':raw_refs}
(HERE/'bulk-codegen-archive-validation.json').write_text(json.dumps(proof,indent=2)+'\n')
print(json.dumps(proof))
