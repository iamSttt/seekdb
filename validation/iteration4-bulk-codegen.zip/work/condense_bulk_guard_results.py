"""Read-only condensation; no execution, adoption, or sample removal."""
import argparse
import hashlib
import json
from pathlib import Path

p = argparse.ArgumentParser()
p.add_argument('--analysis', type=Path, required=True)
p.add_argument('--output', type=Path, required=True)
a = p.parse_args()
assert not a.output.exists(), 'Refuse overwrite'
raw = a.analysis.read_bytes()
d = json.loads(raw)
assert d['status'] == 'verified' and d['verified_pairs'] == 192
assert d['candidate_commit'] == '85cded31d28192f30b4177ed226384ec8d0ffd95'
groups = {}
for name, g in d['groups'].items():
    metrics = {}
    for phase, m in g['timings'].items():
        metrics[phase] = {
            'pairs': m['pairs'],
            'baseline_seconds': m['baseline'],
            'candidate_seconds': m['candidate'],
            'paired_baseline_over_candidate': m['baseline_over_candidate'],
            'slower_candidate_pairs': m['candidate_value_larger_pairs'],
            'seed_ratios': {k: v['baseline_over_candidate'] for k,v in m['by_seed'].items()},
            'order_ratios': {k: v['baseline_over_candidate'] for k,v in m['by_order'].items()},
            'negative_pairs': m['negative_pairs'],
        }
    groups[name] = {'pairs': g['pairs'], 'all_phases_including_negative': metrics}
out = {
    'status': 'measured_not_adopted_pending_refinement',
    'executed_by': 'assistant',
    'source_commit': d['candidate_commit'],
    'baseline_commit': d['baseline_commit'],
    'run_id': 43368305222, 'job_id': 131697858385,
    'pairs': 192, 'candidate_pairs': 150, 'same_binary_control_pairs': 42,
    'binary_gates_passed': 8, 'utf8_cases_passed': 108,
    'source_unit_sanitizer_gates_passed': 3,
    'baseline_binary_sha256': 'acddca115ab183bfc6419e27c9e3383cfd1a9046e3897e5ea516cd7bc0f29f54',
    'candidate_binary_sha256': '2d50c45c9aebee86e9224118aeb294dc574c7c6edea1fdde2dc596aeb751bda3',
    'baseline_matches_prior311_binary_bytes': True,
    'default_enabled': False, 'official_score': None,
    'automatic_submission': False,
    'raw_artifact': {
        'path': 'validation/iteration4-bulk-guard-raw.zip',
        'github_artifact_id': 14012111965,
        'bytes': 49699707,
        'sha256': '44420c714d59c1f98fa32879c917351ca02175aac474eb318217a068b69b31fd',
        'entries': 188, 'uncompressed_bytes': 241011500,
    },
    'analysis_file_sha256': hashlib.sha256(raw).hexdigest(),
    'decision': [
        'Keep the bulk-vector direction as a candidate, not a new default. Preserve the existing four default features and original PGO.',
        '16/64/127-dimensional large-output query phases improve, but filter60k and other protection cases have negative observations. Positive cases do not cancel these negatives.',
        'The short-circuit did not remove protection regressions. Code-generation review identifies an outlined predicate called twice for the two30k projections. Its contribution to the full slowdown is not established.',
        'Test an explicit admission loop with equivalent conditions using the same192-pair protocol. Keep the default off. Do not modify or remove this run samples.',
    ],
    'groups': groups,
    'limitations': d['limitations'] + [
        'The independent analysis includes projection proc CPU, RSS/HWM and I/O snapshots. These are coarse process proxies, not cgroup scores, independent per-phase memory peaks or physical-device I/O.',
        'Projection repeats within one pair are not independent experiments. All query first requests, later requests, startup/ingestion pauses and negative pairs remain in the complete raw archive.',
        '30k does not project a vector. Its slowdown remains negative across all seeds and both orders. Source/layout and host effects are not fully causally separated.',
        'The default root-image correctness proof is separate. Performance evidence applies only to the exact program hashes listed here.',
    ],
}
a.output.write_text(json.dumps(out, ensure_ascii=False, indent=2)+'\n', encoding='utf8', newline='\n')
print(json.dumps({'output': str(a.output), 'bytes': a.output.stat().st_size,
                  'sha256': hashlib.sha256(a.output.read_bytes()).hexdigest()}))
