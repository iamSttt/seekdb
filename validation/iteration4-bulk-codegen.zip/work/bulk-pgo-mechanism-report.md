# Bulk guard: retained PGO and machine-code inspection

This is an assistant's offline inspection of the retained Linux artifacts, not a new benchmark, hardware-counter experiment, or causal attribution. It supports a small explicit-loop experiment, not default adoption of the bulk feature. Source changes and performance outcomes remain separate evidence.

## Scope and provenance

The inspection compares four programs from the complete artifacts already validated by the performance readers:

| Role | Source | Runtime binary SHA-256 |
|---|---|---|
| old_B / new_B | e020fdeb67dd8b64b77f0f8c2905f137f0112bba | acddca115ab183bfc6419e27c9e3383cfd1a9046e3897e5ea516cd7bc0f29f54 |
| old_C, original 84-pair experiment | c562aa21b479c090c6080064a40414959e417fbc | d1f1e389cfd5b182d5cdefdf33d6b06d1faadb0bdd536a702e15349aa5e4f7b7 |
| new_C, guarded 192-pair experiment | 85cded31d28192f30b4177ed226384ec8d0ffd95 | 2d50c45c9aebee86e9224118aeb294dc574c7c6edea1fdde2dc596aeb751bda3 |

The two independently rebuilt baseline programs are byte-identical, including their unstripped ELF (8813344f5d613d6c02969a73eb7374164be9f5d0135c38d149a54c80c7b92c5c). This does not mean their Docker images were reused. Each candidate has the same four retained features plus MVDB_TYPED_BULK_VECTOR_ONLY. The timing programs do not enable JSON diagnostics. The original PGO training source and corpus are unchanged; each role was trained independently.

`inspect_bulk_pgo_mechanism.py` checks the runtime binary, instrumented ELF, unstripped ELF, symbols and sections listings, every source file, training sources, corpus files, and every gcda file against the retained context hashes. It consumes all selected function bytes when disassembling. The report includes those identities. It does not independently repeat the full artifact-manifest verification already performed by the performance reader.

The inputs remain under `performance/bulk-typed-c562aa2/{baseline,bulk}-pgo` and `performance/bulk-guard-85cded3/{baseline,bulk}-pgo`. The script requires capstone 5.0.3 and pyelftools 0.32 in `elf-inspection-deps/` beside it (or installed in the active Python environment). The small analysis archive does not duplicate those large raw artifacts or binary dependencies.

## What executes in the 30k case

The scenario uses 30,000 rows, 128 vector dimensions, two query threads, and projections `id, L2_DISTANCE(...) AS d`; it does not project a VECTOR column. The resident unfiltered path runs execute_impl's scan_half lambda, not Database::scan_vectors. The new bulk source reaches neither LIMIT, WHERE, nor live-key metadata for these two projected items.

Nevertheless, new_C has an outlined projection predicate: an 88-byte hot function plus a 25-byte cold fragment. Following the emitted any_of remainder path for the two-item list gives two calls to that predicate per SELECT. Scalar id returns false after the schema type check; distance returns false before that check. Closure preparation and these call/return boundaries are real instructions even though the source diagnostic metadata counters are zero. The baseline wide-only predicate is inlined at this point.

The older old_C also outlines a predicate through an `_Iter_pred` helper (62 hot bytes plus 7 cold bytes). Therefore the mere presence of helper calls cannot explain why the two separate experiments have different performance signs. The newer source avoids the older unconditional bulk metadata calculation but does not remove outlining. Source changes also alter register allocation and stack-slot usage in execute_impl. The detailed JSON preserves both candidate predicate disassemblies and all differences in the common execute_impl functions.

The narrow next experiment replaces the bulk any_of predicate with an explicit loop while retaining its exact eligibility and diagnostic short-circuit order. Compilation is still free to outline code. The next retained binary must be inspected to establish whether the calls actually disappear, followed by the unchanged paired performance protocol. No fixed cycle cost or promised speedup is inferred here.

## Actual scan kernel and layout

After resolving direct branch/call and RIP-relative targets to symbol/offset references, all common selected functions except execute_impl's main and cold functions have identical instruction sequences between new_B/new_C and between old_C/new_C. The two baselines match for all 95 selected common functions. This normalization is an inspection aid, not a formal semantic-equivalence proof; data/pointer tables and hardware behavior are not proved by it.

In particular, scan_half's 6,503-byte hot body (1,305 decoded instructions), 2,007-byte cold body (444 instructions), std::function invocation trampoline, and manager functions are unchanged under this comparison. The complete lambda body covers the inlined quantized/distance checks. The separately emitted QuantizedQueryBound initialization/update-cap, DistanceBoundContext, exact and bounded distance functions also match. Thus this inspection does not support a claim that a new arithmetic operation or changed distance branch was introduced inside the measured scan loop.

| Function | B address / bytes | old_C address / bytes | new_C address / bytes |
|---|---:|---:|---:|
| execute_impl main | 0x433270 / 10375 | 0x4331b0 / 10450 | 0x433200 / 10338 |
| execute_impl cold | 0x40c6b3 / 11323 | 0x40c6b3 / 11229 | 0x40c6b3 / 11417 |
| scan_half hot | 0x438fa0 / 6503 | 0x438f30 / 6503 | 0x438f10 / 6503 |
| scan_half cold | 0x4102d6 / 2007 | 0x410280 / 2007 | 0x41034e / 2007 |
| query_fanout_run | 0x435b00 / 1008 | 0x435a90 / 1008 | 0x435a70 / 1008 |
| worker_main | 0x446100 / 266 | 0x446090 / 266 | 0x446070 / 266 |
| Database::scan_vectors | 0x42e7e0 / 3842 | 0x42e720 / 3842 | 0x42e770 / 3842 |
| FlatIndex::integer_posting | 0x43ca70 / 1939 | 0x43ca00 / 1939 | 0x43c9e0 / 1939 |
| FlatIndex::posting_span | 0x448370 / 214 | 0x448340 / 214 | 0x448340 / 214 |

All four programs have a 1,015,105-byte .text section and a 301,060-byte .rodata section. Function addresses and alignments differ, including scan_half mod64 offsets 32, 48, and 16. No instruction-cache, branch-miss, or cycle measurements were collected. These address changes are correlations and may motivate investigation; they are not established causes of regression.

The query_pool source and normalized emitted worker/fanout functions are unchanged. Observed runtime diagnostics retain two threads, idle_spin_us=0 and join_spin_us=200. Identical thread count does not alone prove identical runtime scheduling/wake behavior, but neither source nor this disassembly demonstrates a new scheduling strategy.

## PGO counters: changes and non-changes

The private GCC 13.3 gcda format was decoded only after matching its version, record sizes and bounds. Each function is identified through the retained instrumented ELF's gcov_fn_info identifier, line checksum, CFG checksum and unit filename. All functions matched. CFG changes are reported without comparing arc positions. The parser handles negative-length all-zero counter records and requires the terminal record at exact EOF. This interpretation follows the fixed [GCC 13.3 format](https://raw.githubusercontent.com/gcc-mirror/gcc/releases/gcc-13.3.0/gcc/gcov-io.h), [writer](https://raw.githubusercontent.com/gcc-mirror/gcc/releases/gcc-13.3.0/libgcc/libgcov-driver.c), and [runtime structures](https://raw.githubusercontent.com/gcc-mirror/gcc/releases/gcc-13.3.0/libgcc/libgcov.h).

For minivec-flat_index.gcda, all 149 function records match across the compared roles. B versus new_C differs in only 34 functions' time_profiler values, each by +2. Arc and other counter arrays are unchanged. Old_C versus new_C also changes 34 time_profiler functions and no arc arrays. GCC defines time_profiler as first-invocation order; it is not elapsed time or invocation frequency. Therefore differing gcda file hashes do not establish changed flat-index branch frequencies. See [GCC counter definitions](https://raw.githubusercontent.com/gcc-mirror/gcc/releases/gcc-13.3.0/gcc/gcov-counter.def).

Three functions relevant to the actual resident scan have identical CFG checksums and complete arc arrays in B, old_C and new_C:

| Function | Arc array length | CFG checksum | SHA-256 of Python json.dumps(arcs) |
|---|---:|---:|---|
| scan_half | 26 | 987641669 | e03526dcef14337e59c071b579359bd633641382a1b2a84e43048933e67b1ed1 |
| QuantizedQueryBound::initialize | 32 | 775214720 | 946462c6604012f09cd4a7f17bbf01d2f91689b1166f0a5781718c61d0b97cd5 |
| DistanceBoundContext::definitely_greater | 13 | 618903124 | 0923f71aeb4a20309fd7beb7359c965cb0e79161222d2522491a95c74f762dad |

The corresponding first-invocation values increase by one per candidate generation (scan_half 497/498/499, initialization 484/485/486, bound check 506/507/508). Those ordinal changes are consistent with added earlier functions but are not a measured runtime cost.

Some training arc counts do change: new_B/new_C query_fanout_run entries 27 and 31/32 are 38212→45632 and 795→832; measure_wake_us entries 10/11 are 29114→30498 and 589→583. These counters come from six PGO training runs, not the timed 30k experiment. The artifacts have no .gcno source-edge map; the report intentionally does not label those indices as a particular futex or spin branch. The two byte-identical baselines also have differing query-pool and parse-pool training arcs. A changed training count alone therefore does not prove changed final code or explain runtime performance.

## Limits and retained conclusion

The verified 192-pair analysis remains authoritative for performance. Its approximately 0.96793 30k first-phase and 0.96066 post-first64 B/C ratios motivated this inspection; they were not recomputed by the codegen tool. The 30k regression remains unexplained in magnitude. No new performance result, score gain, default activation, or recovery of earlier .919/.979 observations is claimed.

The strongest localized mechanism is the outlined eligibility predicate executed on a projection that can never use bulk output. The strongest exclusions are unchanged emitted scan_half/bound arithmetic and unchanged flat-index arc arrays. Explicit-loop lowering is a falsifiable next candidate: check its actual calls and common scan kernel again, retain all paired negatives, and reject it if the protected workloads still regress.
