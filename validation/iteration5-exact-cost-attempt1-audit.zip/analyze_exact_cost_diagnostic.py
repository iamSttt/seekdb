"""Independent read-only exact-cost evidence reader; no DB or native code execution."""
import argparse
import ast
import hashlib
import io
import json
from pathlib import Path, PurePosixPath
import re
import shlex
import subprocess
import zipfile

FIRST_COMMIT='89fbe16b9bfb841d91ba37fefe13b87ac7044466'
FIRST_RUN=43498082455
PREREG='validation/iteration5-exact-cost-preregistration.json'
PREREG_SHA='f79a3180a8829a7137c140f42ed5847c980fad06b09517c8c13d6ec0cfbbe24b'
R_SHA='acddca115ab183bfc6419e27c9e3383cfd1a9046e3897e5ea516cd7bc0f29f54'
R_ARCHIVE='validation/iteration4-bulk-loop-raw.zip'
R_ARCHIVE_SHA='88e4a73af9d333b08a6db817a78c7cb06357fcfddc05eee1b31c2a065aebfef2'
COMPILER='gcc:13.3.0-bookworm@sha256:1d71f0f3450214bef38fe09e6f610fb6cca90cf97b43f4ce845bfc32a4168818'

def need(ok,message):
    if not ok:raise ValueError(message)
def digest(data):return hashlib.sha256(data).hexdigest()
def readjson(data):return json.loads(data.decode('utf8'),parse_constant=lambda _:(_ for _ in ()).throw(ValueError('nonfinite JSON')))
def blob(repo,commit,name):
    data=subprocess.check_output(['git','-c','safe.directory='+repo.as_posix(),'-C',str(repo),'show',commit+':'+name])
    oid=subprocess.check_output(['git','-c','safe.directory='+repo.as_posix(),'-C',str(repo),'rev-parse',commit+':'+name],text=True).strip()
    need(hashlib.sha1(b'blob '+str(len(data)).encode()+b'\0'+data).hexdigest()==oid,'Git blob mismatch '+name)
    return data
def counters(text):return {row.split()[0]:int(row.split()[1]) for row in text.splitlines() if len(row.split())==2}
def elf(data):need(data[:6]==b'\x7fELF\x02\x01' and int.from_bytes(data[18:20],'little')==62,'not x86-64 ELF')

class Archive:
    def __init__(self,data):
        self.z=zipfile.ZipFile(io.BytesIO(data));names=self.z.namelist()
        need(len(names)==len(set(names)) and len(names)<1000,'duplicate/excess artifact names')
        self.inventory={}
        for name in names:
            p=PurePosixPath(name);need(not p.is_absolute() and '..' not in p.parts and '\\' not in name,'unsafe ZIP path')
            if name.endswith('/'):continue
            info=self.z.getinfo(name);need(info.file_size<250_000_000,'excess member')
            b=self.z.read(name);self.inventory[name]={'bytes':len(b),'sha256':digest(b)}
    def data(self,name):return self.z.read(name)
    def json(self,name):return readjson(self.data(name))

def api_binding(receipt,raw):
    commit=receipt['head_sha'];run=receipt['run_id'];items=receipt['artifacts_api_response']['artifacts']
    found=[x for x in items if x['id']==receipt['artifact_id']];need(len(found)==1,'artifact API identity')
    artifact=found[0]
    need(artifact['name']=='exact-cost-diagnostic' and artifact['expired'] is False,'wrong/expired artifact')
    need(artifact['workflow_run']['id']==run and artifact['workflow_run']['head_sha']==commit,'API run/source mismatch')
    need(artifact['digest']=='sha256:'+digest(raw) and artifact['size_in_bytes']==len(raw),'API digest/size mismatch')
    need(receipt['expected_sha256']==digest(raw) and receipt['expected_bytes']==len(raw),'download receipt mismatch')
    jobs=receipt['jobs_api_response']['jobs'];selected=[j for j in jobs if j['conclusion']!='skipped']
    need(0<len(jobs)<=35 and len(selected)==1 and selected[0]['name']=='exact-cost-diagnostic','provided job-page selection differs')
    need(all(j['run_id']==run and j['status']=='completed' for j in jobs),'unfinished/mismatched job')
    return {'commit':commit,'run_id':run,'artifact_id':artifact['id'],'artifact_sha256':digest(raw),'artifact_bytes':len(raw),
      'conclusion':selected[0]['conclusion'],'job_id':selected[0]['id'],'provided_jobs':len(jobs),'provided_selected_jobs':1,
      'provided_skipped_jobs':len(jobs)-1,'API_all_jobs_enumerated':len(jobs)==35,
      'API_scope':'Provided jobs page only; absence from a partial page does not prove other jobs were skipped.' if len(jobs)<35 else 'All35 workflow jobs provided.'}

def source_binding(repo,commit,a):
    prereg_raw=blob(repo,FIRST_COMMIT,PREREG);need(digest(prereg_raw)==PREREG_SHA,'original prereg differs')
    plan=readjson(prereg_raw);proof=a.json('programs/source-proof.json')
    need(proof['pgo'] is False and proof['archive_sha256']==R_ARCHIVE_SHA and proof['archive_bytes']==49685962,'source scope differs')
    need(proof['runtime_source_commit']=='e020fdeb67dd8b64b77f0f8c2905f137f0112bba' and proof['retained_binary_sha256']==R_SHA,'R identity')
    source_tools={name:blob(repo,commit,'minivec/tools/exact_cost/'+name) for name in plan['source_tool_snapshot']}
    if commit==FIRST_COMMIT:
        for name,data in source_tools.items():need(digest(data)==plan['source_tool_snapshot'][name]['sha256'],'tool differs from first prereg '+name)
    shared={name:blob(repo,commit,name) for name in plan['shared_tool_snapshot']}
    for name,data in shared.items():need(digest(data)==plan['shared_tool_snapshot'][name]['sha256'],'shared input drift '+name)
    runtime_tools={name:digest(data) for name,data in source_tools.items() if name.endswith(('.py','.sh','.h','.cpp'))}
    need(proof['tools']==runtime_tools,'source proof tool hashes differ')
    historical_raw=blob(repo,commit,R_ARCHIVE)
    need(len(historical_raw)==49685962 and digest(historical_raw)==R_ARCHIVE_SHA,'fixed R raw differs')
    with zipfile.ZipFile(io.BytesIO(historical_raw)) as z:
        members={x['path']:x for x in readjson(z.read('hashes.json'))['artifacts']}
        def prior(name):
            data=z.read(name);p=members[name];need(len(data)==p['bytes'] and digest(data)==p['sha256'],'R manifest member '+name);return data
        context=readjson(prior('context.json'))['profile_source_proof']['baseline']
        need(context['source_sha256']==proof['original_source_sha256'] and len(context['source_sha256'])==20,'original20 inventory')
        tree=ast.parse(source_tools['prepare.py'].decode());defs=[x for x in tree.body if isinstance(x,ast.FunctionDef) and x.name in ('need','replace','patch')]
        ns={};exec(compile(ast.Module(body=defs,type_ignores=[]),'<Git-bound pure source patch>','exec'),ns)
        for name,h in context['source_sha256'].items():
            original=prior('baseline-pgo/built-source/'+name);need(digest(original)==h,'original source hash '+name)
            expected=ns['patch'](name,original.decode()).encode() if name in ('main.cpp','distance.h','quantized_bound.h','sql.cpp','db.cpp') else original
            actual=a.data('programs/src/'+name)
            need(actual==expected and digest(actual)==proof['instrumented_source_sha256'][name],'shadow replay differs '+name)
        need(a.data('programs/retained-minivec')==prior('baseline-pgo/minivec'),'retained program bytes differ')
        need(a.data('programs/third_party/json.hpp')==prior('baseline-pgo/built-third-party/json.hpp'),'third-party source differs')
    need(a.data('programs/src/cost_diagnostic.h')==source_tools['cost_diagnostic.h'],'diagnostic header differs')
    need(a.data('programs/timer_overhead.cpp')==source_tools['timer_overhead.cpp'],'timer source differs')
    binaries={}
    log=a.data('compile.log').decode();need('g++ (GCC) 13.3.0' in log,'compiler version')
    flags=re.findall(r'^compiler_flags=(.*)$',log,re.M);need(len(flags)==1,'flags log')
    flags=shlex.split(flags[0]);need(flags==proof['compiler_flags'] and not any('profile' in f or 'fast-math' in f for f in flags),'non-PGO flags differ')
    need(a.data('compiler-image.txt').decode().strip()==COMPILER,'compiler image ref')
    inspection=a.json('compiler-inspect.json');need(len(inspection)==1 and any(COMPILER.split('@')[1] in d for d in inspection[0]['RepoDigests']),'compiler image digest')
    for name in ('retained-minivec','diagnostic-minivec','timer-overhead'):
        b=a.data('programs/'+name);elf(b);h=digest(b);need(re.search(r'^'+h+r'\s+'+re.escape(name)+r'$',log,re.M),'compile ELF hash '+name);binaries[name]=h
    need(binaries['retained-minivec']==R_SHA,'retained SHA')
    launcher=a.data('cgroup_exec');elf(launcher)
    launcher_log=a.data('launcher-sha256.txt').decode()
    need(digest(shared['minivec/tools/cgroup_exec.c']) in launcher_log and digest(launcher) in launcher_log,'launcher build hash')
    return plan,proof,source_tools,shared,{'binary_sha256':binaries,'instrumented_source_files':5,'source_files_verified':20,
      'shared_tool_files_verified':len(shared),'tool_files_verified':len(source_tools),'new_non_PGO_database_builds':1,'new_PGO_builds':0,
      'original_prereg_sha256':PREREG_SHA,'source_proof_sha256':digest(a.data('programs/source-proof.json'))}

def audit_failure(a,report,source_tools,shared):
    need(report['status']=='failed' and report['error']=='ProtocolError: database exited before response','unexpected failure')
    need(len(report['runs'])==1 and report['runs'][0]['role']=='retained','failure run count/role')
    run=report['runs'][0];need(run['binary_sha256']==R_SHA and run['requests']==[] and 'ready' not in run,'nonzero observed request/ready')
    need(a.data('retained-stderr.log')==b'' and run['stderr_bytes']==0 and run['stderr_sha256']==digest(b''),'stderr differs')
    need('diagnostic-stderr.log' not in a.inventory and 'diagnostic-records.json' not in a.inventory,'unexpected diagnostic execution')
    group=run['cgroup'];need('/minivec-exact-cost-' in group['path'],'failure cgroup naming differs')
    launcher=shared['minivec/tools/cgroup_exec.c'].decode();runner=source_tools['run.py'].decode()
    need('const char prefix[]="/sys/fs/cgroup/minivec-report-";' in launcher and 'return 64;' in launcher,'launcher restriction differs')
    need("parent=small.CGROOT/('minivec-exact-cost-'" in runner,'failed runner prefix differs')
    for label in ('before','immediately_after','after'):
        caps=group[label]
        need(caps['cpu.max']=='100000 100000' and caps['memory.max']=='2147483648' and caps['memory.swap.max']=='0','empty cgroup cap')
        need(counters(caps['cpu.stat'])['usage_usec']==0 and caps['memory.peak']=='0' and not caps['cgroup.procs'],'DB entered cgroup or consumed resources')
    need(group['resource_delta']['cpu_stat_delta']['usage_usec']==0 and not any(group['oom_events_delta'].values()),'failure resource delta')
    need(group['timeout'] is False and group['request_timeout_observed'] is False,'timeout differs')
    need('session.start()' in a.data('measurements.log').decode(),'failure stage log')
    return {'status':'verified_failed_before_ready','ready_programs':0,'first_lifecycles_completed':0,'requests_completed':0,'queries_completed':0,
      'diagnostic_records':0,'causal_source_finding':'Runner parent is outside the launchers fixed allowed prefix; this path deterministically returns64 before open/exec. Transport did not persist child exit status, so64 is source-derived, not a measured exit code.',
      'resource_scope':'Empty intended cgroup limits were written/read back; no actual database placement, affinity or resource-run claim is available.',
      'cost_measurements_available':False,'response_oracle_comparisons_completed':0}

def audit(args):
    repo=args.repo.resolve();raw=args.archive.read_bytes();receipt=readjson(args.receipt.read_bytes());api=api_binding(receipt,raw)
    need(api['commit']==FIRST_COMMIT and api['run_id']==FIRST_RUN,'first-attempt reader currently requires fixed run/source')
    a=Archive(raw);plan,proof,tools,shared,binding=source_binding(repo,api['commit'],a)
    report=a.json('measurements.json');need(report['source_proof_sha256']==binding['source_proof_sha256'],'measurement source identity')
    need(report['runtime_source_commit']==proof['runtime_source_commit'],'measurement source commit')
    tools_map=report['tool_sha256']
    for name,h in {**{k:digest(v) for k,v in shared.items() if k in ('minivec/tools/benchmark_iteration.py','minivec/tools/small_compute.py','protocol_check/_transport.py','protocol_check/config.json')},
                  **{'minivec/tools/exact_cost/'+k:digest(v) for k,v in tools.items() if k.endswith(('.py','.h','.cpp'))}}.items():
        found=[v for p,v in tools_map.items() if p.endswith('/'+name)];need(found==[h],'runtime tool identity '+name)
    need(any(p.endswith('/cgroup_exec') and h==digest(a.data('cgroup_exec')) for p,h in tools_map.items()),'runtime launcher identity')
    need(api['conclusion']=='failure','first attempt API conclusion changed')
    failure=audit_failure(a,report,tools,shared)
    overhead=a.json('timer-overhead.json');need(overhead['count']==20000 and overhead['clock']=='CLOCK_THREAD_CPUTIME_ID' and overhead['subtracted'] is False,'timer scope')
    return {'status':'verified_failure_evidence','api':api,'binding':binding,'failure':failure,'empty_timer_probe_only':overhead,
      'artifact_manifest':a.inventory,'original_runner_error':report['error'],'new_DB_runs_by_reader':0,'new_compilations_by_reader':0,
      'performance_candidate_passed':False,'production_CPU_percentages':None,'selected_runtime_changed':False,'formal_submission':False,
      'reader_sha256':digest(Path(__file__).read_bytes()),'api_receipt_sha256':digest(args.receipt.read_bytes()),
      'next_success_reader_scope':'Success branch will verify1303 sequenced responses/1000queries per program, all resource stages and counter conservation. This failure contains none of those completed measurements.'}

def main():
    p=argparse.ArgumentParser();p.add_argument('--repo',type=Path,default=Path(__file__).resolve().parent/'seekdb');p.add_argument('--archive',type=Path,required=True)
    p.add_argument('--receipt',type=Path,required=True);p.add_argument('--output',type=Path,required=True);args=p.parse_args()
    try:result=audit(args)
    except BaseException as exc:
        args.output.write_text(json.dumps({'status':'reader_failed_evidence_not_verified','error':str(exc),'new_DB_runs_by_reader':0},indent=2)+'\n',encoding='utf8');raise
    args.output.write_text(json.dumps(result,indent=2,allow_nan=False)+'\n',encoding='utf8')
    print(json.dumps({'status':result['status'],'artifact_sha256':result['api']['artifact_sha256'],'failure':result['failure']},indent=2))

if __name__=='__main__':main()
