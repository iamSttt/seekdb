"""Archive first diagnostic failure and freeze a tool-only retry; no Git operations."""
import copy
import hashlib
import importlib.util
import io
import json
from pathlib import Path
import subprocess
import zipfile

BASE='cc39f8f0305f0c96980087bf03566bc3be107ef5cce3a29d7498dd2c0df212f5'
OLD='89fbe16b9bfb841d91ba37fefe13b87ac7044466'
RAW='validation/iteration5-exact-cost-attempt1-raw.zip'
AUDIT='validation/iteration5-exact-cost-attempt1-audit.zip'
ERRATUM='validation/iteration5-exact-cost-launcher-erratum.json'
PREREG='validation/iteration5-exact-cost-preregistration.json'
PSHA='f79a3180a8829a7137c140f42ed5847c980fad06b09517c8c13d6ec0cfbbe24b'
CHANGED=['run.py','preflight.py','preflight.json','handoff-manifest.json']
def sha(b):return hashlib.sha256(b).hexdigest()
def enc(x):return (json.dumps(x,ensure_ascii=False,separators=(',',':'),allow_nan=False)+'\n').encode('utf8')
def need(ok,m):
    if not ok:raise ValueError(m)

def main():
    work=Path(__file__).resolve().parent;repo=work/'seekdb';prior=(repo/'conversation.json').read_bytes()
    need(sha(prior)==BASE and prior==(repo/'agent/conversation.json').read_bytes(),'material drift')
    old=json.loads(prior);need(len(old['messages'])==143 and len(old['experiments'])==57,'inventory')
    original_plan=(repo/PREREG).read_bytes();need(sha(original_plan)==PSHA,'original prereg changed');plan=json.loads(original_plan)
    raw=(repo/RAW).read_bytes();need(len(raw)==2733203 and sha(raw)=='15bfe95d4e7f0a93cca454231a841bf0c1c864fd8998a7ab9d034575cac15ec2','raw mismatch')
    analysis_path=work/'exact-cost-attempt1-independent-analysis.json';analysis=json.loads(analysis_path.read_bytes())
    need(analysis['status']=='verified_failure_evidence' and analysis['failure']['first_lifecycles_completed']==0 and analysis['failure']['requests_completed']==0,'failure audit differs')
    files={}
    for name in ['exact-cost-attempt1-api-receipt.json','exact-cost-attempt1-independent-analysis.json','analyze_exact_cost_diagnostic.py',
      'exact-cost-reader-initial-failure.json','exact-cost-retry-preflight-notes.json','exact-cost-attempt1-job.log',Path(__file__).name]:
        files[name]=(work/name).read_bytes()
    files['reader-development-note.json']=enc({'scope':'offline reader implementation only; zero DB execution',
      'first_check':'Rejected an assumed35-job API inventory; provided API page has30. Original rejected output retained.',
      'resolution':'Report provided-page completeness explicitly instead of claiming full API enumeration; raw/source/failure strict checks subsequently passed.'})
    tools=repo/'minivec/tools/exact_cost';changes={}
    for name,p in plan['source_tool_snapshot'].items():
        original=subprocess.check_output(['git','-c','safe.directory='+repo.as_posix(),'-C',str(repo),'show',OLD+':minivec/tools/exact_cost/'+name])
        need(sha(original)==p['sha256'],'old tool prereg differs')
        current=(tools/name).read_bytes();files['failed-source/'+name]=original
        if name in CHANGED:
            need(current!=original,'expected correction missing '+name);files['retry-source/'+name]=current
            changes[name]={'old_bytes':len(original),'old_sha256':sha(original),'new_bytes':len(current),'new_sha256':sha(current)}
        else:need(current==original,'unexpected diagnostic tool change '+name)
    files['original-preregistration.json']=original_plan
    for name,p in plan['shared_tool_snapshot'].items():
        current=(repo/name).read_bytes();need(sha(current)==p['sha256'],'shared dependency changed '+name)
        if name in ('minivec/tools/cgroup_exec.c','.github/workflows/minivec-score.yml'):files['unchanged-shared/'+name]=current
    check=json.loads((tools/'preflight.json').read_bytes());need(check['status']=='passed' and check['count']==23,'retry preflight differs')
    need('launcher_parent_prefix_contract' in check['checks'] and 'rejected_previous_parent_prefix' in check['checks'],'cross-tool checks missing')
    revised=(tools/'run.py').read_text('utf8')
    need("def parent_group_name():return 'minivec-report-exact-cost-'+uuid.uuid4().hex" in revised and 'protocol_process_returncode' in revised,'tool fix/exit evidence missing')
    erratum={'experiment_id':'exact-distance-cost-diagnostic','kind':'post_failed_attempt_tool_correction_before_retry',
      'original_preregistration':{'path':PREREG,'sha256':PSHA,'unchanged':True},
      'failed_attempt':{'source_commit':OLD,'run_id':43498082455,'artifact_id':14073575394,'raw_path':RAW,'raw_bytes':len(raw),'raw_sha256':sha(raw),
        'new_non_PGO_database_builds_completed':1,'timer_probe_builds_completed':1,'new_PGO_builds':0,'ready_programs':0,'SQL_requests_completed':0,
        'first_lifecycles_completed':0,'diagnostic_records':0,'oracle_checks_completed':0,'observed_error':'ProtocolError: database exited before response',
        'causal_evidence':'Actual intended cgroup path uses minivec-exact-cost-, outside unchanged launcher minivec-report- allowlist. Source deterministically rejects before exec; original transport did not persist child exit status, so64 is source-derived.'},
      'changes':changes,'scope':['Use minivec-report-exact-cost-UUID parent accepted by the existing launcher. Do not relax launcher validation.',
        'Record protocol process returncode before closing; add two cross-tool prefix preflight checks; refresh preflight report and handoff hashes.'],
      'unchanged':['archived R algorithm/source and five instrumentation patches','actual retained acdd program','compiler digest/non-PGO flags','workload/seed/order','1CPU/2GiB/swap0 and serial knobs','sampling strides and interpretation','1303 planned requests per program and three oracle indices','original preregistration and failed raw'],
      'local_validation':{'pure_Python_checks':23,'new_DB_runs':0,'earlier_fixture_error_preserved':'Used stale shadow2 without canonical_R_comparison; corrected to verified first-attempt source proof. No DB executed.'},
      'retry':{'status':'frozen_before_retry','planned_new_non_PGO_database_builds':1,'planned_new_PGO_builds':0,'planned_first_lifecycles':2,'executed_first_lifecycles':0,
        'not_a_performance_candidate':True,'selected_runtime_changed':False,'formal_submission':False},
      'API_job_coverage':'Provided API receipt contains30 jobs; only that page independently verified. Full-job exclusivity not asserted from a partial page.',
      'independent_failure_audit_sha256':sha(analysis_path.read_bytes())}
    err_raw=enc(erratum);files['retry-erratum.json']=err_raw
    manifest={'scope':'Failed-before-ready diagnostic evidence and tool-only retry; no cost result or successful DB lifecycle',
      'raw':{'path':RAW,'bytes':len(raw),'sha256':sha(raw)},'erratum':{'path':ERRATUM,'sha256':sha(err_raw)},
      'files':{n:{'bytes':len(b),'sha256':sha(b)} for n,b in sorted(files.items())}}
    out=io.BytesIO()
    with zipfile.ZipFile(out,'w',zipfile.ZIP_DEFLATED,compresslevel=9) as z:
        for name,b in sorted({**files,'manifest.json':enc(manifest)}.items()):
            info=zipfile.ZipInfo(name,(2026,11,14,0,0,0));info.external_attr=0o100644<<16;z.writestr(info,b,compress_type=zipfile.ZIP_DEFLATED,compresslevel=9)
    audit=out.getvalue();new=copy.deepcopy(old);e=new['experiments'][-1]
    need(e['id']=='exact-distance-cost-diagnostic','wrong last experiment')
    e.update(status='attempt1_failed_before_ready_tool_retry_frozen',new_non_PGO_database_builds_executed=1,first_lifecycles_executed=0,
      result_message='assistant-exact-cost-launcher-failure',retry_first_lifecycles_executed=0)
    e['artifacts'] += [{'path':RAW,'sha256':sha(raw)},{'path':AUDIT,'sha256':sha(audit)},{'path':ERRATUM,'sha256':sha(err_raw)}]
    new['messages'].append({'id':'assistant-exact-cost-launcher-failure','role':'assistant','content':
      '诊断attempt1工具失败：shadow非PGO与空计时程序各编译1次；launcher因cgroup前缀不符，在ready前拒绝，0 SQL/0生命周期/0诊断记录，尚无oracle或成本结果。64为源码推断，原记录未保存子进程退出码。仅修正为既有允许前缀、记录退出码并补23项静态预检；原预登记/失败原档保留，同方案重试当时执行0。未改算法、资源或采样，不把失败当性能退化，R仍默认，未正式提交。'})
    need(new['messages'][:-1]==old['messages'] and new['experiments'][:-1]==old['experiments'][:-1],'old history changed')
    need({k:v for k,v in new.items() if k not in ('messages','experiments')}=={k:v for k,v in old.items() if k not in ('messages','experiments')},'root/user manifest changed')
    material=enc(new);need(len(material)<=131072,'overflow')
    spec=importlib.util.spec_from_file_location('retry_material_validator',repo/'minivec/tools/validate_iteration_material.py');checker=importlib.util.module_from_spec(spec);spec.loader.exec_module(checker)
    checker.validate(repo);checker.check_structure(new,new)
    for name,b in [('exact-cost-attempt1-audit.zip',audit),('exact-cost-launcher-erratum.json',err_raw),('exact-cost-retry-material-preview.json',material)]:
        target=work/name;need(not target.exists(),'work output exists');target.write_bytes(b)
    # Parent explicitly authorized these three material destinations and two copies.
    for path,b in [(repo/AUDIT,audit),(repo/ERRATUM,err_raw)]:need(not path.exists(),'repo artifact exists');path.write_bytes(b)
    try:
        (repo/'conversation.json').write_bytes(material);(repo/'agent/conversation.json').write_bytes(material);validation=checker.validate(repo)
    except BaseException:
        (repo/'conversation.json').write_bytes(prior);(repo/'agent/conversation.json').write_bytes(prior)
        (repo/AUDIT).unlink();(repo/ERRATUM).unlink();raise
    receipt={'status':'applied_verified_failure_and_unexecuted_retry','validation':validation,'users':49,'audit_bytes':len(audit),'audit_sha256':sha(audit),
      'erratum_bytes':len(err_raw),'erratum_sha256':sha(err_raw),'audit_members':len(manifest['files']),'old_users_and_messages_unchanged':True,
      'git_mutations':0,'new_DB_runs_by_recorder':0,'new_builds_by_recorder':0}
    (work/'exact-cost-retry-material-receipt.json').write_bytes(enc(receipt));print(json.dumps(receipt,indent=2))

if __name__=='__main__':main()
