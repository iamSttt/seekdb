"""Package completed offline audit; no raw rewrite, DB, network or repo mutation."""
import ast
import hashlib
import json
from pathlib import Path
from statistics import median
import zipfile

W=Path(__file__).resolve().parent
analysis_path=W/'tighter-only-v2-independent-analysis.json'
analysis=json.loads(analysis_path.read_bytes());screen=analysis['preregistered_screen']
assert analysis['status']=='verified' and analysis['verified_pairs']==24
assert screen['status']=='screen_clear_EE_gain_criteria_not_met_keep_R'
assert not screen['R_guard_triggers'] and not screen['eligible_for_one_confirmation']
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()

def metrics(reference,cpu):
    out={}
    for name,value in analysis['measurements'][reference][str(cpu)]['extra_summary']['standard10k'].items():
        rows=value['raw_pairs']
        ratios=[r['candidate']/r['baseline'] for r in rows if r['baseline']]
        out[name]={'median_baseline_absolute':median(r['baseline'] for r in rows),
            'median_candidate_absolute':median(r['candidate'] for r in rows),
            'median_paired_candidate_over_baseline':median(ratios) if ratios else None,
            'candidate_larger_pairs':value['candidate_larger_pairs'],'pairs':len(rows)}
    return out

commit_association=[]
for cpu in (1,2):
    values=analysis['measurements']['ee'][str(cpu)]['extra_summary']['standard10k']
    indexed={name:{r['pair_index']:r for r in item['raw_pairs']} for name,item in values.items()}
    for i,first in indexed['first_lifetime_no_restart'].items():
        if not first['candidate_larger']:continue
        names=('first_lifetime_no_restart','ingest_commit_wall_seconds','ingest_insert_wall_seconds',
            'first_lifetime_query_total','whole_cgroup_device_write_bytes')
        selected={name:indexed[name][i] for name in names}
        commit_association.append({'cpu_count':cpu,'pair_index':i,'order':first['order'],'values':selected,
            'commit_delta_exceeds_first_lifecycle_net_delta':selected['ingest_commit_wall_seconds']['candidate_minus_baseline']>first['candidate_minus_baseline']})
assert len(commit_association)==6 and all(r['values']['ingest_commit_wall_seconds']['candidate_larger'] for r in commit_association)
failures=[]
for cpu,item in screen['EE_primary'].items():
    for metric,value in item['metrics'].items():
        for condition,passed in value['conditions'].items():
            if not passed:failures.append({'cpu_count':int(cpu),'metric':metric,'failed_condition':condition,
                'statistics':value['statistics'],'limit':value['limit']})

decision={'status':'rejected_by_frozen_screen_keep_R','eligible_for_confirmation':False,
    'adopted':False,'formal_submission_by_assistant':False,'formal_score_prediction':None,
    'commit':analysis['commit'],'binary_sha256':analysis['candidate_binary_sha256'],
    'image_id':analysis['candidate_image_id'],'source_runtime_delta':['minivec/src/distance.h'],
    'raw_archive':{'repository_path':'validation/iteration5-tighter-only-v2-raw.zip','bytes':3746136,
        'sha256':'8a044ae1b3372a462c501ea2570af491cfb7fdde4bedbd9c619762f0ae2c7b89'},
    'api_run':43519132752,'artifact_id':14082403498,'job_id_parent_reported':132208642624,
    'job_log_scope':'Connector log transport closed; no further fetch. Complete API-bound artifact was independently verified.',
    'verified_root_gates':22,'actual_root_tighter_oracle_cases':24,'normal_sanitized_checks_each':11452601,
    'verified_performance_pairs':24,'screen':screen,'failed_primary_conditions':failures,
    'absolute_and_paired_default_metrics':{r:{str(c):metrics(r,c) for c in (1,2)} for r in ('ee','retained')},
    'negative_metric_groups_preserved':len(analysis['all_negative_or_mixed_metrics']),
    'negative_metric_group_definition':'125 metric groups with at least one adverse pair; not 125 distinct benchmark pairs.',
    'adverse_first_lifecycle_commit_association':commit_association,
    'commit_association_interpretation':{
        'all_six_adverse_EE_first_lifecycle_pairs_also_have_slower_COMMIT':True,
        'COMMIT_delta_exceeds_net_lifecycle_delta_in_pairs':sum(r['commit_delta_exceeds_first_lifecycle_net_delta'] for r in commit_association),
        'exception':'EE 2CPU pair1 also has slower query total: +31.441671 ms versus COMMIT +7.664323 ms.',
        'whole_cgroup_device_writes_in_all_six_pairs':6070272,
        'scope':'COMMIT timer co-occurrence and additive wall accounting, not a diagnosed I/O cause. Whole-cgroup writes include restart, not COMMIT-only traffic. No COMMIT-only CPU or fsync trace exists. No pair is dropped or labelled noise to change the screen.'},
    'host_model':'AMD EPYC 9V74 80-Core Processor','host_flags_include_avx512':True,
    'limitations':analysis['limitations']+[
        'Medians of separate absolute times differ from the median of paired ratios. The decision uses paired ratios only.',
        'Old retained/EE programs were imported rather than rebuilt alongside this candidate. Whole-version gains are not solely attributed to the certificate change.',
        'The new ELF is byte-identical to the v1 failed-gate ELF, but the v1 failed response was not stored; only v2 actual responses are now verified.'],
    'analysis_file':{'path':analysis_path.name,'sha256':sha(analysis_path)},
    'API_adaptation':{'original':{'path':'tighter-only-v2-api.json','sha256':sha(W/'tighter-only-v2-api.json')},
        'derived_compact':{'path':'tighter-only-v2-api-reader-receipt.json','sha256':sha(W/'tighter-only-v2-api-reader-receipt.json')},
        'scope':'Unique original artifacts[0] copied unchanged into inherited reader receipt; no run/job status invented.'}}
decision_path=W/'tighter-only-v2-independent-decision.json'
decision_path.write_bytes((json.dumps(decision,ensure_ascii=False,indent=2,allow_nan=False)+'\n').encode())
message={
 'role':'assistant','type':'experiment_result_draft','experiment_id':'tighter-certificate-highest-primary24',
 'protocol_revision':2,'implementation_and_tests_by':'assistant',
 'text':'7bab1e96… 的实际根镜像22项门禁、修正后的24个L2投影/TopK用例及24对小算力比较均完成并独立核验。按冻结规则不采用、不进入确认：EE单核首周期wall C/EE=0.8220但仅4/6对更快；双核首周期wall=1.04318（2/6对更快，BA中位1.05659），双核查询wall=0.91370未达0.90。查询CPU单/双核=0.86346/0.88689；R保护未触发。保留全部125项含负面对的指标组，不将不同对照或微核倍率相乘。6个EE首周期退步样本均伴随COMMIT变慢，5个COMMIT增量大于首周期净增量；这是分项关联，不足以认定I/O噪声，更不改变门槛或触发重试。没有正式提测或分数预测。',
 'prior_failure':'v1测试把sqrt投影误当平方距离；PGO1、已运行部分DB、perf0，原失败响应缺失。v2只修测试与证据保存，运行/构建/训练源码未改。'}
(W/'tighter-only-v2-result-message-draft.json').write_bytes((json.dumps(message,ensure_ascii=False,indent=2)+'\n').encode())

# Collect every local Python import dependency of the actual reader, including
# old historical readers/evaluators. Standard-library modules are not bundled.
pending=['analyze_tighter_primary_v2_root'];modules={}
while pending:
    name=pending.pop()
    if name in modules:continue
    path=W/(name+'.py')
    if not path.is_file():continue
    modules[name]=path
    for node in ast.walk(ast.parse(path.read_bytes())):
        names=[i.name for i in node.names] if isinstance(node,ast.Import) else [node.module] if isinstance(node,ast.ImportFrom) and node.module else []
        pending.extend(n.split('.')[0] for n in names if (W/(n.split('.')[0]+'.py')).is_file())
members={f'readers/{path.name}':path.read_bytes() for path in modules.values()}
for name in ('tighter-only-v2-independent-analysis.json','tighter-only-v2-independent-decision.json',
    'tighter-only-v2-result-message-draft.json','tighter-only-v2-api.json','tighter-only-v2-api-reader-receipt.json',
    'tighter-only-v2-reader-events.json','tighter-reader-v2-commit-binding.json','tighter-reader-v2-plan-binding.json',
    'tighter-reader-v2-handoff.json','tighter-projection-v2-preflight.json','check_tighter_projection_v2.py'):
    members[name]=(W/name).read_bytes()
for name in ('tighter-oracle-v2-preregistration-frozen.json','tighter-oracle-v2-erratum-frozen.json'):
    members['frozen/'+name]=(W/name).read_bytes()
for path in sorted((W/'tighter-bound-db-gates-v2').iterdir()):
    if path.is_file():members['gate-sources/'+path.name]=path.read_bytes()
members['package_tighter_only_v2_audit.py']=Path(__file__).read_bytes()
manifest={'scope':'Independent read-only result audit; raw ZIP remains separately preserved in repository validation.',
    'commit':analysis['commit'],'raw_archive':decision['raw_archive'],'members':[
        {'path':name,'bytes':len(raw),'sha256':hashlib.sha256(raw).hexdigest()} for name,raw in sorted(members.items())]}
members['manifest.json']=(json.dumps(manifest,indent=2)+'\n').encode()
archive=W/'tighter-only-v2-audit.zip'
assert not archive.exists(),'refuse overwrite'
with zipfile.ZipFile(archive,'w',compression=zipfile.ZIP_DEFLATED,compresslevel=9) as z:
    for name,raw in sorted(members.items()):z.writestr(name,raw)
with zipfile.ZipFile(archive) as z:
    assert set(z.namelist())==set(members) and all(z.read(k)==v for k,v in members.items())
receipt={'status':'packaged_verified_offline_audit','path':str(archive),'bytes':archive.stat().st_size,'sha256':sha(archive),
    'members':len(members),'local_reader_dependencies':len(modules),'decision':decision['status'],
    'negative_metric_groups_preserved':decision['negative_metric_groups_preserved'],'repository_writes':0,'DB_runs':0}
(W/'tighter-only-v2-audit-receipt.json').write_bytes((json.dumps(receipt,indent=2)+'\n').encode())
print(json.dumps(receipt))
