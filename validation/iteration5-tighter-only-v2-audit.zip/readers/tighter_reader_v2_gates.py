"""Tighter-only exact-source guard; reuse independently reviewed oracle reader.

Candidate commit and fresh preregistration identity are set only after freezing.
No database, compiler, benchmark or current-artifact reconstruction executes.
"""
import hashlib
import json

from analyze_crc_root import require, digest, git, blob, safe_name
from tighter_v2_oracle_reader import (verify_tighter_gate, independently_expected,
    REFERENCE, MICRO_COMMIT, PRODUCTION_SHA, REFERENCE_SHA, MANIFEST_SHA,
    GATE_SOURCE_HASHES, EXPECTED)

PREREG = 'validation/iteration5-tighter-certificate-primary24-oracle-v2-preregistration.json'
PREREG_SHA = 'a771368b7b35be94b579c6c0747e72710e6a1977fce30024af3bce88552ed594'
SOURCE_SNAPSHOT_COUNT = 72
EXPERIMENT = 'tighter-certificate-highest-primary24'
ERRATUM = 'validation/iteration5-tighter-certificate-oracle-v2-erratum.json'
ERRATUM_SHA = '065ecb255183d61ac25008132043cc5b69feb387ef153e2a98e15efcc85cea63'
FAILED_V1_COMMIT = 'd767915b4aa816cb2720947ffcbe681819aa6036'


def runtime_guard(repo,commit):
    require(PREREG_SHA is not None and SOURCE_SNAPSHOT_COUNT>0,'tighter-only prereg not yet frozen')
    inventories=[]
    for rev in (REFERENCE,commit):
        paths=git(repo,'ls-tree','-r','--name-only',rev,'--','minivec/src').decode().splitlines()
        inventories.append({p:digest(blob(repo,rev,p)) for p in paths})
    before,after=inventories
    require(set(after)-set(before)=={'minivec/src/quantized_batch8.h'} and not set(before)-set(after),
            'unexpected runtime inventory change')
    changed=sorted(p for p in before if before[p]!=after[p])
    require(changed==['minivec/src/distance.h'],'runtime delta exceeds isolated tighter certificate')
    # A retained historical header must not silently become part of this build.
    for p in after:
        if p=='minivec/src/quantized_batch8.h':continue
        source=blob(repo,commit,p)
        require(b'quantized_batch8.h' not in source and b'MVDB_ENABLE_BATCH8_QUANTIZED' not in source,
                'inactive batch8 header or policy is referenced by runtime: '+p)
    production=blob(repo,commit,'minivec/src/distance.h')
    require(digest(production)==PRODUCTION_SHA and
            production==blob(repo,commit,'minivec/tools/tighter_bound/candidate_distance.h')==
                        blob(repo,MICRO_COMMIT,'minivec/tools/tighter_bound/candidate_distance.h'),
            'production header not exactly screened micro candidate')
    require(digest(blob(repo,REFERENCE,'minivec/src/distance.h'))==REFERENCE_SHA,
            'old reference is not canonical R header')
    for p in ('Dockerfile','.dockerignore','minivec/Makefile','minivec/tools/pgo/train.cpp','minivec/tools/pgo/run-training.sh'):
        require(blob(repo,REFERENCE,p)==blob(repo,commit,p),'build/training drift '+p)
    require(git(repo,'ls-tree','-r',REFERENCE,'--','minivec/third_party')==
            git(repo,'ls-tree','-r',commit,'--','minivec/third_party'),'third-party drift')
    raw=blob(repo,commit,PREREG);require(digest(raw)==PREREG_SHA,'tighter-only prereg SHA differs');plan=json.loads(raw)
    require(plan['experiment_id']==EXPERIMENT and plan['fixed_plan']['measurement_family']=='highest_primary24_v1' and
            plan['fixed_plan']['pairs']==24 and plan['protocol_revision']==2 and plan['execution']=={
                'this_corrected_plan_new_PGO_builds_executed':0,'this_corrected_plan_database_pairs_executed':0,
                'prior_failed_attempt_root_PGO_builds_completed':1,'prior_failed_attempt_DB_execution_occurred':True,
                'prior_failed_attempt_performance_pairs':0,'default_adopted':False,'assistant_formal_submissions':0},
                'tighter-only corrected prereg scope differs')
    require(len(plan['source_snapshot'])==SOURCE_SNAPSHOT_COUNT and plan['planned_gate_inventory']['root_gate_groups']==22 and
            plan['planned_gate_inventory']['tighter_case_inventory']==EXPECTED,'frozen gate/source inventory differs')
    acquisition=plan['environment_acquisition']
    require(acquisition['maximum_total_attempts']==1 and acquisition['retry_only_if']=='None preauthorized for this screen.' and
            'native ISA choice' in acquisition['no_retry_for'],'isolated screen acquired a different environment policy')
    eraw=blob(repo,commit,ERRATUM);require(digest(eraw)==ERRATUM_SHA,'frozen oracle erratum differs')
    erratum=json.loads(eraw)
    require(erratum['experiment_id']==EXPERIMENT and erratum['correction_revision']==2 and
            erratum['runtime_changes_for_correction']==0 and erratum['failed_attempt']['commit']==FAILED_V1_COMMIT,
            'oracle correction scope differs')
    original=erratum['original_preregistration'];oraw=blob(repo,commit,original['path'])
    require(len(oraw)==original['bytes'] and digest(oraw)==original['sha256'] and
            oraw==blob(repo,FAILED_V1_COMMIT,original['path']),'original failed plan changed')
    failed=erratum['failed_attempt'];fraw=blob(repo,commit,failed['raw'])
    require(len(fraw)==failed['raw_bytes'] and digest(fraw)==failed['raw_sha256'] and
            failed['root_PGO_builds_completed']==1 and failed['DB_execution_occurred'] is True and
            failed['performance_pairs']==0,'failed original artifact or execution scope differs')
    require(not git(repo,'diff','--name-only',FAILED_V1_COMMIT,commit,'--','minivec/src','Dockerfile','.dockerignore',
                    'minivec/Makefile','minivec/third_party','minivec/tools/pgo/train.cpp','minivec/tools/pgo/run-training.sh').strip(),
            'oracle correction changed runtime/build/training source')
    for p,item in plan['source_snapshot'].items():
        safe_name(p);b=blob(repo,commit,p);oid=hashlib.sha1(b'blob '+str(len(b)).encode()+b'\0'+b).hexdigest()
        require(item=={'bytes':len(b),'sha256':digest(b),'git_blob':oid},'frozen committed source mismatch '+p)
    for p,h in GATE_SOURCE_HASHES.items():require(digest(blob(repo,commit,p))==h,'reviewed tighter gate source drift '+p)
    raw=blob(repo,commit,'minivec/tools/tighter_bound/handoff-manifest.json')
    require(digest(raw)==MANIFEST_SHA,'micro package handoff manifest differs');members=json.loads(raw)['files']
    require(len(members)==14 and len({i['path'] for i in members})==14,'micro package member inventory differs')
    for item in members:
        safe_name(item['path']);p='minivec/tools/tighter_bound/'+item['path'];b=blob(repo,commit,p)
        require(len(b)==item['bytes'] and digest(b)==item['sha256'] and b==blob(repo,MICRO_COMMIT,p),
                'frozen screened micro member drift '+p)
    return {'retained_source':REFERENCE,'changed_runtime_files':changed,
        'inactive_historical_header':'minivec/src/quantized_batch8.h','inactive_header_not_referenced':True,
        'candidate_sha256':{'minivec/src/distance.h':after['minivec/src/distance.h']},
        'source_snapshot_verified_count':SOURCE_SNAPSHOT_COUNT,'unchanged_training':True,
        'root_Docker_delta':'None; exact retained R Docker and four feature flags',
        'source_binding_method':'Exact committed blob bytes, including retained CRLF main.cpp; no working-tree clean inference.',
        'production_matches_screened_micro_candidate':True,'screened_micro_source':MICRO_COMMIT,
        'micro_manifest_sha256':MANIFEST_SHA,'micro_manifest_members_verified':14,
        'native_ISA_scope':'Original dispatch is unchanged; no ISA override, AVX2 acquisition probe or environment-based retry.',
        'micro_identity_scope':'Source identity only. Prior micro ratios are not combined with DB measurements.',
        'oracle_protocol_revision':2,'oracle_erratum_sha256':ERRATUM_SHA,'preserved_failed_attempt':failed,
        'failed_attempt_limit':'v1 compared squared values to sqrt projection and stored no failed response. Old runtime output is unrecoverable; no simultaneous runtime error was excluded.'}
