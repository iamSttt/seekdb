"""Pure Python oracle/failed-evidence checks; does not execute a database."""
import ast
from fractions import Fraction
import hashlib
import importlib.util
import json
from pathlib import Path
import random
import struct
import tempfile

import tighter_v2_oracle_reader as reader

W=Path(__file__).resolve().parent
REPO=W/'seekdb'
FILES=W/'tighter-bound-db-gates-v2'
spec=importlib.util.spec_from_file_location('corrected_projection_gate',FILES/'test_tighter_certificate_db.py')
gate=importlib.util.module_from_spec(spec);spec.loader.exec_module(gate)
for path in FILES.glob('*.py'):ast.parse(path.read_bytes())
checks=0
def need(ok,message):
    global checks
    if not ok:raise AssertionError(message)
    checks+=1
def value(bits):return struct.unpack('!d',struct.pack('!Q',bits))[0]
cases=[0,1,0x000fffffffffffff,0x0010000000000000,0x7fefffffffffffff]
for exponent in range(1,2047):cases.append((exponent<<52)|0x123456789abcd)
rng=random.Random(0x71B0A2)
cases.extend(rng.randrange(0x7ff0000000000000) for _ in range(128))
for bits in cases:
    squared=value(bits)
    need(gate.rounded_sqrt_binary64_bits(squared)==reader.integer_sqrt_projection_bits(squared),
         f'independent binary search/isqrt mismatch {bits:016x}')
midpoints=0
for exponent in (-537,-149,-1,0,149,511):
    for mantissa in (0,1,2,0x000ffffffffffffe,0x000fffffffffffff):
        bits=((exponent+1023)<<52)|mantissa
        low,high=Fraction.from_float(value(bits)),Fraction.from_float(value(bits+1))
        target=((low+high)/2)**2
        delta=min(target-low**2,high**2-target)/4
        for s,want in ((target-delta,bits),(target,bits if bits%2==0 else bits+1),(target+delta,bits+1)):
            need(gate.rounded_sqrt_binary64_bits(s)==f'{want:016x}','exact midpoint tie/carry failure');midpoints+=1
for bad in (-1.0,float('inf'),float('nan')):
    rejected=False
    try:gate.rounded_sqrt_binary64_bits(bad)
    except (AssertionError,ValueError,OverflowError):rejected=True
    need(rejected,'nonfinite/negative input accepted')
expected=gate.expected_checks(REPO)
independent=reader.independently_expected(REPO,'d767915b4aa816cb2720947ffcbe681819aa6036')
need(expected==independent and len(expected)==24,'24 actual-gate expectations differ from independent isqrt reader')
need(all(row['expected_rows'][0][0]==-9007199254740993 for row in expected if row['kind']=='indexed_near_tie'),
     'squared-distance/PK ranking changed')
# Deliberately fail the first query with a parsed response. This is a transport
# stub only, proving failure-first evidence storage without launching any DB.
oracle=gate.load_oracle(REPO);original_identity=gate.process_identity
response={'columns':['id','d'],'rows':[[-901,1.0]],'status':'ok'}
class FakeSession:
    def __init__(self,config,log,**kwargs):Path(log).write_bytes(b'')
    def start(self):pass
    def close(self):pass
    def shutdown(self):pass
oracle.Session=FakeSession
oracle.execute=lambda *args,**kwargs: response if args[2].startswith('serial_d128_') else {'status':'ok'}
gate.process_identity=lambda *args:{'pid':1,'native_tasks':[1],'binary_sha256':'0'*64,'runtime_environment':{}}
with tempfile.TemporaryDirectory(prefix='tighter-v2-failure-record-') as td:
    actual=[];sessions=[];failed=False
    try:gate.run_group(oracle,Path('not-executed'),'0'*64,Path(td),actual,sessions,128,'serial')
    except AssertionError as exc:failed='projected sqrt' in str(exc)
    finally:gate.process_identity=original_identity
    need(failed and len(actual)==1 and actual[0]['status']=='failed' and actual[0]['raw_response']==response and
         actual[0]['actual_rows']==[[-901,'3ff0000000000000']] and len(actual[0]['expected_rows'])==33,
         'failed comparison lost parsed response or normalized expected/actual rows')
report={'status':'passed_pure_python_only','checks':checks,'finite_binary64_cases':len(cases),'exact_midpoint_cases':midpoints,
    'actual_gate_expected_cases':24,'failure_record_stub_cases':1,'schema':gate.SCHEMA,
    'files':{p.name:hashlib.sha256(p.read_bytes()).hexdigest() for p in sorted(FILES.iterdir()) if p.is_file()},
    'projection_semantics':gate.PROJECTION_SEMANTICS,'native_executions':0,'database_runs':0,'performance_pairs':0,
    'scope':'Oracle tests only. Prior actual CI already built one PGO image and executed some DB gates; failed before performance.'}
out=W/'tighter-projection-v2-preflight.json';out.write_bytes((json.dumps(report,indent=2)+'\n').encode())
print(json.dumps({'status':report['status'],'checks':checks,'finite_cases':len(cases),'midpoints':midpoints,'output':str(out)}))
