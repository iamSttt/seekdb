"""Preview metadata-only material compaction. Never writes either repository copy."""
from copy import deepcopy
import hashlib
import importlib.util
import json
from pathlib import Path

WORK = Path(__file__).resolve().parent
REPO = WORK / 'seekdb'
BASE_BYTES = 128857
BASE_SHA = 'adc02b314b7e3ce4bb3a0268f8a6bae919a5c23dc1a17d93a521a3618bffcac6'
ARCHIVE = 'validation/iteration5-pre-insert-result-material.json'
PREVIEW = WORK / 'insert-result-material-preview.json'
SUMMARY = WORK / 'insert-result-material-preview-summary.json'
MAX_BYTES = 131072
MIN_FREE_BYTES = 5 * 1024
MOVED_FIELDS = {
    46: ('assistant_proposed_directions', 'active_candidate', 'other_directions_implemented',
         'root_pgo_builds_planned', 'planned_database_pairs', 'plan', 'artifacts', 'source_commit',
         'run_id', 'job_id', 'artifact_id', 'candidate_binary_sha256', 'candidate_image_id',
         'independent_analysis_sha256'),
    48: ('comparison', 'imported_candidate_binary_sha256', 'planned_database_pairs',
         'planned_new_root_builds', 'new_pgo_builds_planned', 'plan', 'artifacts', 'run_id',
         'job_id', 'artifact_id', 'harness_commit', 'independent_analysis_sha256'),
}
EXPECTED_IDS = {46: 'new-directions-crc32-ieee-screen', 48: 'highest-original-root-direct-comparison'}


def require(ok, message):
    if not ok:
        raise ValueError(message)


def sha(value):
    return hashlib.sha256(value).hexdigest()


def encoded(value):
    return json.dumps(value, ensure_ascii=False, separators=(',', ':'), allow_nan=False).encode('utf8')


def pointers(value, path=''):
    found = []
    if isinstance(value, dict):
        for key, child in value.items():
            location = path + '/' + key.replace('~', '~0').replace('/', '~1')
            if key == 'pointer' or key.endswith('_pointer'):
                found.append((location, child))
            found.extend(pointers(child, location))
    elif isinstance(value, list):
        for index, child in enumerate(value):
            found.extend(pointers(child, path + '/' + str(index)))
    return found


def main():
    require(not PREVIEW.exists() and not SUMMARY.exists(), 'refuse preview overwrite')
    raw = (REPO / 'conversation.json').read_bytes()
    require(raw == (REPO / 'agent/conversation.json').read_bytes(), 'material copies differ')
    require(len(raw) == BASE_BYTES and sha(raw) == BASE_SHA, 'material no longer matches reviewed baseline')
    archive_raw = (REPO / ARCHIVE).read_bytes()
    require(archive_raw == raw, 'root must first save the exact full baseline archive')
    spec = importlib.util.spec_from_file_location('material_validator', REPO / 'minivec/tools/validate_iteration_material.py')
    validator = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(validator)
    baseline_validation = validator.validate(REPO)
    original = json.loads(raw, object_pairs_hook=validator.unique_object)
    require(encoded(original) + b'\n' == raw, 'baseline is not exact expected canonical encoding')
    require(len(original['messages']) == 121 and sum(m['role'] == 'user' for m in original['messages']) == 44,
            'message inventory differs')
    preview = deepcopy(original)
    changed = []
    for index, keys in MOVED_FIELDS.items():
        old = original['experiments'][index]
        current = preview['experiments'][index]
        require(old['id'] == EXPECTED_IDS[index] and old['executed_by'] == 'assistant', 'wrong experiment')
        require('archived_metadata' not in current and all(key in current for key in keys), 'metadata plan differs')
        for key in keys:
            del current[key]
        # source_location belongs to this external, exact archive. It is never
        # presented as an internal RFC6901 pointer in the current conversation.
        current['archived_metadata'] = {'path': ARCHIVE, 'sha256': BASE_SHA,
                                        'source_location': '/experiments/' + str(index)}
        reference = current['archived_metadata']
        require(validator.resolve_pointer(json.loads(archive_raw), reference['source_location']) == old,
                'external archived source location differs')
        require({key: value for key, value in current.items() if key != 'archived_metadata'} ==
                {key: value for key, value in old.items() if key not in keys}, 'unexpected in-place change')
        changed.append({'experiment_index': index, 'id': old['id'], 'source_location': reference['source_location'],
            'archived_fields': list(keys), 'old_entry_bytes': len(encoded(old)), 'new_entry_bytes': len(encoded(current)),
            'saved_bytes': len(encoded(old)) - len(encoded(current)),
            'archived_field_value_sha256': {key: sha(encoded(old[key])) for key in keys},
            'retained_fields': [key for key in current if key != 'archived_metadata']})

    # Entire messages, not just user content: roles, text, all keys and order stay.
    require(encoded(preview['messages']) == encoded(original['messages']), 'a message changed')
    old_users = [m for m in original['messages'] if m['role'] == 'user']
    new_users = [m for m in preview['messages'] if m['role'] == 'user']
    require(encoded(new_users) == encoded(old_users), 'a user object/order changed')
    require(encoded(preview['provenance']) == encoded(original['provenance']), 'original provenance/manifest changed')
    require(encoded(preview['selected_runtime']) == encoded(original['selected_runtime']), 'selected runtime changed')
    require(encoded(preview['official_result']) == encoded(original['official_result']) and
            encoded(preview['experiments'][47]) == encoded(original['experiments'][47]), 'formal score record changed')
    require(pointers(preview) == pointers(original), 'existing internal pointer locations or values changed')
    for _, pointer in pointers(original):
        require(encoded(validator.resolve_pointer(preview, pointer)) ==
                encoded(validator.resolve_pointer(original, pointer)), 'pointer target changed: ' + pointer)
    for key in original:
        if key != 'experiments':
            require(encoded(preview[key]) == encoded(original[key]), 'unrelated top-level field changed: ' + key)
    for index, experiment in enumerate(original['experiments']):
        if index not in MOVED_FIELDS:
            require(encoded(preview['experiments'][index]) == encoded(experiment), 'unrelated experiment changed')
    validator.check_structure(preview, preview)
    output = encoded(preview) + b'\n'
    require(MAX_BYTES - len(output) >= MIN_FREE_BYTES, 'preview does not leave at least 5 KiB')
    require(BASE_BYTES - len(output) <= 3200, 'compaction exceeded the requested narrow scope')
    require((REPO / 'conversation.json').read_bytes() == raw and
            (REPO / 'agent/conversation.json').read_bytes() == raw and (REPO / ARCHIVE).read_bytes() == raw,
            'repository or archive changed during preview')
    summary = {'status': 'preview_only_not_applied', 'input_bytes': len(raw), 'input_sha256': BASE_SHA,
        'preview_path': str(PREVIEW), 'preview_bytes': len(output), 'preview_sha256': sha(output),
        'bytes_saved': len(raw) - len(output), 'remaining_bytes': MAX_BYTES - len(output),
        'archive': {'path': ARCHIVE, 'sha256': BASE_SHA, 'bytes': len(raw)}, 'changed_experiments': changed,
        'preserved_messages': 121, 'preserved_user_objects': 44, 'preserved_internal_pointers': len(pointers(original)),
        'messages_sequence_sha256': sha(encoded(original['messages'])),
        'user_objects_sequence_sha256': sha(encoded(old_users)),
        'user_manifest_sha256': sha(encoded(original['provenance']['user_content_sha256'])),
        'all_original_message_bytes_and_order_preserved': True, 'original_provenance_unchanged': True,
        'six_formal_score_record_unchanged': True, 'selected_runtime_unchanged': True,
        'measurements_positive_negative_messages_unchanged': True, 'failure_statuses_unchanged': True,
        'baseline_validation': baseline_validation, 'preview_structure_checked': True,
        'repository_writes': 0, 'new_database_runs': 0, 'apply_available_in_this_script': False,
        'scope': 'Only duplicate assistant identity/build/planning metadata in experiments 46 and 48 is archived. All 121 messages, experimental observations/counters/statuses, 44 users, original provenance, internal pointer targets and official scores remain inline. Root review and a separate checked apply are required.'}
    PREVIEW.write_bytes(output)
    SUMMARY.write_text(json.dumps(summary, ensure_ascii=False, indent=2) + '\n', encoding='utf8', newline='\n')
    print(json.dumps({key: summary[key] for key in ('status', 'preview_bytes', 'preview_sha256', 'bytes_saved',
        'remaining_bytes', 'preserved_messages', 'preserved_user_objects', 'preserved_internal_pointers', 'repository_writes')}))


if __name__ == '__main__':
    main()
