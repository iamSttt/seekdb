# INSERT目标类型复制：实现审查

已按root授权将独立候选接入 `work/seekdb/minivec/src/exec.cpp`，新增 `minivec/tests/test_insert_owned_copy.cpp`；未修改db.cpp、CRC、材料、CI或提交。已查workspace祖先与repo内（含隐藏路径），未找到适用AGENTS.md。

运行变化仅限INSERT：目标schema列与literal都为VECTOR时，用 `Value::ofVec(literal.v)` 建独立浮点副本，不复制马上被存储层清掉的原字符串；其他类型仍复制完整Value。普通顺序和显式列映射都先拥有完整行，再 `std::move` 交给按值接收的db.insert。公开const Statement保持所有权，未移动AST，也不把其过大reserve容量转存到表。普通路径仍复制一次浮点payload，不应称消除了这部分复制；显式列映射另外省掉full到insert的一次深拷贝。

校验与异常审查：schema/未知列/重复列仍先解析；行宽和遗漏列检查保留。db.cpp的check_vector_value只读type、维数及finite，不依赖s；durable尺寸、VARCHAR原拼写与长度、BIGINT转换、记录长度、重复PK、WAL与COMMIT仍走原规则。新局部拷贝分配位于原execute_statement的try范围，JSON调用异常由end_statement(false)回滚；没有新增吞异常或提前提交。SQL文本execute异常路径与JSON的既有差异未改，不宣称新增全API异常安全保证。

独立测试覆盖普通/重排列的同一AST成功→回滚→再次成功→重复PK失败，逐Value及浮点bit不变；两路径均验证过大AST容量不转存；VARCHAR bracket拼写、VECTOR负零、BIGINT/VARCHAR转换；重复/遗漏列、后段坏维度和重复PK的语句回滚；显式事务早先成功语句保留；手工非有限向量仍拒绝；WAL重开后仅四条预期记录。未注入bad_alloc，分配异常边界目前是源码审查结论。

本地仅做差分/换行/静态核对，未声称Linux编译或性能通过。exec.cpp保持原CRLF，diff为15增3删；新增测试LF。root将恢复旧CRC后独立测试，避免组合归因。风险包括lambda和逐Value构造改变编译布局、小标量INSERT固定成本，以及省掉字符串复制在完整生命周期中的占比未知。

Linux命令（从repo根目录执行；输出放新临时目录，不覆盖历史产物）：

```bash
out=$(mktemp -d /tmp/mvdb-insert-copy-check-XXXXXX)
features=(-DMVDB_ENABLE_SPILL_FILTER -DMVDB_ENABLE_TYPED_JSON -DMVDB_TYPED_WIDE_VECTOR_ONLY -DMVDB_MULTI_POSTING_REUSE_ONLY)
g++ -O2 -std=c++17 -pthread "${features[@]}" -Iminivec/src \
  minivec/tests/test_insert_owned_copy.cpp minivec/src/{db,exec,sql,value,flat_index}.cpp \
  -o "$out/insert-owned"
"$out/insert-owned"
g++ -O1 -g -std=c++17 -pthread "${features[@]}" -Iminivec/src \
  -fno-omit-frame-pointer -fsanitize=address,undefined -fno-sanitize-recover=all -no-pie \
  minivec/tests/test_insert_owned_copy.cpp minivec/src/{db,exec,sql,value,flat_index}.cpp \
  -o "$out/insert-owned-san"
ASAN_OPTIONS=detect_leaks=0 UBSAN_OPTIONS=halt_on_error=1:print_stacktrace=1 "$out/insert-owned-san"
```

建议同一测试也链接保留版本的完整src/third_party上下文运行，四宏相同；不要只把exec.cpp复制到孤立目录（它相对引用third_party）。现有test_query_regressions的INSERT所有权/NUL/hex/subnormal回归继续保留，但不能把旧结果冒充本次候选通过。后续性能优先同机实际程序的导入与首生命周期，保留显式列重排、标量与字符串保护；结果出来前不默认采用。
