"""Preview-only N rejection, deferred V2 and thread-control plan; no repo writes."""
import argparse
import copy
import hashlib
import importlib.util
import io
import json
from pathlib import Path
from statistics import median
import sys
import zipfile
sys.dont_write_bytecode = True

BASE_SHA='2c965ce5f7dc1f12f01bc1514554e9eb945b246343331d9f84bd5646bc50cbb9'
N='7554753868330006270cf39b1d32108f0a40ccac'
RAW_SHA='a0e9d3e89add2e85ac841e01083ea7a29e220f2d4b65dd7cd6b3538c69278ae3'
ANALYSIS_SHA='5790be91990ef2c0da66d5875783d345a6ae655966f7fa26e3502561bbf7806e'
RAW_PATH='validation/iteration5-insert-copy-n-raw.zip'
AUDIT_PATH='validation/iteration5-insert-copy-n-audit.zip'
NEW_USER={'id':'user-network-restored-continue','role':'user','content':'已恢复网络，继续'}

def require(value,message):
    if not value:raise ValueError(message)
def sha(raw):return hashlib.sha256(raw).hexdigest()
def encode(value):return (json.dumps(value,ensure_ascii=False,separators=(',',':'),allow_nan=False)+'\n').encode('utf8')

def main():
    work=Path(__file__).resolve().parent
    p=argparse.ArgumentParser(description=__doc__)
    p.add_argument('--repo',type=Path,default=work/'seekdb')
    p.add_argument('--output',type=Path,default=work/'insert-copy-n-result-preview.json')
    p.add_argument('--summary',type=Path,default=work/'insert-copy-n-result-preview-summary.json')
    p.add_argument('--require-archives',action='store_true',help='Fail until root has saved both exact archives; still preview only.')
    args=p.parse_args();repo=args.repo.resolve()
    for path in (args.output,args.summary):
        require(not path.resolve().is_relative_to(repo) and not path.exists(),'preview destination must be new and outside repo')
    raw=(repo/'conversation.json').read_bytes()
    require(raw==(repo/'agent/conversation.json').read_bytes() and len(raw)==125885 and sha(raw)==BASE_SHA,'material drift')
    require(sha((repo/'minivec/src/exec.cpp').read_bytes())=='366eb7a8f0bb22ae113aa9e841443f8913b4e876cc6599183bd6450f914137e5' and
            sha((repo/'minivec/src/db.cpp').read_bytes())=='9ca1d88ce5f8fe168c5a20800cbb2d69a09f34f6496c737e8a7be9b3fddb818e',
            'claimed retained-source restoration differs')
    old=json.loads(raw);m=copy.deepcopy(old)
    users=[x for x in old['messages'] if x['role']=='user']
    require(len(old['messages'])==121 and len(users)==44 and len(old['experiments'])==50,'original inventory differs')
    require(NEW_USER['id'] not in {x['id'] for x in old['messages']},'duplicate new user')
    ar=(work/'insert-copy-independent-analysis.json').read_bytes();a=json.loads(ar)
    require(sha(ar)==ANALYSIS_SHA and a['status']=='verified' and a['verified_pairs']==24 and a['commit']==N and
            a['artifact_sha256']==RAW_SHA and len(a['all_negative_or_mixed_metrics'])==136,'independent N result differs')
    require(a['joint_default_wall_cpu_regressions_over_2pct_majority']=={'retained-1cpu':['ingest'],'retained-2cpu':['ingest'],'ee-1cpu':[],'ee-2cpu':[]},'N default rejection differs')
    ingest_audit=json.loads((work/'insert-copy-ingest-audit.json').read_bytes())
    require(ingest_audit['new_database_runs']==0,'ingest audit is not read-only')
    resultdir=work/'performance/insert-copy-7554753'
    gates=json.loads((resultdir/'root-gates-summary.json').read_bytes())
    require(gates['passed'] is True and len(gates['checks'])==18 and all(x is True for x in gates['checks'].values()) and
            gates['insert_owned_copy_checks']=={'normal':952,'sanitized':952} and gates['runtime_commit']==N and
            gates['image_binary_sha256']==a['candidate_binary_sha256'],'actual root/source correctness evidence differs')
    actual_raw=(work/'performance/insert-copy-7554753.zip').read_bytes()
    require(len(actual_raw)==3723866 and sha(actual_raw)==RAW_SHA,'raw API archive differs')
    with zipfile.ZipFile(io.BytesIO(actual_raw)) as bundle:
        for cpu in (1,2):
            source=json.loads(bundle.read(f'insert-copy-root/retained-{cpu}cpu.json'))
            pairs=[x for x in source['pairs'] if x['scenario']=='standard10k']
            require(len(pairs)==6,'original ingest pair count differs')
            ratios={'user_us':[],'system_us':[]}
            for pair in pairs:
                values=[];ios=[]
                for side in ('baseline','candidate'):
                    run=pair[side];phases={x['phase']:x for x in run['adapter']['phase_cgroups']}
                    parts=[dict(line.split() for line in phases[k]['cpu.stat'].splitlines()) for k in ('before_ingest','after_ingest')]
                    values.append({key:int(parts[1][raw_key])-int(parts[0][raw_key]) for key,raw_key in [('user_us','user_usec'),('system_us','system_usec')]})
                    snapshots={x['phase']:x['process_io_counters_proxy'] for x in run['resource_snapshots']}
                    ios.append({key:snapshots['after_ingest'][key]-snapshots['before_ingest'][key] for key in ('rchar','wchar','syscr','syscw','read_bytes','write_bytes')})
                require(ios[0]==ios[1],'original ingest I/O pair differs')
                for key in ratios:ratios[key].append(values[1][key]/values[0][key])
            expected=ingest_audit['contrasts'][f'retained-{cpu}cpu']['medians']
            require(all(median(v)==expected[k] for k,v in ratios.items()) and median(ratios['user_us'])<1 and median(ratios['system_us'])>1.4,
                    'new ingest causal limitation is not supported by original raw counters')
    saved_raw=repo/RAW_PATH;saved_audit=repo/AUDIT_PATH
    if saved_raw.exists():require(saved_raw.read_bytes()==actual_raw,'saved N raw archive differs')
    audit=None
    if saved_audit.exists():
        with zipfile.ZipFile(saved_audit) as z:
            names=z.namelist();require(len(names)==len(set(names)),'duplicate audit members')
            require('insert-copy-independent-analysis.json' in names and z.read('insert-copy-independent-analysis.json')==ar,'audit does not contain exact independent N analysis')
            if args.require_archives:
                require(z.read('record_insert_copy_n_result.py')==Path(__file__).read_bytes(),'root must refresh archived logger before final preview')
        audit={'path':AUDIT_PATH,'sha256':sha(saved_audit.read_bytes())}
    if args.require_archives:require(saved_raw.is_file() and audit is not None,'root must save both archives before final preview')

    e=m['experiments'][49];require(e['id']=='schema-aware-insert-owned-copy','experiment49 changed')
    e.update(status='measured_rejected_default',database_pairs_executed=24,new_pgo_builds_executed=1,
        default_adopted=False,source_commit=N,run_id=43464055936,artifact_id=14057922936,
        candidate_binary_sha256=a['candidate_binary_sha256'],result_message='assistant-insert-n-result',
        correctness={'root_gate_groups':18,'source_owned_copy_checks':{'normal':952,'sanitized':952},
                     'actual_image_utf8_cases':54,'actual_root_json_topk_public':True},
        negative_or_mixed_metrics_preserved=136,
        artifacts=[{'path':RAW_PATH,'sha256':RAW_SHA}],
        adoption_screen='N/R ingest wall and CPU medians both >1.02 with majority slower at 1/2CPU: reject N. Stage sums, memory and protection remain separate; no score inference.')
    if audit:e['artifacts'].append(audit)
    else:e['pending_audit_archive']=AUDIT_PATH
    # Explicit convention prevents this new inverse ratio from being confused
    # with the historical material's usual baseline/candidate convention.
    e['default_N_over_R']={'columns':['CPU','pairs','ingest_wall','ingest_CPU','INSERT_wall','INSERT_slower','query_wall','query_CPU','first_stage_sum'],
        'rows':[[1,6,1.07383,1.06722,1.035534,6,0.939685,0.940758,0.99156],
                [2,6,1.051646,1.020947,1.023335,5,0.945672,0.923486,1.005087]],'greater_than_one':'N slower'}
    m['messages'].append(NEW_USER)
    m['provenance']['user_content_sha256'][NEW_USER['id']]=sha(NEW_USER['content'].encode('utf8'))
    m['messages'].append({'id':'assistant-insert-n-result','role':'assistant','content':
        'N755实际根PGO完成24对与18组门禁，正确性通过不等于性能获益。相对R，1/2CPU写入wall慢7.38%/5.17%、CPU慢6.72%/2.09%，均触发否决；1CPU INSERT 6/6慢。查询约省6%时间，但首周期阶段计时和一略快一略慢，均3/6退步；不采用N，selected_runtime仍R。exec已恢复7ca原字节，未新构建。spill16/宽向量阶段wall改善但CPU混合，136项负面及绝对对子全存档。EE/N另组2CPU首段约省11%不能替代R直接比较。BEGIN/INSERT/COMMIT仅分wall，CPU为整段；不是正式T/B/M，不推分。省字符串复制未证实是收益或退化原因。'})
    m['messages'].append({'id':'assistant-insert-v2-plan','role':'assistant','content':
        'V2定长直接填值暂缓，PGO0/DB0：原N写入user CPU反降约2.9%/4.2%，system增40%/46%，读写字节及调用数相同。尚不能定位临时Value开销；原始负面保留，不改默认。'})
    m['messages'].append({'id':'assistant-insert-thread-control-plan','role':'assistant','content':
        'assistant改提机制诊断：复用R/N实际ELF，同runner 1CPU/2GiB，自动与parse/query均1线程各4对，共8对，政策交错且AB/BA平衡。无新PGO、无默认改动。差异收窄仅支持线程/内核路径敏感，不能独归parser/query或证明涨分；当前DB0。'})
    m['experiments'].append({'id':'insert-thread-mechanism-control','proposed_by':'assistant','executed_by':'assistant',
        'status':'planned_unmeasured','user_request_message':NEW_USER['id'],
        'plan_message':'assistant-insert-thread-control-plan',
        'plan':{'pairs':8,'per_policy':4,'logical_cpus':1,'memory_bytes':2147483648,'swap':0,'mode':'exact',
                'policies':['automatic','MVDB_PARSE_THREADS=MVDB_QUERY_THREADS=1'],'order':'interleaved policies; balanced AB/BA'},
        'hypothesis':'Thread/kernel sensitivity unproven; imported R/N bytes, no runtime/default change.',
        'new_pgo_builds_executed':0,'database_pairs_executed':0,'default_adopted':False,
        'formal_submission_authorized':False,'assistant_formal_submissions':0})
    require(m['messages'][:121]==old['messages'],'existing messages changed')
    require([x for x in m['messages'] if x['role']=='user']==users+[NEW_USER],'user objects/order changed')
    old_manifest=old['provenance']['user_content_sha256'];new_manifest=m['provenance']['user_content_sha256']
    require(new_manifest==old_manifest|{NEW_USER['id']:sha(NEW_USER['content'].encode('utf8'))},'user provenance changed')
    for key in ('selected_runtime','official_result','platform_observation','historical_selected_runtime'):
        require(m[key]==old[key],key+' changed')
    require(m['experiments'][:49]==old['experiments'][:49],'prior experiment changed')
    result=encode(m)
    # If audit is pending reserve the future full artifact entry too.
    projected=copy.deepcopy(m)
    if audit is None:
        del projected['experiments'][49]['pending_audit_archive']
        projected['experiments'][49]['artifacts'].append({'path':AUDIT_PATH,'sha256':'f'*64})
    final_bytes=len(encode(projected))
    require(131072-final_bytes>=2048,'less than 2 KiB would remain; propose compaction separately, never delete automatically')
    spec=importlib.util.spec_from_file_location('insert_material_validator',repo/'minivec/tools/validate_iteration_material.py')
    checker=importlib.util.module_from_spec(spec);spec.loader.exec_module(checker);checker.check_structure(m,m)
    if args.require_archives:
        for item in e['artifacts']:checker.check_artifact(repo,item)
    summary={'status':'preview_only_not_applied','input_bytes':len(raw),'input_sha256':BASE_SHA,
        'preview_bytes':len(result),'preview_sha256':sha(result),'remaining_bytes':131072-len(result),
        'projected_final_remaining_bytes':131072-final_bytes,'all_original_messages_preserved':121,'original_user_objects_preserved':44,
        'new_user_messages':1,'total_users':45,'total_messages':len(m['messages']),'total_experiments':len(m['experiments']),
        'new_user_content_sha256':new_manifest[NEW_USER['id']],'selected_runtime_unchanged':True,'formal_scores_unchanged':True,
        'N_measured_pairs':24,'N_default_adopted':False,'V2_status':'deferred','V2_measured_pairs':0,'V2_new_pgo_builds':0,
        'thread_control_planned_pairs':8,'thread_control_measured_pairs':0,'thread_control_new_pgo_builds':0,
        'analysis_sha256':ANALYSIS_SHA,'raw_saved':saved_raw.is_file(),'audit_saved':audit is not None,
        'audit_sha256':audit['sha256'] if audit else None,'repo_writes':0,'new_database_runs':0,
        'additional_compaction':None,'apply_available':False}
    args.output.write_bytes(result);args.summary.write_text(json.dumps(summary,ensure_ascii=False,indent=2)+'\n',encoding='utf8')
    print(json.dumps(summary,ensure_ascii=False,indent=2))

if __name__=='__main__':main()
