# INSERT V2：普通列顺序的固定行大小草稿

仅生成 `insert-copy-v2-draft.patch`，未修改repo、编译、运行DB或推送。补丁针对当前N提交7554753868330006270cf39b1d32108f0a40ccac，exec.cpp原始CRLF SHA256为a1c88c50e43a636476a735162c38bf6a94b9d32f927a25c3342f05d665710d84。若正式应用应保留原CRLF，且重新核对基线；不能覆盖其他修改。

root报告N的24对正确性全过，但R/N导入wall退化约7.38%/5.17%、CPU约6.72%/2.095%，1CPU INSERT wall为6/6负面；查询约快6%。本审查未独立重算这些新数据，不能把退化原因认定为push_back或临时对象。查询收益也不能抵销导入的稳定负面。

V2只替换普通顺序分支的4行构建逻辑：`std::vector<Value> owned(row.size())`一次确定Value元素个数，按下标填充。目标和literal均为VECTOR时，直接设置目标type并复制v；新Value的s/i保持默认空/零，与V1的`Value::ofVec(literal.v)`结果一致。其他情况执行完整Value副本赋值。最终仍move这个独立owned行给db.insert。显式列重排路径、own_value helper和std::move(full)保持V1；parser、线程、存储及数据库校验不变。

值得试验的机制：普通路径不再逐次调用vector::push_back，不需每轮维护append边界/size；VECTOR分支不再经返回临时Value再移动进入row。不过优化编译器可能已消去部分临时操作和容量检查，源码上少写一层不能证明机器码少做等量工作。

风险：按size分配先默认构造所有Value，然后赋值，可能增加type/i/string/vector初始化及非VECTOR赋值成本；V1的复制构造有时反而更直接。分配次数不一定减少：两者都有一次行数组分配和每个有效向量的独立payload分配。该差异还可能改变内联和PGO布局，不能从当前导入退化推断V2一定恢复，也不能仅靠非PGO微基准采用。

所有权与失败路径：不move AST，不继承AST的过大vector容量；VARCHAR含bracket的双表示完整复制。类型/维度/finite/记录长度仍由db.insert检查。复制异常只污染尚未发布的本地owned对象，RAII释放；JSON语句边界仍按原execute_statement回滚此前成功行。SQL文本接口既有异常处理差异未改，不能宣称修复。当前test_insert_owned_copy的普通/重排列复用、成功回滚、后段维度/PK失败、保留显式事务前句、负零、标量转换、过大容量、WAL重启应原样用于V1/V2/保留版。

最小后续验证：正常及ASan/UBSan所有权测试先通过；随后完整根Docker按原四宏和既有PGO训练构建一个实际V2程序，绑定源/镜像/ELF，继续相同1/2CPU、exact、2GiB、swap0数据。先看导入/INSERT/COMMIT的绝对wall和CPU及首生命周期阶段和，再看查询和spill/wide保护，保留所有负面。若要把收益归因这一个构造变体，应同轮把固定保存的V1字节与实际V2直接配对；只和更老R对照只能证明整版变化，不能单独证明V1→V2机制。完整编译PGO结果出来前本草稿仍不采用。
