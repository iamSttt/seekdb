# INSERT 目标类型复制候选：最小实际根验证

本计划由 assistant 提出并实现测试接线，不是 user 新提出的具体机制。候选运行源码是保留版 7ca 的行为加 exec.cpp INSERT 目标类型复制；db.cpp 已恢复保留版逐字节 CRC。CRC header 单测仅保留为历史兼容回归，不表示本次运行采用 CRC8。

只新建一次当前根 Docker PGO 镜像；全部既有根门禁、实际镜像协议/54项 UTF8/TopK 串并行/恢复/内存预算和 sanitizer 保留。新增 INSERT const AST、目标类型、回滚和容量所有权 native 测试 normal+ASan/UBSan。native fixture 是源码测试，实际镜像的协议测试单独记录，不混称。

实际镜像提取 ELF 作为唯一 N。R 导入既有验证 acdd 字节与完整源码/PGO来源；EE 从已校验最高根 raw 导入实际 9a437 字节与根镜像/源码证明，不重建两种参照。EE 原 Actions 包漏传 ee-context/.dockerignore，严格只允许该既知成员从固定 Git 证明 source ZIP 在内存校验；其余成员必须完整，原 raw 不修改。原 raw SHA 为 cb6a5801cf2195cfcb0aafe7067143c825c8420974ead2c9e81ab6e6c2deb599，3879395 B。

固定24对，一对两个完整数据库生命周期，均 exact、2 GiB、swap=0、数据库实际 affinity 验证、CPU quota=CPU数×100000/100000。驱动/oracle 保持在数据库 cgroup 外；所有原模式、响应、独立 oracle、进程清理、OOM、CPU/内存cap 前后及阶段检查继续运行。

|直接比较|1 CPU|2 CPU|合计|
|---|---|---|---|
|R / N|standard10k 6对；spill_high_q16 2对|standard10k 6对；wide768 2对|16对|
|EE / N|standard10k 4对|standard10k 4对|8对|

仍用已验证 workload generator、seed7319、10k×128/1000查询/K10/100条写入批，半数查询普通列过滤；每场景交替 AB/BA。冻结独立 insert-copy plan，原12+8、40对历史计划验真不放宽。默认配对数量用于筛选，不能证明正式分数下限或统计显著性。

默认组新增建表后、写入前一次 cgroup snapshot。写入 CPU 为 before_ingest→after_ingest，包含 BEGIN/INSERT/COMMIT；三类请求 wall 分别记在 ingest_request_seconds，不重加到生命周期总和。首1000查询 CPU 为 after_index_build→query_before_update。首周期 wall 为启动/建表/写入/索引/首1000查询/退出的请求timer之和，不是含oracle和遥测空隙的端到端wall。对应CPU截至 before_shutdown，因此明确名称含 to_before_shutdown。after_restart→query_after_restart 包含重启后验证，不能标成纯query CPU。记录全部原phase/raw pair、mempeak与设备写字节，不移除异常慢COMMIT、不删除离群点。

采用前必须正确性全过，分别看 R/N 和 EE/N 默认组的首周期、首1000查询、写入 wall 与 CPU。若同一默认指标 wall 和 CPU 均多数对变慢且中位候选/基线超过1.02，标 do_not_adopt_default。没有触发也只是待人工审阅；重大混合结果不默认采用。spill收益不能抵消默认退化，不平均跨场景倍率，不相乘跨主机或跨参照比值，EE本地直接比较也不是正式分保证。

接线复用 prepare_small_root 的根镜像/Git输入证明、small_compute 的启动器/模式/资源/正确性、summarize_small_root 的逐运行验真。仅添加专用导入、shell入口与24对collector；ci_score 在全部根门禁后调用新入口。workflow 的 insert_copy / [insert-copy] 只触发这一根构建，排除普通大矩阵；另两个性能hook与其互斥。失败由collector写 failed_or_incomplete 并保留已有证据，不能因部分完成标全部通过。
