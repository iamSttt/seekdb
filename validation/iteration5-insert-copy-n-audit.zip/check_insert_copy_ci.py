"""Controlled INSERT-plan/metric rejection checks; zero database executions."""
import ast, copy, json, math, subprocess, sys, tempfile
from pathlib import Path
w=Path(__file__).resolve().parent
t=w/'seekdb/minivec/tools'
sys.path.insert(0,str(t))
import small_compute as s
import summarize_small_root as old
import summarize_insert_copy_root as new
checks=[]
def require(ok):
    if not ok: raise AssertionError('controlled check failed')
def reject(fn):
    try: fn()
    except (ValueError,KeyError): return
    raise AssertionError('invalid fixture accepted')
def check(name,fn): fn();checks.append(name)
for name in ('small_compute.py','benchmark_iteration.py','summarize_small_root.py','prepare_small_compute.py',
             'prepare_insert_copy_root.py','summarize_insert_copy_root.py'):
    ast.parse((t/name).read_text(encoding='utf8'),filename=str(t/name))
check('24_pair_matrix',lambda:require(sum(len(s.insert_copy_plan(r,c)) for r in ('retained','ee') for c in (1,2))==24))
for reference in ('retained','ee'):
    for count in (1,2):
        raw=json.loads((w/f'performance/highest-95afba3/ee-vs-retained/measurements-{count}cpu.json').read_bytes())
        fixed=s.insert_copy_plan(reference,count)
        data=copy.deepcopy(raw)
        data['pairs']=[]
        for entry in fixed:
            source=next(x for x in raw['pairs'] if x['scenario']==entry['scenario'] and x['pair_index']==entry['pair_index']%2)
            pair=copy.deepcopy(source);pair.update(entry)
            for role in ('baseline','candidate'):
                run=pair[role]
                if entry['scenario']=='standard10k':
                    before=copy.deepcopy(run['adapter']['phase_cgroups'][0]);before['phase']='before_ingest'
                    before['cpu.stat']=run['cgroup']['before']['cpu.stat']
                    run['adapter']['phase_cgroups'].insert(0,before)
                    run['ingest_request_seconds']={k:run['phase_seconds']['ingest']/3 for k in ('begin','insert','commit')}
            data['pairs'].append(pair)
        cases=tuple(dict.fromkeys(x['scenario'] for x in fixed))
        data.update(insert_copy_reference=reference,plan=fixed,protection_only=False,
                    expected_pairs=len(fixed),completed_pairs=len(fixed))
        def verify(value):old.verify_measurement(value,count,cases,value['identity_record_sha256'],value['identities'],reference)
        check(f'{reference}_{count}cpu_controlled_inventory',lambda:verify(data))
        for label,mutate in (
            ('missing_pair',lambda x:x['pairs'].pop()),
            ('wrong_order',lambda x:x['pairs'][0].update(order=['candidate','baseline'])),
            ('missing_phase',lambda x:x['pairs'][0]['candidate']['adapter']['phase_cgroups'].pop(0)),
            ('uncapped_phase',lambda x:x['pairs'][0]['candidate']['adapter']['phase_cgroups'][0].update({'memory.max':'max'})),
            ('wrong_mode',lambda x:x['pairs'][0]['candidate']['query']['query_before_update']['modes'].__setitem__(0,'ann'))):
            broken=copy.deepcopy(data);mutate(broken)
            check(f'{reference}_{count}cpu_reject_{label}',lambda broken=broken:reject(lambda:verify(broken)))
        check(f'{reference}_{count}cpu_metrics_keep_all_pairs',lambda:require(len(new.paired_standard(data)['metrics']['ingest_cpu_usec']['raw_pairs'])==(6 if reference=='retained' else 4)))
        bad=copy.deepcopy(data['pairs'][0]['candidate']);bad['ingest_request_seconds']['insert']+=1
        check(f'{reference}_{count}cpu_reject_double_ingest',lambda:reject(lambda:new.standard_metrics(bad)))
        bad=copy.deepcopy(data['pairs'][0]['candidate']);bad['adapter']['phase_cgroups'][0]['phase']='after_restart'
        check(f'{reference}_{count}cpu_reject_bad_cpu_scope',lambda:reject(lambda:new.standard_metrics(bad)))

def synthetic(scale):
    phases={k:scale for k in ('startup','create_table','ingest','index_build','query_before_update','shutdown')}
    names=['before_ingest','after_ingest','after_index_build','query_before_update','before_shutdown',
           'after_restart','query_after_restart','before_final_shutdown']
    return {'phase_seconds':phases,'ingest_request_seconds':{k:scale/3 for k in ('begin','insert','commit')},
            'query':{'query_before_update':{'per_request_seconds':[scale/1000]*1000}},
            'adapter':{'phase_cgroups':[{'phase':name,'cpu.stat':f'usage_usec {round((i+1)*100000*scale)}'} for i,name in enumerate(names)]},
            'cgroup':{'before':{'cpu.stat':'usage_usec 0'},'resource_delta':{'cpu_stat_delta':{'usage_usec':round(900000*scale)},
                         'memory_peak_bytes':100,'io_stat_delta':{'disk':{'wbytes':100}}}}}
data={'pairs':[{'scenario':'standard10k','pair_index':i,'order':['baseline','candidate'],
               'baseline':synthetic(1),'candidate':synthetic(1.03)} for i in range(6)]}
check('joint_three_percent_cpu_wall_rejected_for_default',lambda:require(new.paired_standard(data)['joint_wall_cpu_regression_over_2pct_majority']==['first_lifecycle','first_1000_queries','ingest']))
for pair in data['pairs']:pair['candidate']=synthetic(.99)
check('faster_screen_never_auto_adopted',lambda:require(new.paired_standard(data)['decision']=='manual_review_required_no_automatic_adoption'))

with tempfile.TemporaryDirectory(prefix='mvdb-insert-plan-') as temp:
    for reference in ('retained','ee'):
        for count in (1,2):
            out=Path(temp)/f'{reference}{count}.json'
            subprocess.run([sys.executable,'-B',str(t/'small_compute.py'),'--tools',str(t),'--output',str(out),
                            '--plan-only','--insert-copy-reference',reference,'--db-cpu-count',str(count),
                            '--allow-version-contrast','--query-mode','exact'],check=True)
            check(f'CLI_{reference}_{count}cpu_plan_only',lambda:require(json.loads(out.read_bytes())['pairs']==s.insert_copy_plan(reference,count)))
record={'status':'passed','checks':checks,'count':len(checks),'linux_database_runs':0,
        'scope':'Python syntax, actual CLI plan-only, controlled transformed old-result fixtures and artificial metric decision boundaries. No new performance measurements or Linux cgroup execution.'}
(w/'insert-copy-ci-static-validation.json').write_text(json.dumps(record,indent=2)+'\n')
print(json.dumps({'status':'passed','checks':len(checks),'linux_database_runs':0}))
