"""Pure-Python reader checks. Replays archived counters; no new DB measurement."""
import ast
import copy
import json
import sys
from pathlib import Path
from types import SimpleNamespace
sys.dont_write_bytecode=True
import analyze_insert_copy_root as r

W=Path(__file__).resolve().parent
checks=[]
def ok(name,fn):
    fn();checks.append({'name':name,'status':'passed'})
def rejected(name,fn):
    try:fn()
    except (ValueError,KeyError,FileNotFoundError):checks.append({'name':name,'status':'passed','expected_rejection':True})
    else:raise AssertionError(name+' accepted bad evidence')
def require(x):
    if not x:raise AssertionError('preflight invariant')

source=(W/'analyze_insert_copy_root.py').read_text(encoding='utf8')
ok('reader_AST',lambda:ast.parse(source))
ok('exact_24_plan',lambda:require(sum(len(r.plan(a,c)) for a in ('retained','ee') for c in (1,2))==24))
for arm,cpu,n in [('retained',1,8),('retained',2,8),('ee',1,4),('ee',2,4)]:
    ok(f'{arm}_{cpu}_frozen_count_order',lambda a=arm,c=cpu,n=n:require(len(r.plan(a,c))==n and
        all(p['order']==(['baseline','candidate'] if p['pair_index']%2==0 else ['candidate','baseline']) for p in r.plan(a,c))))
rejected('unknown_arm',lambda:r.plan('crc',1))
rejected('unknown_CPU',lambda:r.plan('retained',4))
raw=r.read(W/'performance/highest-95afba3/ee-vs-retained/measurements-1cpu.json')
actual=raw['pairs'][0]['baseline']
fixture=copy.deepcopy(actual)
snapshot=copy.deepcopy(fixture['adapter']['phase_cgroups'][0]);snapshot['phase']='before_ingest'
values=r.counters(snapshot['cpu.stat']);values['usage_usec']-=1000
snapshot['cpu.stat']='\n'.join(k+' '+str(v) for k,v in values.items())
fixture['adapter']['phase_cgroups'].insert(0,snapshot)
fixture['ingest_request_seconds']={'begin':.001,'insert':fixture['phase_seconds']['ingest']-.002,'commit':.001}
ok('archived_timing_components_not_double_counted',lambda:require(r.metrics(fixture,'standard10k')['first_lifetime_no_restart']==r.highest.combined_metrics(actual)['first_lifetime_no_restart']))
ok('constructed_interval_CPU_not_request_CPU_allocation',lambda:require(r.metrics(fixture,'standard10k')['ingest_cpu_usec']==1000 and not any(k.startswith('ingest_begin_cpu') for k in r.metrics(fixture,'standard10k'))))
sys.path.insert(0,str(W/'seekdb/minivec/tools'))
from summarize_insert_copy_root import paired_standard
pair_fixture={'pairs':[{'scenario':'standard10k','pair_index':0,'order':['baseline','candidate'],
                       'baseline':fixture,'candidate':copy.deepcopy(fixture)}]}
claimed=paired_standard(pair_fixture);derived=r.extra_summary(pair_fixture)['standard10k']
ok('independent_default_math_matches_collector_control',lambda:r.collector_default(derived,claimed))
bad_claim=copy.deepcopy(claimed);bad_claim['metrics']['ingest_wall_seconds']['raw_pairs'][0]['candidate']+=1
rejected('collector_raw_metric_tamper',lambda:r.collector_default(derived,bad_claim))
bad_claim=copy.deepcopy(claimed);bad_claim['decision']='adopt'
rejected('collector_adoption_tamper',lambda:r.collector_default(derived,bad_claim))
bad=copy.deepcopy(fixture);bad['ingest_request_seconds']['commit']+=.1
rejected('nonreconciling_components',lambda:r.metrics(bad,'standard10k'))
bad=copy.deepcopy(fixture);bad['ingest_request_seconds']['begin']=float('nan')
rejected('nonfinite_components',lambda:r.metrics(bad,'standard10k'))
bad=copy.deepcopy(fixture);bad['adapter']['phase_cgroups'].pop(0)
rejected('missing_CPU_boundary',lambda:r.metrics(bad,'standard10k'))
bad=copy.deepcopy(fixture);bad['adapter']['phase_cgroups'].insert(0,copy.deepcopy(snapshot))
rejected('duplicate_CPU_boundary',lambda:r.metrics(bad,'standard10k'))
bad=copy.deepcopy(fixture);v=r.counters(bad['adapter']['phase_cgroups'][1]['cpu.stat']);v['usage_usec']+=1
bad['adapter']['phase_cgroups'][0]['cpu.stat']='\n'.join(k+' '+str(x) for k,x in v.items())
rejected('negative_CPU_delta',lambda:r.metrics(bad,'standard10k'))
rejected('historical_20plan_cannot_masquerade_as_24',lambda:r.verify_insert_measurements(raw,1,('standard10k','spill_high_q16'),W,{}, {},{},'retained'))
rejected('wrong_fixed_commit',lambda:r.audit(SimpleNamespace(input=W,repo=W/'seekdb',commit='0'*40)))
rejected('missing_new_artifact',lambda:r.audit(SimpleNamespace(input=W/'missing-insert-evidence',repo=W/'seekdb',commit=r.INSERT_COMMIT,archive=W/'missing-insert.zip',artifact_sha256='0'*64,artifact_bytes=1)))
result={'status':'passed','checks':checks,'check_count':len(checks),'database_runs':0,'real_new_artifact_verified':False,
        'reader_sha256':r.sha(W/'analyze_insert_copy_root.py'),'fixed_commit':r.INSERT_COMMIT,
        'scope':'Controlled Python arithmetic/fail-closed checks. One archived measurement is copied only in memory and receives explicitly constructed CPU/start/subtimer fields; these are never performance evidence.'}
(W/'insert-reader-preflight.json').write_text(json.dumps(result,indent=2)+'\n',encoding='utf8')
print(json.dumps({k:result[k] for k in ('status','check_count','database_runs','real_new_artifact_verified','reader_sha256')}))
