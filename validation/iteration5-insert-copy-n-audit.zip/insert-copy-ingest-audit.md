# N755 写入退化独立复核

只读实际 `work/performance/insert-copy-7554753/insert-copy-root`，没有运行数据库、修改代码或改变采用标准。逐对分项、任务和 I/O 数值保存于 `work/insert-copy-ingest-audit.json`。R=acdd；实际 N=56061188b2f84127e563e1d061452ec6cc62c8fddbdf09c23bcf4d8b155c2784。仍维持本轮不默认采用。

|R/N 默认10k|1 CPU，6对|2 CPU，6对|
|---|---:|---:|
|写入 wall 候选/基线中位|1.07383|1.05165|
|写入总 CPU 候选/基线中位|1.06722|1.02095|
|user CPU 候选/基线中位|0.97114|0.95818|
|system CPU 候选/基线中位|1.40015|1.46296|
|INSERT 请求变慢对数|6/6|5/6|
|INSERT wall 配对增量中位|+6.861 ms|+4.337 ms|
|COMMIT wall 配对增量中位|+7.905 ms|+3.719 ms|

1 CPU 六对 BEGIN/INSERT/COMMIT wall 增量(ms)，保持原顺序：

|pair/order|BEGIN|INSERT|COMMIT|
|---|---:|---:|---:|
|0 BC|-0.229|6.753|-15.935|
|1 CB|0.924|10.748|11.952|
|2 BC|2.397|6.185|13.905|
|3 CB|0.413|6.970|14.007|
|4 BC|0.909|12.021|3.858|
|5 CB|0.214|5.114|1.640|

2 CPU 六对：

|pair/order|BEGIN|INSERT|COMMIT|
|---|---:|---:|---:|
|0 BC|-0.375|-3.667|1.647|
|1 CB|0.289|2.331|9.731|
|2 BC|-0.278|0.753|-3.561|
|3 CB|-0.050|6.343|14.239|
|4 BC|0.283|8.570|5.791|
|5 CB|1.965|10.424|1.457|

用户态CPU并没有一致增加；总CPU上升不能直接称为 `reserve/push_back` 临时 Value 构造开销已定位。原候选对 owned 一次 reserve(row.size)，不会因 push_back 多次增长；改为定长数组填值可以改变构造/赋值路径，但没有现有证据证明它能解决这轮主要退化。V2 应暂缓而不是凭该解释立即采纳。

12 对 R/N 的写入阶段读取/写入计数完全一致：rchar=25,277,454，wchar=5,666,194，syscr=602，syscw=400，设备 read_bytes=409,600、write_bytes=6,062,080，cgroup rios=100/wios=151，第一次退出后的持久文件总量=5,654,588 B。它们排除了已观测的字节量和 read/write 调用数量增多，不能排除 futex、sync、mmap/brk、缺页或每次调用成本变化。COMMIT 分项存在明显波动，不能用请求总 wall 直接定位 executor 内部。

所有 R/N 写入阶段 cgroup throttled_usec 增量为0，原生任务均从2个到3个；原已有非主任务增量0 tick，新出现任务累计1–3 tick，主任务约7–10 tick。tick为100Hz/10ms，且新任务没有写入前快照，不能据此精细定位哪个阶段/函数多耗几毫秒。原 raw 没有 minflt/majflt、voluntary/nonvoluntary context-switch、实际频率、cycles/IPC或逐函数CPU计数；相关 `/proc` 字段在旧采样器中未保存。

PGO生成器和训练shell两个SHA与R来源证明完全相同，固定gcc13.3与四宏；实际Docker日志没有 `-march=native`。但R导入构建记录是EPYC9V74，N当前根训练/测量机是EPYC7763，CPU特性会影响训练时运行分派和调度，源码变化也能改变全程序布局与反馈。原日志只给gcda摘要，未导出可直接比较的函数计数。以上是混杂因素，不能宣布PGO导致退化，也不能当噪声抹掉已观察的负面结果。

唯一建议的下一实验：复用原R/N实际ELF、不新PGO、不改运行代码，在同一runner、1CPU/2GiB下，比较自动线程与 `MVDB_PARSE_THREADS=MVDB_QUERY_THREADS=1` 两个诊断条件，每种4对R/N（AB/BA各2），交错政策顺序，共8对；保留原10k/COMMIT/首周期计时。若实施，仅在既有写入前后快照补各native task的fault/context-switch计数。比较同轮各条件的N-R写入差值；差异缩小仅支持线程协作/内核路径敏感性，不能单独归因parser或query。它不改变默认线程政策、不触及线程阈值矩阵。仅在新host跑固定线程再对比旧轮不能提供同等因果证据。
