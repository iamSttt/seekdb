"""Freeze only three new C3 evidence files; never modify old archives/material."""
import ast
import hashlib
import json
from pathlib import Path, PurePosixPath
import shutil
import subprocess
import zipfile

import condense_bulk_loop_results as condense

HERE = Path(__file__).resolve().parent
REPO = HERE / 'seekdb'
COMMIT = condense.COMMIT
RAW_SHA = '88e4a73af9d333b08a6db817a78c7cb06357fcfddc05eee1b31c2a065aebfef2'


def sha(path):
    with path.open('rb') as stream:
        return stream_sha(stream)


def stream_sha(stream):
    value = hashlib.sha256()
    for block in iter(lambda: stream.read(1024 * 1024), b''):
        value.update(block)
    return value.hexdigest()


def digest(data):
    return hashlib.sha256(data).hexdigest()


def encoded(value):
    return (json.dumps(value, ensure_ascii=False, indent=2, allow_nan=False) + '\n').encode('utf8')


def safe_members(bundle):
    names = set()
    for item in bundle.infolist():
        name = item.filename
        relative = PurePosixPath(name)
        assert name not in names and not item.is_dir(), 'duplicate/directory ZIP member'
        assert name and not relative.is_absolute() and relative.as_posix() == name
        assert not any(part in ('.', '..') for part in relative.parts) and '\\' not in name and ':' not in name
        assert (item.external_attr >> 16) & 0o170000 != 0o120000, 'symlink ZIP member'
        names.add(name)
    return names


def main():
    output = REPO / 'validation'
    targets = {k: output / ('iteration4-bulk-loop-' + k + ('.json' if k == 'results' else '.zip'))
               for k in ('raw', 'analysis', 'results')}
    assert all(not p.exists() for p in targets.values()), 'refuse overwrite'
    names = [
        'analyze_bulk_guard.py', 'analyze_bulk_typed.py', 'analyze_retained_final.py', 'augment_bulk_projection_resources.py',
        'check_bulk_guard_analysis.py', 'check_bulk_guard.py', 'check_retained_final_analyzer.py',
        'bulk-guard-analyzer-static-validation.json', 'bulk-guard-harness-static-validation.json',
        'bulk-loop-analysis.json', 'evaluate_bulk_guard_192.py', 'bulk-loop-evaluation.json',
        'bulk-loop-adoption-assessment.json', 'create_bulk_loop_assessment.py', 'bulk-loop-artifact-metadata.json',
        'bulk-loop-cpp-static-validation.json', 'bulk-loop-preflight-review.json', 'bulk-loop-preflight-package-validation.json',
        'root-c3d421ed-proof.json', 'root-c3d421ed-github-observation.json', 'verify_root_c3d421ed.py',
        'inspect_bulk_loop_codegen.py', 'inspect_bulk_pgo_mechanism.py', 'bulk-loop-codegen-inspection.json',
        'bulk-loop-codegen-and-resource-notes.md', 'condense_bulk_loop_results.py', 'archive_bulk_loop.py',
    ]
    entries = {name: (HERE / name).read_bytes() for name in names}
    read = lambda name: json.loads(entries[name])
    audit, evaluation, root = [read(n) for n in ('bulk-loop-analysis.json', 'bulk-loop-evaluation.json', 'root-c3d421ed-proof.json')]
    assert audit['status'] == 'verified' and audit['candidate_commit'] == COMMIT and audit['verified_pairs'] == 192
    assert evaluation['evidence']['independent_analysis_sha256'] == digest(entries['bulk-loop-analysis.json'])
    assert evaluation['evidence']['evaluation_tool_sha256'] == digest(entries['evaluate_bulk_guard_192.py'])
    assessment = read('bulk-loop-adoption-assessment.json')
    assert assessment['evidence']['derived_report_sha256'] == digest(entries['bulk-loop-evaluation.json'])
    assert assessment['evidence']['assessment_generator_sha256'] == digest(entries['create_bulk_loop_assessment.py'])
    static = read('bulk-guard-analyzer-static-validation.json')
    assert static['status'] == 'passed' and len(static['checks']) == 15
    for key, name in (('analyzer_sha256', 'analyze_bulk_guard.py'), ('shared_analyzer_sha256', 'analyze_retained_final.py'), ('test_sha256', 'check_bulk_guard_analysis.py')):
        assert static[key] == digest(entries[name])
    metadata = read('bulk-loop-artifact-metadata.json')
    assert metadata['source_commit'] == metadata['artifact']['workflow_run']['head_sha'] == COMMIT
    assert metadata['artifact']['digest'] == 'sha256:' + RAW_SHA
    raw = HERE / 'performance/bulk-loop-c3d421e.zip'
    assert raw.stat().st_size == metadata['artifact']['size_in_bytes'] == 49685962 and sha(raw) == RAW_SHA
    with zipfile.ZipFile(raw) as bundle:
        raw_names = safe_members(bundle)
        assert len(raw_names) == 188 and sum(i.file_size for i in bundle.infolist()) == 241004106
        assert raw_names == set(audit['artifact_files_verified']) | {'hashes.json'}
        assert digest(bundle.read('hashes.json')) == audit['artifact_manifest_sha256']
        for name, expected in audit['artifact_files_verified'].items():
            with bundle.open(name) as stream:
                assert stream_sha(stream) == expected, name
    raw_ref = {'path': targets['raw'].relative_to(REPO).as_posix(), 'github_artifact_id': metadata['artifact']['id'],
               'bytes': raw.stat().st_size, 'sha256': RAW_SHA, 'entries': 188, 'uncompressed_bytes': 241004106,
               'artifact_manifest_sha256': audit['artifact_manifest_sha256'],
               'measurements_sha256': audit['artifact_files_verified']['measurements.json']}
    root_zip = HERE / 'performance/root-image-validation-c3d421ed.zip'
    assert root_zip.stat().st_size == root['artifact_bytes'] == 59935 and sha(root_zip) == root['artifact_sha256']
    assert root['runtime_commit'] == COMMIT and root['checks'] == 16 and root['actual_image_utf8_checks'] == 54
    assert root['experimental_bulk_macro_enabled'] is False
    with zipfile.ZipFile(root_zip) as bundle:
        assert safe_members(bundle) == set(root['artifact_file_hashes'])
        for name, expected in root['artifact_file_hashes'].items():
            assert digest(bundle.read(name)) == expected, name
    entries[root_zip.name] = root_zip.read_bytes()
    codegen = read('bulk-loop-codegen-inspection.json')
    assert codegen['status'] == 'verified_offline_call_chain_inspection' and codegen['runtime_executions'] == 0
    assert codegen['roles']['loop_c3']['runtime_sha256'] == evaluation['binary_sha256']['bulk']
    assert codegen['roles']['baseline']['runtime_sha256'] == evaluation['binary_sha256']['baseline'] == root['image_binary_sha256']
    previous = REPO / 'validation/iteration4-bulk-guard-raw.zip'
    assert sha(previous) == '44420c714d59c1f98fa32879c917351ca02175aac474eb318217a068b69b31fd'
    entries['raw-artifact-reference.json'] = encoded(raw_ref)
    entries['previous-codegen-input-reference.json'] = encoded({'path': previous.relative_to(REPO).as_posix(),
        'sha256': sha(previous), 'bytes': previous.stat().st_size,
        'purpose': 'Read-only old85 binary comparison; keep the original existing ZIP, do not duplicate or mutate it.'})
    git = ['git', '-c', 'safe.directory=' + REPO.as_posix(), '-C', str(REPO)]
    snapshot = ['Dockerfile', '.dockerignore', 'minivec/Makefile', 'minivec/src/exec.cpp',
                'minivec/src/json_response_diagnostics.h', 'protocol_check/_transport.py', 'protocol_check/config.json',
                'minivec/tests/json_protocol.py', 'minivec/tests/test_bulk_typed_response.cpp', 'minivec/tests/test_typed_response.py']
    snapshot += ['minivec/tools/' + n for n in ('ablation_build.py', 'bulk_guard_proof.py', 'benchmark_bulk_guard.py',
        'ci_bulk_guard_confirmation.sh', 'bulk_typed_proof.py', 'benchmark_bulk_typed.py', 'benchmark_regression_ablation.py',
        'regression_ablation_proof.py', 'benchmark_iteration.py', 'benchmark_report_matrix.py', 'benchmark_projection.py',
        'benchmark_filter_repeat.py', 'ci_score.sh', 'pgo/train.cpp', 'pgo/run-training.sh')]
    for name in snapshot:
        entries['seekdb/' + name] = subprocess.check_output(git + ['show', COMMIT + ':' + name])
    for name, expected in read('bulk-guard-harness-static-validation.json')['files_sha256'].items():
        assert digest(entries['seekdb/minivec/tools/' + name]) == expected
    entries['README.md'] = b'''# Explicit-loop C3: immutable evidence, default OFF

Source c3d421ed0c1f92deaef65cf2a8d28aaa9d477042, run43419207297,
performance job131864668030. The original192 raw ZIP is separate at
validation/iteration4-bulk-loop-raw.zip,49685962 bytes, SHA256
88e4a73af9d333b08a6db817a78c7cb06357fcfddc05eee1b31c2a065aebfef2.
It has188 files/241004106 uncompressed bytes. Each member and the raw manifest
were checked against the frozen independent audit; no samples were rewritten.

Read bulk-loop-analysis.json for the full independent source/profile/binary/
oracle audit; bulk-loop-evaluation.json for the derived phase/resource analysis;
bulk-loop-adoption-assessment.json for assistant interpretation. Its generator
create_bulk_loop_assessment.py selects exact fields and adds authored prose;
it is not another source verifier. The frozen15 reader and12 producer fixture
records are historical static evidence, not newly executed Linux tests.

The experiment has150 candidate pairs and42 identical-baseline A/A pairs,
8 actual-binary gates,108 UTF8 cases and3 diagnostic/sanitizer gates. Large
16/64/127 outputs improve, but128/768 preservation and many64 distance cases
retain consistent negatives. Bulk remains OFF and this guard series closes.
All first/warm/restart queries, negative pairs, startup and ingestion pauses,
resource observations and order/seed differences remain. No AA normalization,
outlier deletion, official score forecast, Prompt claim or formal submission.

The included root validation ZIP/proof is a separate four-flag correctness job:
16 gates/54 UTF8 cases. Its CI-recorded binary SHA acddca115ab183bfc6419e27c9e3383cfd1a9046e3897e5ea516cd7bc0f29f54
matches the measured baseline and retained E/311 bytes, not five-flag candidate
97e4dbe8e5cc57f17268b2b08150d3913289e1aecbf4e88289c8aa32efd8e743.
The root artifact does not contain the executable for a new local hash. This
historical byte identity does not identify the user's official submission.

Codegen JSON/scripts/notes verify the predicate helper calls disappeared, but
also show changed scan/heap code generation. They do not prove a pure two-call
performance effect. Reproduction needs capstone5.0.3/pyelftools0.32 and both raw
directories: performance/bulk-loop-c3d421e and performance/bulk-guard-85cded3.
The old guard ZIP is referenced by hash, not modified or duplicated here.

To re-audit, unpack evidence in a separate writable directory, retain the full
Git repository including C3 and E, and run (new output paths only):
python -B analyze_bulk_guard.py --input RAW --source-repo REPO --candidate-commit c3d421ed0c1f92deaef65cf2a8d28aaa9d477042 --output NEW_AUDIT.json
python -B evaluate_bulk_guard_192.py --artifact RAW --analysis NEW_AUDIT.json --candidate-commit c3d421ed0c1f92deaef65cf2a8d28aaa9d477042 --output NEW_EVALUATION.json
The fixture scripts and archive/condensation tools are included; fixture tests
were not rerun just for packaging. seekdb/ is an immutable dependency snapshot,
not a full checkout. Root/codegen scripts retain their original work-layout
expectations. Source-only static hashes may reflect Windows CRLF, whereas
actual source proofs use committed Git blob bytes.

Process CPU has coarse ticks; HWM is cumulative and RSS a point sample. Resource
intervals include host-oracle gaps or restart probes, and no cgroup/official
resource equivalence is asserted. Archive creation changes only three new
validation files, not source/defaults/conversation/docs. archive-manifest.json
hashes every other member; the final external results JSON records this ZIP's
own hash and every measured phase. There is no circular self-hash dependency.
'''
    for name, value in entries.items():
        if name.endswith('.py'):
            ast.parse(value, filename=name)
    entries['archive-manifest.json'] = encoded({'source_commit': COMMIT,
        'scope': 'Every other member; the archive itself is hashed in the external results JSON.',
        'files': [{'path': name, 'bytes': len(value), 'sha256': digest(value)} for name, value in sorted(entries.items())]})
    with zipfile.ZipFile(targets['analysis'], 'x', compression=zipfile.ZIP_DEFLATED, compresslevel=9) as bundle:
        for name, value in sorted(entries.items()):
            info = zipfile.ZipInfo(name, (2026, 11, 13, 0, 0, 0)); info.compress_type = zipfile.ZIP_DEFLATED
            bundle.writestr(info, value, compresslevel=9)
    with zipfile.ZipFile(targets['analysis']) as bundle:
        assert safe_members(bundle) == set(entries)
        manifest = json.loads(bundle.read('archive-manifest.json'))
        assert len(manifest['files']) == len(entries) - 1
        for item in manifest['files']:
            data = bundle.read(item['path'])
            assert len(data) == item['bytes'] and digest(data) == item['sha256']
    shutil.copyfile(raw, targets['raw']); assert sha(targets['raw']) == RAW_SHA
    analysis_ref = {'path': targets['analysis'].relative_to(REPO).as_posix(), 'bytes': targets['analysis'].stat().st_size,
                    'sha256': sha(targets['analysis']), 'members': len(entries)}
    results = condense.build(audit, evaluation, root, raw_ref, analysis_ref)
    # Full inventory/numerical equality check against the source audit before publication.
    assert set(results['groups']) == set(audit['groups'])
    for name, group in audit['groups'].items():
        phases = results['groups'][name]['all_phases_including_negative']
        assert set(phases) == set(group['timings'])
        for phase, metric in group['timings'].items():
            assert phases[phase]['negative_pairs'] == metric['negative_pairs']
            assert phases[phase]['paired_baseline_over_candidate'] == metric['baseline_over_candidate']
    with targets['results'].open('xb') as stream:
        stream.write(encoded(results))
    report = {'status': 'archived_and_verified', 'source_commit': COMMIT,
        'new_files': {name: {'path': path.relative_to(REPO).as_posix(), 'bytes': path.stat().st_size, 'sha256': sha(path)} for name, path in targets.items()},
        'raw_entries_verified': 188, 'root_entries_verified': len(root['artifact_file_hashes']),
        'analysis_entries_verified': len(entries), 'groups_retained': len(results['groups']),
        'all_phases_and_negative_pair_ids_equal_to_frozen_audit': True,
        'packaged_python_ast_passed': True, 'fixture_suites_repeated': False,
        'scope': 'Archive bytes/member hashes and complete condensation only; no Linux engine execution, source/default change or official submission.'}
    (HERE / 'bulk-loop-archive-validation.json').write_bytes(encoded(report))
    print(json.dumps(report))


if __name__ == '__main__':
    main()
