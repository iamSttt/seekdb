"""Read-only verification of thec3d421ed four-flag root-image artifact."""
import hashlib
import json
from pathlib import Path, PurePosixPath
import re
import shutil
import subprocess
import zipfile

HERE = Path(__file__).resolve().parent
REPO = HERE / 'seekdb'
ROOT = HERE / 'performance/root-image-validation-c3d421ed'
COMMIT = 'c3d421ed0c1f92deaef65cf2a8d28aaa9d477042'
FLAGS = ['-DMVDB_ENABLE_SPILL_FILTER', '-DMVDB_ENABLE_TYPED_JSON',
         '-DMVDB_TYPED_WIDE_VECTOR_ONLY', '-DMVDB_MULTI_POSTING_REUSE_ONLY']
SELECTORS = ['Dockerfile', '.dockerignore', 'minivec/src', 'minivec/third_party',
             'minivec/Makefile', 'minivec/tests', 'minivec/tools/ci_score.sh',
             'minivec/tools/ci_final_performance.sh', 'minivec/tools/pgo/train.cpp',
             'minivec/tools/pgo/run-training.sh', 'STDIO_PROTOCOL.md', 'protocol_check', 'mysqltest']
git = ['git', '-c', 'safe.directory=' + REPO.as_posix(), '-C', str(REPO)]

def sha(path):
    h = hashlib.sha256()
    with path.open('rb') as f:
        for b in iter(lambda: f.read(1024 * 1024), b''): h.update(b)
    return h.hexdigest()

def read(path):
    return json.loads(path.read_text(encoding='utf-8'))

artifact = ROOT.with_suffix('.zip')
observation = read(HERE / 'root-c3d421ed-github-observation.json')
assert len(observation['artifacts']) == 1
expected_artifact = observation['artifacts'][0]
assert expected_artifact['workflow_run']['head_sha'] == COMMIT
assert expected_artifact['digest'] == 'sha256:' + sha(artifact)
assert expected_artifact['size_in_bytes'] == artifact.stat().st_size
with zipfile.ZipFile(artifact) as z:
    assert z.testzip() is None
    entries = z.infolist()
    assert len(entries) == 94
    for e in entries:
        assert sha(ROOT / e.filename) == hashlib.sha256(z.read(e)).hexdigest(), e.filename

summary = read(ROOT / 'verification-summary.json')
assert summary['runtime_commit'] == COMMIT == (ROOT / 'runtime-commit.txt').read_text().strip()
assert summary['passed'] is True and len(summary['checks']) == 16 and all(v is True for v in summary['checks'].values())
assert summary['selected_feature_flags'] == FLAGS
image_sha = (ROOT / 'image-binary-sha256.txt').read_text().split()[0]
assert summary['image_binary_sha256'] == image_sha
assert summary['source_binary_sha256'] == (ROOT / 'source-binary-sha256.txt').read_text().split()[0]
image = read(ROOT / 'image-inspect.json')
assert len(image) == 1 and image[0]['Id'] == summary['image_id'] == (ROOT / 'image-id.txt').read_text().strip()
assert image[0]['Architecture'] == 'amd64' and image[0]['Os'] == 'linux'
utf8 = read(ROOT / 'image-binary-utf8.json')
expected = {(malformed, dim, path) for malformed in ['ff', 'c080', 'eda080', 'f4908080', 'e4b8', '80']
            for dim in [None, 127, 128] for path in ['ORDER BY id LIMIT 10', 'unbounded', 'ORDER BY id LIMIT 4096']}
actual = {(x['malformed_hex'], x['projected_vector_dimension'], x['path']) for x in utf8['checks']}
assert utf8['status'] == 'passed' and len(utf8['checks']) == 54 and actual == expected
assert all(x['status'] == 'passed' and x['valid_prefix_bytes'] == 90000 for x in utf8['checks'])
for log in ['image-binary-json.log', 'image-binary-topk.log', 'image-binary-topk-parallel.log',
            'filter-reuse-normal.log', 'filter-reuse-sanitized.log']:
    assert 'PASS' in (ROOT / log).read_text(encoding='utf-8')

inputs = {}
for line in (ROOT / 'input-sha256.txt').read_text().splitlines():
    digest, name = line.split('  ', 1)
    p = PurePosixPath(name)
    assert re.fullmatch('[0-9a-f]{64}', digest) and name not in inputs
    assert not p.is_absolute() and p.as_posix() == name and '..' not in p.parts
    inputs[name] = digest
paths = subprocess.check_output(git + ['ls-tree', '-r', '--name-only', COMMIT, '--'] + SELECTORS).decode().splitlines()
assert len(paths) == 140
assert set(paths) == set(inputs), (set(paths) - set(inputs), set(inputs) - set(paths))
batch = subprocess.check_output(git + ['cat-file', '--batch'], input=''.join(COMMIT + ':' + p + '\n' for p in paths).encode())
offset = 0
blobs = {}
for p in paths:
    end = batch.index(b'\n', offset)
    oid, typ, length = batch[offset:end].split()
    assert typ == b'blob'
    offset = end + 1
    b = batch[offset:offset + int(length)]
    assert len(b) == int(length) and hashlib.sha256(b).hexdigest() == inputs[p], p
    offset += int(length)
    assert batch[offset:offset + 1] == b'\n'; offset += 1
    blobs[p] = b
assert offset == len(batch)
docker = blobs['Dockerfile'].decode()
make = blobs['minivec/Makefile'].decode()
ci = blobs['minivec/tools/ci_score.sh'].decode()
assert re.search(r'ARG FEATURE_FLAGS="' + re.escape(' '.join(FLAGS)) + '"', docker)
assert re.search(r'FEATURE_FLAGS \?= ' + re.escape(' '.join(FLAGS)) + r'\s*\n', make)
assert "FEATURE_FLAGS='" + ' '.join(FLAGS) + "'" in ci
assert 'docker cp "$container:/minivec" "$scratch/image-binary"' in ci
assert 'python3 minivec/tests/test_typed_response.py' in ci

observation = read(HERE / 'root-c3d421ed-github-observation.json')
assert observation['run_id'] == 43419207297
job = observation['job']
assert job['id'] == 131864668470 and job['status'] == 'completed' and job['conclusion'] == 'success'
metadata = observation['artifacts']
assert len(metadata) == 1 and metadata[0]['id'] == expected_artifact['id']
assert metadata[0]['workflow_run']['head_sha'] == COMMIT
assert metadata[0]['digest'] == 'sha256:' + sha(artifact)
assert metadata[0]['size_in_bytes'] == artifact.stat().st_size
proof = {
    'status': 'verified', 'runtime_commit': COMMIT, 'run_id': 43419207297,
    'job_id': 131864668470, 'github_job_observed_conclusion': 'success',
    'artifact_id': expected_artifact['id'], 'artifact_sha256': sha(artifact),
    'artifact_bytes': artifact.stat().st_size, 'artifact_files': len(entries),
    'artifact_uncompressed_bytes': sum(e.file_size for e in entries),
    'artifact_file_hashes': {e.filename: sha(ROOT / e.filename) for e in entries},
    'immutable_git_inputs_verified': len(inputs), 'input_hashes': inputs,
    'input_manifest_sha256': sha(ROOT / 'input-sha256.txt'),
    'verification_summary_sha256': sha(ROOT / 'verification-summary.json'),
    'github_observation_sha256': sha(HERE / 'root-c3d421ed-github-observation.json'),
    'checks': 16, 'check_results': summary['checks'], 'actual_image_utf8_checks': 54,
    'default_flags': FLAGS, 'image_id': summary['image_id'],
    'image_binary_sha256': image_sha,
    'source_binary_sha256': summary['source_binary_sha256'],
    'experimental_bulk_macro_enabled': False,
    'performance_measured': False,
    'performance_scope': 'This root job performs correctness/build checks only. The separate explicit-loop192-pair performance artifact was not fetched or analyzed here. A later five-flag default build requires a separate actual-image proof and binary binding; do not transfer these four-flag results.',
    'verification_scope': 'Authenticated GitHub job/artifact metadata, original ZIP digest, every extracted file, summary/gate logs, complete immutable Git blob input set and default feature wiring verified. No local Docker/C++ execution. Root artifact records CI extraction SHA but does not include the executable for local rehash.',
    'formal_submission_performed': False, 'official_score': None,
}
out = HERE / 'root-c3d421ed-proof.json'
assert not out.exists()
out.write_bytes((json.dumps(proof, indent=2, allow_nan=False) + '\n').encode())
print(json.dumps({k: proof[k] for k in ['status','runtime_commit','immutable_git_inputs_verified','checks','actual_image_utf8_checks','image_binary_sha256','performance_measured']}))
