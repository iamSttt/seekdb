"""Offline targeted call-chain/codegen comparison. No database execution."""
import collections
import difflib
import hashlib
import json
from pathlib import Path
from inspect_bulk_pgo_mechanism import Elf, parse_nm, disassemble, gcda
from capstone import Cs, CS_ARCH_X86, CS_MODE_64, CS_GRP_CALL, CS_GRP_JUMP
from capstone.x86_const import X86_OP_IMM

HERE=Path(__file__).resolve().parent
ROOTS={'baseline':'bulk-loop-c3d421e/baseline-pgo',
       'guard85':'bulk-guard-85cded3/bulk-pgo',
       'loop_c3':'bulk-loop-c3d421e/bulk-pgo'}
sha=lambda b:hashlib.sha256(b).hexdigest()
roles={}; elfs={}; syms={}; chains={}

def instructions(elf,record):
    md=Cs(CS_ARCH_X86,CS_MODE_64);md.detail=True
    seq=list(md.disasm(elf.read(record['address'],record['bytes']),record['address']))
    assert sum(i.size for i in seq)==record['bytes']
    return seq

def calls(elf,record):
    return [elf.reference(i.operands[0].imm,(record['address'],record['address']+record['bytes'],''))
            if i.operands and i.operands[0].type==X86_OP_IMM else i.op_str
            for i in instructions(elf,record) if i.group(CS_GRP_CALL)]

for role,rel in ROOTS.items():
    root=HERE/'performance'/rel;training=root/'training'
    ctx=json.loads((root.parent/'context.json').read_text())['profile_source_proof']['baseline' if role=='baseline' else 'bulk']
    assert sha((root/'minivec').read_bytes())==ctx['binary_sha256']
    for name,key in [('unstripped-minivec','unstripped_binary_sha256'),('instrumented-minivec','instrumented_binary_sha256')]:
        assert sha((training/name).read_bytes())==ctx[key]
    for name,expected in ctx['layout_sha256'].items():assert sha((training/name).read_bytes())==expected
    for name,expected in ctx['source_sha256'].items():assert sha((root/'built-source'/name).read_bytes())==expected
    elf=Elf(training/'unstripped-minivec');elfs[role]=elf
    nm=parse_nm(training/'symbols.txt');syms[role]=nm
    # Identify via the actual unsigned std::function trampoline, not lambda numbering.
    invoke=[(n,v) for n,v in nm.items() if n.startswith('std::_Function_handler<void (unsigned int), ') and 'mvdb::execute_impl(' in n and '::_M_invoke(' in n]
    assert len(invoke)==1
    invoke_name,invoke_rec=invoke[0]
    jumps=[i for i in instructions(elf,invoke_rec) if i.group(CS_GRP_JUMP)]
    assert len(jumps)==1 and jumps[0].operands[0].type==X86_OP_IMM
    target=jumps[0].operands[0].imm
    hot=[(n,v) for n,v in nm.items() if v['address']==target and n.startswith('mvdb::execute_impl(') and '::operator()(unsigned int) const' in n and '[clone .cold]' not in n]
    assert len(hot)==1
    hot_name,hot_rec=hot[0]
    cold_name=hot_name+' [clone .cold]';assert cold_name in nm
    cold_rec=nm[cold_name]
    mains=[(n,v) for n,v in nm.items() if n.startswith('mvdb::execute_impl(') and '::{lambda' not in n and '[clone' not in n]
    assert len(mains)==1
    main_name,main_rec=mains[0]
    wrappers=[(n,v) for n,v in nm.items() if n.startswith('mvdb::execute_impl(') and '::_FUN(void*, unsigned int)' in n and '[clone' not in n]
    assert len(wrappers)==1
    wrapper_name,wrapper_rec=wrappers[0]
    # The wrapper calls the std::function invoker field; the unique unsigned
    # invoker above forwards to the concrete hot scan body by direct jump.
    assert calls(elf,wrapper_rec)==['qword ptr [rdi + 0x18]']
    predicates={n:v for n,v in nm.items() if '::{lambda(mvdb::execute_impl' in n and '::Item const&)#' in n}
    inst=Elf(training/'instrumented-minivec');names=inst.gcov_functions()
    profs={p.name:gcda(p,names) for p in sorted((training/'profile-data').glob('*.gcda'))}
    for name,p in profs.items():assert p['sha256']==ctx['profile_sha256'][name]
    # Resolve the instrumented function name by unstripped ELF symbol at the
    # verified scan target. Do not reuse the previous artifact's lambda ordinal.
    mangled=[s.name for s in elf.symbols if s['st_info']['type']=='STT_FUNC' and s['st_value']==target and 'execute_impl' in s.name]
    assert len(mangled)==1
    scan_prof=[p for unit in profs.values() for p in unit['functions'] if p['name']==mangled[0]]
    assert len(scan_prof)==1
    chains[role]={'run_half':(wrapper_name,wrapper_rec),'invoke':(invoke_name,invoke_rec),'scan_hot':(hot_name,hot_rec),
                  'scan_cold':(cold_name,cold_rec),'execute_main':(main_name,main_rec)}
    roles[role]={'source_commit':ctx['source_commit'],'runtime_sha256':ctx['binary_sha256'],
                 'unstripped_sha256':ctx['unstripped_binary_sha256'],
                 'instrumented_sha256':ctx['instrumented_binary_sha256'],
                 'context_sha256':sha((root.parent/'context.json').read_bytes()),
                 'profile_sha256':ctx['profile_sha256'],'source_sha256':ctx['source_sha256'],
                 'feature_flags':ctx['feature_flags'],
                 'scan_chain':{k:{'name':n,**r,'normalized':disassemble(elf,r)[0]} for k,(n,r) in chains[role].items()},
                 'predicate_functions':predicates,
                 'scan_profile':scan_prof[0],
                 'calls':{k:dict(collections.Counter(calls(elf,r))) for k,(n,r) in chains[role].items()},
                 'text_bytes':elf.elf.get_section_by_name('.text')['sh_size']}
    roles[role]['push_heap_symbols']={n:v for n,v in nm.items() if n.startswith('void std::push_heap<') and 'mvdb::execute_impl(' in n}
    assert any('self+' not in x for x in calls(elf,main_rec))

comparisons={}
for left,right in [('baseline','loop_c3'),('guard85','loop_c3')]:
    comp={}
    for key in chains[left]:
        an,ar=chains[left][key];bn,br=chains[right][key]
        aa,ad,ah=disassemble(elfs[left],ar);bb,bd,bh=disassemble(elfs[right],br)
        comp[key]={'before_name':an,'after_name':bn,'bytes':[ar['bytes'],br['bytes']],
                   'instruction_counts':[len(aa),len(bb)],'same_raw_bytes':ah==bh,
                   'same_normalized_instructions':aa==bb,
                   'normalized_diff':list(difflib.unified_diff(aa,bb,n=2)),
                   'before_disassembly':ad,'after_disassembly':bd}
    a=roles[left]['scan_profile'];b=roles[right]['scan_profile']
    comp['scan_training_profile']={'same_cfg_checksum':a['cfg_checksum']==b['cfg_checksum'],
                                   'same_arcs':a['counters'].get('arcs')==b['counters'].get('arcs'),
                                   'arc_lengths':[len(a['counters'].get('arcs',[])),len(b['counters'].get('arcs',[]))]}
    comparisons[left+'__'+right]=comp

assert len(roles['guard85']['predicate_functions'])==2
assert len(roles['loop_c3']['predicate_functions'])==0
seq=roles['loop_c3']['scan_chain']['execute_main']['normalized']
at=[i for i,s in enumerate(seq) if s=='cmp edx,127'];assert len(at)==1
prefix=seq[at[0]-14:at[0]+4]
assert not any(s.startswith('call ') for s in prefix)
roles['loop_c3']['inline_scalar_distance_vector_type_loop_excerpt']=prefix
assert roles['baseline']['runtime_sha256']==json.loads((HERE/'root-c3d421ed-proof.json').read_text())['image_binary_sha256']
out={'status':'verified_offline_call_chain_inspection','runtime_executions':0,
     'interpretation':'Match scan_half via unique std::function<void(unsigned)>::_M_invoke direct jump and target operator body. Nonempty exact matches required. Predicate symbol absence alone does not prove zero admission cost; inspect main inline decision. Normalized code is not a formal semantic proof or performance cause.',
     'root_program_matches_measured_baseline_sha':True,
     'roles':roles,'comparisons':comparisons}
(HERE/'bulk-loop-codegen-inspection.json').write_text(json.dumps(out,indent=2)+'\n')
print(json.dumps({'status':out['status'],'roles':{r:{'predicate_symbols':len(v['predicate_functions']),
    'scan_hot_bytes':v['scan_chain']['scan_hot']['bytes'],'scan_cold_bytes':v['scan_chain']['scan_cold']['bytes']} for r,v in roles.items()},
    'profile':{p:c['scan_training_profile'] for p,c in comparisons.items()}}))
