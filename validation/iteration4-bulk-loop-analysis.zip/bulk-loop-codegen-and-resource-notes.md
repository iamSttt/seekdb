# C3 explicit loop: offline codegen and small-resource audit

Assistant read-only inspection, 2026-11-13. No source/default changes, CI invocation, or new performance run was performed by this audit. Performance decisions belong to the independently verified `bulk-loop-analysis.json`, not to function size or this source review.

## Binary binding and actual machine-code result

- Loop candidate source: `c3d421ed0c1f92deaef65cf2a8d28aaa9d477042`; measured program SHA-256 `97e4dbe8e5cc57f17268b2b08150d3913289e1aecbf4e88289c8aa32efd8e743`.
- Measured baseline source: `e020fdeb67dd8b64b77f0f8c2905f137f0112bba`; program SHA-256 `acddca115ab183bfc6419e27c9e3383cfd1a9046e3897e5ea516cd7bc0f29f54`.
- The C3 root validation job's four-default-feature image also records `acdd...9f54`. Thus the validated root program matches the measured baseline, not the five-feature bulk candidate. Root validation proves 140 immutable Git inputs, 16 gates and 54 actual-image UTF-8 cases (`root-c3d421ed-proof.json`).

`inspect_bulk_loop_codegen.py` verifies retained runtime/unstripped/instrumented ELF hashes, source files, symbol/section listings and profile hashes against artifact context. It depends on the frozen `inspect_bulk_pgo_mechanism.py`, capstone 5.0.3 and pyelftools 0.32. The raw inputs are `performance/bulk-loop-c3d421e/` and `performance/bulk-guard-85cded3/`; output is `bulk-loop-codegen-inspection.json`. It does not execute these programs.

The old 88-byte hot / 25-byte cold Item-only predicate helper is absent from C3. This is supported by more than missing names: execute_impl contains the inline distance/scalar/type/dimension loop, with no call in its scalar/distance decision sequence. It advances 48 bytes per Item and checks the VECTOR dimension against 127 only after a VECTOR type match. The two old predicate calls on `id, distance` have therefore been eliminated in this actual candidate.

Scan matching is independent of lambda ordinal. The unique `std::_Function_handler<void(unsigned), ...>::_M_invoke` is decoded and its direct jump target must match exactly one unsigned operator body. The `run_half` wrapper is independently identified and must call the std::function invoker field. Empty or ambiguous matches fail the script. C3's wrapper is at `0x446960`, its invoker at `0x446980`, and that invoker directly jumps to scan_half at `0x438860`.

| Body | Baseline | Previous guard85 | Loop C3 |
|---|---:|---:|---:|
| run_half | 32 B | 32 B | 32 B |
| unsigned invoker | 10 B | 10 B | 10 B |
| scan_half hot | 6503 B / 1305 instructions | 6503 B / 1305 instructions | 5395 B / 1096 instructions |
| scan_half cold | 2007 B / 444 instructions | 2007 B / 444 instructions | 1450 B / 320 instructions |
| execute_impl main | 10375 B | 10338 B | 10113 B |
| .text | 1015105 B | 1015105 B | 1013377 B |

The wrappers have identical normalized instructions. The scan body does not: C3 introduces a call to a separately emitted `std::push_heap` specialization, which has 1198 hot bytes plus 497 cold bytes. Neither older program has that separate symbol. The scan's local stack reservation changes from 600 to 584 bytes; registers, stack slots and branch layout also change. Direct quantized initialization, bound update, distance and heap-adjustment call sites remain present. These are real compiler decisions beyond the admission predicate. The 26 training arc counters and CFG checksum for the correctly matched scan function remain identical across all three roles.

Consequently the implementation achieved predicate-call elimination, but the experiment is not a pure two-call subtraction. A smaller scan body does not establish lower execution time: some work has moved into a called helper. Without a compiler inlining report or hardware counters, this audit does not assign why the inliner changed or attribute the performance outcome to any one machine-code change.

## Default threads: concrete costs, not hidden-score attribution

The public checked-in `protocol_check/config.json` specifies CPU 2, memory `2g`, pids 128 and a 16 MiB response ceiling. This is public-driver evidence; the coordinator is separately verifying the platform's actual evaluation configuration and score. These notes do not infer hidden workload weights or turn CI ratios into a score forecast.

The current four defaults do **not** enable `MVDB_ENABLE_WORKLOAD_FANOUT`. The default query policy therefore bypasses the affinity/cgroup helper in `query_cost.h` and calls the legacy policy directly:

1. `query_pool.h::query_fanout_mode()` reads `sysconf(_SC_NPROCESSORS_ONLN)`, not cgroup CPU quota. With at least two online CPUs and no environment override, it selects Adaptive. `MVDB_QUERY_THREADS=1` or `MVDB_SINGLE_THREAD` selects Never; an explicit value >=2 forces the two-part path when at least two online CPUs are reported. The force still requires the outer execution-path eligibility checks.
2. `exec.cpp::execute_statement()` calls `query_pool_startup_probe()` before executing the first statement. Under the default policy, this starts the 256 KiB-stack query worker and performs 8 warm-up plus 200 futex handshake samples. A valid first CREATE, tiny query, or subsequently filtered workload pays this one-time cost too. It occurs after ready, on the first statement, despite the source comment describing it as outside timed queries.
3. The adaptive estimate is fixed at 10 ns per candidate row and requires predicted gain of at least 15 us. It does not use dimension, K, quantization rejection rate or actual query time. Its effective row threshold is at least `max(1024, 3000 + 400*wake_us)`; for example wake=5 us gives 5000 rows. The execution path additionally requires unfiltered resident, non-approximate, ascending bounded TopK and K<=1024. Filters/spilled storage do not use this two-part query path.
4. Between queries the worker sleeps (`idle_spin=0`). The caller may perform 200 pause iterations while joining a selected fan-out. This is **200 iterations, not 200 microseconds**. There is no continuously busy background query worker in this default code.

CPU 2 itself does not imply an oversubscription bug: a fan-out uses the caller plus one worker. However `sysconf` can expose host CPU count rather than the process's effective allocation, and the wake median/10 ns heuristic does not model cgroup throttling or contention. Those are plausible configuration costs, not measurements showing they caused the official loss. The enabled workload-policy helper would inspect sched_getaffinity and cgroup v2 cpu.max, including ancestors, but it is off and is not proposed for automatic activation here.

The parser pool is separate. `parse_thread_count()` defaults to min(2, hardware_concurrency), allows an explicit 1..8, and does not consult quota. `sql.cpp` constructs `ParsePool::instance()` before checking the 16-row parallel threshold in drain(), so the first ordinary INSERT with literal jobs can create its worker even below the threshold. `MVDB_QUERY_THREADS=1` does not disable this parser pool. Under single-client execution, parsing and scanning are sequential; the presence of both worker threads does not prove three active compute threads at once.

## Smallest useful configuration comparison

The proposed same-`acdd` experiment with original environment versus `MVDB_QUERY_THREADS=1` is well isolated from source, compiler and PGO changes. It still changes two runtime behaviors together: first-statement calibration/worker creation and steady-state query fan-out. Record first SQL/import, first SELECT, subsequent SELECTs and complete measured lifecycle separately. Run both arms inside the same verified CPU2/2GiB limit and preserve actual stderr policy, cgroup throttling and memory evidence if available. Keep parser threads unchanged initially; otherwise a gain would mix parser and query-pool effects.

If serial wins on small cases but loses on expensive scans, a plausible retention strategy is narrower lazy calibration: only initialize/probe when the first query is actually eligible for resident fan-out, retaining the existing per-query decision afterward. This is a future independently testable candidate, not implemented or proven here. If the loss is in long steady-state fan-out, lazy initialization cannot fix it; a different policy would need its own evidence. The prior forced-two-thread 30k regression cannot itself prove default Adaptive is bad, and filtered warm-query regression cannot be attributed to this non-filtered fan-out branch.

## Memory and I/O configuration

Actual source limits are conservative relative to 2 GiB: per-table payload spill 32 MiB, aggregate resident payload 64 MiB, aggregate flat-index budget 16 MiB, sort-run budget 8 MiB, retained UPDATE before-images 1 MiB, automatic checkpoint after about 64 MiB of WAL. They are separate budgets; none is a whole-process cap. Row metadata, PK maps, SQL/AST and complete response buffers are additional memory. The result sorter charges payload length rather than string capacity, and final JSON is still accumulated before publication.

These thresholds can force payload/index disk paths and external sorting while substantial cgroup headroom remains, so they are credible large-data latency costs. They are not evidence that memory budget explains tiny resident workloads, nor permission to raise limits globally: official memory/I/O scoring, transient row/AST peaks and multi-table interactions may penalize that change. A budget experiment would need paired cgroup memory peak, throttling, I/O and correctness evidence under the actual limit. The immediate thread-only experiment avoids changing these safety bounds and preserves the already measured spill feature.
