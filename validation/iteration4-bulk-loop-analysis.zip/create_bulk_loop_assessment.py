"""Reproduce the assistant's C3 assessment from frozen, verified JSON reports.

This selects exact statistics and adds explicitly authored interpretation. It
is not an independent source/profile verifier or a benchmark execution tool.
"""
import hashlib
import json
from pathlib import Path

HERE = Path(__file__).resolve().parent
COMMIT = "c3d421ed0c1f92deaef65cf2a8d28aaa9d477042"


def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def compact(metric):
    def part(m):
        return {k: m[k] for k in ("pairs", "baseline", "candidate", "baseline_over_candidate",
                                  "candidate_larger_pairs", "candidate_smaller_pairs", "equal_pairs")}
    return {**part(metric), "unit": metric["unit"],
            "by_seed": {k: part(v) for k, v in metric["by_seed"].items()},
            "by_order": {k: part(v) for k, v in metric["by_order"].items()},
            "negative_pair_ids": metric["candidate_larger_pair_ids"]}


def main():
    derived_path = HERE / "bulk-loop-evaluation.json"
    audit_path = HERE / "bulk-loop-analysis.json"
    derived = json.loads(derived_path.read_bytes())
    audit = json.loads(audit_path.read_bytes())
    assert derived["status"] == "derived_from_verified_inputs" and audit["status"] == "verified"
    assert derived["verified_pairs"] == audit["verified_pairs"] == 192
    assert derived["candidate_commit"] == audit["candidate_commit"] == COMMIT
    assert derived["evidence"]["independent_analysis_sha256"] == sha(audit_path)
    assert derived["evidence"]["evaluation_tool_sha256"] == sha(HERE / "evaluate_bulk_guard_192.py")
    chosen = {}
    for name, group in derived["groups"].items():
        if not name.startswith("bulk/"):
            continue
        keys = ["lifecycle/measured_lifecycle", "query_before_update/all_requests",
                "query_before_update/first", "query_before_update/front64", "query_before_update/after64",
                "query_after_restart/all_requests", "query_after_restart/first", "query_after_restart/after64",
                "all_seven_query_timers", "accounted_timer_sum", "lifecycle/startup",
                "lifecycle/create_and_insert", "lifecycle/ingest", "lifecycle/index_build", "lifecycle/restart"]
        keys += [p + "/" + phase for p in ("wide_large4096", "wide_all", "wide_distance10", "narrow_all")
                 for phase in ("all_three", "first", "remaining_two")]
        chosen[name] = {"timings": {k: compact(group["timings"][k]) for k in keys if k in group["timings"]},
                        "aa_context": {k: v for k, v in group.get("aa_context", {}).get("timings", {}).items()
                                       if k in keys},
                        "complete_metrics_and_raw_negative_pairs": "bulk-loop-evaluation.json#/groups/" + name.replace("/", "~1")}
    report = {
        "status": "assistant_assessment_of_verified_192", "candidate_commit": COMMIT,
        "role": "assistant", "recommendation": "Do not enable the bulk macro. End this guard experiment series; retain the verified four-flag source pending official-submission identity and a separate small-resource screen.",
        "automatic_adoption": False, "source_or_default_changed_by_this_analysis": False,
        "new_ci_started": False, "official_score": None, "formal_submission": False,
        "evidence": {"raw": "performance/bulk-loop-c3d421e", "archive": "performance/bulk-loop-c3d421e.zip",
                     "archive_sha256": "88e4a73af9d333b08a6db817a78c7cb06357fcfddc05eee1b31c2a065aebfef2",
                     "independent_audit": audit_path.name, "independent_audit_sha256": sha(audit_path),
                     "derived_report": derived_path.name, "derived_report_sha256": sha(derived_path),
                     "assessment_generator_sha256": sha(Path(__file__)), "binary_sha256": derived["binary_sha256"],
                     "baseline_matches_retained_actual_binary": derived["earlier_delivery_binary_comparison"]["byte_identical_to_earlier_actual_binary"]},
        "findings": [
            "Correctness:192 pairs, eight actual-binary gates,108 UTF8 cases and three source diagnostic/sanitizer gates passed. No official evaluation, resource limit equivalence or Prompt score is inferred.",
            "Bulk outputs remain clearly beneficial on fixed16/64/127 workloads: seven-query timer sum ratios1.12517/1.16071/1.19835, all45 pairs positive, every seed and both orders positive. Large4096 ratios1.15187/1.19048/1.22698 and unbounded-vector ratios1.12805/1.15270/1.18838 are each positive in all15 pairs. First and subsequent requests in these output phases also improve in every pair.",
            "30k first1000 ratio1.00120, first query1.00699, front64 ratio1.00258 and after936 ratio1.00085 are nearly neutral. Counts remain5/5/6/7 negative respectively. Restart queries1.00685 have6 negatives; lifecycle1.05701 has6 negatives. This differs from the earlier85 experiment but does not isolate a causal effect across different runners and PGO builds. CPU medians600ms/600ms and memory near equality accompany the neutral first batch.",
            "Standard first1000 ratio0.99770 has8 negatives, after936 ratio0.99905 has8; restart1.01278 has4 and lifecycle1.02144 has7. First-batch seed7319/8911 and both order medians are slightly negative. A positive lifecycle median does not establish every original phase is protected.",
            "60k first1000 ratio0.99726 has9 negatives; front64 improves1.00645 but after936 ratio0.99741 has9 negatives and all seed medians below1. Restart batch0.99539 has8 negatives. Its first query0.99166 has14 negatives, all three seed and both order medians below1; medians7.119ms to7.224ms. AA first-restart ratio1.0051 does not erase this loss. Restart batch AA0.9967 is near the candidate ratio; neither is an automatic noise correction.",
            "The strongest remaining output protection failure is128 dimensions: seven-query sum0.99227 has14/15 negative, large4096 ratio0.99239 has13, and unbounded-vector output0.99379 has14. Every seed and both orders are below1 for all three totals. Large4096 tail0.99235 has14 negatives; unbounded tail0.99200 has13. AA seven-query sum1.0055 has all six ratios above1 (range1.0029..1.0153), which does not support labeling the candidate losses universally as noise.",
            "768 dimensions also remain negative: seven-query sum0.99313 has12 negatives, large4096 ratio0.99471 has12, and unbounded-vector0.99312 has14; all seed/order medians are negative. Unbounded tail0.99451 has14 negatives. Accounted total1.02786 is positive overall but includes large variable ingestion/startup costs; it does not negate the query losses.",
            "Many64 distance10 ratio0.95387 has11 negatives; first0.94625 has12 and both have all seed/order medians below1. Remainingtwo0.99142 has8 negatives with mixed seed/order directions. AA total1.0067 (range0.9401..1.1398), first1.0405 and tail0.9697 are retained without normalization. Seed7319 pair0 AB remains an outlier: total2.030609 to5.152019ms, first1.233612 to4.210598ms, tail0.796997 to0.941421ms.",
            "Many16 distance total1.08661 has4 negatives, first1.03592 has5 and tail1.15330 has6; seed8911 total/first is negative and seed7319 tail is negative. Many127 distance total0.98896 has8 negatives, first0.99006 has10, tail1.04565 has7 with mixed order/seed effects. These phases are not declared universally protected. Narrow-all16/64/127 ratios0.97288/0.98035/0.98791 have10/11/9 negatives.",
            "Projection accounted totals16/64/127 are1.08651/1.10267/1.14054 with6/2/4 negative pairs.128 accounted0.88652 has9 negatives. Startup and ingestion outliers remain fully included: e.g.128 create-and-insert ratio range0.0692..5.1247 and accounted range0.3432..1.5834. These are sums of measured engine/transport timers, excluding untimed host oracles; not full wall-clock lifecycle.",
            "Spill compound query batches1.00713/1.00873 mostly improve, but full measured lifecycle0.96651 has9 negatives, ingest0.94482 has9, index-build0.97622 has10 and restart0.89208 has13. High-hit spill batches1.00407/1.00177 and lifecycle1.00064 are approximately neutral, while its first pre-restart query0.98481 has11 negatives across all seed/order medians. No spill loss is removed as unrelated noise.",
            "Resource mechanisms:16/64/127 large4096 CPU proxy medians120 to100ms,320 to260ms,450 to360ms, lower in every pair; wide-all medians130 to110ms,360 to320ms,510 to420ms. Wide-all CPU decreases in13/15 for16 and15/15 for64/127; the two negative16 CPU observations remain. HWM decreases in every eligible bulk-output pair; wide-all medians36601856 to35643392,38887424 to35676160,46964736 to45760512 bytes. RSS need not decrease with HWM.",
            "All reported query/projection IO delta counters remain paired-equal, including temporary-sort write/cancelled-write bytes. This is not an IO-byte reduction.128/768 CPU ticks and memory are near equal at their measurement resolution, insufficient to dismiss their consistent sub-percent wall-time losses.",
            "Resource scope: process100Hz CPU ticks, floating subtraction ties, cumulative HWM and instantaneous RSS; no cgroup memory/CPU/IO quotas were imposed by this192 driver. Projection resource intervals include untimed oracle gaps and restart intervals include verification probes. Zero CPU delta is resolution-limited, not no work.",
            "No cross-run claim that the loop fixed the previous4% regression or that outlined calls explain every loss. Machine-code analysis is separate evidence; this decision relies on the actual paired observations and the user's requirement to preserve original paths.",
            "The user reports a lower official score and no Prompt credit for an afternoon submission. Its exact submission identity, numeric score and failure details are not established by this benchmark. Even a locally positive candidate would require that identity check and small-resource representative validation before any adoption. No additional guard experiment or formal submission is recommended here."
        ],
        "statistics_limits": ["B/C below1 means candidate slower. Medians of paired ratios differ from ratios of displayed duration medians.",
                              "All negative pairs, first requests, AB/BA differences and stalls retained in the complete derived report.",
                              "Three fixed seeds times five process pairs are not15 independent datasets. Six AA pairs use the same baseline binary, not independently trained PGO builds.",
                              "No AA normalization, new significance test, pooled score, default change or experiment launch.",
                              "Prose ratios are rounded; structured exact values and original raw measurements are authoritative."],
        "selected_metrics": chosen,
    }
    output = HERE / "bulk-loop-adoption-assessment.json"
    with output.open("x", encoding="utf8", newline="\n") as stream:
        json.dump(report, stream, ensure_ascii=False, indent=2, allow_nan=False)
        stream.write("\n")
    print(json.dumps({"output": str(output), "bytes": output.stat().st_size, "sha256": sha(output)}))


if __name__ == "__main__":
    main()
