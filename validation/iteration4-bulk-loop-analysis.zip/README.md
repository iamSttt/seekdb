# Explicit-loop C3: immutable evidence, default OFF

Source c3d421ed0c1f92deaef65cf2a8d28aaa9d477042, run43419207297,
performance job131864668030. The original192 raw ZIP is separate at
validation/iteration4-bulk-loop-raw.zip,49685962 bytes, SHA256
88e4a73af9d333b08a6db817a78c7cb06357fcfddc05eee1b31c2a065aebfef2.
It has188 files/241004106 uncompressed bytes. Each member and the raw manifest
were checked against the frozen independent audit; no samples were rewritten.

Read bulk-loop-analysis.json for the full independent source/profile/binary/
oracle audit; bulk-loop-evaluation.json for the derived phase/resource analysis;
bulk-loop-adoption-assessment.json for assistant interpretation. Its generator
create_bulk_loop_assessment.py selects exact fields and adds authored prose;
it is not another source verifier. The frozen15 reader and12 producer fixture
records are historical static evidence, not newly executed Linux tests.

The experiment has150 candidate pairs and42 identical-baseline A/A pairs,
8 actual-binary gates,108 UTF8 cases and3 diagnostic/sanitizer gates. Large
16/64/127 outputs improve, but128/768 preservation and many64 distance cases
retain consistent negatives. Bulk remains OFF and this guard series closes.
All first/warm/restart queries, negative pairs, startup and ingestion pauses,
resource observations and order/seed differences remain. No AA normalization,
outlier deletion, official score forecast, Prompt claim or formal submission.

The included root validation ZIP/proof is a separate four-flag correctness job:
16 gates/54 UTF8 cases. Its CI-recorded binary SHA acddca115ab183bfc6419e27c9e3383cfd1a9046e3897e5ea516cd7bc0f29f54
matches the measured baseline and retained E/311 bytes, not five-flag candidate
97e4dbe8e5cc57f17268b2b08150d3913289e1aecbf4e88289c8aa32efd8e743.
The root artifact does not contain the executable for a new local hash. This
historical byte identity does not identify the user's official submission.

Codegen JSON/scripts/notes verify the predicate helper calls disappeared, but
also show changed scan/heap code generation. They do not prove a pure two-call
performance effect. Reproduction needs capstone5.0.3/pyelftools0.32 and both raw
directories: performance/bulk-loop-c3d421e and performance/bulk-guard-85cded3.
The old guard ZIP is referenced by hash, not modified or duplicated here.

To re-audit, unpack evidence in a separate writable directory, retain the full
Git repository including C3 and E, and run (new output paths only):
python -B analyze_bulk_guard.py --input RAW --source-repo REPO --candidate-commit c3d421ed0c1f92deaef65cf2a8d28aaa9d477042 --output NEW_AUDIT.json
python -B evaluate_bulk_guard_192.py --artifact RAW --analysis NEW_AUDIT.json --candidate-commit c3d421ed0c1f92deaef65cf2a8d28aaa9d477042 --output NEW_EVALUATION.json
The fixture scripts and archive/condensation tools are included; fixture tests
were not rerun just for packaging. seekdb/ is an immutable dependency snapshot,
not a full checkout. Root/codegen scripts retain their original work-layout
expectations. Source-only static hashes may reflect Windows CRLF, whereas
actual source proofs use committed Git blob bytes.

Process CPU has coarse ticks; HWM is cumulative and RSS a point sample. Resource
intervals include host-oracle gaps or restart probes, and no cgroup/official
resource equivalence is asserted. Archive creation changes only three new
validation files, not source/defaults/conversation/docs. archive-manifest.json
hashes every other member; the final external results JSON records this ZIP's
own hash and every measured phase. There is no circular self-hash dependency.
