"""C3 exact phase condensation; no execution, adoption or negative-sample removal."""
import argparse
import hashlib
import json
from pathlib import Path

COMMIT = 'c3d421ed0c1f92deaef65cf2a8d28aaa9d477042'


def build(analysis, evaluation, root_proof, raw_ref, analysis_ref):
    assert analysis['status'] == 'verified' and analysis['candidate_commit'] == COMMIT
    assert evaluation['status'] == 'derived_from_verified_inputs' and evaluation['candidate_commit'] == COMMIT
    assert analysis['verified_pairs'] == evaluation['verified_pairs'] == 192
    assert root_proof['runtime_commit'] == COMMIT and root_proof['status'] == 'verified'
    groups = {}
    for name, group in analysis['groups'].items():
        metrics = {}
        for phase, item in group['timings'].items():
            metrics[phase] = {
                'pairs': item['pairs'], 'baseline_seconds': item['baseline'], 'candidate_seconds': item['candidate'],
                'paired_baseline_over_candidate': item['baseline_over_candidate'],
                'slower_candidate_pairs': item['candidate_value_larger_pairs'],
                'seed_ratios': {k: v['baseline_over_candidate'] for k, v in item['by_seed'].items()},
                'order_ratios': {k: v['baseline_over_candidate'] for k, v in item['by_order'].items()},
                'negative_pairs': item['negative_pairs'],
            }
        resources = evaluation['groups'][name]['resources']
        resource_summary = {}
        for phase, observation in resources['phases'].items():
            measured = {}
            for key, item in observation['metrics'].items():
                if 'unavailable' in item:
                    measured[key] = item
                else:
                    measured[key] = {k: item[k] for k in ('unit', 'pairs', 'baseline', 'candidate',
                        'baseline_over_candidate', 'candidate_larger_pairs', 'candidate_smaller_pairs',
                        'equal_pairs', 'undefined_ratio_pairs')}
            resource_summary[phase] = {'snapshot_pair': observation['snapshot_pair'], 'metrics': measured}
        groups[name] = {'pairs': group['pairs'], 'all_phases_including_negative': metrics,
                        'resource_aggregates': resource_summary,
                        'complete_resource_raw_pairs': 'bulk-loop-evaluation.json#/groups/' + name.replace('/', '~1') + '/resources'}
    binary = evaluation['binary_sha256']
    return {
        'status': 'measured_not_adopted_guard_series_closed', 'executed_by': 'assistant',
        'source_commit': COMMIT, 'baseline_commit': analysis['baseline_commit'],
        'run_id': 43419207297, 'job_id': 131864668030, 'pairs': 192, 'candidate_pairs': 150,
        'same_binary_control_pairs': 42, 'binary_gates_passed': 8, 'utf8_cases_passed': 108,
        'source_unit_sanitizer_gates_passed': 3, 'baseline_binary_sha256': binary['baseline'],
        'candidate_binary_sha256': binary['bulk'], 'default_enabled': False, 'official_score': None,
        'automatic_submission': False, 'new_ci_started_by_archiving': False,
        'raw_artifact': raw_ref, 'analysis_archive': analysis_ref,
        'decision': [
            'Keep MVDB_TYPED_BULK_VECTOR_ONLY off. End this guard experiment series; preserve the verified four-default-feature behavior pending official-submission identity and a separate small-resource screen.',
            'The16/64/127-dimensional bulk outputs improve, but original128/768-dimensional output paths and many64 distance projections retain directional regressions. Positive cases do not cancel negative cases.',
            '30k is approximately neutral in this run. No cross-run claim that the loop alone fixed earlier losses: its actual PGO scan layout and outlined heap helper also changed.',
            'No more guard experiment or five-flag actual-root bridge is enabled by these results. No formal submission, official-score or Prompt-pass claim.',
        ],
        'root_default_proof': {
            'run_id': root_proof['run_id'], 'job_id': root_proof['job_id'], 'checks': root_proof['checks'],
            'actual_image_utf8_checks': root_proof['actual_image_utf8_checks'],
            'image_id': root_proof['image_id'], 'image_binary_sha256': root_proof['image_binary_sha256'],
            'default_flags': root_proof['default_flags'], 'experimental_bulk_macro_enabled': False,
            'recorded_root_binary_sha_matches_measured_baseline': root_proof['image_binary_sha256'] == binary['baseline'],
            'recorded_root_binary_sha_matches_measured_candidate': root_proof['image_binary_sha256'] == binary['bulk'],
            'scope': 'The root correctness job records the same executable SHA as the retained E/311 baseline. This is historical byte identity, not new five-flag performance or official submission identity. Its small artifact does not contain the executable for a new local hash.',
        },
        'groups': groups,
        'limitations': analysis['limitations'] + [
            'Every measured phase, negative pair, seed and order remains in this condensation; complete per-request values and resource observations are in the raw and analysis archives.',
            'Projection accounted sums exclude untimed host parsing/oracles/snapshots; startup includes process/reader creation and ready receipt, not isolated database CPU.',
            'Process CPU has100Hz tick granularity and floating subtraction ties. HWM is cumulative and RSS instantaneous; no official cgroup resource equality or physical disk throughput is established.',
            'The user reported a lower score and no Prompt credit for an afternoon submission, but this archive does not verify that submission commit, image/binary or numeric score.',
        ],
    }


def main():
    p = argparse.ArgumentParser(description=__doc__)
    for key in ('analysis', 'evaluation', 'root-proof', 'raw-reference', 'analysis-reference', 'output'):
        p.add_argument('--' + key, type=Path, required=True)
    args = p.parse_args()
    read = lambda path: json.loads(path.read_bytes())
    result = build(read(args.analysis), read(args.evaluation), read(args.root_proof),
                   read(args.raw_reference), read(args.analysis_reference))
    with args.output.open('x', encoding='utf8', newline='\n') as stream:
        json.dump(result, stream, ensure_ascii=False, indent=2, allow_nan=False); stream.write('\n')
    print(json.dumps({'output': str(args.output), 'bytes': args.output.stat().st_size,
                      'sha256': hashlib.sha256(args.output.read_bytes()).hexdigest()}))


if __name__ == '__main__':
    main()
