#!/usr/bin/env python3
"""Read-only phase/resource interpretation after the independent 192-pair audit.

This is a derived report, not a second source/profile/oracle verifier. It binds
the exact raw files to that audit, then independently recomputes all paired
statistics. It neither executes a benchmark nor changes an adoption decision.
"""
import argparse
from collections import defaultdict
from fractions import Fraction
import hashlib
import json
import math
from pathlib import Path, PurePosixPath
import re
from statistics import median

BASELINE = "e020fdeb67dd8b64b77f0f8c2905f137f0112bba"
SEEDS = (7319, 8911, 13337)
CASES = ("standard10k", "resident30k", "filter60k", "many16", "spill_compound",
         "spill_high", "wide128", "wide768", "many64", "many127")
AA_CASES = {"resident30k", "filter60k", "many16", "many64", "many127", "wide128", "wide768"}
PROJECTIONS = {"many16", "many64", "many127", "wide128", "wide768"}
LABELS = ("narrow_top10", "wide_top10", "narrow_large4096", "wide_large4096",
          "narrow_all", "wide_all", "wide_distance10")
RESOURCE_LABELS = ("wide_large4096", "wide_all", "wide_distance10")
IO_KEYS = ("rchar", "wchar", "syscr", "syscw", "read_bytes", "write_bytes", "cancelled_write_bytes")


def require(value, message):
    if not value:
        raise ValueError(message)


def sha(path):
    value = hashlib.sha256()
    with path.open("rb") as stream:
        for block in iter(lambda: stream.read(1024 * 1024), b""):
            value.update(block)
    return value.hexdigest()


def read(path):
    def unique(items):
        result = {}
        for key, value in items:
            require(key not in result, "duplicate JSON key")
            result[key] = value
        return result
    def invalid(value):
        raise ValueError("nonfinite JSON number: " + value)
    return json.loads(path.read_bytes(), object_pairs_hook=unique, parse_constant=invalid)


def number(value, positive=False):
    require(type(value) in (int, float) and math.isfinite(value) and
            (value > 0 if positive else value >= 0), "invalid numeric observation")
    return value


def statistics(values):
    require(values, "empty statistic")
    result = {"samples": len(values), "min": min(values), "max": max(values)}
    if all(type(v) is int for v in values):
        ordered = sorted(values); middle = len(values) // 2
        exact = Fraction(ordered[middle]) if len(values) % 2 else Fraction(ordered[middle - 1] + ordered[middle], 2)
        result["median"] = exact.numerator if exact.denominator == 1 else (float(exact) if abs(exact.numerator) <= 2 ** 53 else None)
        if exact.denominator != 1:
            result["median_exact_fraction"] = {"numerator": exact.numerator, "denominator": exact.denominator}
    else:
        result["median"] = median(values)
    return result


def identity(pair):
    return {key: pair[key] for key in ("scenario", "seed", "pair_index", "order")}


def aggregate(rows):
    ratios = [r["baseline_over_candidate"] for r in rows if r["baseline_over_candidate"] is not None]
    return {"pairs": len(rows), "baseline": statistics([r["baseline"] for r in rows]),
            "candidate": statistics([r["candidate"] for r in rows]),
            "baseline_over_candidate": statistics(ratios) if ratios else None,
            "candidate_larger_pairs": sum(r["candidate"] > r["baseline"] for r in rows),
            "candidate_smaller_pairs": sum(r["candidate"] < r["baseline"] for r in rows),
            "equal_pairs": sum(r["candidate"] == r["baseline"] for r in rows),
            "undefined_ratio_pairs": sum(r["candidate"] == 0 for r in rows)}


def metric(pairs, getter, unit):
    rows = []
    for pair in pairs:
        b, c = [number(getter(pair[side])) for side in ("baseline", "candidate")]
        rows.append({**identity(pair), "baseline": b, "candidate": c,
                     "baseline_over_candidate": b / c if c else None})
    return {"unit": unit, **aggregate(rows),
            "by_seed": {str(seed): aggregate([r for r in rows if r["seed"] == seed]) for seed in SEEDS},
            "by_order": {order: aggregate([r for r in rows if r["order"][0] == first])
                         for order, first in (("AB", "baseline"), ("BA", "candidate"))},
            "candidate_larger_pair_ids": [identity(r) for r in rows if r["candidate"] > r["baseline"]],
            "raw_pairs": rows}


def planned():
    result = []
    for case_index, case in enumerate(CASES):
        for seed_index, seed in enumerate(SEEDS):
            for index in range(5):
                contrasts = ("bulk", "aa") if (case_index + seed_index + index) % 2 == 0 else ("aa", "bulk")
                for role in contrasts:
                    if role == "aa" and (case not in AA_CASES or index >= 2):
                        continue
                    order = ["baseline", "candidate"]
                    if (case_index + seed_index + index + (role == "aa")) % 2:
                        order.reverse()
                    result.append({"scenario": case, "seed": seed, "pair_index": index,
                                   "contrast": role, "order": order,
                                   "query_threads": 2 if case in ("standard10k", "resident30k") else 1})
    require(len(result) == 192, "internal 192 plan error")
    return result


def bind_inputs(root, audit_path, candidate):
    require(re.fullmatch("[0-9a-f]{40}", candidate or ""), "full expected candidate SHA required")
    audit = read(audit_path)
    require(audit["status"] == "verified" and audit["kind"] == "bulk_guard_192_readonly_audit" and
            audit["verified_pairs"] == 192 and audit["candidate_commit"] == candidate and
            audit["baseline_commit"] == BASELINE, "independent audit is incomplete or for different source")
    require(sha(root / "hashes.json") == audit["artifact_manifest_sha256"], "artifact/audit manifest differs")
    manifest = read(root / "hashes.json"); entries = {}
    for item in manifest["artifacts"]:
        name = item["path"]; relative = PurePosixPath(name)
        require(type(name) is str and name not in entries and not relative.is_absolute() and
                relative.as_posix() == name and not any(p in (".", "..") for p in relative.parts) and
                "\\" not in name and ":" not in name, "invalid/duplicate manifest name")
        entries[name] = item
    verified = audit["artifact_files_verified"]
    data = {}
    for name in ("measurements.json", "context.json", "summary.json", "run-status.json"):
        path = root / name; item = entries[name]
        require(path.stat().st_size == item["bytes"] and sha(path) == item["sha256"] == verified[name],
                "derived input changed after independent audit: " + name)
        data[name] = read(path)
    raw, context, summary, status = [data[n + ".json"] for n in ("measurements", "context", "summary", "run-status")]
    require(summary["status"] == status["proof_status"] == raw["status"] == "passed" and
            summary["verified_total_pairs"] == 192 and summary["per_candidate_pairs"] == 150 and
            summary["identical_baseline_aa_pairs"] == 42 and summary["exit_code"] == status["exit_code"] == 0,
            "CI summary/status incomplete")
    require(raw["candidate_commit"] == context["candidate_commit"] == candidate and
            raw["baseline_commit"] == context["baseline_commit"] == BASELINE and
            raw["build_context_sha256"] == entries["context.json"]["sha256"] and raw["binary_unchanged"] is True,
            "measurement/context binding differs")
    require(context["profile_source_proof"] == audit["profile_source_proof"], "audited profile proof changed")
    require(raw["plan"] == planned() and len(raw["pairs"]) == 192, "raw plan differs")
    for pair, expected in zip(raw["pairs"], planned()):
        require(type(pair["seed"]) is int and type(pair["pair_index"]) is int and
                all(pair[k] == v for k, v in expected.items()), "pair identity/order differs")
        role = "baseline" if pair["contrast"] == "aa" else "bulk"
        for side, actual_role in (("baseline", "baseline"), ("candidate", role)):
            require(pair["binary_sha256"][side] == raw["binaries"][actual_role]["sha256"] ==
                    context["profile_source_proof"][actual_role]["binary_sha256"] and
                    pair["binary_paths"][side] == raw["binaries"][actual_role]["path"], "candidate/AA binary differs")
    return raw, audit, entries


def timing_map(run, scenario):
    if scenario in PROJECTIONS:
        require(set(run["phases"]) == set(LABELS), "projection phases incomplete")
        result = {"lifecycle/" + k: number(v, True) for k, v in run["lifecycle_seconds"].items()}
        for label in LABELS:
            phase = run["phases"][label]; values = [number(s["seconds"], True) for s in phase["requests"]]
            require(len(values) == 3 and math.isclose(math.fsum(values), phase["wall_seconds"], rel_tol=1e-12, abs_tol=1e-12), "projection sample sum differs")
            result[label + "/all_three"] = math.fsum(values)
            result[label + "/first"] = values[0]
            result[label + "/remaining_two"] = math.fsum(values[1:])
        result["all_seven_query_timers"] = math.fsum(run["phases"][label]["wall_seconds"] for label in LABELS)
        result["accounted_timer_sum"] = result["all_seven_query_timers"] + math.fsum(run["lifecycle_seconds"].values())
        return result
    result = {"lifecycle/" + k: number(v, True) for k, v in run["phase_seconds"].items()}
    count = 64 if scenario.startswith("spill_") else 1000
    require(set(run["query"]) == {"query_before_update", "query_after_restart"}, "query phases incomplete")
    for phase, query in run["query"].items():
        values = [number(v, True) for v in query["per_request_seconds"]]
        require(len(values) == count and math.isclose(math.fsum(values), run["phase_seconds"][phase], rel_tol=1e-12, abs_tol=1e-12), "query count/sum differs")
        for suffix, part in (("all_requests", values), ("first", values[:1]), ("front64", values[:64]),
                             ("after_first_front64", values[1:64]), ("after64", values[64:])):
            if part:
                result[phase + "/" + suffix] = math.fsum(part)
        if scenario == "standard10k":
            result[phase + "/unfiltered_exact_all"] = math.fsum(values[::2])
            result[phase + "/single_filter_ann_all"] = math.fsum(values[1::2])
    return result


def resources(pairs, projected):
    phases = RESOURCE_LABELS if projected else ("query_before_update", "query_after_restart")
    runs = [p[s] for p in pairs for s in ("baseline", "candidate")]
    maps = {}
    for run in runs:
        snapshots = run["policy_evidence"]["task_snapshots"] if projected else run["resource_snapshots"]
        indexed = {s["phase"]: s for s in snapshots}
        require(len(indexed) == len(snapshots), "duplicate resource phase")
        maps[id(run)] = indexed
    result = {"scope": "Process proxies, not cgroup/device I/O scores. HWM is cumulative within a process, RSS is a point observation. CPU uses coarse /proc ticks; zero delta does not mean zero work.", "phases": {}}
    for phase in phases:
        before_name = phase + "/before" if projected else ("after_index_build" if phase == "query_before_update" else "after_restart")
        after_name = phase + "/after" if projected else phase
        def field(run, endpoint, family, key):
            snap = maps[id(run)].get(before_name if endpoint == "before" else after_name, {})
            return snap.get(family, {}).get(key) if family else snap.get(key)
        output = {"snapshot_pair": [before_name, after_name], "metrics": {}}
        result["phases"][phase] = output
        if projected:
            output["scope"] = "Snapshots surround all three requests and their untimed host oracle gaps. They are not isolated request timers and may include other process work."
        elif phase == "query_after_restart":
            output["scope"] = "The snapshot interval also includes restart verification/startup probes; it is not isolated query CPU or I/O."
        specifications = [("after_hwm_bytes", "bytes", "process_memory_proxy", "VmHWM_bytes", False),
                          ("after_rss_bytes", "bytes", "process_memory_proxy", "VmRSS_bytes", False),
                          ("cpu_delta_seconds", "seconds", None, "process_cpu_seconds", True)]
        specifications += [("io_delta/" + key, "count" if key in ("syscr", "syscw") else "bytes", "process_io_counters_proxy", key, True) for key in IO_KEYS]
        for name, unit, family, key, delta in specifications:
            values = {}
            for run in runs:
                after = field(run, "after", family, key)
                before = field(run, "before", family, key) if delta else 0
                if after is None or before is None:
                    break
                number(after); number(before)
                values[id(run)] = number(after - before)
            if len(values) != len(runs):
                output["metrics"][name] = {"unavailable": "not present for every pair; no partial aggregate"}
            else:
                output["metrics"][name] = metric(pairs, lambda run, v=values: v[id(run)], unit)
        clocks = sorted({maps[id(run)][after_name]["clock_ticks_per_second"] for run in runs
                         if after_name in maps[id(run)] and "clock_ticks_per_second" in maps[id(run)][after_name]})
        output["observed_clock_ticks_per_second"] = clocks
    return result


def evaluate(root, audit_path, candidate):
    raw, audit, entries = bind_inputs(root, audit_path, candidate)
    grouped = defaultdict(list)
    for pair in raw["pairs"]:
        grouped[pair["contrast"] + "/" + pair["scenario"]].append(pair)
    expected_groups = {"bulk/" + s for s in CASES} | {"aa/" + s for s in AA_CASES}
    require(set(grouped) == expected_groups, "missing group")
    groups = {}
    for key, pairs in grouped.items():
        role, scenario = key.split("/")
        require(len(pairs) == (6 if role == "aa" else 15), "group sample count differs")
        maps = {id(run): timing_map(run, scenario) for p in pairs for run in (p["baseline"], p["candidate"])}
        keys = set(next(iter(maps.values())))
        require(all(set(v) == keys for v in maps.values()), "paired timing inventory differs")
        groups[key] = {"pairs": len(pairs), "sample_scope": "Three fixed seeds; repeated processes within each seed are not new independent datasets.",
            "timings": {name: metric(pairs, lambda run, n=name: maps[id(run)][n], "seconds") for name in sorted(keys)},
            "resources": resources(pairs, scenario in PROJECTIONS)}
    for key, group in groups.items():
        role, scenario = key.split("/")
        if role != "bulk" or scenario not in AA_CASES:
            continue
        control = groups["aa/" + scenario]
        group["aa_context"] = {"group": "aa/" + scenario, "pairs": 6,
            "scope": "Observed same-binary process/host variation only. No normalization, rejection of negative samples, or PGO-build-variance claim.",
            "timings": {name: {"candidate_median_ratio": item["baseline_over_candidate"]["median"],
                "aa_ratio": control["timings"][name]["baseline_over_candidate"]} for name, item in group["timings"].items()}}
    return {"status": "derived_from_verified_inputs", "kind": "bulk_guard_192_phase_resource_evaluation",
        "candidate_commit": candidate, "baseline_commit": BASELINE, "verified_pairs": 192,
        "candidate_pairs": 150, "identical_binary_aa_pairs": 42, "automatic_adoption": False, "official_score": None,
        "binary_sha256": {role: raw["binaries"][role]["sha256"] for role in ("baseline", "bulk")},
        "earlier_delivery_binary_comparison": audit.get("earlier_delivery_binary_comparison"),
        "evidence": {"artifact": str(root.resolve()), "independent_analysis": str(audit_path.resolve()),
            "independent_analysis_sha256": sha(audit_path), "manifest_sha256": audit["artifact_manifest_sha256"],
            "measurements_sha256": entries["measurements.json"]["sha256"], "context_sha256": entries["context.json"]["sha256"],
            "evaluation_tool_sha256": sha(Path(__file__))},
        "interpretation": ["For timings B/C<1 means candidate slower. For resource counters candidate_larger means larger, not automatically worse.",
            "Every raw paired value, seed/order subgroup, and negative pair remains. No outliers or first requests are discarded.",
            "front64 includes the first request; after64 contains936 queries for standard/resident/filter and is absent for64-query spill cases.",
            "Projection all_seven_query_timers and accounted_timer_sum are sums of timers, not total end-to-end wall time. Oracle/parsing/snapshot time is excluded.",
            "The independent input audit owns full Git/source/profile/artifact validation. This derived report rechecks input binding and recomputes phase/resource statistics, not all file hashes or SQL oracles.",
            "No new bootstrap, population significance, pooled cross-scenario speedup, switch change, or formal submission is produced."],
        "groups": groups}


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--artifact", type=Path, required=True)
    parser.add_argument("--analysis", type=Path, required=True)
    parser.add_argument("--candidate-commit", required=True)
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args()
    require(not args.output.exists(), "refusing to overwrite a report")
    require(not args.output.resolve().is_relative_to(args.artifact.resolve()), "output must not alter the raw artifact")
    result = evaluate(args.artifact.resolve(), args.analysis.resolve(), args.candidate_commit)
    with args.output.open("x", encoding="utf-8", newline="\n") as stream:
        json.dump(result, stream, ensure_ascii=False, indent=2, allow_nan=False); stream.write("\n")
    print(json.dumps({"status": result["status"], "pairs": 192, "groups": len(result["groups"]), "output": str(args.output.resolve())}))


if __name__ == "__main__":
    main()
