"""Read-only descriptive query-policy strata; no new DB or build execution."""
import json,math,re,hashlib
from pathlib import Path
from statistics import median
import analyze_crc_root as core

W=Path(__file__).resolve().parent
inputs={
 'matched':('matched-insert-6d2c433','40d79384e07229ea2f72de3c0776fba489a737ee8f925fe49c5f09d5efc1a79b',
            'matched-insert-independent-analysis.json','44fb8c46ac14fd8ba6c6b870f1656da1ae9509c4153f51c6aeac6e763b0115e6'),
 'control':('insert-thread-control-33a52a7','22b44f025aebf40c7fd62bfe0571c6982fe98f80ea8ac4384ac10141558740cc',
            'insert-thread-control-independent-analysis.json','d0ef2df93984fbd8d56f62b51cb4f3561510a14b5cec13834a3e76809458d76f')}

def source(name,member):
 stem,archive_sha,analysis,analysis_sha=inputs[name]
 assert core.sha(W/'performance'/(stem+'.zip'))==archive_sha
 assert core.sha(W/analysis)==analysis_sha
 directory=W/'performance'/stem
 manifest=core.read(directory/'hashes.json')
 record=next(x for x in manifest['artifacts'] if x['path']==member)
 path=directory/member
 assert path.stat().st_size==record['bytes'] and core.sha(path)==record['sha256']
 return core.read(path)

def policy(run):
 lines=run['thread_policy_observations']['fanout_log_lines']
 assert run['thread_policy_observations']['stderr_complete']
 if run['effective_environment'].get('MVDB_QUERY_THREADS')=='1':
  assert not lines and run['effective_environment']['MVDB_PARSE_THREADS']=='1'
  return [{'wake_us':None,'unfiltered_selected_threads':1,'source':'explicit PARSE=QUERY=1, actual ready environment checked'}]*2
 assert run['effective_environment']=={}
 sessions=[]
 for line in lines:
  if 'median of 200 handshakes' in line:
   sessions.append({'wake_us':float(re.search(r'wake_us=([0-9.]+)',line).group(1)),
                    'decisions':[],'source':'complete stderr, cached startup wake, first four eligible decisions'})
  else:
   match=re.fullmatch(r'mvdb: fanout rows=10000 scan=100.0us wake=([0-9.]+)us predicted_gain=([-0-9.]+)us -> ([12]) threads?',line)
   assert match and sessions
   assert float(match.group(1))==sessions[-1]['wake_us']
   sessions[-1]['decisions'].append(int(match.group(3)))
 assert len(sessions)==2
 for session in sessions:
  assert len(session['decisions'])==4 and len(set(session['decisions']))==1
  session['unfiltered_selected_threads']=session.pop('decisions')[0]
 return sessions

def phase(run,name,index):
 samples=run['query'][name]['per_request_seconds'];assert len(samples)==1000
 phases={p['phase']:p for p in run['adapter']['phase_cgroups']}
 start='after_index_build' if index==0 else 'after_restart'
 before,after=[core.counters(phases[n]['cpu.stat']) for n in (start,name)]
 old={(t['tid'],t['starttime_ticks']):t['cpu_ticks'] for t in phases[start]['native_tasks']}
 ticks=sum(t['cpu_ticks']-old.get((t['tid'],t['starttime_ticks']),0) for t in phases[name]['native_tasks'] if not t['main'])
 return {'policy':policy(run)[index],
   'metrics':{'all_1000_wall_seconds':math.fsum(samples),'first_query_wall_seconds':samples[0],
    'tail_999_wall_seconds':math.fsum(samples[1:]),'after64_936_wall_seconds':math.fsum(samples[64:]),
    'unfiltered_tail_499_wall_seconds':math.fsum(samples[2::2]),'filtered_500_wall_seconds':math.fsum(samples[1::2]),
    'query_interval_cpu_usec':after['usage_usec']-before['usage_usec'],
    'query_interval_user_usec':after['user_usec']-before['user_usec'],
    'query_interval_system_usec':after['system_usec']-before['system_usec']},
   'nonmain_cpu_ticks_delta':ticks,'first_query_cpu_usec':None,'tail_query_cpu_usec':None,
   'cpu_scope':'Query-phase aggregate only; restart phase also includes ID/vector recovery verification.' if index else 'Query-phase aggregate only; no per-request CPU sampling.'}

def summary(rows):
 out={'pair_count':len(rows),'pair_indices':[r['pair_index'] for r in rows],'metrics':{}}
 for metric in rows[0]['baseline']['metrics']:
  b=[r['baseline']['metrics'][metric] for r in rows];c=[r['candidate']['metrics'][metric] for r in rows]
  ratios=[cv/bv for bv,cv in zip(b,c)]
  out['metrics'][metric]={'candidate_over_baseline_median':median(ratios),
   'candidate_larger_pairs':sum(cv>bv for bv,cv in zip(b,c)),'raw_paired_ratios':ratios,
   'baseline_absolute':b,'candidate_absolute':c,
   'leave_one_pair_out_medians':([median(ratios[:i]+ratios[i+1:]) for i in range(len(ratios))] if len(rows)>1 else None),
   'summed_candidate_over_summed_baseline':math.fsum(c)/math.fsum(b)}
 return out

def group(data,policy_name=None):
 pairs=[p for p in data['pairs'] if policy_name is None or p['policy']==policy_name]
 out={}
 for index,name in enumerate(('query_before_update','query_after_restart')):
  rows=[];strata={}
  for pair in pairs:
   row={k:pair[k] for k in ('pair_index','order')}
   for role in ('baseline','candidate'):row[role]=phase(pair[role],name,index)
   sides=[row[s]['policy']['unfiltered_selected_threads'] for s in ('baseline','candidate')]
   row['policy_stratum']='R'+str(sides[0])+'_N'+str(sides[1]);rows.append(row)
   strata.setdefault(row['policy_stratum'],[]).append(row)
  out[name]={'all_pairs':summary(rows),'descriptive_strata':{k:summary(v) for k,v in strata.items()},'raw_pairs':rows}
 return out

matched={str(c):group(source('matched',f'measurements-{c}cpu.json')) for c in (1,2)}
control=source('control','measurements.json')
result={'status':'descriptive_analysis_of_verified_artifacts','inputs':inputs,'matched':matched,
 'prior_control':{p:group(control,p) for p in ('default','single')},
 'limitations':[
 'All pairs remain in the primary results. Same-policy strata and leave-one-pair-out summaries are sensitivity descriptions, not replacement samples or significance tests.',
 'The workload alternates 500 unfiltered and 500 filtered queries. Logged fanout applies only to eligible unfiltered scans; filtered queries are serial. Four decisions are logged per startup. Fixed rows/cached wake and unchanged query code imply a constant policy within each phase; not 1000 individual thread traces.',
 'CPU is sampled only at phase boundaries. No first-query CPU, tail CPU or per-query CPU can be recovered. Restart CPU additionally includes recovery verification.',
 'The 999-query and after64 tails are fixed descriptive slices, not proofs of steady state. First request index 0 is a planted-vector/tie query.',
 'Historical thread control changes PARSE_THREADS and QUERY_THREADS together and suppresses query startup calibration. It cannot isolate query calibration alone.',
 'Prior control uses old N1/5606; matched uses new N2/07da on another host. Cross-run ratios cannot be used as a causal estimate or combined sample.',
 'Runtime/default source has not been changed; no new DB, build, CI or formal submission occurred in this analysis.']}
target=W/'matched-query-policy-strata.json';assert not target.exists()
target.write_text(json.dumps(result,ensure_ascii=False,indent=2)+'\n',encoding='utf8')
print(json.dumps({'output':str(target),'bytes':target.stat().st_size,'sha256':core.sha(target)}))
for cpu,phases in matched.items():
 for name,phase_data in phases.items():
  print('MATCHED',cpu,name)
  for key,s in {'ALL':phase_data['all_pairs'],**phase_data['descriptive_strata']}.items():
   print(key,s['pair_count'],{k:(round(v['candidate_over_baseline_median'],5),v['candidate_larger_pairs'],v['leave_one_pair_out_medians']) for k,v in s['metrics'].items() if k in ('all_1000_wall_seconds','first_query_wall_seconds','tail_999_wall_seconds','query_interval_cpu_usec')})
