"""Render verified descriptive facts; no DB/CI operation."""
import json
from pathlib import Path
import analyze_crc_root as c
w=Path(__file__).resolve().parent
d=c.read(w/'matched-query-policy-strata.json')
repo=w/'seekdb'
sources=('33a52a7dd4426af059ec2334b7c93a07c38c93c9','7554753868330006270cf39b1d32108f0a40ccac')
for name in ('query_pool.h','query_cost.h'):
 assert c.blob(repo,sources[0],'minivec/src/'+name)==c.blob(repo,sources[1],'minivec/src/'+name)
lines=['# INSERT matched 结果：查询分流诊断','',
'建议：保留 R 默认，预先限定最多一次独立 matched 复验。现有 1 CPU 同分流收益足以支持复验，尚不足以采用；立即修改线程校准会混入新变量，也无法解释全部结果。若复验未能同时保住默认全周期和写入/重启指标，停止 INSERT 分支，之后再独立研究校准。', '',
'这不是新的性能实验。所有数值来自已完整审核的 6d2c433 matched 8 对和 33a52a7 thread-control 8 对。两个来源分别汇总，不合并或交叉乘倍率。全部对子保留；分层与逐一留一对只是敏感性描述，不能替代全体结果，也不是显著性检验。', '',
'线程列指无过滤扫描选择的线程数。每阶段 1000 条查询交替包含 500 条无过滤、500 条过滤查询，后者串行。日志每次进程启动记录前四次合格扫描决策；相同候选行数、缓存 wake 和未变的 query_pool/query_cost 代码支持阶段内策略不变，但并非逐条 1000 次线程轨迹。', '',
'CPU 只有整段查询区间采样，无法给出首条或后续查询各自的 CPU。重启阶段 CPU 还包含恢复结果验证。后 999 条只是固定切片，不应宣称已经证明进入稳态。', '',
'## matched 每对实际观察','',
'| CPU / 阶段 / 对号 | wake R/N（µs） | 无过滤线程 R/N | 首条 wall R/N（ms） | 后999 wall R/N（ms） | 整段 CPU R/N（ms） |',
'|---|---:|---:|---:|---:|---:|']
for cpu,phases in d['matched'].items():
 for phase,v in phases.items():
  for row in v['raw_pairs']:
   b,n=row['baseline'],row['candidate'];bm,nm=b['metrics'],n['metrics']
   lines.append(f"| {cpu} / {'首段' if phase=='query_before_update' else '重启后'} / {row['pair_index']} | {b['policy']['wake_us']:.2f}/{n['policy']['wake_us']:.2f} | {b['policy']['unfiltered_selected_threads']}/{n['policy']['unfiltered_selected_threads']} | {bm['first_query_wall_seconds']*1000:.3f}/{nm['first_query_wall_seconds']*1000:.3f} | {bm['tail_999_wall_seconds']*1000:.3f}/{nm['tail_999_wall_seconds']*1000:.3f} | {bm['query_interval_cpu_usec']/1000:.3f}/{nm['query_interval_cpu_usec']/1000:.3f} |")
lines += ['', '## 分层结果与限制', '',
'以下比值均为候选/保留版，超过 1 为候选更慢。', '',
'- 1 CPU 首段四对均为 2/2 线程，无分流变化：1000 条 wall 中位 0.90565、CPU 0.93401，各 3/4 对改善。逐一留一对后，中位 wall 为 0.86647–0.94483、CPU 为 0.90028–0.96774，方向不被某一对单独决定。后 999 条 wall 为 0.90550，无过滤后 499 条为 0.91786，过滤 500 条为 0.93735；收益不只存在于首条或分流路径。',
'- 1 CPU 重启后同为 2/2：wall 中位 0.92663，但只有 2/4 对改善，逐一留一对范围 0.84190–1.01137，不能称重启收益稳定。',
'- 2 CPU 首段全部四对 wall 0.93770、CPU 0.94767；同为 1/1 的三对 wall 0.99527、CPU 0.99801，接近持平。同分流首条 wall 为 1.02550，其中 2/3 对更慢。分流不一致的第 3 对 R 为 2、N 为 1，wall 0.88012、CPU 0.56206；它不能代表一般 INSERT 效果。全部四对逐一留一对的查询 wall 仍低于 1，但跨度 0.88012–0.99527，收益量级不稳定。',
'- 2 CPU 重启后全四对 wall 1.01265，3/4 对更慢；首条 wall 1.09290，3/4 更慢。两对 R=1/N=2 的 wall 为 1.06859、CPU 1.68985，两对均负；同为 1/1 的两对 wall 一正一负。这些负面保持在全体结果中。',
'- 整段写入另有独立负面：2 CPU ingest CPU 1.01464，3/4 对增加；system CPU 1.31772，4/4 增加，而 user CPU 0.96544，4/4 减少。不能把未超过联合 2% 门槛写成“没有退化”。', '',
'## 与旧 thread-control 的关系', '',
'旧 control 的默认 1 CPU 四对同为 2/2，N1/R 查询 wall 0.99872、CPU 1.01227；双线程环境均设为 1 后同为 1/1，wall 1.00767、CPU 0.99938。重启后 wall 分别 1.03414 与 1.02980，均 3/4 对更慢。', '',
'因此，旧 N1 并没有稳定查询收益；旧 control 也不能证明立即关闭查询线程就会改善候选。它同时改变解析池和查询池，并省掉校准启动成本，无法单独归因 query calibration。N1/5606 与本轮 N2/07da 是不同 ELF、不同运行主机，不能把两个实验当同一分布。', '',
'## 校准机制的可核实问题', '',
'现行默认编译未开启 MVDB_ENABLE_WORKLOAD_FANOUT，因此使用 query_pool 的静态每行 10 ns 模型。10000 行预测扫描 100 µs，判据 50−2×wake≥15，使 wake=17.5 µs 成为切换点。双核重启后记录中的 17.14/17.38 与 17.57/18.60 已落在阈值两侧；同一组内还出现首段 0.74 µs 与其他 19.30–28.80 µs 的差异。日志和整段非主线程 ticks 与决策一致，但不能从这些结果确定校准差异由调度、构建、代码布局或 ISA 中哪一项导致。', '',
'1 CPU 默认仍选择 2 线程，是因为现行默认模式主要检查在线 CPU 数，并未在这条默认路径检查单 CPU affinity。此前直接加入 affinity 禁分流的实际版本已遭保护场景退化否决，不能借本次诊断重新默认启用。', '',
'## 一次复验应预先固定什么', '',
'1. 不改 runtime、线程环境、Docker、PGO 训练、flags 或负载；两边分别完整重建一次，使用新 ELF/镜像身份。保留 1/2 CPU 各四对、AB/BA、exact、2 GiB、swap=0，完整保留校准日志与重启。',
'2. 主结果始终是全部对子。首周期阶段计时和、重启包含总计、ingest wall+CPU、首条与查询整段同时展示；同分流分层只解释机制，不用于删掉不利样本。维持已约定的联合 wall/CPU 退化拒绝标准，并明确报告低于阈值的持续负面。',
'3. 只允许这一次验证稳定性，不重复测到出现有利结果。如果 1 CPU 同分流的方向消失，或写入/重启完整成本再次表现为一致退化，就终止该 INSERT 候选。即便方向复现，也只支持进入保护场景验证，不能直接默认采用或预测正式分。',
'4. 线程校准有独立研究价值，但应在 INSERT 决策之后另起窄实验；不要把校准修复与复制策略合并。当前观察不支持直接调整阈值以贴合这几对结果。', '',
'数据文件：matched-query-policy-strata.json（完整绝对对子、总结果、全部分层、逐一留一对）；matched-insert-independent-analysis.json（全量身份、资源和原始负面核验）。',
'诊断输入 SHA256：`'+c.sha(w/'matched-query-policy-strata.json')+'`。', '']
target=w/'matched-query-policy-diagnosis.md';assert not target.exists()
target.write_text('\n'.join(lines),encoding='utf8')
print(json.dumps({'path':str(target),'bytes':target.stat().st_size,'sha256':c.sha(target)}))
