"""Prepare immutable matched-run audit and material preview; never write the repo."""
import hashlib
import importlib.util
import io
import json
from pathlib import Path
import zipfile

BASE = '96452c7d83c798ad425c4370996e85fe3bc09c0149fbde33140ca7815f3c5fd9'
COMMIT = '6d2c4331d82073cc166c32c29f59dcf6cfaf31da'
RAW_SHA = '40d79384e07229ea2f72de3c0776fba489a737ee8f925fe49c5f09d5efc1a79b'
ANALYSIS_SHA = '44fb8c46ac14fd8ba6c6b870f1656da1ae9509c4153f51c6aeac6e763b0115e6'
DECISION_SHA = '6b78746d3ecadaa3b80d4f16536ac4522805140efefdf7594b91864fb2d52d57'
STRATA_SHA = '12b3fc9f40426712637734c246c1da6450b19c01819ea1eb417e2e668408aea9'
R2 = 'acddca115ab183bfc6419e27c9e3383cfd1a9046e3897e5ea516cd7bc0f29f54'
N2 = '07daffba3ef448636e335292e894b6af005a18d0c02307495b371435b6d9a548'
RAW_DEST = 'validation/iteration5-matched-insert-root-raw.zip'
AUDIT_DEST = 'validation/iteration5-matched-insert-root-audit.zip'

def need(condition, message):
    if not condition:
        raise ValueError(message)

def sha(data):
    return hashlib.sha256(data).hexdigest()

def encode(value):
    return (json.dumps(value, ensure_ascii=False, separators=(',', ':'), allow_nan=False) + '\n').encode('utf-8')

def pointers(value):
    result = []
    if isinstance(value, dict):
        for key, child in value.items():
            if key == 'pointer' or key.endswith('_pointer'):
                need(isinstance(child, str), 'pointer must be text')
                result.append(child)
            result.extend(pointers(child))
    elif isinstance(value, list):
        for child in value:
            result.extend(pointers(child))
    return result

def main():
    work = Path(__file__).resolve().parent
    repo = work / 'seekdb'
    raw = (repo / 'conversation.json').read_bytes()
    need(raw == (repo / 'agent/conversation.json').read_bytes(), 'material copies differ')
    need(len(raw) == 128990 and sha(raw) == BASE, 'material drift')
    old = json.loads(raw)
    need(encode(old) == raw, 'original serialization differs')
    need(len(old['experiments']) == 52 and len(old['messages']) == 127, 'inventory drift')
    users = [m for m in old['messages'] if m['role'] == 'user']
    need(len(users) == 45, 'user inventory drift')
    actual_raw = (work / 'performance/matched-insert-6d2c433.zip').read_bytes()
    need(len(actual_raw) == 2668095 and sha(actual_raw) == RAW_SHA, 'actual raw drift')
    files = {}
    for filename in (
        'analyze_matched_insert_roots.py', 'check_matched_insert_reader.py',
        'matched-insert-reader-preflight.json', 'check_matched_insert_roots.py',
        'matched-insert-roots-preflight.json', 'matched-insert-independent-analysis.json',
        'summarize_matched_insert_independent.py', 'matched-insert-independent-decision.json',
        'analyze_matched_query_strata.py', 'matched-query-policy-strata.json',
        'write_matched_query_diagnosis.py', 'matched-query-policy-diagnosis.md',
        'matched-repeat-dispatch.json',
        Path(__file__).name,
    ):
        files[filename] = (work / filename).read_bytes()
    need(sha(files['matched-insert-independent-analysis.json']) == ANALYSIS_SHA, 'analysis drift')
    need(sha(files['matched-insert-independent-decision.json']) == DECISION_SHA, 'decision drift')
    need(sha(files['matched-query-policy-strata.json']) == STRATA_SHA, 'strata drift')
    analysis = json.loads(files['matched-insert-independent-analysis.json'])
    decision = json.loads(files['matched-insert-independent-decision.json'])
    preflight = json.loads(files['matched-insert-reader-preflight.json'])
    need(analysis['status'] == 'verified' and analysis['verified_pairs'] == 8
         and analysis['new_root_pgo_builds'] == 2 and analysis['harness_commit'] == COMMIT
         and analysis['artifact_sha256'] == RAW_SHA and len(analysis['all_negative_or_mixed_metrics']) == 58,
         'independent verification differs')
    need(analysis['programs']['r2']['binary_sha256'] == R2 and analysis['programs']['n2']['binary_sha256'] == N2,
         'actual program identities differ')
    need(decision['analysis_sha256'] == ANALYSIS_SHA and decision['negative_or_mixed_metric_entries'] == 58
         and decision['decision'] == 'retain_R_pending_further_evidence_not_automatic_adoption', 'decision differs')
    need(preflight['status'] == 'passed' and preflight['check_count'] == 19
         and preflight['database_runs'] == 0 and preflight['compiler_runs'] == 0
         and preflight['reader_sha256'] == sha(files['analyze_matched_insert_roots.py']), 'preflight differs')
    need(decision['metrics']['2']['ingest_system_usec']['candidate_larger_pairs'] == 4
         and decision['metrics']['2']['ingest_cpu_usec']['candidate_larger_pairs'] == 3, 'negative evidence differs')
    manifest = {
        'schema': 'matched-result-audit-v1', 'harness_commit': COMMIT,
        'source_material': {'bytes': len(raw), 'sha256': BASE},
        'actual_raw': {'path': RAW_DEST, 'bytes': len(actual_raw), 'sha256': RAW_SHA},
        'programs': {key: {field: record[field] for field in ('label', 'source_commit', 'binary_sha256', 'image_id')}
                     for key, record in analysis['programs'].items()},
        'result': {'verified_pairs': 8, 'new_root_pgo_builds': 2, 'negative_or_mixed_metric_entries': 58,
                   'source_sanitizers_rerun': False, 'default_adopted': False, 'official_score': None},
        'preflight_scope': '19 controls are pre-execution Python checks; actual eight pairs are verified by the separately archived analysis.',
        'repeat_plan': {'new_root_pgo_builds_planned': 2, 'database_pairs_planned': 8,
                        'run_id': 43475743893, 'status': 'running_no_verified_results', 'verified_pairs': 0,
                        'configuration': 'Same workflow, sources, flags, training, workload and 1/2 CPU four-pair plan; one independent repeat only.'},
        'files': {name: {'bytes': len(data), 'sha256': sha(data)} for name, data in sorted(files.items())},
    }
    archive = io.BytesIO()
    with zipfile.ZipFile(archive, 'w', compression=zipfile.ZIP_DEFLATED, compresslevel=9) as zf:
        for name, data in sorted({**files, 'manifest.json': encode(manifest)}.items()):
            info = zipfile.ZipInfo(name, date_time=(2026, 11, 14, 0, 0, 0))
            info.compress_type = zipfile.ZIP_DEFLATED
            info.external_attr = 0o100644 << 16
            zf.writestr(info, data, compress_type=zipfile.ZIP_DEFLATED, compresslevel=9)
    audit = archive.getvalue()
    new = json.loads(raw)
    exp = new['experiments'][51]
    need(exp['id'] == 'same-runner-matched-root-pgo' and exp['status'] == 'planned_unmeasured', 'experiment 51 drift')
    exp.update(status='measured_R_retained', new_pgo_builds_executed=2, database_pairs_executed=8,
               result_message='assistant-matched-root-result', negative_or_mixed_metrics_preserved=58,
               artifacts=[{'path': RAW_DEST, 'sha256': RAW_SHA}, {'path': AUDIT_DEST, 'sha256': sha(audit)}])
    new['messages'].append({'id': 'assistant-matched-root-result', 'role': 'assistant', 'content':
        'assistant实测：新PGO2次、exact/2GiB/swap0共8对通过。R2=acdd、N2=07da，完整身份见audit。1/2CPU首周期阶段和N2/R2=0.9263/0.9724，非连续端到端。保留58项负面/混合：2CPU写入系统CPU4/4增加、总CPU3/4增加，首条/重启仍有退步；一对首次查询R2双线程/N2单线程，收益不能全归因复制。source sanitizer未重跑。R继续默认，旧N1否决不撤销，未证明正式涨分。'})
    new['messages'].append({'id': 'assistant-matched-repeat-plan', 'role': 'assistant', 'content':
        'assistant复验计划：原工作流/源码/四宏/训练/8对配置不变，仅一次独立复验，不改线程、不挑硬件反复跑。CI运行中，尚无已核验结果。采用前需跨轮稳健及保护验证；R默认，旧负面保留，不代正式提交。'})
    new['experiments'].append({'id': 'matched-root-single-repeat', 'proposed_by': 'assistant', 'executed_by': 'assistant',
        'status': 'running_no_verified_results', 'plan_message': 'assistant-matched-repeat-plan', 'run_id': 43475743893,
        'planned_root_pgo_builds': 2, 'planned_database_pairs': 8,
        'new_pgo_builds_verified': 0, 'database_pairs_verified': 0, 'default_adopted': False, 'assistant_formal_submissions': 0})
    need(new['messages'][:127] == old['messages'], 'original message changed')
    need([m for m in new['messages'] if m['role'] == 'user'] == users, 'original user changed')
    need(new['experiments'][:51] == old['experiments'][:51], 'previous experiment changed')
    for key in old:
        if key not in ('messages', 'experiments'):
            need(new[key] == old[key], key + ' changed')
    spec = importlib.util.spec_from_file_location('preview_validator', repo / 'minivec/tools/validate_iteration_material.py')
    checker = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(checker)
    for pointer in pointers(old):
        need(encode(checker.resolve_pointer(old, pointer)) == encode(checker.resolve_pointer(new, pointer)), 'pointer target changed: ' + pointer)
    checker.check_structure(new, new)
    preview = encode(new)
    summary = {
        'status': 'preview_only_not_applied', 'apply_available': False, 'repository_writes': 0, 'git_commands': 0,
        'new_database_runs_by_this_script': 0, 'source_bytes': len(raw), 'source_sha256': BASE,
        'preview_bytes': len(preview), 'preview_sha256': sha(preview), 'remaining_bytes': 131072 - len(preview),
        'within_limit': len(preview) <= 131072, 'all_original_messages_preserved': 127, 'original_users_preserved': 45,
        'new_messages': 2, 'total_messages': len(new['messages']), 'total_experiments': len(new['experiments']),
        'user_manifest_unchanged': True, 'all_existing_pointer_targets_unchanged': True,
        'formal_results_and_selected_runtime_unchanged': True, 'compressed_fields': [],
        'checks': ['pinned_material_and_evidence', '19_prechecks_reader_identity', 'eight_pairs_two_PGO_58_negatives',
                   'original_messages_users_and_all_other_root_fields', 'old_experiments_except_51', 'all_pointers', 'preview_schema_structure'],
        'prospective_full_repository_validation_run': False,
        'suggested_copy': [
            {'work_source': 'performance/matched-insert-6d2c433.zip', 'repo_target': RAW_DEST, 'bytes': len(actual_raw), 'sha256': RAW_SHA},
            {'work_source': 'iteration5-matched-insert-root-audit.zip', 'repo_target': AUDIT_DEST, 'bytes': len(audit), 'sha256': sha(audit)},
            {'work_source': 'matched-result-material-preview.json', 'repo_targets': ['conversation.json', 'agent/conversation.json'], 'bytes': len(preview), 'sha256': sha(preview)},
        ],
    }
    for name, data in [('iteration5-matched-insert-root-audit.zip', audit),
                       ('matched-result-material-preview.json', preview), ('matched-result-material-summary.json', encode(summary))]:
        destination = work / name
        need(not destination.resolve().is_relative_to(repo.resolve()), 'work output only')
        need(not destination.exists(), 'refuse overwrite: ' + name)
        destination.write_bytes(data)
    print(json.dumps({key: summary[key] for key in ('status', 'preview_bytes', 'remaining_bytes', 'within_limit', 'preview_sha256')}, indent=2))

if __name__ == '__main__':
    main()
