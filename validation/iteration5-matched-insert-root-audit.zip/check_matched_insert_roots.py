"""Small matched-plan/gate preflight; read old artifacts, never run a DB."""
import ast,copy,json,shutil,sys,tempfile
from pathlib import Path
w=Path(__file__).resolve().parent;t=w/'seekdb/minivec/tools';sys.path.insert(0,str(t))
import small_compute as s
from summarize_small_root import verify_measurement
from prepare_matched_insert_roots import training_evidence,gates
checks=[]
def need(ok):
 if not ok:raise AssertionError('failed assertion')
def check(name,fn):fn();checks.append(name)
def reject(fn):
 try:fn()
 except (ValueError,KeyError):return
 raise AssertionError('invalid fixture accepted')
for name in ('prepare_matched_insert_roots.py','summarize_matched_insert_roots.py','small_compute.py','summarize_small_root.py'):
 ast.parse((t/name).read_text(encoding='utf8'),filename=name)
prior=w/'performance/insert-copy-7554753'
source=json.loads((prior/'insert-copy-root/programs/root-proof.json').read_bytes())['root_input_sha256']
train=training_evidence(prior/'docker-build.log',source)
check('prior_log_six_oracles_and_six_profiles',lambda:need(len(train['oracle_records'])==6 and len(train['profile_sha256_from_build_log'])==6))
for count in (1,2):
 data=json.loads((prior/f'insert-copy-root/retained-{count}cpu.json').read_bytes())
 data.update(matched_insert_roots=True,insert_copy_reference=None,insert_thread_control=False,expected_pairs=4,completed_pairs=4,
             protection_only=False,plan=s.matched_insert_plan(count))
 data['pairs']=data['pairs'][:4]
 for pair in data['pairs']:
  for role in ('baseline','candidate'):
   pair[role]['effective_environment']={}
   for ready in pair[role]['adapter']['ready_memberships']:ready['runtime_environment']={}
 def verify(v):verify_measurement(v,count,('standard10k',),v['identity_record_sha256'],v['identities'],matched_roots=True)
 check(f'{count}cpu_controlled_matched_plan',lambda:verify(data))
 for label,change in (
  ('missing_pair',lambda x:x['pairs'].pop()),
  ('actual_policy_override',lambda x:x['pairs'][0]['candidate']['adapter']['ready_memberships'][0].update(runtime_environment={'MVDB_QUERY_THREADS':'1'})),
  ('wrong_memory',lambda x:x['pairs'][0]['candidate']['cgroup']['after'].update({'memory.max':'max'})),
  ('wrong_order',lambda x:x['pairs'][0].update(order=['candidate','baseline']))):
  bad=copy.deepcopy(data);change(bad)
  check(f'{count}cpu_reject_'+label,lambda bad=bad:reject(lambda:verify(bad)))
with tempfile.TemporaryDirectory(prefix='mvdb-matched-gate-') as td:
 out=Path(td)
 for name in ('image-handshake','image-public','image-interactive'):shutil.copytree(prior/name,out/name)
 for old,new in (('image-interactive.log','image-interactive.log'),('image-binary-json.log','json.log'),
                 ('image-binary-utf8.json','utf8.json'),('image-binary-topk.log','topk.log'),('image-binary-topk-parallel.log','topk-parallel.log')):
  shutil.copyfile(prior/old,out/new)
 check('prior_actual_image_seven_gate_categories',lambda:need(len(gates(w/'seekdb',out))==7))
 text=(out/'json.log').read_text();(out/'json.log').write_text(text.replace('PASS legacy_mode',''))
 check('reject_missing_json_case',lambda:reject(lambda:gates(w/'seekdb',out)))
record={'status':'passed','checks':checks,'count':len(checks),'linux_database_runs':0,
        'scope':'Python syntax, old build-log/gate readers, controlled resource/plan negative fixtures. No new builds or Linux measurement.'}
(w/'matched-insert-roots-preflight.json').write_text(json.dumps(record,indent=2)+'\n')
print(json.dumps({'status':'passed','checks':len(checks),'linux_database_runs':0}))
