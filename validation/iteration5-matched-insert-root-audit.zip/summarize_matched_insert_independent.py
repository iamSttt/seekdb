"""Compact facts derived from the independently verified matched-root artifact."""
import hashlib
import json
from pathlib import Path
from statistics import median

w=Path(__file__).resolve().parent
path=w/'matched-insert-independent-analysis.json'
raw=path.read_bytes();data=json.loads(raw)
assert data['status']=='verified' and data['verified_pairs']==8
keys=('first_lifetime_no_restart','first_lifetime_query_total','first_queries_cpu_usec',
      'ingest_wall_seconds','ingest_cpu_usec','ingest_insert_wall_seconds','ingest_commit_wall_seconds',
      'ingest_user_usec','ingest_system_usec','whole_cgroup_memory_peak_bytes',
      'whole_cgroup_device_read_bytes','whole_cgroup_device_write_bytes',
      'after_ingest_process_wchar_proxy','after_ingest_process_write_bytes_proxy','first_shutdown_logical_file_bytes')
metrics={}
for cpu,measurement in data['measurements'].items():
    metrics[cpu]={}
    for key in keys:
        item=measurement['extra_summary']['standard10k'][key];rows=item['raw_pairs']
        metrics[cpu][key]={'median_candidate_over_baseline':median(r['candidate']/r['baseline'] for r in rows),
            'candidate_larger_pairs':item['candidate_larger_pairs'],'paired_absolute_values':[
                {k:r[k] for k in ('pair_index','order','baseline','candidate','candidate_minus_baseline','candidate_larger')} for r in rows]}
policy=[]
for pair in data['measurements']['2']['resources_and_policy']:
    row={'pair_index':pair['pair_index'],'order':pair['order']}
    for role,side in pair['sides'].items():
        lines=side['policy']['fanout_log_lines']
        row[role]={'startup_calibration':lines[0],
            'first_logged_fanout_decision':next(s for s in lines if 'fanout rows=' in s),
            'first_query_cpu_interval':side['cpu_intervals']['query_before_update']}
    policy.append(row)
out={'status':'derived_from_verified_evidence','analysis_sha256':hashlib.sha256(raw).hexdigest(),
     'harness_commit':data['harness_commit'],'artifact_sha256':data['artifact_sha256'],
     'verified_pairs':8,'new_pgo_builds':2,'negative_or_mixed_metric_entries':len(data['all_negative_or_mixed_metrics']),
     'source_sanitizers_rerun':False,'metrics':metrics,'two_cpu_first_query_policy':policy,
     'decision':'retain_R_pending_further_evidence_not_automatic_adoption',
     'interpretation':[
       'This matched build has no joint wall/CPU >2% default regression, but only four pairs per CPU and no protection scenarios.',
       'N2 improves first-lifetime stage sums in 3/4 one-CPU and 4/4 two-CPU pairs. Stage sums are not elapsed end-to-end wall time.',
       'Two-CPU ingest system CPU rises in 4/4 pairs, user CPU falls in 4/4, and total ingest CPU rises in 3/4. The earlier N1 result is not erased.',
       'Two-CPU pair 3 first-query automatic fanout differs: R2 uses two threads and N2 uses one. All first-query decisions in pairs 0/1/2 use one thread. First-query benefits cannot all be attributed to INSERT copying.',
       'Two-CPU pairs 1/2 have only about 0.5% first-query wall improvement; absolute pair values and CPU counters are retained.',
       'R2 was rebuilt and happens to match prior acdd bytes. N2 differs from prior 5606 bytes. This is evidence of different candidate builds, not a causal proof of ISA/PGO effects.',
       'The previous N1 regression and the present N2 result have different build/runtime conditions; do not combine or multiply their ratios.',
       'Device read/write byte counts and shutdown logical file sizes are identical between sides. Process wchar is a proxy and differs by one byte in one pair. No large peak-memory saving is established.',
       'Official binary identities and T/B/M are unknown; no score floor or score prediction follows.'
     ]}
target=w/'matched-insert-independent-decision.json'
assert not target.exists()
target.write_text(json.dumps(out,ensure_ascii=False,indent=2)+'\n',encoding='utf8')
print(json.dumps({'output':str(target),'bytes':target.stat().st_size,'sha256':hashlib.sha256(target.read_bytes()).hexdigest()}))
