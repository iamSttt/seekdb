# FMA compensated-distance v2 independent decision

**Rejected by the frozen standalone screen.** Correctness passed; no DB integration, PGO, official submission or score claim.

| Scenario | Wall C/old | CPU C/old | Wall median old → C (ms) | Worse pairs |
|---|---:|---:|---:|---:|
| fullmantissa128 | 1.359418 | 1.362114 | 5.312 → 7.230 | 4/4 |
| fullmantissa512 | 0.271900 | 0.271945 | 70.231 → 19.084 | 0/4 |
| grid128 | 1.730103 | 1.729178 | 3.636 → 6.296 | 4/4 |

All 37 source pins, 7842 independent integer/Fraction fixtures, 3 builds, 14 native executions, 12 pairs and actual 1 CPU / 2 GiB / zero-swap limits verified. Normal and sanitized tests each passed 3,854,877 checks. All 16 adverse wall/CPU pair-metrics (8 pairs) and raw fault/context counters remain available.

The actual kernel retains the exact-product FMA residual and TwoSum dependency chain; whole-wrapper timing includes recurring controls, coordinate admission, certificate and original fallback. This limited codegen review found no blocker. Timed-corpus fallback counts were not measured, so the observed distribution is not assigned a speculative cause.

The first attempt remains a tool failure after one successful compilation and zero test/performance executions. V2 changes the counter-key spelling only; algorithm, oracle and thresholds are unchanged. The original analysis remains immutable with its pending-review label; the separately bound codegen review completes that step.
