"""Package the actual FMA v2 read-only audit; never run native code or change raw."""
import ast, hashlib, json, sys, zipfile
from pathlib import Path
from statistics import median
sys.dont_write_bytecode=True
from analyze_quant_batch_prototype import blob

W=Path(__file__).resolve().parent
digest=lambda data:hashlib.sha256(data).hexdigest()
read=lambda name:json.loads((W/name).read_bytes())
analysis_path=W/'compensated-v2-independent-analysis.json'
d=read(analysis_path.name);s=d['screen'];c=d['codegen_evidence']
assert d['status']=='verified_micro_evidence_pending_codegen_semantic_review'
assert d['api_binding']['commit']=='6712fd0b4d270bd4fd742dacfd416a2d96fe5a12'
assert d['api_binding']['artifact_sha256']=='8a6ebb04f478d15345075c207ea25e41a6c07ab1e960250bcf186d43e35b795b'
assert d['api_binding']['artifact_bytes']==2511943
assert len(s['pairs'])==12 and not s['timing_screen_passed']
disasm=(W/'compensated-v2-raw/micro-disassembly.txt').read_bytes()
assert digest(disasm)==c['objdump_sha256']
text=disasm.decode()
# These anchors bind the manually reviewed locations; they do not replace the
# dataflow review below with an opcode-name test or a new decoder framework.
for anchor in ('40289d:', '40297a:', '402dec:', '402df1:', '402e2a:',
               '403fda:', '403fdf:', '403ffa:', '404108:', '40419c:', '4041b6:', '404245:'):
    assert anchor in text
observations=[
 {'span':'0x402952..0x402994 / 0x402840..0x4028b7',
  'finding':'measure reads RAW wall and thread CPU before work(d, selected_role, 64), then CPU and wall after it. work selects 0x402a10 old or 0x402bf0 candidate once, invokes the selected wrapper indirectly at 0x40289d for every row, accumulates returned bits, and repeats 64 times. The timed target is not the bare kernel.'},
 {'span':'0x402bf0..0x402e49',
  'finding':'The candidate checks both pointers, dimension 16..4096 and modulo 4, cached AVX2/FMA support, then reads MXCSR and x87 controls inside each call. Masks compare MXCSR & 0xffc0 to 0x1f80 and x87 & 0x0f3f to 0x033f before calling the kernel. Non-certified outcomes branch to the original inlined long-double scalar path; that path can tail-call distance_exact at 0x402c6b. Certified values alone return directly. No control-word writes were found in this wrapper.'},
 {'span':'0x40400b..0x404075',
  'finding':'Each four-coordinate block extracts raw exponent and absolute bits before floating conversion. It rejects exponent 255, applies effective exponent max(e,1), and rejects absolute exponent difference >28 except either-zero pairs. The success branch precedes conversion and arithmetic.'},
 {'span':'0x403fc0..0x404007',
  'finding':'vcvtps2pd and vsubpd produce d in ymm0; vmulpd produces p in ymm10; vfmsub132pd ymm0,ymm10,ymm0 computes d*d-p as one fused residual. ymm2 is old high; ymm11=high+p, ymm12=sum-high, ymm1=sum-z then high-(sum-z), ymm10=p-z, followed by their addition. Residual is added to this TwoSum error, then to low in ymm3. high becomes sum. The six-operation TwoSum dependency chain and explicit residual remain; no reassociation or unintended contraction removes them.'},
 {'span':'0x4040b0..0x404108',
  'finding':'Four double high lanes and four low lanes are loaded into x87. Three additions reduce each four-lane group and the seventh adds both totals, preserving the source grouping and extended-precision final reduction.'},
 {'span':'0x404161..0x404247',
  'finding':'The error-factor arithmetic is in x87. Two nextafter(long double,long double) calls remain, for factor and final product. The rounded double and adjacent-double neighbors feed extended midpoint arithmetic and strictly positive margins; equality falls back. Helper calls to finite tests, neighbors, and nextafter are included in the timed wrapper. This review does not attribute a measured percentage of cost to them.'},
 {'span':'0x402a10..0x402be5',
  'finding':'The old target retains four x87 accumulation chains, its original conservative midpoint certificate and a tail call to exact integer fallback. The actual reference source is the frozen original Git header, not the previously rejected half/quarter certificates.'}
]
review={'status':'limited_actual_codegen_review_no_blocker_found',
 'micro_sha256':c['micro_sha256'],'objdump_sha256':c['objdump_sha256'],
 'observations':observations,
 'scope':'Manual review of the Git-bound CI post-timing objdump for this actual micro ELF and the frozen C++ source; not a formal whole-binary equivalence proof. No local native execution or fresh disassembly was performed.',
 'limitations':['Correctness concerns numeric results under admitted controls, not equivalence of sticky floating exception flags.',
  'Timing-corpus certification/fallback counts were not instrumented; fixture outcome counts cannot explain the timing distribution.',
  'Warm-up initializes CPU support before timing; all recurring per-call guards and the complete fallback remain timed.',
  'An optional local pyelftools availability check failed (module absent); no installation or replacement framework was added. The CI objdump and actual ELF are hash-bound, and only their stated review scope is claimed.'],
 'performance_decision_unchanged':True,'new_native_runs':0,'new_DB_runs':0}
def write_new(name,obj):
    p=W/name;assert not p.exists();p.write_text(json.dumps(obj,indent=2,ensure_ascii=False,allow_nan=False)+'\n',encoding='utf-8')
write_new('compensated-v2-codegen-review.json',review)

summary={}
for name,metrics in s['groups'].items():
    summary[name]={}
    for key,value in metrics.items():
        rows=value['raw_pairs']
        summary[name][key]={'paired_candidate_over_old_median':value['median'],
            'AB_median':value['AB_median'],'BA_median':value['BA_median'],
            'old_absolute_median_ns':median(x['old'] for x in rows),
            'candidate_absolute_median_ns':median(x['candidate'] for x in rows),
            'faster_pairs':value['faster_pairs'],'worse_pairs':value['candidate_worse_pairs'],'pairs':4}
resource_adverse=[]
for pair in s['pairs']:
    old,new=pair['measurements']
    for key in ('minor_faults','major_faults','voluntary_switches','involuntary_switches'):
        if new[key]>old[key]:resource_adverse.append({'scenario':pair['scenario'],'pair':pair['pair'],'order':pair['order'],
            'metric':key,'old':old[key],'candidate':new[key]})
decision={'status':'rejected_by_frozen_standalone_screen',
 'experiment_id':d['experiment_id'],'commit':d['api_binding']['commit'],
 'API_binding':d['api_binding'],'plan_sha256':d['plan_sha256'],
 'source_inputs_verified':37,'correctness':'normal_and_sanitized_passed',
 'native_evidence':d['native_evidence'],'resources':d['resources'],
 'host_model':'AMD EPYC 9V74 80-Core Processor',
 'whole_call_micro_pairs':12,'dimensions':summary,
 'primary_failed_metrics':s['primary_failed_metrics'],'grid_guard_triggers':s['grid_guard_triggers'],
 'all_negative_pair_metrics':s['all_negative_pair_metrics'],
 'negative_pair_metric_count':len(s['all_negative_pair_metrics']),
 'negative_pair_metric_scope':'16 entries represent 8 adverse pairs across wall and CPU, not 16 independent pairs.',
 'resource_adverse_pair_metrics':resource_adverse,
 'limited_actual_codegen_review':'no blocker found; separate bound review retained',
 'adopted':False,'eligible_for_DB_integration':False,'official_submission_recommended':False,
 'formal_score_prediction':None,'DB_runs':0,'PGO_builds':0,
 'previous_tool_failure_preserved':d['tool_correction'],
 'analysis':{'path':analysis_path.name,'bytes':analysis_path.stat().st_size,'sha256':digest(analysis_path.read_bytes())},
 'limitations':d['limitations'][:-1]+review['limitations']+[
  'The 512-dimensional benefit cannot compensate the failed 128-dimensional primary and grid protection conditions.',
  'No threshold was altered, no unfavorable pair removed, and no cross-host or half/quarter result was used for this decision.',
  'The limited codegen review completes the separate pending review in the immutable analysis; it does not turn a failed timing screen into eligibility.']}
write_new('compensated-v2-independent-decision.json',decision)
lines=['# FMA compensated-distance v2 independent decision','',
 '**Rejected by the frozen standalone screen.** Correctness passed; no DB integration, PGO, official submission or score claim.','',
 '| Scenario | Wall C/old | CPU C/old | Wall median old → C (ms) | Worse pairs |',
 '|---|---:|---:|---:|---:|']
for name,values in summary.items():
    a,b=values['wall_ns'],values['thread_cpu_ns']
    lines.append(f"| {name} | {a['paired_candidate_over_old_median']:.6f} | {b['paired_candidate_over_old_median']:.6f} | {a['old_absolute_median_ns']/1e6:.3f} → {a['candidate_absolute_median_ns']/1e6:.3f} | {a['worse_pairs']}/4 |")
lines +=['',
 'All 37 source pins, 7842 independent integer/Fraction fixtures, 3 builds, 14 native executions, 12 pairs and actual 1 CPU / 2 GiB / zero-swap limits verified. Normal and sanitized tests each passed 3,854,877 checks. All 16 adverse wall/CPU pair-metrics (8 pairs) and raw fault/context counters remain available.',
 '', 'The actual kernel retains the exact-product FMA residual and TwoSum dependency chain; whole-wrapper timing includes recurring controls, coordinate admission, certificate and original fallback. This limited codegen review found no blocker. Timed-corpus fallback counts were not measured, so the observed distribution is not assigned a speculative cause.',
 '', 'The first attempt remains a tool failure after one successful compilation and zero test/performance executions. V2 changes the counter-key spelling only; algorithm, oracle and thresholds are unchanged. The original analysis remains immutable with its pending-review label; the separately bound codegen review completes that step.']
md=W/'compensated-v2-independent-decision.md';assert not md.exists();md.write_text('\n'.join(lines)+'\n',encoding='utf-8')

pending=['analyze_compensated_v2_prototype'];modules={}
while pending:
    name=pending.pop()
    if name in modules:continue
    p=W/(name+'.py')
    if not p.is_file():continue
    modules[name]=p
    for node in ast.walk(ast.parse(p.read_bytes())):
        imports=[a.name for a in node.names] if isinstance(node,ast.Import) else [node.module] if isinstance(node,ast.ImportFrom) and node.module else []
        pending.extend(x.split('.')[0] for x in imports if (W/(x.split('.')[0]+'.py')).is_file())
members={'readers/'+p.name:p.read_bytes() for p in modules.values()}
for name in ('compensated-v2-independent-analysis.json','compensated-v2-independent-decision.json',
 'compensated-v2-independent-decision.md','compensated-v2-codegen-review.json','compensated-v2-api.json',
 'compensated-v2-reader-static-preflight.json','compensated-v2-reader-commit-preflight.json',
 'check_compensated_v2_reader.py','prepare_compensated_v2_reader.py','package_compensated_v2_audit.py'):
    members[name]=(W/name).read_bytes()
plan_path='validation/iteration5-compensated-distance-counter-v2-preregistration.json'
for path in (plan_path,'validation/iteration5-compensated-counter-v2-erratum.json'):
    members['git-source/'+path]=blob(W/'seekdb',decision['commit'],path)
members['raw-selected/micro-disassembly.txt']=disasm
manifest={'scope':'Read-only audit of the complete separately preserved raw archive; no native or DB execution by reader.',
 'commit':decision['commit'],'raw_archive':{'repository_path':'validation/iteration5-compensated-v2-raw.zip',
 'bytes':2511943,'sha256':d['api_binding']['artifact_sha256']},
 'members':[{'path':name,'bytes':len(data),'sha256':digest(data)} for name,data in sorted(members.items())]}
members['manifest.json']=(json.dumps(manifest,indent=2)+'\n').encode()
archive=W/'compensated-v2-independent-audit.zip';assert not archive.exists()
with zipfile.ZipFile(archive,'w',compression=zipfile.ZIP_DEFLATED,compresslevel=9) as z:
    for name,data in sorted(members.items()):
        item=zipfile.ZipInfo(name,date_time=(2026,11,14,0,0,0));item.compress_type=zipfile.ZIP_DEFLATED
        z.writestr(item,data,compresslevel=9)
with zipfile.ZipFile(archive) as z:
    assert set(z.namelist())==set(members) and all(z.read(name)==data for name,data in members.items())
receipt={'status':'packaged_verified_offline_audit','archive':str(archive),'bytes':archive.stat().st_size,
 'sha256':digest(archive.read_bytes()),'members':len(members),'local_reader_dependencies':len(modules),
 'decision':decision['status'],'negative_pair_metrics':16,
 'analysis_sha256':digest(analysis_path.read_bytes()),
 'decision_sha256':digest((W/'compensated-v2-independent-decision.json').read_bytes()),
 'codegen_review_sha256':digest((W/'compensated-v2-codegen-review.json').read_bytes()),
 'new_native_runs':0,'new_DB_runs':0,'repository_writes':0}
write_new('compensated-v2-independent-audit-receipt.json',receipt)
print(json.dumps(receipt))
