"""Narrow v2 preservation/source checks; no fixture generation or native runs."""
import ast, hashlib, json, sys
from pathlib import Path
from types import SimpleNamespace
sys.dont_write_bytecode=True
import analyze_compensated_v2_prototype as reader

w=Path(__file__).resolve().parent;checks=[]
def check(name,value):
    if not value:raise AssertionError(name)
    checks.append(name)
def funcs(name):
    return {n.name:ast.dump(n) for n in ast.parse((w/name).read_bytes()).body if isinstance(n,ast.FunctionDef)}
old,new=funcs('analyze_compensated_prototype.py'),funcs('analyze_compensated_v2_prototype.py')
for name in ('api','native','resources','disassembly','measurements'):
    check(name+' unchanged from v1 reader',old[name]==new[name])
plan_path=w/'seekdb'/reader.PLAN
plan=json.loads(plan_path.read_bytes())
check('corrected plan exact SHA',hashlib.sha256(plan_path.read_bytes()).hexdigest()==reader.PLAN_SHA)
check('37 source pins',len(plan['source_snapshot'])==37)
if reader.COMMIT is None:
    try:reader.frozen(SimpleNamespace(commit='0'*40,plan_sha256=reader.PLAN_SHA))
    except ValueError:checks.append('unbound commit refuses evidence')
    else:raise AssertionError('unbound accepted')
    suffix='static'
else:
    args=SimpleNamespace(commit=reader.COMMIT,plan_sha256=reader.PLAN_SHA,plan=plan_path,repo=w/'seekdb')
    verified,files,manifest=reader.source_files(args)
    check('actual Git 37 source pins and one-line correction guard',len(files)==37 and len(manifest['files'])==16)
    suffix='commit'
report={'status':'passed_static_source_checks_only','checks':checks,'commit':reader.COMMIT,'plan_sha256':reader.PLAN_SHA,
 'reader_sha256':hashlib.sha256((w/'analyze_compensated_v2_prototype.py').read_bytes()).hexdigest(),
 'old_reader_sha256':hashlib.sha256((w/'analyze_compensated_prototype.py').read_bytes()).hexdigest(),
 'new_native_runs':0,'new_DB_runs':0,'current_result_artifact_read':False}
target=w/('compensated-v2-reader-'+suffix+'-preflight.json');assert not target.exists()
target.write_text(json.dumps(report,indent=2)+'\n',encoding='utf-8')
print(json.dumps(report))
