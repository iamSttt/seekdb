"""Independent immutable-source/resource/oracle/whole-call micro reader; no native execution."""
import argparse, hashlib, json, math, re, struct
from fractions import Fraction
from pathlib import Path
from statistics import median

from analyze_quant_batch_prototype import Archive, need, sha, readjson, blob
from analyze_crc_root import verify_archive
from analyze_quarter_margin_prototype import integer, micro_corpus

COMMIT = '6712fd0b4d270bd4fd742dacfd416a2d96fe5a12'
PLAN = 'validation/iteration5-compensated-distance-counter-v2-preregistration.json'
PLAN_SHA = 'd528f738fbbeaccaf8a2ec806f9e08d3843696ff7a2ff4fa5afa2dec8cb26da2'
EXPERIMENT = 'compensated-distance-standalone-counter-v2'
BASE_PREFIX = 'minivec/tools/compensated_distance/'
PREFIX = BASE_PREFIX + 'corrected_v2/'
OLD_PREFIX = BASE_PREFIX + 'frozen/'
V1_COMMIT = '633edcd8237e59426c1112ba82a09e61e1e224ad'
ERRATUM_SHA = '8b962700da13d2ef5e46afe281b5d6d1c342f08477762fff147bd716bad6e03f'
MANIFEST = '19dfc583d3a40298f119d9b7edd4621fd4e4ea167dde835ec07f82307b819026'
REFERENCE = '7094c0892de1b56377a65675a119a942cd07959f22e128673738c6c953fc1fe9'
HEADER = '8cb12b2cf9c4c76d87099584a46f6e82e429b12448c7c0a7ff902317ba10585c'
ORACLE = 'a159c84b49ad4a2c018aa208677cd67143395d362ce214fa7a34db83adcd3608'
IMAGE = 'gcc:13.3.0-bookworm@sha256:1d71f0f3450214bef38fe09e6f610fb6cca90cf97b43f4ce845bfc32a4168818'
SCENARIOS = ('fullmantissa128','fullmantissa512','grid128')


def frozen(args):
    need(COMMIT is not None and args.commit == COMMIT and args.plan_sha256 == PLAN_SHA, 'compensated commit/plan not frozen or mismatched')


def api(receipt, raw, commit):
    art = receipt['artifact']; run = art['workflow_run']
    need(receipt['commit'] == run['head_sha'] == commit and receipt['run_id'] == run['id'], 'API run/source differs')
    need(art['name'] == 'compensated-distance-prototype-results' and art['size_in_bytes'] == len(raw) and
         art['digest'] == 'sha256:' + sha(raw) and art['expired'] is False, 'API artifact differs')
    need(art['url'] == 'https://api.github.com/repos/iamSttt/seekdb/actions/artifacts/' + str(art['id']), 'API repository differs')
    jobs = receipt.get('jobs', [])
    if isinstance(jobs, dict): jobs = jobs['jobs']
    selected = [job for job in jobs if job['name'] == 'tighter-bound-prototype']
    if jobs:
        need(len(selected) == 1 and selected[0]['run_id'] == run['id'] and selected[0]['status'] == 'completed', 'API job differs')
    return {'commit':commit,'run_id':run['id'],'artifact_id':art['id'],'artifact_sha256':sha(raw),'artifact_bytes':len(raw),
        'job_id':selected[0]['id'] if selected else receipt.get('job_id'),
        'job_conclusion':selected[0]['conclusion'] if selected else None,
        'job_independently_API_verified':bool(selected),'provided_jobs':len(jobs),'all_jobs_independently_enumerated':False}


def source_files(args):
    frozen(args)
    raw = args.plan.read_bytes()
    need(sha(raw) == PLAN_SHA and raw == blob(args.repo,args.commit,PLAN), 'exact committed preregistration differs')
    plan = readjson(raw)
    need(plan['experiment_id'] == EXPERIMENT and plan['default_adoption'] is False and plan['new_native_executions_observed'] == 0, 'plan scope differs')
    need(len(plan['source_snapshot']) == 37, 'source inventory differs')
    files = {}
    for path,item in plan['source_snapshot'].items():
        data = blob(args.repo,args.commit,path)
        oid = hashlib.sha1(b'blob '+str(len(data)).encode()+b'\0'+data).hexdigest()
        need(item == {'bytes':len(data),'sha256':sha(data),'git_blob':oid}, 'source pin differs: '+path)
        files[path] = data
    manifest_raw = files[PREFIX+'runner-manifest.json']
    need(sha(manifest_raw) == MANIFEST == plan['prototype_manifest_sha256'], 'runner manifest differs')
    manifest = readjson(manifest_raw)
    need(len(manifest['files']) == len({item['path'] for item in manifest['files']}) == 16, 'frozen package inventory differs')
    expected = {PREFIX+item['path'] for item in manifest['files']} | {PREFIX+'runner-manifest.json', BASE_PREFIX+'ci_prototype.sh', '.github/workflows/minivec-score.yml','.gitattributes'}
    expected |= {OLD_PREFIX+item['path'] for item in manifest['files']} | {OLD_PREFIX+'runner-manifest.json'}
    need(set(files) == expected, 'extra/missing Git source member')
    for item in manifest['files']:
        data = files[PREFIX+item['path']]
        need(len(data) == item['bytes'] and sha(data) == item['sha256'], 'frozen member differs')
    proof = readjson(files[PREFIX+'source-proof.json'])
    reference = blob(args.repo,proof['reference_commit'],proof['reference_git_path'])
    need(reference == files[PREFIX+'reference_distance.h'] and sha(reference) == REFERENCE == proof['reference_sha256'], 'canonical original reference differs')
    need(sha(files[PREFIX+'compensated_distance.h']) == HEADER == proof['compensated_header_sha256'], 'compensated algorithm differs')
    need(sha(files[PREFIX+'oracle.bin']) == ORACLE == proof['oracle_sha256'] and len(files[PREFIX+'oracle.bin']) == 3816012 and proof['oracle_cases'] == 7842, 'frozen oracle differs')
    need(proof['tighter_candidate_imported'] is proof['batch8_imported'] is proof['algorithm_modified'] is False, 'mixed candidate provenance')
    need(b'tighter_long_double_environment' not in reference, 'half/quarter reference imported')
    for path,item in plan['proofs'].items():
        need(len(files[path]) == item['bytes'] and sha(files[path]) == item['sha256'], 'proof source differs')
    verify_counter_correction(args,plan,files,manifest)
    return plan, files, manifest



def verify_counter_correction(args,plan,files,manifest):
    import io,zipfile
    need(plan['experiment_family']=='compensated-distance-standalone-v1', 'v2 family differs')
    item=plan['tool_erratum'];raw=blob(args.repo,args.commit,item['path'])
    need(item['path']=='validation/iteration5-compensated-counter-v2-erratum.json' and len(raw)==item['bytes']==3345 and
         sha(raw)==item['sha256']==ERRATUM_SHA, 'tool erratum differs')
    erratum=readjson(raw);original=erratum['original_preregistration']
    oldplan_raw=blob(args.repo,args.commit,original['path'])
    need(oldplan_raw==blob(args.repo,V1_COMMIT,original['path']) and len(oldplan_raw)==original['bytes']==12237 and
         sha(oldplan_raw)==original['sha256']=='a8a792a8da249645d82dcae7c661a6add9a3f846d76bfc305545d4561a65f866', 'old failed plan changed')
    oldplan=readjson(oldplan_raw)
    for key in ('scope','hypothesis','reference','production','execution','correctness','fixed_plan','screen'):
        need(plan[key]==oldplan[key], 'tool correction changed experimental definition: '+key)
    need(plan['corrected_attempt_execution_observed']=={'native_compilations':0,'native_tests':0,'pairs':0,'DB_runs':0,'PGO_builds':0}, 'v2 claims premature execution')
    parent_manifest=files[OLD_PREFIX+'runner-manifest.json']
    need(sha(parent_manifest)=='404e2ac0fb136b3cf9d0580575717d795e111ad184d30e0d3c832949e4ffb175', 'original manifest changed')
    oldmembers=readjson(parent_manifest)['files']
    need({x['path'] for x in oldmembers}=={x['path'] for x in manifest['files']}, 'corrected file inventory changed')
    for entry in oldmembers:
        name=entry['path'];old=files[OLD_PREFIX+name];new=files[PREFIX+name]
        need(len(old)==entry['bytes'] and sha(old)==entry['sha256'] and old==blob(args.repo,V1_COMMIT,OLD_PREFIX+name), 'v1 frozen member changed')
        if name=='run_linux.py':
            before=b"result['native_'+native_kind+'_completed'] += 1"
            after=b"result['native_'+native_kind+'s_completed'] += 1"
            need(old.count(before)==1 and new==old.replace(before,after), 'runner change exceeds single counter fix')
        else:need(new==old, 'algorithm/fixture/workload changed: '+name)
    need(sha(files[PREFIX+'run_linux.py'])==erratum['new_runner_sha256']=='d8ff6b720fd517a5044e5d70fcde39f94d532747de47a2b6df3ce8ddf97f836f' and
         sha(files[BASE_PREFIX+'ci_prototype.sh'])==erratum['new_wrapper_sha256']=='8dde9d434cf66244e6477914ab9e362f15da567792c26be329ab5ba057cf9840', 'corrected runner/wrapper identity differs')
    need(erratum['v1_frozen_preserved'] is True and erratum['correction']['algorithm_fixture_workload_threshold_changes'] is False and
         erratum['new_manifest_sha256']==MANIFEST, 'erratum scope differs')
    failure=plan['failed_prior_attempt'];need(failure==erratum['failed_attempt'] and failure['commit']==V1_COMMIT and
         failure['observed_successful_native_compilations']==1 and failure['recorded_completed_compile_counter']==0 and
         failure['native_test_executions']==failure['performance_pairs']==failure['DB_runs']==failure['PGO_builds']==0, 'old failure reclassified')
    item=failure['raw'];prior=blob(args.repo,args.commit,item['path'])
    need(len(prior)==item['bytes']==2310807 and sha(prior)==item['sha256']=='98ea4f92dd3cfa22763729a27ac1ad9d58b6f71f128f578e6a2cdf968e988bb4','old raw failure differs')
    with zipfile.ZipFile(io.BytesIO(prior)) as z:
        old_summary=readjson(z.read('results/summary.json'));old_binary=z.read('results/normal')
        need(old_summary['error']=="'native_compilation_completed'" and old_summary['commands'][-1]['name']=='build-normal' and
             old_summary['commands'][-1]['exit_code']==0 and 'pairs' not in old_summary, 'old tool failure evidence differs')
        need(len(old_binary)==failure['normal_ELF']['bytes'] and sha(old_binary)==failure['normal_ELF']['sha256'], 'old compiled but unexecuted ELF differs')
    item=erratum['independent_failure_audit'];prior_audit=blob(args.repo,args.commit,item['path'])
    need(len(prior_audit)==item['bytes']==56785 and sha(prior_audit)==item['sha256']=='350995fde9b4410dee9966bc8f73c256fd4cfda8c06a588271dc1dfc4929f617', 'independent failure audit differs')
    with zipfile.ZipFile(io.BytesIO(prior_audit)) as z:
        report=z.read('compensated-attempt1-independent-audit.json')
        need(sha(report)==item['audit_json_sha256']=='ec66f086b401840a9e7bc5b7d671ceb7c92fc4b87a1f991e3519c29feeea1178', 'failure audit member differs')

def sources(a,args):
    plan, files, manifest = source_files(args)
    need(a.data('source-manifest.json') == files[PREFIX+'runner-manifest.json'], 'actual manifest differs')
    need(a.json('source-verification.json') == {'status':'verified','members':16,'experiment_id':EXPERIMENT,
        'manifest_sha256':MANIFEST,'ci_wrapper_sha256':sha(files[BASE_PREFIX+'ci_prototype.sh'])}, 'actual source proof differs')
    actual = {}
    for line in a.data('input-sha256.txt').decode().splitlines():
        value,path = line.split(maxsplit=1);path=path.lstrip('*')
        need(path not in actual, 'duplicate actual source input');actual[path]=value
    need(actual == {path:sha(data) for path,data in files.items()}, 'executed Git input set differs')
    need(a.data('harness-commit.txt').decode().strip() == args.commit, 'actual harness commit differs')
    wrapper = files[BASE_PREFIX+'ci_prototype.sh'].decode()
    entries = re.findall(r'cat > "\$output/container-entry.py" <<\x27PY\x27\n(.*?)\nPY\n',wrapper,re.S)
    need(len(entries) == 1 and a.data('container-entry.py') == (entries[0]+'\n').encode(), 'actual container entry differs')
    return plan,files,manifest


def oracle(a,s,files):
    raw = a.data('results/oracle.bin');meta = a.json('results/oracle.json')
    need(raw == files[PREFIX+'oracle.bin'] and meta == readjson(files[PREFIX+'oracle.json']), 'regenerated binary oracle or parsed metadata differs')
    need(meta == s['oracle'] and meta['sha256'] == ORACLE == sha(raw) and meta['bytes'] == len(raw), 'oracle metadata differs')
    need(raw[:8] == b'MVDCMP1\0','oracle magic')
    count = struct.unpack_from('<I',raw,8)[0];at=12;sum_n=0;admitted=0;shape=0;coordinate=0
    need(count == meta['cases'] == 7842, 'case count differs')
    for _ in range(count):
        n,expected,guard = struct.unpack_from('<IQI',raw,at);at+=16
        need(n <= 4097 and guard in (0,1) and at+8*n <= len(raw), 'fixture shape invalid')
        lhs=struct.unpack_from('<'+'I'*n,raw,at);rhs=struct.unpack_from('<'+'I'*n,raw,at+4*n);at+=8*n;sum_n+=n
        total=sum((integer(x)-integer(y))**2 for x,y in zip(lhs,rhs))
        actual=struct.unpack('<Q',struct.pack('<d',float(Fraction(total,1<<298))))[0]
        need(actual == expected, 'independent integer/Fraction oracle differs')
        valid_shape=16 <= n <= 4096 and n%4 == 0
        valid_coordinates=all(not (x&0x7fffffff and y&0x7fffffff) or abs(max((x>>23)&255,1)-max((y>>23)&255,1)) <= 28 for x,y in zip(lhs,rhs))
        need(guard == int(valid_shape and valid_coordinates), 'independent coordinate/shape admission differs')
        admitted+=guard;shape+=not valid_shape;coordinate+=valid_shape and not valid_coordinates
    need(at == len(raw) and admitted == meta['admitted_coordinate_shape_cases'] == 7808, 'oracle tail/admission inventory differs')
    return {'cases':count,'admitted_coordinate_shape_cases':admitted,'shape_cases':shape,'coordinate_cases':coordinate,
        'sum_dimensions':sum_n,'sha256':sha(raw),'independently_recomputed_results':count,
        'native_check_count_base_excluding_certified':61+20*count+8*sum_n}


def native(a,s,files,manifest,independent):
    need(s['database_runs'] == s['pgo_builds'] == 0 and s['native_compilation_attempts'] == s['native_compilations_completed'] == 3 and
        s['native_execution_attempts'] == s['native_executions_completed'] == 14, 'native execution inventory differs')
    need(s['runner_manifest_sha256'] == MANIFEST and s['source_sha256'] == {item['path']:item['sha256'] for item in manifest['files']}, 'mounted runner source differs')
    need(s['source_proof'] == readjson(files[PREFIX+'source-proof.json']), 'actual source proof differs')
    need(a.data('results/compiler-version.log').strip() == a.data('preflight-compiler-version.txt').strip() == b'13.3.0' and
         s['compiler'] == a.data('results/compiler.log').decode().splitlines()[0], 'compiler differs')
    flags=['g++','-std=c++17','-ffp-contract=off','-fno-math-errno','-pthread']
    commands=[('compiler',['g++','--version'],None),('compiler-version',['g++','-dumpfullversion'],None),('cpu',['lscpu'],None),
        ('fixture-generation',None,None),
        ('build-normal',flags+['-O3','/prototype/test_compensated_distance.cpp','-o','/out/results/normal'],'compilation'),
        ('normal',['/out/results/normal','/out/results/oracle.bin'],'execution'),
        ('build-sanitized',flags+['-O1','-g','-fno-omit-frame-pointer','-fsanitize=address,undefined','-no-pie','/prototype/test_compensated_distance.cpp','-o','/out/results/sanitized'],'compilation'),
        ('sanitized',['/out/results/sanitized','/out/results/oracle.bin'],'execution'),
        ('build-micro',flags+['-O3','/prototype/benchmark_compensated_fixed.cpp','-o','/out/results/micro'],'compilation')]
    commands += [(f'micro-{name}-{i}',['/out/results/micro',name,'AB' if i%2==0 else 'BA'],'execution') for i in range(4) for name in SCENARIOS]
    need(len(commands) == len(s['commands']) == 21, 'command inventory differs')
    for actual,(name,argv,kind) in zip(s['commands'],commands):
        need(actual['name'] == name and actual['exit_code'] == 0 and actual['status'] == 'completed' and
             actual['native_kind'] == kind and type(actual['pid']) is int and actual['pid'] > 0, 'command incomplete or failed')
        if argv is None:
            need(actual['argv'][0].endswith('/python3') and actual['argv'][1:] == ['/prototype/make_fixtures.py','--output','/out/results/oracle.bin'], 'fixture generator argv differs')
        else:need(actual['argv'] == argv, 'compile/run command differs: '+name)
        need('results/'+name+'.log' in a.inventory, 'missing command log')
    need(readjson(a.data('results/fixture-generation.log')) == s['oracle'], 'generator log differs')
    counts=[];coverage=[]
    for mode in ('normal','sanitized'):
        text=a.data('results/'+mode+'.log').decode()
        matches=re.findall(r'^certified=(\d+) boundary_fallback=(\d+) coordinate_fallback=(\d+) shape_fallback=(\d+)$',text,re.M)
        need(len(matches)==1,'native path coverage absent');c,b,k,h=map(int,matches[0])
        need(c>100 and b>0 and c+b==independent['admitted_coordinate_shape_cases'] and k==independent['coordinate_cases'] and h==independent['shape_cases'] and k>0 and h>0,'native path inventory differs')
        expected=independent['native_check_count_base_excluding_certified']+c
        need(re.findall(r'^compensated_distance_checks=(\d+)$',text,re.M)==[str(expected)] and text.splitlines().count('compensated_distance=PASS')==1 and
             not any(value in text for value in ('ERROR: AddressSanitizer','runtime error:','FAIL ')), 'native oracle pass/count/diagnostics differ')
        counts.append(expected);coverage.append({'certified':c,'boundary':b,'coordinate':k,'shape':h})
    need(counts[0]==counts[1] and coverage[0]==coverage[1] and s['correctness_checks']==dict(zip(('normal','sanitized'),counts)),'normal/sanitized evidence differs')
    binaries={}
    for name in ('normal','sanitized','micro'):
        raw=a.data('results/'+name)
        need(raw[:6]==b'\x7fELF\x02\x01' and int.from_bytes(raw[18:20],'little')==62,'wrong ELF architecture')
        binaries[name]=sha(raw)
    need(binaries==s['binary_sha256'],'actual ELF identity differs')
    return {'native_builds':3,'native_executions':14,'normal_sanitized_checks_each':counts[0],
        'fixture_outcome_counts':coverage[0],'binary_sha256':binaries,'DB_runs':0,'PGO_builds':0,
        'counter_scope':'Fixture outcomes only; no timed-corpus certification or shadow counters are measured.'}


def disassembly(a):
    need(a.json('micro-disassembly-status.json')=={'exit_code':0,'timed':False},'post-timing objdump failed/missing')
    raw=a.data('results/micro');text=a.data('micro-disassembly.txt').decode()
    need(raw[:6]==b'\x7fELF\x02\x01','ELF format')
    functions={};name=None
    for line in text.splitlines():
        header=re.fullmatch(r'([0-9a-f]+) <(.+)>:',line)
        if header:
            name=header[2];need(name not in functions,'duplicate objdump symbol');functions[name]=[];continue
        if name is not None and line.strip():functions[name].append(line)
    selected={}
    for role,prefix in (('kernel','mvdb::compensated_draft::kernel('),('candidate_wrapper','comparison::new_distance('),('reference_wrapper','comparison::old_distance(')):
        found=[(key,value) for key,value in functions.items() if key.startswith(prefix)]
        need(len(found)==1 and found[0][1], 'actual '+role+' function missing/ambiguous')
        selected[role]={'symbol':found[0][0],'objdump_lines':found[0][1]}
    return {'status':'actual_ELF_and_CI_objdump_bound_semantic_review_pending','micro_sha256':sha(raw),
        'objdump_sha256':sha(a.data('micro-disassembly.txt')),'functions':selected,
        'scope':'The Git-bound wrapper dumps this actual micro ELF after all pairs; raw artifact SHA binds both files. Relevant kernel and whole-wrapper dataflow still require manual review, not merely opcode-name matching.'}


def measurements(a,s,plan):
    need(s['plan']=={'scenarios':list(SCENARIOS),'pairs_per_scenario':4,'orders':['AB','BA','AB','BA'],'rows':512,
         'repetitions_per_arm':64,'whole_call':True,'counter_instrumented_timing':False},'fixed whole-call plan differs')
    corpora={name:micro_corpus(name) for name in SCENARIOS};pairs=[]
    for i in range(4):
        for name in SCENARIOS:
            row=readjson(a.data(f'results/micro-{name}-{i}.log'));row['pair']=i
            need(row['scenario']==name and row['order']==('AB' if i%2==0 else 'BA') and row['rows']==512 and
                 row['dimension']==corpora[name]['dimension'] and row['repetitions']==64 and row['counter_instrumented'] is False and
                 row['whole_call'] is True and row['untimed_row_oracle_checks']==512,'whole-call pair plan differs')
            need(row['dataset_fnv64']==corpora[name]['dataset_fnv64'],'independent dataset fingerprint differs')
            need([item['role'] for item in row['measurements']]==['old','candidate'],'micro role order differs')
            for item in row['measurements']:
                need(item['checksum']==corpora[name]['expected_checksum'],'independent complete-scan checksum differs')
                need(all(type(item[key]) is int and item[key]>0 for key in ('wall_ns','thread_cpu_ns')),'invalid clocks')
                need(all(type(item[key]) is int and item[key]>=0 for key in ('minor_faults','major_faults','voluntary_switches','involuntary_switches')),'invalid fault/context counters')
            pairs.append(row)
    need(pairs==s['pairs'],'raw pairs differ from summary')
    rule=plan['screen']['fullmantissa128_and512_separately']
    need(rule=={'metrics':'wall and thread CPU separately','median_ratio_max':0.95,'strictly_faster_pairs_min':3,
         'AB_median_strictly_below':1.0,'BA_median_strictly_below':1.0},'frozen screen drift')
    groups={};negative=[];failed=[];guards=[]
    for name in SCENARIOS:
        rows=[row for row in pairs if row['scenario']==name];groups[name]={}
        for metric in ('wall_ns','thread_cpu_ns'):
            values=[row['measurements'][1][metric]/row['measurements'][0][metric] for row in rows]
            stats={'ratios':values,'median':median(values),'AB_median':median(values[::2]),'BA_median':median(values[1::2]),
                'faster_pairs':sum(value<1 for value in values),'candidate_worse_pairs':sum(value>1 for value in values),
                'raw_pairs':[{'pair':row['pair'],'order':row['order'],'old':row['measurements'][0][metric],'candidate':row['measurements'][1][metric]} for row in rows]}
            need(s['groups'][name][metric]=={'candidate_over_old':values,'median':stats['median'],'candidate_worse_pairs':stats['candidate_worse_pairs']},'runner arithmetic differs')
            groups[name][metric]=stats
            negative += [{'scenario':name,'metric':metric,'ratio':value,**row} for row,value in zip(stats['raw_pairs'],values) if value>1]
            if name=='grid128':
                if all(stats[key]>1.02 for key in ('median','AB_median','BA_median')):guards.append({'scenario':name,'metric':metric})
            else:
                conditions={'median':stats['median']<=.95,'faster':stats['faster_pairs']>=3,'AB':stats['AB_median']<1,'BA':stats['BA_median']<1}
                if not all(conditions.values()):failed.append({'scenario':name,'metric':metric,'conditions':conditions})
    passed=not failed and not guards
    return {'pairs':pairs,'groups':groups,'corpus_reproduction':corpora,'primary_failed_metrics':failed,'grid_guard_triggers':guards,
        'all_negative_pair_metrics':negative,'timing_screen_passed':passed,'codegen_semantic_review_required':True,
        'eligible_for_database_integration_investigation':False,'automatic_adoption':False,'official_score_prediction':None,
        'decision':'timing_screen_passed_pending_actual_codegen_review' if passed else 'mechanism_screen_not_passed_no_DB_gain_claim',
        'counter_scope':'No timed-corpus rescue counts or shadow ELF exist; fixture counts are not a substitute.'}


def audit(args):
    frozen(args)
    raw=args.archive.read_bytes();a=Archive(raw);binding=api(readjson(args.receipt.read_bytes()),raw,args.commit)
    verify_archive(args.input,args.archive,binding['artifact_sha256'],len(raw));plan,files,manifest=sources(a,args)
    ci=a.json('ci-status.json');need(ci['database_runs']==ci['pgo_builds']==ci['container_builds']==0,'unexpected DB/PGO/container build')
    base={'api_binding':binding,'plan_sha256':PLAN_SHA,'source_inputs_verified':len(files),'artifact_manifest':a.inventory,
        'new_native_executions_by_reader':0,'new_database_runs_by_reader':0,'formal_submission':False,'automatic_adoption':False,
        'tool_correction':{'erratum_sha256':ERRATUM_SHA,'old_failure_preserved':True,'old_actual_completed_compilations':1,'old_native_tests':0,'old_pairs':0,'algorithm_and_thresholds_changed':False}}
    if ci['exit_code']!=0 or binding['job_conclusion'] not in (None,'success'):
        return {**base,'status':'verified_failed_or_incomplete_attempt','CI_status':ci,
            'partial_runner_summary':a.json('results/summary.json') if 'results/summary.json' in a.inventory else None,'performance_screen_evaluated':False}
    need(a.json('runner-exit.json')=={'exit_code':0,'database_runs':0,'pgo_builds':0},'runner did not finish successfully')
    s=a.json('results/summary.json');need(s['status']=='correctness_and_fixed_micro_completed','summary incomplete')
    resource=resources(a,s);independent=oracle(a,s,files);native_evidence=native(a,s,files,manifest,independent)
    code=disassembly(a);screen=measurements(a,s,plan)
    return {**base,'status':'verified_micro_evidence_pending_codegen_semantic_review','experiment_id':EXPERIMENT,
        'resources':resource,'independent_fixture_oracle':independent,'native_evidence':native_evidence,'codegen_evidence':code,'screen':screen,
        'limitations':['Standalone warm whole-call scalar wrapper, no SQL/index/TopK/storage/PGO or formal-score conclusion.',
            'Every timed candidate call includes admission, control checks, certification and scalar fallback. First-use feature initialization is warmed outside timing.',
            'All pairs and negative fault/context/timing observations retained; no cross-host/cross-run multiplication or comparison to half/quarter gains.',
            'Sticky exception status is outside the equivalence claim; controls are read without changes.',
            'Artifact and frozen wrapper bind actual ELF and post-timing objdump; this is distinct from semantic instruction review. No integration eligibility is granted before that review.']}


def main():
    parser=argparse.ArgumentParser(description=__doc__)
    for name in ('input','archive','receipt','plan','output'):parser.add_argument('--'+name,type=Path,required=True)
    parser.add_argument('--repo',type=Path,default=Path(__file__).resolve().parent/'seekdb')
    parser.add_argument('--commit',required=True);parser.add_argument('--plan-sha256',required=True)
    args=parser.parse_args();need(not args.output.exists(),'refuse overwrite')
    need(not args.output.resolve().is_relative_to(args.input.resolve()),'output may not modify raw')
    try:result=audit(args)
    except Exception as exc:
        args.output.with_suffix('.reader-error.json').write_text(json.dumps({'status':'evidence_not_verified','error':str(exc),'native_DB_runs':0},indent=2)+'\n',encoding='utf-8');raise
    args.output.write_text(json.dumps(result,indent=2,allow_nan=False)+'\n',encoding='utf-8')
    print(json.dumps({'status':result['status'],'screen':result.get('screen',{}).get('decision'),'negative_pair_metrics':len(result.get('screen',{}).get('all_negative_pair_metrics',[]))}))


# The unchanged resource verifier is copied below by the work-only preparation
# script, with solely native completed counts changed from 4/15 to 3/14.

def resources(a,s):
    cpu=int(a.data('requested-cpu.txt'));need(cpu>=0,'CPU invalid')
    before=a.json('resource-preflight.json');after=a.json('resource-postflight.json')
    need(before['status']=='verified' and before['native_started'] is False and before['database_runs']==before['pgo_builds']==0 and before['affinity']==[cpu],'real pre-native cap proof absent')
    need(after['status']=='verified' and after['runner_exit_code']==0 and after['affinity']==[cpu],'real post-run cap proof absent')
    for where in ('preflight-','results/'):
        q,period=map(int,a.data(where+'cpu-max.txt').decode().split());need(q==period and period>0,'actual CPU quota differs')
        need(a.data(where+'memory-max.txt').strip()==b'2147483648' and a.data(where+'memory-swap-max.txt').strip()==b'0','actual memory/swap differs')
        status=dict(x.split(':',1) for x in a.data(where+'proc-status.txt').decode().splitlines() if ':' in x)
        need(status['Cpus_allowed_list'].strip()==str(cpu),'actual driver affinity differs')
    for name,value in before['observed'].items():need(value==a.data('preflight-'+name+'.txt').decode().strip(),'preflight raw snapshot differs')
    q,period=map(int,after['cpu.max'].split());need(q==period and period>0 and after['memory.max']=='2147483648' and after['memory.swap.max']=='0','postflight actual caps differ')
    need(s['affinity']=={'before':[cpu],'selected':[cpu]} and not s.get('unavailable_resource_files'),'runner affinity missing')
    need(a.json('resource-verification.json')=={'status':'verified','cpu_quota':q,'cpu_period':period,'memory_max':2147483648,'swap_max':0,'cpu_affinity':[cpu],'database_runs':0,'pgo_builds':0,'native_compilations_completed':3,'native_executions_completed':14},'wrapper resource summary differs')
    start,end,im=[a.json(n)[0] for n in ('container-start-inspect.json','container-final-inspect.json','tooling-image-inspect.json')]
    need(start['Id']==end['Id']==a.data('container-id.txt').decode().strip() and start['Image']==end['Image']==im['Id'],'container/image identity differs')
    need('gcc@'+IMAGE.split('@')[1] in im['RepoDigests'],'toolchain digest differs')
    need(end['State']['ExitCode']==0 and not end['State']['OOMKilled'] and not end['State']['Running'],'container failed/OOM/incomplete')
    for obj in (start,end):
        h=obj['HostConfig'];need(h['NetworkMode']=='none' and h['CpusetCpus']==str(cpu) and h['NanoCpus']==1000000000 and h['Memory']==h['MemorySwap']==2147483648 and h['PidsLimit']==128,'Docker resources differ')
        mounts={x['Destination']:x for x in obj['Mounts']};need(set(mounts)=={'/prototype','/out'} and mounts['/prototype']['RW'] is False and mounts['/out']['RW'] is True,'source/output mounts differ')
        need(obj['Config']['Cmd']==['bash','-c','set -euo pipefail; command -v python3; exec python3 /out/container-entry.py'],'container command differs')
    return {'actual_cpu':cpu,'cpu_max':[q,period],'memory_max':2147483648,'swap_max':0,'container_id':end['Id'],'toolchain_image_id':im['Id'],
      'scope':'Live parent cgroup/affinity checked before and after native runner; runner/children inherit the constrained container. No per-native-process resource traces.'}

if __name__=="__main__":main()
