"""Keep v1 reader immutable; derive only counter-corrected v2 identity handling."""
import ast
from pathlib import Path

w=Path(__file__).resolve().parent
text=(w/'analyze_compensated_prototype.py').read_text(encoding='utf-8')
text=text.replace("COMMIT = '633edcd8237e59426c1112ba82a09e61e1e224ad'", "COMMIT = None  # Bind only after the corrected experiment is committed.")
text=text.replace('validation/iteration5-compensated-distance-prototype-preregistration.json', 'validation/iteration5-compensated-distance-counter-v2-preregistration.json')
text=text.replace('a8a792a8da249645d82dcae7c661a6add9a3f846d76bfc305545d4561a65f866','d528f738fbbeaccaf8a2ec806f9e08d3843696ff7a2ff4fa5afa2dec8cb26da2')
text=text.replace("EXPERIMENT = 'compensated-distance-standalone-v1'", "EXPERIMENT = 'compensated-distance-standalone-counter-v2'")
text=text.replace("PREFIX = BASE_PREFIX + 'frozen/'", "PREFIX = BASE_PREFIX + 'corrected_v2/'\nOLD_PREFIX = BASE_PREFIX + 'frozen/'\nV1_COMMIT = '633edcd8237e59426c1112ba82a09e61e1e224ad'\nERRATUM_SHA = '8b962700da13d2ef5e46afe281b5d6d1c342f08477762fff147bd716bad6e03f'")
text=text.replace("MANIFEST = '404e2ac0fb136b3cf9d0580575717d795e111ad184d30e0d3c832949e4ffb175'", "MANIFEST = '19dfc583d3a40298f119d9b7edd4621fd4e4ea167dde835ec07f82307b819026'")
text=text.replace("len(plan['source_snapshot']) == 20", "len(plan['source_snapshot']) == 37")
text=text.replace("    need(set(files) == expected, 'extra/missing Git source member')", "    expected |= {OLD_PREFIX+item['path'] for item in manifest['files']} | {OLD_PREFIX+'runner-manifest.json'}\n    need(set(files) == expected, 'extra/missing Git source member')")
text=text.replace("    return plan, files, manifest", "    verify_counter_correction(args,plan,files,manifest)\n    return plan, files, manifest")
text=text.replace("raw == files[PREFIX+'oracle.bin'] and a.data('results/oracle.json') == files[PREFIX+'oracle.json']", "raw == files[PREFIX+'oracle.bin'] and meta == readjson(files[PREFIX+'oracle.json'])")
text=text.replace("'regenerated oracle not frozen bytes'", "'regenerated binary oracle or parsed metadata differs'")
text=text.replace("'new_native_executions_by_reader':0,'new_database_runs_by_reader':0,'formal_submission':False,'automatic_adoption':False}",
    "'new_native_executions_by_reader':0,'new_database_runs_by_reader':0,'formal_submission':False,'automatic_adoption':False,\n"
    "        'tool_correction':{'erratum_sha256':ERRATUM_SHA,'old_failure_preserved':True,'old_actual_completed_compilations':1,'old_native_tests':0,'old_pairs':0,'algorithm_and_thresholds_changed':False}}")
insertion='''

def verify_counter_correction(args,plan,files,manifest):
    import io,zipfile
    need(plan['experiment_family']=='compensated-distance-standalone-v1', 'v2 family differs')
    item=plan['tool_erratum'];raw=blob(args.repo,args.commit,item['path'])
    need(item['path']=='validation/iteration5-compensated-counter-v2-erratum.json' and len(raw)==item['bytes']==3345 and
         sha(raw)==item['sha256']==ERRATUM_SHA, 'tool erratum differs')
    erratum=readjson(raw);original=erratum['original_preregistration']
    oldplan_raw=blob(args.repo,args.commit,original['path'])
    need(oldplan_raw==blob(args.repo,V1_COMMIT,original['path']) and len(oldplan_raw)==original['bytes']==12237 and
         sha(oldplan_raw)==original['sha256']=='a8a792a8da249645d82dcae7c661a6add9a3f846d76bfc305545d4561a65f866', 'old failed plan changed')
    oldplan=readjson(oldplan_raw)
    for key in ('scope','hypothesis','reference','production','execution','correctness','fixed_plan','screen'):
        need(plan[key]==oldplan[key], 'tool correction changed experimental definition: '+key)
    need(plan['corrected_attempt_execution_observed']=={'native_compilations':0,'native_tests':0,'pairs':0,'DB_runs':0,'PGO_builds':0}, 'v2 claims premature execution')
    parent_manifest=files[OLD_PREFIX+'runner-manifest.json']
    need(sha(parent_manifest)=='404e2ac0fb136b3cf9d0580575717d795e111ad184d30e0d3c832949e4ffb175', 'original manifest changed')
    oldmembers=readjson(parent_manifest)['files']
    need({x['path'] for x in oldmembers}=={x['path'] for x in manifest['files']}, 'corrected file inventory changed')
    for entry in oldmembers:
        name=entry['path'];old=files[OLD_PREFIX+name];new=files[PREFIX+name]
        need(len(old)==entry['bytes'] and sha(old)==entry['sha256'] and old==blob(args.repo,V1_COMMIT,OLD_PREFIX+name), 'v1 frozen member changed')
        if name=='run_linux.py':
            before=b"result['native_'+native_kind+'_completed'] += 1"
            after=b"result['native_'+native_kind+'s_completed'] += 1"
            need(old.count(before)==1 and new==old.replace(before,after), 'runner change exceeds single counter fix')
        else:need(new==old, 'algorithm/fixture/workload changed: '+name)
    need(sha(files[PREFIX+'run_linux.py'])==erratum['new_runner_sha256']=='d8ff6b720fd517a5044e5d70fcde39f94d532747de47a2b6df3ce8ddf97f836f' and
         sha(files[BASE_PREFIX+'ci_prototype.sh'])==erratum['new_wrapper_sha256']=='8dde9d434cf66244e6477914ab9e362f15da567792c26be329ab5ba057cf9840', 'corrected runner/wrapper identity differs')
    need(erratum['v1_frozen_preserved'] is True and erratum['correction']['algorithm_fixture_workload_threshold_changes'] is False and
         erratum['new_manifest_sha256']==MANIFEST, 'erratum scope differs')
    failure=plan['failed_prior_attempt'];need(failure==erratum['failed_attempt'] and failure['commit']==V1_COMMIT and
         failure['observed_successful_native_compilations']==1 and failure['recorded_completed_compile_counter']==0 and
         failure['native_test_executions']==failure['performance_pairs']==failure['DB_runs']==failure['PGO_builds']==0, 'old failure reclassified')
    item=failure['raw'];prior=blob(args.repo,args.commit,item['path'])
    need(len(prior)==item['bytes']==2310807 and sha(prior)==item['sha256']=='98ea4f92dd3cfa22763729a27ac1ad9d58b6f71f128f578e6a2cdf968e988bb4','old raw failure differs')
    with zipfile.ZipFile(io.BytesIO(prior)) as z:
        old_summary=readjson(z.read('results/summary.json'));old_binary=z.read('results/normal')
        need(old_summary['error']=="'native_compilation_completed'" and old_summary['commands'][-1]['name']=='build-normal' and
             old_summary['commands'][-1]['exit_code']==0 and 'pairs' not in old_summary, 'old tool failure evidence differs')
        need(len(old_binary)==failure['normal_ELF']['bytes'] and sha(old_binary)==failure['normal_ELF']['sha256'], 'old compiled but unexecuted ELF differs')
    item=erratum['independent_failure_audit'];prior_audit=blob(args.repo,args.commit,item['path'])
    need(len(prior_audit)==item['bytes']==56785 and sha(prior_audit)==item['sha256']=='350995fde9b4410dee9966bc8f73c256fd4cfda8c06a588271dc1dfc4929f617', 'independent failure audit differs')
    with zipfile.ZipFile(io.BytesIO(prior_audit)) as z:
        report=z.read('compensated-attempt1-independent-audit.json')
        need(sha(report)==item['audit_json_sha256']=='ec66f086b401840a9e7bc5b7d671ceb7c92fc4b87a1f991e3519c29feeea1178', 'failure audit member differs')
'''
anchor='\ndef sources(a,args):'
assert text.count(anchor)==1
text=text.replace(anchor,insertion+anchor)
target=w/'analyze_compensated_v2_prototype.py';assert not target.exists()
ast.parse(text);target.write_text(text,encoding='utf-8',newline='\n')
print('prepared separate corrected-v2 reader; commit pending')
