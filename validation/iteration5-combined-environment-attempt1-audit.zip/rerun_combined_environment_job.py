"""Retry the frozen unsupported-ISA acquisition; no credentials in outputs."""
import hashlib,json,os,subprocess,urllib.request
from pathlib import Path
root=Path('work/combined-environment-attempt1-raw')
report=json.loads((root/'batch8-environment.json').read_bytes())
assert report['status']=='unsupported_native_isa' and report['native_row_isa']=='avx512'
assert report['database_runs']==report['pgo_builds']==report['performance_pairs']==0
assert (root/'batch8-environment-exit-code.txt').read_text().strip()=='78'
assert (root/'runtime-commit.txt').read_text().strip()=='ab6deae90dfeeb3f1c9e254c43beff0df1c258b6'
raw=Path('work/seekdb/validation/iteration5-combined-environment-attempt1-raw.zip').read_bytes()
assert len(raw)==42446 and hashlib.sha256(raw).hexdigest()=='d214e0b7d7fba335402ed3a62587276596742e7f9f7fdb50cf8fe89b0914a0fd'
plan=json.loads(Path('work/seekdb/validation/iteration5-batch8-tighter-primary24-preregistration.json').read_bytes())
assert plan['experiment_id']=='batch8-tighter-certificate-highest-primary24'
assert len(list(root.iterdir()))==11
receipt_path=Path('work/combined-environment-rerun-receipt.json');assert not receipt_path.exists()
result=subprocess.run(['git','credential','fill'],input='protocol=https\nhost=github.com\n\n',text=True,capture_output=True,check=True,timeout=30,
 env=dict(os.environ,GIT_TERMINAL_PROMPT='0',GCM_INTERACTIVE='Never'))
fields=dict(line.split('=',1) for line in result.stdout.splitlines() if '=' in line)
request=urllib.request.Request('https://api.github.com/repos/iamSttt/seekdb/actions/jobs/132191972711/rerun',data=b'{}',method='POST',
 headers={'Authorization':'Bearer '+fields['password'],'User-Agent':'MiniVectorDB-authorized-CI','Accept':'application/vnd.github+json','Content-Type':'application/json'})
with urllib.request.urlopen(request,timeout=40) as response:
 receipt={'status':response.status,'run_id':43514245437,'rerun_job_id':132191972711,'environment_attempt_requested':2,
 'reason':'predeclared unsupported native ISA with exit78; database/PGO/performance all zero'}
receipt_path.write_bytes((json.dumps(receipt,indent=2)+'\n').encode());print(json.dumps(receipt))
