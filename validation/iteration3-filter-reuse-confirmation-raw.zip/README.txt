Real Linux results: filter reuse4 internal gates,6 PGO engine gates,30 pairs; root validation separately uses3 flags without reuse.
Final4flag/120 plan is not yet executed.
Root performed sh -n on the newly edited ci_score: exit0. Embedded Python AST and all3 default-feature lists agree on4flags.
