"""Extract the filter-lifecycle collector's JSON and text blocks from job logs."""
import hashlib
import json
from pathlib import Path, PurePosixPath
import re
import sys

raw, out = map(Path, sys.argv[1:3])
out.mkdir(parents=True, exist_ok=True)
marker = 'MINIVEC_FILTER_LIFECYCLE'
pending, payload, saved = None, [], []
for number, original in enumerate(raw.read_text(encoding='utf-8-sig').splitlines(), 1):
    line = re.sub(r'^\ufeff*\d{4}-\d\d-\d\dT\S+ ', '', original)
    if line.startswith(marker + '_BEGIN '):
        if pending is not None:
            raise ValueError('nested marker')
        name = json.loads(line[len(marker + '_BEGIN '):])
        path = PurePosixPath(name)
        if path.is_absolute() or '..' in path.parts or '\\' in name or ':' in name:
            raise ValueError('unsafe report path')
        pending, payload, first = path, [], number
    elif line.endswith(marker + '_END'):
        if pending is None:
            raise ValueError('end without begin')
        prefix = line[:-len(marker + '_END')]
        if prefix:
            payload.append(prefix)
        data = ('\n'.join(payload).rstrip('\n') + '\n').encode()
        if pending.suffix == '.json':
            json.loads(data, parse_constant=lambda value: (_ for _ in ()).throw(ValueError(value)))
        elif pending.suffix != '.txt':
            raise ValueError('unexpected block type')
        target = out / pending
        if target.exists():
            raise ValueError('duplicate report ' + str(pending))
        target.parent.mkdir(parents=True, exist_ok=True)
        target.write_bytes(data)
        saved.append({'path': pending.as_posix(), 'bytes': len(data),
                      'sha256': hashlib.sha256(data).hexdigest(),
                      'first_log_line': first, 'last_log_line': number})
        pending = None
    elif pending is not None:
        payload.append(line)
if pending is not None or not saved:
    raise ValueError('incomplete/no marked reports')
manifest = {'source_log': str(raw.resolve()), 'log_bytes': raw.stat().st_size,
            'log_sha256': hashlib.sha256(raw.read_bytes()).hexdigest(),
            'reports': saved,
            'normalization': 'Removed GitHub timestamps and normalized terminal LF; original log retained.'}
if (out / 'hashes.json').exists():
    expected = {item['path']: item for item in json.loads((out / 'hashes.json').read_text())['artifacts']}
    checked = []
    for item in saved:
        if item['path'] == 'hashes.json':
            continue
        want = expected[item['path']]
        if (want['bytes'], want['sha256']) != (item['bytes'], item['sha256']):
            raise ValueError('artifact hash mismatch ' + item['path'])
        checked.append(item['path'])
    manifest['collector_hashes_verified'] = checked
(out / 'extraction.json').write_text(json.dumps(manifest, indent=2) + '\n')
print(json.dumps({'reports': len(saved), 'bytes': manifest['log_bytes'],
                  'collector_hashes_verified': len(manifest.get('collector_hashes_verified', []))}))
