"""Independent analysis for the new 30-pair filter-reuse confirmation."""
import argparse
import hashlib
import json
from pathlib import Path
import re
import analyze_write_query_results as common

CASES=('resident_compound_q1','resident_compound_q16')
SEEDS=(7319,8911,13337)
SIDES=('baseline','candidate')
require=common.require
load=common.load
sha=common.sha

def group_summary(pairs):
    return {'pairs':len(pairs),'timing_ms':common.summarize_pairs(pairs,'timing_ms'),
            'resources':common.summarize_pairs(pairs,'resources')}

def main():
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--input',type=Path,default=Path(__file__).resolve().parent/'performance/filter-reuse-54ce8402')
    parser.add_argument('--output',type=Path,default=Path(__file__).resolve().parent/'filter-reuse-30-analysis.json')
    args=parser.parse_args();root=args.input
    status=load(root/'run-status.json');summary=load(root/'summary.json');context=load(root/'context.json')
    report=load(root/'write-query.json');build=load(root/'build-context.json');proof=load(root/'proof/context.json')
    extraction=load(root/'extraction.json')
    require(status['exit_code']==0 and status['proof_complete'] is True and summary['status']=='passed','Run incomplete/failed')
    require(summary['pgo_correctness_gates']==6 and summary['internal_gate_checks']==4 and
            summary['total_pairs']==summary['expected_total_pairs']==30 and
            summary['source_profile_binary_verified'] is True and summary['root_feature_flags_isolated'] is True,
            'Missing source/PGO/unit/complete-matrix proof')
    revision=summary['source_commit']
    require(re.fullmatch('[0-9a-f]{40}',revision) and context['source_commit']==build['source_commit']==proof['source_commit']==revision,
            'Source commit mismatch')
    require(build['feature']==proof['feature']=='filter-reuse' and build['pgo_enabled'] is True and
            build['same_compiler_and_training'] is True and build['feature_flags_isolated'] is True and
            build['root_feature_flags_override']=='','Not the isolated original PGO feature contrast')
    for side,expected in [('baseline',['-DMVDB_DISABLE_MULTI_POSTING']),('candidate',['-DMVDB_MULTI_POSTING_REUSE_ONLY'])]:
        require(build[side+'_flags']==proof[side+'_flags']==context[side+'_flags']==expected,'Unexpected feature flags')
        actual=proof['profile_source_proof'][side+'-pgo']['effective_common_flags']
        require([flag for flag in actual if flag.startswith('-DMVDB_')]==expected,'Actual compiled feature leakage')
        require(report['binaries'][side]['sha256']==build['binaries'][side]['sha256']==
                proof['profile_source_proof'][side+'-pgo']['binary_sha256'],'Binary SHA binding mismatch')
    require(summary['report_sha256']==sha(root/'write-query.json') and
            report['build_context']['sha256']==sha(root/'build-context.json'),'Report/build-context hash mismatch')
    require({'summary.json','write-query.json','proof/context.json','build-context.json'}<=
            set(extraction['collector_hashes_verified']),'Exact collector hashes not verified')
    ids=[(p['scenario'],p['seed'],p['pair_index']) for p in report['pairs']]
    require(report['status']=='passed' and report['binary_unchanged'] is True and
            report['total_pairs']==report['expected_total_pairs']==30 and
            len(ids)==len(set(ids))==30 and set(ids)=={(c,s,i) for c in CASES for s in SEEDS for i in range(5)},
            'Invalid pair matrix')
    grouped={case:[] for case in CASES}
    for raw in report['pairs']:
        reads=16 if raw['scenario'].endswith('q16') else 1
        require(raw['reads_per_write']==reads and raw['mutation_count']==4 and raw['all_responses_identical'] is True,
                'Incorrect read/write pattern')
        require(raw['baseline']['response_sha256']==raw['candidate']['response_sha256'] and
                re.fullmatch('[0-9a-f]{64}',raw['baseline']['response_sha256']),'Response proof mismatch')
        pair={key:raw[key] for key in ('scenario','seed','pair_index','order','workload_sha256')}
        for side in SIDES:
            common.audit_side(raw[side],reads,raw['rows'],'resident_storage_observed')
            timings=common.metrics(raw[side])
            if reads>1:
                cycle_queries=[raw[side]['query'][f'query_cycle_{i}']['per_request_seconds'] for i in range(4)]
                timings['all_cycle_second_query']=1000*sum(q[1] for q in cycle_queries)
                timings['mean_query_after_second']=1000*sum(sum(q[2:]) for q in cycle_queries)/(4*(reads-2))
                timings['initial_second_query']=1000*raw[side]['query']['query_before_mutations']['per_request_seconds'][1]
            pair[side]={'timing_ms':timings,'resources':common.resources(raw[side]),
                        'original_phase_names':list(raw[side]['phase_seconds']),
                        'write_cycles':raw[side]['write_cycles'],'query':raw[side]['query'],
                        'response_sha256':raw[side]['response_sha256']}
        grouped[raw['scenario']].append(pair)
    result={'source_commit':revision,'run_id':43348429817,'job_id':131633298761,'author':'assistant',
            'input_directory':str(root),'raw_log_sha256':extraction['log_sha256'],
            'artifact_sha256':{name:sha(root/name) for name in
                               ('write-query.json','context.json','summary.json','build-context.json','proof/context.json')},
            'verified_pairs':30,'scenarios':{},'official_score':None,'production_defaults_changed':False,
            'definitions':['B/C ratios are calculated within each pair; >1 favors the candidate.',
                           '15 pairs per scenario = 3 seeds x 5 pairs. Four cycles/individual requests are not independent replicates.',
                           'All first-query rebuild time and BEGIN/UPDATE/COMMIT stay in cycle and measured lifecycle totals.',
                           'first_query fields sum the first query across four cycles; divide absolute milliseconds by four for mean first-query latency.',
                           'full_run_wall includes verification/snapshots/cleanup, while measured_lifecycle excludes them.',
                           'Restart queries follow point-query persistence verification; no page-cache eviction or cold-cache claim.',
                           'Process CPU/IO snapshots are proxies sampled before each shutdown; they omit shutdown resource use and include persistence verification.',
                           'A/B and B/A strata are retained; one shared host, independently trained PGO code and temporal drift remain limitations.',
                           'No trimming, dropping outliers or choosing only favorable seeds/order strata. No automatic admission/default decision.']}
    principal=('all_cycles','all_cycle_first_query','all_cycle_write_and_commit','mean_warm_query',
               'all_cycle_second_query','mean_query_after_second',
               'initial_first_query','initial_index_plus_first_query','restart_plus_first_query',
               'measured_lifecycle','full_run_wall_including_verification')
    compact={}
    for case,pairs in grouped.items():
        item=group_summary(pairs)
        item['by_seed']={str(seed):group_summary([p for p in pairs if p['seed']==seed]) for seed in SEEDS}
        item['by_order']={label:group_summary([p for p in pairs if p['order'][0]==first])
                          for label,first in [('AB','baseline'),('BA','candidate')]}
        item['by_seed_order']={str(seed):{label:group_summary([p for p in pairs if p['seed']==seed and p['order'][0]==first])
                                          for label,first in [('AB','baseline'),('BA','candidate')]} for seed in SEEDS}
        item['raw_pairs']=pairs
        item['negative_pairs']={metric:[{'seed':p['seed'],'pair_index':p['pair_index'],'order':p['order'],
                                        'baseline_ms':p['baseline']['timing_ms'][metric],
                                        'candidate_ms':p['candidate']['timing_ms'][metric],
                                        'ratio':p['baseline']['timing_ms'][metric]/p['candidate']['timing_ms'][metric]}
                                       for p in pairs if p['candidate']['timing_ms'][metric]>p['baseline']['timing_ms'][metric]]
                                for metric in principal if metric in pairs[0]['baseline']['timing_ms']}
        item['large_ratio_deviation_pairs']=[]
        for p in pairs:
            for metric in ('all_cycles','measured_lifecycle'):
                ratio=p['baseline']['timing_ms'][metric]/p['candidate']['timing_ms'][metric]
                if .8<=ratio<=1.25:continue
                phases=[name for name in p['baseline']['original_phase_names']
                        if name not in ('measured_lifecycle','restart_verification_wall')]
                if metric=='all_cycles':
                    phases=[name for name in phases if name.startswith(('writes_cycle_','query_cycle_'))]
                deltas=sorted([{'phase':name,'candidate_minus_baseline_ms':
                                p['candidate']['timing_ms'][name]-p['baseline']['timing_ms'][name],
                                'baseline_ms':p['baseline']['timing_ms'][name],
                                'candidate_ms':p['candidate']['timing_ms'][name]} for name in phases],
                              key=lambda x:abs(x['candidate_minus_baseline_ms']),reverse=True)
                item['large_ratio_deviation_pairs'].append({'seed':p['seed'],'pair_index':p['pair_index'],
                    'order':p['order'],'metric':metric,'ratio':ratio,'largest_phase_deltas':deltas[:3],
                    'treatment':'retained in all statistics; ratio threshold is a reporting flag, not an exclusion rule'})
        item['write_operation_pauses_over_10ms']=[]
        for p in pairs:
            for side in SIDES:
                for cycle in p[side]['write_cycles']:
                    operations=[('begin',cycle['begin_seconds']),('commit',cycle['commit_seconds'])]
                    operations.extend((m['kind'],m['seconds']) for m in cycle['mutations'])
                    for operation,seconds in operations:
                        if seconds<=.01:continue
                        other=SIDES[1-SIDES.index(side)]
                        peer=p[other]['write_cycles'][cycle['cycle']]
                        peer_seconds=(peer[operation+'_seconds'] if operation in ('begin','commit')
                                      else sum(m['seconds'] for m in peer['mutations'] if m['kind']==operation))
                        item['write_operation_pauses_over_10ms'].append({
                            'seed':p['seed'],'pair_index':p['pair_index'],'order':p['order'],
                            'side':side,'cycle':cycle['cycle'],'operation':operation,
                            'duration_ms':1000*seconds,'peer_duration_ms':1000*peer_seconds,
                            'treatment':'retained in all primary totals; elapsed-time observation, root cause not identified'})
        result['scenarios'][case]=item
        compact[case]={metric:{'B_ms':value['baseline']['median'],'C_ms':value['candidate']['median'],
                               'B_over_C':value.get('baseline_over_candidate'),
                               'candidate_slower_pairs':value['candidate_larger_pairs']}
                       for metric,value in item['timing_ms'].items() if metric in principal}
    args.output.write_text(json.dumps(result,indent=2,allow_nan=False)+'\n',encoding='utf-8')
    print(json.dumps(compact,indent=2))

if __name__=='__main__':main()
