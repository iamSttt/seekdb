"""Human-readable decision evidence; never edits production/defaults/materials."""
import hashlib
import json
from pathlib import Path

work=Path(__file__).resolve().parent
source=work/'filter-reuse-30-analysis.json'
analysis=json.loads(source.read_text(encoding='utf-8'))
source_sha=hashlib.sha256(source.read_bytes()).hexdigest()
metrics=('all_cycle_write_and_commit','all_cycle_first_query','all_cycle_second_query',
         'mean_warm_query','mean_query_after_second','all_cycles','initial_first_query',
         'initial_second_query','initial_index_plus_first_query','restart_plus_first_query',
         'measured_lifecycle','full_run_wall_including_verification')
resource_keys=('maximum_process_high_water_bytes','maximum_sampled_rss_bytes',
               'sum_pre_shutdown_process_cpu_seconds','initial_and_mutation_query_windows_cpu_seconds',
               'sum_pre_shutdown_io_rchar','sum_pre_shutdown_io_syscr',
               'sum_pre_shutdown_io_read_bytes','sum_pre_shutdown_io_write_bytes',
               'shutdown_data_file_bytes','final_shutdown_data_file_bytes')

def compact(item):
    return {'pairs':item['pairs'], 'timing_ms':{m:item['timing_ms'][m] for m in metrics if m in item['timing_ms']}}

result={
    'author':'assistant',
    'purpose':'Analysis of observed isolated filter-reuse confirmation; not a user statement or final default adoption.',
    'source_commit':analysis['source_commit'], 'run_id':analysis['run_id'], 'job_id':analysis['job_id'],
    'analysis_path':str(source), 'analysis_sha256':source_sha,
    'raw_log_sha256':analysis['raw_log_sha256'], 'artifact_sha256':analysis['artifact_sha256'],
    'verification':{'internal_O2_sanitizer_checks':4,'actual_original_PGO_protocol_TopK_gates':6,
                    'pairs':30,'pairs_per_scenario':15,'seeds':3,'pairs_per_seed':5,
                    'source_binary_profile_bound':True,'responses_identical_and_oracles_passed':True,
                    'root_feature_flags_explicitly_cleared':True,
                    'baseline_flags':['-DMVDB_DISABLE_MULTI_POSTING'],
                    'candidate_flags':['-DMVDB_MULTI_POSTING_REUSE_ONLY'],
                    'omitted_pairs':0,'trimmed_measurements':0},
    'ratio_definition':'B/C is the within-pair baseline/candidate elapsed-time ratio; >1 favors candidate. Side medians and paired-ratio medians need not have the same quotient.',
    'scenarios':{}, 'interpretation':{}, 'required_next_checks':[],
    'official_score':None,'production_defaults_changed':False,
}
for case,item in analysis['scenarios'].items():
    result['scenarios'][case]=compact(item)
    result['scenarios'][case].update({
        'by_seed':{s:compact(g) for s,g in item['by_seed'].items()},
        'by_order':{s:compact(g) for s,g in item['by_order'].items()},
        'by_seed_order_complete_in_analysis':True,
        'negative_pairs':item['negative_pairs'],
        'large_ratio_deviation_pairs':item['large_ratio_deviation_pairs'],
        'write_operation_pauses_over_10ms':item['write_operation_pauses_over_10ms'],
        'resources':{k:item['resources'][k] for k in resource_keys},
    })

result['interpretation']={
 'decision':
  'Proceed to the already planned actual-root-image 120-pair check with this gate as a candidate combination. This honors the requested first-query legacy algorithm. It is not a final default admission and does not establish zero overhead, a universal 16-read threshold or a competition score.',
 'mechanism_vs_timing':
  'The normal/sanitized diagnostic gates verify no compound planner/sample on the first successful query, later promotion, mutation/reopen resets and failure/budget fallback. They establish algorithm selection, not equality of elapsed time. Feature-specific PGO code layout and whole-process timing remain part of the measured treatment.',
 'q1_negative':
  'Four-cycle B/C median 0.9938678583 (range 0.9491174937-1.0257473130), with 9/15 regressions: candidate is about 0.62% longer by the median paired ratio. By seed 7319/8911/13337: 1.0061759320/0.9938678583/0.9848415307, negative counts 2/5,3/5,4/5. AB 0.9872109704 (6/8 negative), BA 1.0061759320 (3/7 negative). Order/seed direction changes prevent a robust q1 speedup claim.',
 'q16_primary':
  'Four-cycle B/C median 1.0234142395 (range 0.4146099096-2.6276753843), with 13/15 improvements. This is about 2.29% less elapsed time by the median paired ratio. By seed 7319/8911/13337: 1.0390768487/1.0483415750/1.0164165187, negative counts 0/5,1/5,1/5. AB 1.0234142395 (1/7 negative), BA 1.0303186157 (1/8 negative). Both execution-order strata and every seed have positive medians; all individual negatives remain.',
 'initial_and_post_write_first_query':
  'Initial first-query B/C is 0.9437715590 at q1 and 0.9411638607 at q16, with 11/15 and 12/15 negatives. Median paired added latency is 0.058536 ms and 0.068341 ms respectively. Four post-write first-query sums have B/C 0.9932035030/0.9904035865 and 9/15 negatives in each scenario; paired added sums are 0.473160/0.674426 ms. The tested old algorithm still has an observable small cost in these builds; do not call it free.',
 'promotion_and_steady_queries':
  'For q16, the second query after each write pays promotion: four-query sum baseline median 0.978518 ms versus candidate 3.811437 ms, B/C 0.2608874354 and 15/15 negatives. The mean over queries 2-16, including promotion, improves 1.2823781775, all 15 pairs. Queries 3-16 improve 2.0710611639, all 15 pairs. These are explanatory slices; the primary cycle/lifecycle totals retain first-query rebuilding, promotion, all reads and all writes.',
 'full_lifecycle_limits':
  'Measured lifecycle B/C q1 1.0163269963 (0.6297895346-1.4992241413, 3/15 negative), q16 1.0475586454 (0.3780223039-1.9214115624, 6/15 negative). q16 seed 13337 lifecycle median is 0.9997113059, despite positive cycles. Positive total medians do not overturn the q1 cycle/initial-query regressions or prove all workloads faster. Startup, ingest and restart variation is retained.',
 'large_pauses':
  'No values are removed. All seven observed write-operation delays above 10 ms are COMMIT, not BEGIN: baseline 26.973105,39.441015,37.638915,90.819345,42.975898 ms; candidate 64.958749 and120.170983 ms. Their counterparts are about 0.309-0.417 ms. There are no >10 ms BEGIN/UPDATE write operations in this report. Exact seed/pair/cycle identities and all phase deltas are retained. The report identifies the elapsed phase, not a proven scheduler, fsync or storage cause.',
 'resource_evidence':
  'Both scenarios have median sampled RSS delta +12,288 bytes (q1 range0..20,480, q16 8,192..20,480). HWM median deltas are +12,288/+8,192 bytes, with both signs in individual pairs. These are process observations, not exact posting allocations or cgroup peaks. Pre-shutdown CPU paired medians are 0 s at q1 and -0.01 s at q16, near the counter granularity; query-window CPU median delta is0 in both. Every paired rchar/syscr/read_bytes/write_bytes and final persistent byte count is identical; there is no measured IO reduction.',
 'scope':
  'Each scenario has 15 pairs from three seeds on one shared host. Four cycles and repeated queries within one process are not independent replications. The two tested read counts distinguish one-shot and repeated use but do not estimate a universal break-even count. The original PGO procedure is the same while each role has its own trained profile. There is no disk-cache eviction or formal competition evaluation.',
}
result['required_next_checks']=[
 'Validate the actual chosen root Docker image and immutable binary with the planned 120 pairs, protocol/TopK/UTF-8 and sanitizer gates; isolated feature tests cannot substitute for combination evidence.',
 'Carry the q1, initial-first-query and promotion negatives into conversation.json as assistant observations, separate from the user\'s actual prediction/judgment. Do not present q16-only benefit as zero-cost default safety.',
 'No additional threshold or independent optimization is required to interpret this confirmation. If the final actual-image comparison fails, use its predeclared rollback/disabled path rather than trimming these pauses.',
]
result['measurement_limits']=analysis['definitions']
destination=work/'filter-reuse-30-decision.json'
destination.write_text(json.dumps(result,indent=2,ensure_ascii=False,allow_nan=False)+'\n',encoding='utf-8')
print(json.dumps({'output':str(destination),'bytes':destination.stat().st_size,
                  'sha256':hashlib.sha256(destination.read_bytes()).hexdigest(),
                  'analysis_sha256':source_sha,'verified_pairs':30},indent=2))
