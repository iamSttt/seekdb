"""Independent read-only audit of the 12-pair no-fanout control, no DB execution.

Adapted from SHA256 7d81520ccada0a8302931c4e4edd26e9723b48fb1031c9524698f3706c8b1597.
The first control and its audit remain untouched. Expected artifact identity is
supplied from the GitHub artifact response, not inferred from its contents.
"""
import argparse
import hashlib
import json
import math
from pathlib import Path
from statistics import median
import subprocess
import zipfile

SOURCE = 'e020fdeb67dd8b64b77f0f8c2905f137f0112bba'
BINARY = 'acddca115ab183bfc6419e27c9e3383cfd1a9046e3897e5ea516cd7bc0f29f54'
CASES = ('standard10k', 'resident30k', 'filter60k', 'spill_high_q1', 'spill_high_q16', 'wide768')
LABELS = {'narrow_top10', 'wide_top10', 'narrow_large4096', 'wide_large4096', 'narrow_all', 'wide_all', 'wide_distance10'}


def require(ok, message):
    if not ok: raise ValueError(message)


def sha(path):
    h = hashlib.sha256()
    with path.open('rb') as f:
        for data in iter(lambda: f.read(1024 * 1024), b''): h.update(data)
    return h.hexdigest()


def read(path): return json.loads(path.read_bytes())


def values(run):
    if 'phase_seconds' in run:
        out = dict(run['phase_seconds'])
        for name, phase in run['query'].items():
            samples = phase['per_request_seconds']
            for label, subset in (('first', samples[:1]), ('front64', samples[:64]), ('after64', samples[64:])):
                if subset: out[name + '/' + label] = math.fsum(subset)
        return out
    return {**{'lifecycle/' + k: v for k, v in run['lifecycle_seconds'].items()},
        **{'query/' + k: v['wall_seconds'] for k, v in run['phases'].items()},
        'accounted_timer_sum': math.fsum(run['lifecycle_seconds'].values()) + math.fsum(p['wall_seconds'] for p in run['phases'].values())}


def kv(raw): return {p[0]: int(p[1]) for line in raw.splitlines() if len(p := line.split()) == 2}


def task_delta(start, end):
    old = {(t['tid'], t['starttime_ticks']): t['cpu_ticks'] for t in start['native_tasks']}
    ticks = sum(t['cpu_ticks'] - old.get((t['tid'], t['starttime_ticks']), 0) for t in end['native_tasks'] if not t['main'])
    return {'start_phase': start['phase'], 'end_phase': end['phase'],
        'interval_scope': 'Includes DB restart ID/payload verification before the timed query phase.' if start['phase'] == 'after_restart' else 'Post-index snapshot through completion of first query phase.',
        'cpu_usage_usec': kv(end['cpu.stat'])['usage_usec'] - kv(start['cpu.stat'])['usage_usec'],
        'nonmain_cpu_ticks_delta': ticks, 'clock_ticks_per_second': end['clock_ticks_per_second'],
        'nonmain_scope': 'May include parser work; observed alongside fanout decisions, not a named-query-worker-only counter.'}


def audit(root, repo, commit, zip_sha, zip_bytes):
    require(len(commit) == 40 and all(c in '0123456789abcdef' for c in commit), 'invalid expected commit')
    require(len(zip_sha) == 64 and all(c in '0123456789abcdef' for c in zip_sha), 'invalid expected artifact digest')
    require(sha(root.with_suffix('.zip')) == zip_sha and root.with_suffix('.zip').stat().st_size == zip_bytes, 'outer artifact differs')
    with zipfile.ZipFile(root.with_suffix('.zip')) as archive:
        names = archive.namelist()
        require(len(names) == len(set(names)), 'duplicate archive member')
        require(set(names) == {p.relative_to(root).as_posix() for p in root.rglob('*') if p.is_file()}, 'archive/extracted inventory mismatch')
        for name in names:
            path = (root / name).resolve()
            require(path.is_relative_to(root.resolve()) and path.is_file(), 'unsafe archive member')
            require(hashlib.sha256(archive.read(name)).hexdigest() == sha(path), 'archive/extracted bytes differ')
    inventory = read(root / 'hashes.json')['artifacts']
    require(len(inventory) == 15 and len({i['path'] for i in inventory}) == 15, 'wrong inventory')
    require({p.relative_to(root).as_posix() for p in root.rglob('*') if p.is_file()} == {i['path'] for i in inventory} | {'hashes.json'}, 'file set differs')
    for i in inventory:
        path = (root / i['path']).resolve()
        require(path.is_relative_to(root.resolve()) and path.stat().st_size == i['bytes'] and sha(path) == i['sha256'], 'member differs')
    require((root / 'harness-commit.txt').read_text().strip() == commit, 'wrong harness commit')
    require((root / 'stage.txt').read_text().strip() == 'complete', 'incomplete stage')
    report, summary, provenance = read(root / 'measurements.json'), read(root / 'summary.json'), read(root / 'retained/provenance.json')
    require(summary['status'] == report['status'] == 'passed' and summary['exit_code'] == 0 and
            report['completed_pairs'] == summary['completed_pairs'] == report['expected_pairs'] == 12, 'incomplete/failed run')
    require(summary['new_pgo_builds'] == provenance['new_pgo_builds'] == 0 and
            report['comparison_kind'] == 'same_binary_environment_control', 'wrong comparison')
    require(provenance['status'] == 'verified' and provenance['source_commit'] == SOURCE and provenance['binary_sha256'] == BINARY and
            provenance['harness_matches_git'] is True and provenance['harness_commit'] == commit and provenance['candidate_policy'] == 'no-fanout', 'provenance mismatch')
    require(sha(root / 'retained/submitted-source-minivec') == BINARY and sha(root / 'retained/prior-context.json') == provenance['retained_context_sha256'], 'retained program/context differs')
    for path, digest in provenance['harness_file_sha256'].items():
        blob = subprocess.check_output(['git', '-c', 'safe.directory=' + repo.as_posix(), '-C', str(repo), 'show', commit + ':' + path])
        require(hashlib.sha256(blob).hexdigest() == digest, 'Git harness mismatch: ' + path)
    expected_tools = {'minivec/tools/small_compute.py', 'minivec/tools/benchmark_iteration.py',
        'minivec/tools/benchmark_index_delta.py', 'minivec/tools/benchmark_write_query.py', 'minivec/tools/benchmark_projection.py',
        'minivec/tests/json_protocol.py', 'protocol_check/_transport.py', 'protocol_check/config.json'}
    actual_tools = {path.split('/seekdb/seekdb/', 1)[1]: digest for path, digest in report['tool_hashes'].items()}
    require(set(actual_tools) == expected_tools and all(provenance['harness_file_sha256'][path] == digest for path, digest in actual_tools.items()), 'actual imported tools differ from Git-bound inputs')
    require(report['launcher_sha256'] == sha(root / 'cgroup_exec'), 'actual launcher differs')
    launcher_lines = (root / 'launcher-sha256.txt').read_text().splitlines()
    require(len(launcher_lines) == 2 and launcher_lines[0].split()[0] == provenance['harness_file_sha256']['minivec/tools/cgroup_exec.c'] and
            launcher_lines[1].split()[0] == report['launcher_sha256'], 'launcher source/binary binding differs')
    for path, digest in provenance['source_and_training_sha256'].items():
        blob = subprocess.check_output(['git', '-c', 'safe.directory=' + repo.as_posix(), '-C', str(repo), 'show', SOURCE + ':' + path])
        require(hashlib.sha256(blob).hexdigest() == digest, 'Git source/training mismatch')
    require(report['identity_record_sha256'] == sha(root / 'retained/identities.json'), 'identity JSON changed')
    for role in ('baseline', 'candidate'):
        item = report['identities'][role]
        require(item['source_commit'] == SOURCE and item['binary_sha256'] == BINARY and
                item['evidence_sha256'] == sha(root / 'retained/provenance.json'), 'role identity differs')
        require(item['environment'] == ({} if role == 'baseline' else {'MVDB_QUERY_FANOUT_ROWS': '9223372036854775807'}), 'unexpected intervention')
    require(report['identities']['baseline']['binary'] == report['identities']['candidate']['binary'], 'control binary path differs')
    expected = [{'scenario': n, 'seed': 7319, 'pair_index': i, 'order': ['baseline', 'candidate'] if i == 0 else ['candidate', 'baseline']} for n in CASES for i in range(2)]
    require(report['plan'] == expected and [{k: p[k] for k in ('scenario', 'seed', 'pair_index', 'order')} for p in report['pairs']] == expected, '12 AB/BA identities differ')
    require(report['requested_limits'] == {'cpu_quota_us': 100000, 'cpu_period_us': 100000, 'memory_max': None, 'swap_max': None} and report['db_cpu'] == 0, 'resource envelope differs')
    require(0 in report['host']['driver_affinity'] and len(report['host']['driver_affinity']) >= 2, 'driver affinity unexpectedly restricted')
    derived, details = {}, []
    for p in report['pairs']:
        require(p['all_responses_identical'] is True, 'response equivalence absent')
        b, c = p['baseline'], p['candidate']
        row = {k: p[k] for k in ('scenario', 'seed', 'pair_index', 'order')}
        row['sides'] = {}
        for role, run in (('baseline', b), ('candidate', c)):
            g = run['cgroup']; adapter = run['adapter']; policy = run['thread_policy_observations']
            require(run['declared_environment'] == report['identities'][role]['environment'], 'actual declared intervention differs')
            require(g['before']['cpu.max'] == g['after']['cpu.max'] == '100000 100000' and
                    g['before']['memory.max'] == g['after']['memory.max'] == g['before']['memory.swap.max'] == g['after']['memory.swap.max'] == 'max', 'actual limits differ')
            require(not g['timeout'] and not g.get('cleanup_kill_required') and g['watchdog_error'] is None and
                    not g['request_timeout_observed'] and not any(g['oom_events_delta'].values()) and g['after']['cgroup.procs'] == '', 'resource/timeout failure')
            require(len(adapter['ready_memberships']) == (1 if p['scenario'] == 'wide768' else 2), 'ready/restart evidence incomplete')
            for ready in adapter['ready_memberships']:
                require(ready['pid'] in ready['members'] and ready['driver_pid'] not in ready['members'] and
                        ready['actual_exe'] == report['identities'][role]['binary'] and ready['cpus_allowed_list'] == '0', 'actual process binding differs')
            phases = adapter['phase_cgroups']
            require(len(phases) == (14 if p['scenario'] == 'wide768' else 15 if p['scenario'].startswith('spill_') else 7), 'phase resources incomplete')
            for phase in phases:
                require(not phase.get('native_tasks_error') and not phase.get('task_read_errors') and phase['native_tasks'] and
                        all(t['cpus_allowed_list'] == '0' for t in phase['native_tasks']), 'task evidence missing or affinity drift')
            cpu_before, cpu_after = kv(g['before']['cpu.stat']), kv(g['after']['cpu.stat'])
            require(g['resource_delta']['cpu_stat_delta'] == {k: v - cpu_before.get(k, 0) for k, v in cpu_after.items()} and
                    g['resource_delta']['memory_peak_bytes'] == int(g['after']['memory.peak']), 'resource arithmetic differs')
            by_phase = {x['phase']: x for x in phases}
            row['sides'][role] = {'resources': g['resource_delta'], 'policy': policy,
                'query_cpu': {end: task_delta(by_phase[start], by_phase[end]) for start, end in
                    (('after_index_build', 'query_before_update'), ('after_restart', 'query_after_restart'))
                    if start in by_phase and end in by_phase}}
            require(policy['stderr_complete'] is True and policy['requested_query_threads'] == 'automatic', 'policy evidence differs')
            wake_lines = [line for line in policy['fanout_log_lines'] if 'wake_us=' in line and '(measured, median of 200 handshakes)' in line]
            require(len(wake_lines) == len(adapter['ready_memberships']), 'startup calibration missing or not measured')
            if role == 'candidate':
                require(not any('-> 2 threads' in line for line in policy['fanout_log_lines']), 'no-fanout candidate selected parallel query')
                require(all(sum(not task['main'] for task in phase['native_tasks']) >= 1 for phase in phases if phase['phase'] != 'after_restart'), 'retained worker evidence missing after first SQL')
                # after_restart is before the first restarted SQL; execute_statement
                # performs the startup probe, so no worker is expected at that ready snapshot.
        if p['scenario'] == 'wide768':
            for run in (b, c):
                require(set(run['phases']) == LABELS and run['status'] == 'passed', 'wrong projection phases')
                for phase in run['phases'].values():
                    require(len(phase['requests']) == 3 and phase['wall_seconds'] == sum(r['seconds'] for r in phase['requests']) and phase['independent_oracle'], 'projection oracle/timers incomplete')
            for label in LABELS:
                require([(r['response_sha256'], r['response_bytes']) for r in b['phases'][label]['requests']] ==
                        [(r['response_sha256'], r['response_bytes']) for r in c['phases'][label]['requests']], 'projection output differs')
        else:
            require(b['response_sha256'] == c['response_sha256'], 'lifecycle response hash differs')
            for run in (b, c):
                if p['scenario'].startswith('spill_'):
                    require(run['real_spill_observed'] is True and run['correctness']['all_query_responses_independent_oracle'] is True, 'spill/oracle evidence incomplete')
                    require(len(run['write_cycles']) == 4 and len(run['query']) == 6 and
                            all(len(q['per_request_seconds']) == (16 if p['scenario'].endswith('q16') else 1) for q in run['query'].values()), 'write-query counts differ')
                else:
                    require(set(run['query']) == {'query_before_update', 'query_after_restart'} and
                            all(len(q['per_request_seconds']) == 1000 for q in run['query'].values()) and
                            run['correctness']['sampled_topk_oracle_queries'] == [0, 1, 999], 'iteration counts/oracle differ')
        bv, cv = values(b), values(c); require(set(bv) == set(cv), 'timing schema differs')
        for key in bv:
            require(math.isfinite(bv[key]) and math.isfinite(cv[key]) and bv[key] >= 0 and cv[key] > 0, 'invalid timer')
            derived.setdefault(p['scenario'], {}).setdefault(key, []).append({'pair_index': p['pair_index'], 'order': p['order'],
                'baseline_seconds': bv[key], 'candidate_seconds': cv[key], 'baseline_over_candidate': bv[key] / cv[key], 'candidate_slower': cv[key] > bv[key]})
        details.append(row)
    calculated = {name: {phase: {'raw_pairs': rows, 'median_baseline_over_candidate': median(r['baseline_over_candidate'] for r in rows),
                  'candidate_slower_pairs': sum(r['candidate_slower'] for r in rows)} for phase, rows in phases.items()} for name, phases in derived.items()}
    require(calculated == report['summary'], 'summary recomputation differs')
    return {'status': 'verified', 'verified_pairs': 12, 'harness_commit': commit, 'source_commit': SOURCE, 'binary_sha256': BINARY,
        'artifact_sha256': zip_sha, 'artifact_manifest_sha256': sha(root / 'hashes.json'), 'measurement_sha256': sha(root / 'measurements.json'),
        'artifact_files_verified': 15, 'summary': calculated, 'resources_and_policy': details, 'host': report['host'],
        'actual_cpu_model': (root / 'lscpu.txt').read_text(), 'requested_limits': report['requested_limits'],
        'ancestor_constraints': report['pairs'][0]['baseline']['cgroup']['ancestor_constraints'],
        'official_score': None, 'automatic_adoption': False, 'limitations': report['limitations'] + [
            'Independent reader verifies retained evidence and summaries; it does not rerun DB statements or reconstruct absent raw responses.',
            'One fixed seed with AB/BA two pairs cannot establish general performance or justify adoption; no-fanout retains worker allocation and startup calibration and changes the row threshold only.',
            'No throttling was observed in this diagnostic; one-CPU affinity is the operative scheduling restriction, not proof of official quota behavior.',
            'Spill q1 first-A wall-time outliers must remain visible; do not attribute its aggregate ratio to stable thread-policy improvement.']}


def main():
    p = argparse.ArgumentParser(description=__doc__); p.add_argument('--input', type=Path, required=True)
    p.add_argument('--repo', type=Path, default=Path(__file__).resolve().parent / 'seekdb'); p.add_argument('--output', type=Path, required=True)
    p.add_argument('--commit', required=True); p.add_argument('--artifact-sha256', required=True); p.add_argument('--artifact-bytes', type=int, required=True)
    args = p.parse_args(); require(not args.output.exists(), 'refuse overwrite')
    require(not args.output.resolve().is_relative_to(args.input.resolve()), 'analysis must not modify raw tree')
    result = audit(args.input.resolve(), args.repo.resolve(), args.commit, args.artifact_sha256, args.artifact_bytes)
    args.output.write_text(json.dumps(result, ensure_ascii=False, indent=2, allow_nan=False) + '\n', encoding='utf-8')
    print(json.dumps({'status': result['status'], 'verified_pairs': result['verified_pairs'], 'output': str(args.output)}))


if __name__ == '__main__': main()
