"""Independent failed-tool audit. Does not invoke the successful micro auditor."""
import ast, hashlib, json, sys, zipfile
from pathlib import Path
from types import SimpleNamespace

sys.dont_write_bytecode=True
import analyze_compensated_prototype as evidence

W=Path(__file__).resolve().parent;repo=W/'seekdb';root=W/'compensated-attempt1-raw'
archive=repo/'validation/iteration5-compensated-attempt1-raw.zip'
raw=archive.read_bytes()
assert len(raw)==2310807 and evidence.sha(raw)=='98ea4f92dd3cfa22763729a27ac1ad9d58b6f71f128f578e6a2cdf968e988bb4'
a=evidence.Archive(raw)
evidence.verify_archive(root,archive,evidence.sha(raw),len(raw))
assert len(a.inventory)==38
api=evidence.api(json.loads((W/'compensated-attempt1-api.json').read_bytes()),raw,evidence.COMMIT)
assert api['run_id']==43526884326 and api['artifact_id']==14085996291 and api['job_id']==132234734387 and api['job_conclusion']=='failure'
args=SimpleNamespace(repo=repo,commit=evidence.COMMIT,plan_sha256=evidence.PLAN_SHA,plan=repo/evidence.PLAN)
plan,files,manifest=evidence.sources(a,args)
s=a.json('results/summary.json')
assert s['status']=='failed_or_unsupported' and s['error']=="'native_compilation_completed'"
assert s['database_runs']==s['pgo_builds']==0
assert s['native_compilation_attempts']==1 and s['native_compilations_completed']==0
assert s['native_execution_attempts']==s['native_executions_completed']==0 and 'pairs' not in s
commands=s['commands']
assert [x['name'] for x in commands]==['compiler','compiler-version','cpu','fixture-generation','build-normal']
assert all(x['exit_code']==0 and x['status']=='completed' and type(x['pid']) is int and x['pid']>0 for x in commands)
assert [x['native_kind'] for x in commands]==[None,None,None,None,'compilation']
build=commands[-1]
assert build['argv']==['g++','-std=c++17','-ffp-contract=off','-fno-math-errno','-pthread','-O3','/prototype/test_compensated_distance.cpp','-o','/out/results/normal']
assert a.data('results/compiler-version.log').strip()==a.data('preflight-compiler-version.txt').strip()==b'13.3.0'
normal=a.data('results/normal')
assert normal[:6]==b'\x7fELF\x02\x01' and int.from_bytes(normal[18:20],'little')==62
assert len(normal)==103216
for name in ('normal.log','sanitized','sanitized.log','micro','build-sanitized.log','build-micro.log'):
    assert 'results/'+name not in a.inventory
assert not any(name.startswith('results/micro-') for name in a.inventory)
assert 'micro-disassembly.txt' not in a.inventory and 'resource-verification.json' not in a.inventory
assert a.json('ci-status.json')=={'exit_code':1,'database_runs':0,'pgo_builds':0,'container_builds':0}
assert a.json('runner-exit.json')=={'exit_code':1,'database_runs':0,'pgo_builds':0}
trace=a.data('run.log').decode()
assert "KeyError: 'native_compilation_completed'" in trace and "result['native_'+native_kind+'_completed'] += 1" in trace
source=files[evidence.PREFIX+'run_linux.py'].decode()
assert "'native_compilations_completed': 0" in source and "'native_executions_completed': 0" in source
assert "result['native_'+native_kind+'_completed'] += 1" in source
assert source.index("require(code == 0, name+' failed/unsupported; log retained')")<source.index("result['native_'+native_kind+'_completed'] += 1")
assert a.data('results/oracle.bin')==files[evidence.PREFIX+'oracle.bin'] and evidence.sha(a.data('results/oracle.bin'))==evidence.ORACLE
assert a.json('results/oracle.json')==json.loads(files[evidence.PREFIX+'oracle.json'])==s['oracle']==json.loads(a.data('results/fixture-generation.log'))
assert s['source_sha256']=={x['path']:x['sha256'] for x in manifest['files']}
assert s['source_proof']==json.loads(files[evidence.PREFIX+'source-proof.json'])
cpu=int(a.data('requested-cpu.txt'));before=a.json('resource-preflight.json');after=a.json('resource-postflight.json')
assert before['status']=='verified' and before['native_started'] is False and before['affinity']==[cpu]
assert after=={'status':'verified','runner_exit_code':1,'cpu.max':'100000 100000','memory.max':'2147483648','memory.swap.max':'0','affinity':[cpu]}
for where in ('preflight-','results/'):
    assert a.data(where+'cpu-max.txt').strip()==b'100000 100000'
    assert a.data(where+'memory-max.txt').strip()==b'2147483648' and a.data(where+'memory-swap-max.txt').strip()==b'0'
    status=dict(line.split(':',1) for line in a.data(where+'proc-status.txt').decode().splitlines() if ':' in line)
    assert status['Cpus_allowed_list'].strip()==str(cpu)
start,end,image=[a.json(name)[0] for name in ('container-start-inspect.json','container-final-inspect.json','tooling-image-inspect.json')]
assert start['Id']==end['Id']==a.data('container-id.txt').decode().strip() and start['Image']==end['Image']==image['Id']
assert 'gcc@'+evidence.IMAGE.split('@')[1] in image['RepoDigests']
assert end['State']['ExitCode']==1 and not end['State']['Running'] and not end['State']['OOMKilled']
for container in (start,end):
    host=container['HostConfig']
    assert host['NetworkMode']=='none' and host['CpusetCpus']==str(cpu) and host['NanoCpus']==1000000000
    assert host['Memory']==host['MemorySwap']==2147483648 and host['PidsLimit']==128
    mounts={x['Destination']:x for x in container['Mounts']}
    assert set(mounts)=={'/prototype','/out'} and mounts['/prototype']['RW'] is False and mounts['/out']['RW'] is True
    assert container['Config']['Cmd']==['bash','-c','set -euo pipefail; command -v python3; exec python3 /out/container-entry.py']

report={'status':'verified_runner_counter_key_failure_before_native_test_or_performance','api_binding':api,
 'raw_archive':{'path':'validation/iteration5-compensated-attempt1-raw.zip','bytes':len(raw),'sha256':evidence.sha(raw),'members':len(a.inventory)},
 'source_commit':evidence.COMMIT,'plan_sha256':evidence.PLAN_SHA,'source_inputs_verified':len(files),
 'failure':{'type':'KeyError','key':'native_compilation_completed','location':'run_linux.py run(): successful compiler returned, then singular completed-key increment failed',
   'initialized_keys':['native_compilations_completed','native_executions_completed'],
   'expression':"result['native_'+native_kind+'_completed'] += 1",'execution_kind_has_same_unreached_key_bug':True},
 'recorded_summary_counters':{key:s[key] for key in ('native_compilation_attempts','native_compilations_completed','native_execution_attempts','native_executions_completed')},
 'independently_reconstructed_execution':{'native_compilations_attempted':1,'native_compilations_completed':1,'native_test_executions':0,'native_micro_executions':0,
    'performance_pairs':0,'database_runs':0,'PGO_builds':0,'fixture_generator_runs':1,
    'evidence':'build-normal completed command exit0 plus actual x86-64 ELF; frozen runner fails at the immediately following bookkeeping increment, before normal test launch.'},
 'normal_ELF':{'path':'results/normal','bytes':len(normal),'sha256':evidence.sha(normal),'executed':False},
 'compiler_warning_log':{'path':'results/build-normal.log','sha256':evidence.sha(a.data('results/build-normal.log')),
    'scope':'Original reference emits a loop-optimization warning for a hypothetical enormous index. Warning preserved; no native correctness assertion was run.'},
 'oracle':{'binary_sha256':evidence.ORACLE,'cases':7842,'binary_bytes_equal_frozen':True,'metadata_objects_equal':True,
    'frozen_metadata_bytes':len(files[evidence.PREFIX+'oracle.json']),'Linux_metadata_bytes':len(a.data('results/oracle.json')),
    'metadata_difference':'CRLF versus LF serialization only; decoded objects identical. This audit does not regenerate fixtures or rerun their numeric oracle.'},
 'resources':{'cpu':cpu,'cpu_max':[100000,100000],'memory_max':2147483648,'swap_max':0,'before_and_after_verified':True,'container_exit_code':1,'OOMKilled':False,'image_id':image['Id']},
 'algorithm_correctness_result':None,'performance_result':None,'default_adopted':False,'formal_submission':False,
 'raw_summary_modified':False,'repository_modified':False,'reader_native_or_DB_runs':0,
 'limitations':['Compilation success is not a native test pass. No speed, rejection or algorithm-correctness conclusion follows.',
    'Reported zero completed compilations is retained verbatim and separately reconciled; no raw field was rewritten.',
    'Only the provided jobs API page is verified; global workflow pagination is not asserted.']}
report_path=W/'compensated-attempt1-independent-audit.json';assert not report_path.exists()
report_path.write_text(json.dumps(report,indent=2)+'\n',encoding='utf-8')
names=['compensated-attempt1-independent-audit.json','compensated-attempt1-api.json','audit_compensated_attempt1.py']
members={name:(W/name).read_bytes() for name in names}
pending=['analyze_compensated_prototype'];seen=set()
while pending:
    name=pending.pop();path=W/(name+'.py')
    if name in seen or not path.is_file():continue
    seen.add(name);members['readers/'+path.name]=path.read_bytes()
    for node in ast.walk(ast.parse(path.read_bytes())):
        mods=[x.name for x in node.names] if isinstance(node,ast.Import) else [node.module] if isinstance(node,ast.ImportFrom) and node.module else []
        pending.extend(n.split('.')[0] for n in mods if (W/(n.split('.')[0]+'.py')).is_file())
for path in ('run.log','results/summary.json','results/build-normal.log','resource-preflight.json','resource-postflight.json','ci-status.json'):
    members['raw-selected/'+path]=a.data(path)
members['source/run_linux.py']=files[evidence.PREFIX+'run_linux.py']
manifest_out={'source_commit':evidence.COMMIT,'raw_archive':report['raw_archive'],'members':[{'path':name,'bytes':len(data),'sha256':evidence.sha(data)} for name,data in sorted(members.items())]}
members['manifest.json']=(json.dumps(manifest_out,indent=2)+'\n').encode()
auditzip=W/'compensated-attempt1-independent-audit.zip';assert not auditzip.exists()
with zipfile.ZipFile(auditzip,'w',compression=zipfile.ZIP_DEFLATED,compresslevel=9) as z:
    for name,data in sorted(members.items()):z.writestr(name,data)
with zipfile.ZipFile(auditzip) as z:assert set(z.namelist())==set(members) and all(z.read(name)==data for name,data in members.items())
receipt={'status':'packaged_verified_failed_attempt','path':str(auditzip),'bytes':auditzip.stat().st_size,'sha256':evidence.sha(auditzip.read_bytes()),'members':len(members),
 'audit_json_sha256':evidence.sha(report_path.read_bytes()),'actual_completed_compilations':1,'native_test_executions':0,'performance_pairs':0,'reader_native_DB_runs':0}
(W/'compensated-attempt1-independent-audit-receipt.json').write_text(json.dumps(receipt,indent=2)+'\n',encoding='utf-8')
print(json.dumps(receipt))
