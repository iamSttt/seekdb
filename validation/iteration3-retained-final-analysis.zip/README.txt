Real120-pair analysis; raw artifact is archived separately byte-for-byte from GitHub.
Raw GitHub artifact SHA256 matches the GitHub metadata digest. All29 final-performance manifest entries and137 candidate Git source files verified.
Analysis is read-only and does not re-run the Linux oracle or rebuild an image. Stats preserve raw integers; timing ratios are floating point.
To rerun analyzer, place scripts in a work directory with a sibling seekdb clone, extract raw artifact to a directory, and pass --input, --candidate-commit and --expected-feature-flags explicitly.
