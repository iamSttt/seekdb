"""Derive new work-only readers without changing any half reader or evidence."""
import ast, hashlib
from pathlib import Path

w = Path(__file__).resolve().parent
half = 'bdcc9e587677b91c0e57a0da8dd63eda7160c62fb9121e22cf5db19d243bf7c7'
quarter = 'cfd6d6a2b111b2f9c72081bd33ba481343d375adb3b01405077e88516875284a'

def write(name, data):
    target = w / name
    assert not target.exists(), 'do not overwrite ' + name
    ast.parse(data)
    target.write_text(data, encoding='utf-8', newline='\n')

data = (w / 'tighter_v2_oracle_reader.py').read_text(encoding='utf-8')
data = data.replace('Independent v2 L2 projection and actual-ELF tighter-certificate checks.',
                    'Independent v2 L2 projection checks for the separate quarter candidate.')
data = data.replace("MICRO_COMMIT = 'ff7f4c414e2717dc7f1de4786af6270a1a606745'", "MICRO_COMMIT = '001aa6b279f3c1244a7b8dc01c5c7fcbd9cc455e'")
data = data.replace(half, quarter)
data = data.replace('259b4cc06b2b5aaa0baf0680f5d60a4eacde48b26ea3225580fe250af66b761e', '602bff53962b8b1711f1d2ee67431856c97e9d131e97b9a925bb0d400c7e1c70')
verify = (w / 'quarter-root-conditional-draft/minivec/tools/verify_tighter_root.py').read_bytes()
assert quarter.encode() in verify and half.encode() not in verify
data = data.replace('872895e235ff383e24ee3d3e5684a41d76f1ece1559ac01bd36d7ed748f07915', hashlib.sha256(verify).hexdigest())
write('quarter_v2_oracle_reader.py', data)

data = (w / 'evaluate_tighter_primary24_v2_screen.py').read_text(encoding='utf-8')
data = data.replace("PREREG_SHA='a771368b7b35be94b579c6c0747e72710e6a1977fce30024af3bce88552ed594'", "PREREG_SHA='5553f14dfac2be87843727b304e8903676e1d61dd15e27cc083ac84567e70587'")
data = data.replace('tighter-certificate-highest-primary24', 'quarter-plus-margin-highest-primary24')
data = data.replace("    retained.require(hashlib.sha256(policy_raw).hexdigest()==POLICY_SHA,'new clear-gain policy drift')", "    retained.require(PREREG_SHA is not None and preregistration_sha256==PREREG_SHA,'quarter preregistration not frozen or mismatched')\n    retained.require(hashlib.sha256(policy_raw).hexdigest()==POLICY_SHA,'new clear-gain policy drift')")
write('evaluate_quarter_primary24_screen.py', data)

data = (w / 'analyze_tighter_primary_v2_root.py').read_text(encoding='utf-8')
data = data.replace('isolated tighter certificate highest-primary24_v1.', 'separate quarter-plus-margin highest-primary24_v1.')
data = data.replace("CANDIDATE_COMMIT = '7bab1e96c6783ee5398028d5dc8843dad739b425'", "CANDIDATE_COMMIT = '9a291b478d160308813d37698f771249d5c9bbbd'")
data = data.replace('validation/iteration5-tighter-certificate-primary24-oracle-v2-preregistration.json', 'validation/iteration5-quarter-margin-primary24-preregistration.json')
data = data.replace('tighter-certificate-highest-primary24', 'quarter-plus-margin-highest-primary24')
data = data.replace('evaluate_tighter_primary24_v2_screen', 'evaluate_quarter_primary24_screen')
data = data.replace('from tighter_reader_v2_gates import', 'from quarter_reader_gates import')
data = data.replace('The isolated tighter certificate is compared directly', 'The quarter-plus-margin certificate is compared directly')
data = data.replace('This is a fresh isolated tighter-certificate screen, not confirmation or adoption.', 'This is a fresh quarter-candidate screen, not a rerun of the half-v1 oracle failure, confirmation, or adoption.')
data = data.replace("        'Workload generators are repeated in Python only;", "        'Prior half-v1 failure and half-v2 rejection are historical evidence only. The new quarter multiply can set FE_INEXACT and does not claim sticky-status equivalence.',\n        'Workload generators are repeated in Python only;")
data = data.replace('# Runtime guard is imported from independent batch8_reader_gates.', '# Runtime guard is imported from the separate quarter_reader_gates.')
data = data.replace('def audit(args):\n', "def audit(args):\n    require(CANDIDATE_COMMIT is not None and screen.PREREG_SHA is not None, 'quarter root commit/plan not frozen')\n")
write('analyze_quarter_primary_root.py', data)
print('Prepared three independent quarter reader modules; commit/plan binding pending.')
