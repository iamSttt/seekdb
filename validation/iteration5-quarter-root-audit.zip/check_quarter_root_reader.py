"""Necessary source/identity preflight; no fixture generation or native execution."""
import ast, hashlib, json, sys
from pathlib import Path
from types import SimpleNamespace

sys.dont_write_bytecode = True
w = Path(__file__).resolve().parent
checks = []

def check(name, value):
    if not value: raise AssertionError(name)
    checks.append(name)

def functions(name):
    return {node.name: ast.dump(node) for node in ast.parse((w / name).read_bytes()).body if isinstance(node, ast.FunctionDef)}

old = functions('analyze_tighter_primary_v2_root.py')
new = functions('analyze_quarter_primary_root.py')
for name in ('plan','elf','clear_generator_modules','historical_ee','metrics','extra_summary','collector_default','gate_artifacts',
             'quantizer_gate','source_equivalence_gates','crc_regression_unit','screen_input','training_log','verify_highest_measurements'):
    check(name + ' unchanged from half-v2 measurement reader', new[name] == old[name])
old_oracle = functions('tighter_v2_oracle_reader.py')
new_oracle = functions('quarter_v2_oracle_reader.py')
for name in ('integer_sqrt_projection_bits','independently_expected','verify_tighter_gate'):
    check(name + ' unchanged from reviewed independent v2 oracle', new_oracle[name] == old_oracle[name])
for name in ('analyze_quarter_primary_root.py','quarter_reader_gates.py','quarter_v2_oracle_reader.py','evaluate_quarter_primary24_screen.py'):
    ast.parse((w / name).read_bytes());check(name + ' Python AST', True)
old_screen = ast.parse((w / 'evaluate_tighter_primary24_v2_screen.py').read_bytes())
new_screen = ast.parse((w / 'evaluate_quarter_primary24_screen.py').read_bytes())
old_fn = next(x for x in old_screen.body if isinstance(x,ast.FunctionDef) and x.name == 'evaluate_screen')
new_fn = next(x for x in new_screen.body if isinstance(x,ast.FunctionDef) and x.name == 'evaluate_screen')
check('clear-gain arithmetic unchanged except new fail-closed plan guard',
      ast.dump(ast.Module(body=new_fn.body[1:],type_ignores=[])) == ast.dump(ast.Module(body=old_fn.body,type_ignores=[])))
import analyze_quarter_primary_root as reader
import quarter_reader_gates as guards
import evaluate_quarter_primary24_screen as screen
if reader.CANDIDATE_COMMIT is None:
    try:
        reader.audit(SimpleNamespace())
    except ValueError as exc:
        check('unbound reader refuses before opening evidence', 'not frozen' in str(exc))
    else:
        raise AssertionError('unbound reader accepted')
    source_proof = None
else:
    check('plan pin shared by reader, runtime guard and screen', reader.PREREG_PATH == guards.PREREG and guards.PREREG_SHA == screen.PREREG_SHA)
    source_proof = guards.runtime_guard(w / 'seekdb', reader.CANDIDATE_COMMIT)
    check('committed source guard passed', source_proof['production_matches_screened_micro_candidate'] is True)
report = {'status':'passed_static_and_source_preflight_only','checks':checks,'check_count':len(checks),
          'commit':reader.CANDIDATE_COMMIT,'plan_sha256':screen.PREREG_SHA,'runtime_source_proof':source_proof,
          'new_native_runs':0,'new_DB_runs':0,'new_performance_pairs':0,'current_result_artifact_read':False,
          'reader_files':{name:hashlib.sha256((w/name).read_bytes()).hexdigest() for name in
              ('analyze_quarter_primary_root.py','quarter_reader_gates.py','quarter_v2_oracle_reader.py','evaluate_quarter_primary24_screen.py')}}
out = w / ('quarter-root-reader-commit-preflight.json' if reader.CANDIDATE_COMMIT else 'quarter-root-reader-static-preflight.json')
assert not out.exists(), 'refuse overwrite prior preflight'
out.write_text(json.dumps(report,indent=2) + '\n', encoding='utf-8')
print(json.dumps({'status':report['status'],'check_count':len(checks),'commit':reader.CANDIDATE_COMMIT,'native_DB_runs':0}))
