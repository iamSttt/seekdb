"""New quarter candidate identity guard; historical half evidence is never a rerun.

Reads committed inputs and immutable evidence only. No native or DB execution.
"""
import hashlib
import io
import json
import zipfile

from analyze_crc_root import require, digest, git, blob, safe_name
from quarter_v2_oracle_reader import (verify_tighter_gate, independently_expected,
    REFERENCE, MICRO_COMMIT, PRODUCTION_SHA, REFERENCE_SHA, MANIFEST_SHA,
    GATE_SOURCE_HASHES, EXPECTED)

PREREG = 'validation/iteration5-quarter-margin-primary24-preregistration.json'
PREREG_SHA = '5553f14dfac2be87843727b304e8903676e1d61dd15e27cc083ac84567e70587'
SOURCE_SNAPSHOT_COUNT = 97
EXPERIMENT = 'quarter-plus-margin-highest-primary24'
HALF_HEADER = 'bdcc9e587677b91c0e57a0da8dd63eda7160c62fb9121e22cf5db19d243bf7c7'
MICRO_PREFIX = 'minivec/tools/quarter_margin/'
MICRO_RAW = ('validation/iteration5-quarter-margin-raw.zip', 2808622, '04cb55eaf78e489fa52bf0910c039eb10fa406942deedc20171e411f75e54877')
MICRO_AUDIT = ('validation/iteration5-quarter-margin-audit.zip', 87007, '23f30937d128db4b1ed8b6b1347dd4a89fbc09f8d0bc628a6a742f4a02846e39')
MICRO_ANALYSIS_SHA = 'a864e85a39babecfc67562b51e9dbcc9a45457ce75c2047951c4694059c5a947'
MICRO_DECISION_SHA = '62e0585dc2775fc143e542302d3ce9579ccb05f964b83492440b06b17c7074ed'


def committed_artifact(repo, commit, identity):
    path, size, expected = identity
    data = blob(repo, commit, path)
    require(len(data) == size and digest(data) == expected, 'immutable evidence differs: ' + path)
    return data


def micro_admission(repo, commit, admission):
    raw = committed_artifact(repo, commit, MICRO_RAW)
    audit = committed_artifact(repo, commit, MICRO_AUDIT)
    with zipfile.ZipFile(io.BytesIO(audit)) as z:
        names = z.namelist()
        require(len(names) == len(set(names)) == 23, 'micro audit inventory differs')
        for name in names:
            safe_name(name)
        manifest = json.loads(z.read('audit-manifest.json'))
        require(set(manifest['files']) == set(names) - {'audit-manifest.json'}, 'micro audit manifest inventory differs')
        for name, item in manifest['files'].items():
            data = z.read(name)
            require(len(data) == item['bytes'] and digest(data) == item['sha256'], 'micro audit member differs')
        analysis_raw = z.read('quarter-margin-independent-analysis.json')
        decision_raw = z.read('quarter-margin-independent-decision.json')
        require(digest(analysis_raw) == MICRO_ANALYSIS_SHA and digest(decision_raw) == MICRO_DECISION_SHA, 'independent micro decision differs')
        analysis, decision = json.loads(analysis_raw), json.loads(decision_raw)
    binding = analysis['api_binding']
    require(binding['commit'] == MICRO_COMMIT and binding['run_id'] == 43522172103 and binding['artifact_id'] == 14084205394 and
            binding['artifact_sha256'] == digest(raw) and binding['artifact_bytes'] == len(raw), 'micro API/raw binding differs')
    require(analysis['status'] == 'verified_micro_evidence' and
            analysis['experiment_id'] == 'quarter-plus-margin-standalone-v1' and
            decision['decision'] == 'mechanism_screen_passed_DB_investigation_only' and
            decision['default_adopted'] is False and decision['official_submission_recommended'] is False and
            decision['negative_pair_metric_count'] == 8 and len(decision['all_negative_pair_metrics']) == 8 and
            decision['database_runs'] == decision['PGO_builds'] == 0, 'micro screen/adoption/history scope differs')
    with zipfile.ZipFile(io.BytesIO(raw)) as z:
        summary = json.loads(z.read('results/summary.json'))
        require(summary['source_proof']['candidate_sha256'] == PRODUCTION_SHA and
                summary['experiment_id'] == analysis['experiment_id'], 'micro actual candidate identity differs')
        binary_sha = {name: digest(z.read('results/' + name)) for name in ('normal', 'sanitized', 'diagnostic', 'micro')}
        require(binary_sha == summary['binary_sha256'] == analysis['native_evidence']['binary_sha256'], 'micro actual ELF differs')
    require(admission['required'] is True and admission['current_status'] == 'independent_micro_screen_passed_admits_only_one_new_root_screen' and
            admission['source_commit'] == MICRO_COMMIT and admission['frozen_manifest_sha256'] == MANIFEST_SHA, 'plan micro admission scope differs')
    preceding_plan = admission['preregistration']
    preceding_raw = blob(repo, commit, preceding_plan['path'])
    require(preceding_raw == blob(repo, MICRO_COMMIT, preceding_plan['path']) and len(preceding_raw) == preceding_plan['bytes'] == 12142 and
            digest(preceding_raw) == preceding_plan['sha256'] == 'e9a4ca2acd6b1174d6c9e8460d82881981270d201b679004b6f4c4048916feb8', 'micro original plan differs')
    evidence = admission['evidence']
    for key, identity in (('raw_archive', MICRO_RAW), ('audit_archive', MICRO_AUDIT)):
        require(evidence[key] == dict(zip(('path','bytes','sha256'), identity)), 'plan micro archive identity differs')
    require(evidence['analysis_member'] == {'name':'quarter-margin-independent-analysis.json','bytes':len(analysis_raw),'sha256':MICRO_ANALYSIS_SHA} and
            evidence['decision_member'] == {'name':'quarter-margin-independent-decision.json','bytes':len(decision_raw),'sha256':MICRO_DECISION_SHA} and
            evidence['API_binding'] == binding and evidence['actual_micro_ELF_sha256'] == binary_sha and
            evidence['decision'] == decision['decision'] and evidence['micro_pair_count'] == 12 and
            evidence['normal_sanitized_checks_each'] == 11452601 and evidence['negative_pair_metric_count'] == 8, 'plan micro result differs from immutable audit')
    return {'source_commit': MICRO_COMMIT, 'production_header_sha256': PRODUCTION_SHA,
        'raw_archive': {'path': MICRO_RAW[0], 'bytes': len(raw), 'sha256': digest(raw)},
        'independent_audit': {'path': MICRO_AUDIT[0], 'bytes': len(audit), 'sha256': digest(audit)},
        'analysis_sha256': MICRO_ANALYSIS_SHA, 'decision_sha256': MICRO_DECISION_SHA,
        'actual_micro_binary_sha256': binary_sha, 'negative_pair_metric_count': 8,
        'scope': 'Previously verified standalone screen permits investigation only. No historical ratios are combined with this root result.'}


def historical_half(repo, commit):
    erratum_path = 'validation/iteration5-tighter-certificate-oracle-v2-erratum.json'
    erratum = blob(repo, commit, erratum_path)
    require(digest(erratum) == '065ecb255183d61ac25008132043cc5b69feb387ef153e2a98e15efcc85cea63', 'historical v1 erratum changed')
    failure = json.loads(erratum)['failed_attempt']
    require(failure['commit'] == 'd767915b4aa816cb2720947ffcbe681819aa6036' and failure['root_PGO_builds_completed'] == 1 and
            failure['DB_execution_occurred'] is True and failure['performance_pairs'] == 0, 'old failure was reclassified')
    committed_artifact(repo, commit, (failure['raw'], failure['raw_bytes'], failure['raw_sha256']))
    committed_artifact(repo, commit, ('validation/iteration5-tighter-only-v2-raw.zip', 3746136, '8a044ae1b3372a462c501ea2570af491cfb7fdde4bedbd9c619762f0ae2c7b89'))
    archive = committed_artifact(repo, commit, ('validation/iteration5-tighter-only-v2-audit.zip', 236373, '3897556aa997f541063edd1f928fa9e328bed1ed1f43c17570863a1ffa3ddd1b'))
    with zipfile.ZipFile(io.BytesIO(archive)) as z:
        old = json.loads(z.read('tighter-only-v2-independent-decision.json'))
    require(old['commit'] == '7bab1e96c6783ee5398028d5dc8843dad739b425' and old['status'] == 'rejected_by_frozen_screen_keep_R' and
            old['adopted'] is False and old['eligible_for_confirmation'] is False, 'old half rejection was reclassified')
    return {'half_v1_failure': failure, 'half_v2_status': old['status'], 'half_v2_adopted': False,
        'scope': 'Historical records only. Quarter is a separate candidate, not a v1 tool-correction retry or half confirmation.'}


def runtime_guard(repo, commit):
    require(PREREG_SHA is not None and SOURCE_SNAPSHOT_COUNT > 0, 'quarter preregistration not yet frozen')
    inventories = []
    for rev in (REFERENCE, commit):
        paths = git(repo, 'ls-tree', '-r', '--name-only', rev, '--', 'minivec/src').decode().splitlines()
        inventories.append({p: digest(blob(repo, rev, p)) for p in paths})
    before, after = inventories
    require(set(after) - set(before) == {'minivec/src/quantized_batch8.h'} and not set(before) - set(after), 'unexpected runtime inventory change')
    changed = sorted(p for p in before if before[p] != after[p])
    require(changed == ['minivec/src/distance.h'], 'runtime delta exceeds isolated quarter certificate')
    for path in after:
        if path == 'minivec/src/quantized_batch8.h':
            require(blob(repo, commit, path) == blob(repo, MICRO_COMMIT, path), 'inactive archived header changed')
            continue
        source = blob(repo, commit, path)
        require(b'quantized_batch8.h' not in source and b'MVDB_ENABLE_BATCH8_QUANTIZED' not in source, 'inactive batch8 header referenced: ' + path)
    production = blob(repo, commit, 'minivec/src/distance.h')
    require(digest(production) == PRODUCTION_SHA and production == blob(repo, commit, MICRO_PREFIX + 'candidate_distance.h') ==
            blob(repo, MICRO_COMMIT, MICRO_PREFIX + 'candidate_distance.h'), 'production is not exact screened quarter candidate')
    require(digest(blob(repo, REFERENCE, 'minivec/src/distance.h')) == REFERENCE_SHA, 'R reference differs')
    require(digest(blob(repo, commit, 'minivec/tools/tighter_bound/candidate_distance.h')) == HALF_HEADER,
            'historical half source altered or substituted')
    for path in ('Dockerfile', '.dockerignore', 'minivec/Makefile', 'minivec/tools/pgo/train.cpp', 'minivec/tools/pgo/run-training.sh'):
        require(blob(repo, REFERENCE, path) == blob(repo, commit, path), 'build/training drift: ' + path)
    require(git(repo, 'ls-tree', '-r', REFERENCE, '--', 'minivec/third_party') ==
            git(repo, 'ls-tree', '-r', commit, '--', 'minivec/third_party'), 'third-party drift')
    raw = blob(repo, commit, PREREG)
    require(digest(raw) == PREREG_SHA, 'quarter preregistration SHA differs')
    plan = json.loads(raw)
    require(plan['experiment_id'] == EXPERIMENT and plan['fixed_plan']['measurement_family'] == 'highest_primary24_v1' and
            plan['fixed_plan']['seed'] == 7319 and plan['fixed_plan']['pairs'] == 24 and plan['protocol_revision'] == 2 and
            plan['execution'] == {'quarter_root_PGO_builds_executed': 0, 'quarter_root_database_pairs_executed': 0,
                'default_adopted': False, 'assistant_formal_submissions': 0, 'confirmation19087_enabled': False}, 'new quarter plan scope differs')
    require(plan['candidate']['runtime_delta_files'] == changed and plan['candidate']['production_header_sha256'] == PRODUCTION_SHA and
            plan['candidate']['candidate_origin'] == {'source_commit': MICRO_COMMIT, 'path': MICRO_PREFIX + 'candidate_distance.h', 'sha256': PRODUCTION_SHA}, 'quarter origin differs')
    require(len(plan['source_snapshot']) == SOURCE_SNAPSHOT_COUNT and plan['planned_gate_inventory']['root_gate_groups'] == 22 and
            plan['planned_gate_inventory']['tighter_case_inventory'] == EXPECTED, 'source/gate inventory differs')
    acquire = plan['environment_acquisition']
    require(acquire['maximum_total_attempts'] == 1 and acquire['retry_only_if'] == 'None preauthorized for this screen.' and
            'native ISA choice' in acquire['no_retry_for'], 'unplanned environment selection/retry')
    for path, item in plan['source_snapshot'].items():
        safe_name(path); data = blob(repo, commit, path)
        oid = hashlib.sha1(b'blob ' + str(len(data)).encode() + b'\0' + data).hexdigest()
        require(item == {'bytes': len(data), 'sha256': digest(data), 'git_blob': oid}, 'committed source pin differs: ' + path)
    for path, expected in GATE_SOURCE_HASHES.items():
        require(digest(blob(repo, commit, path)) == expected, 'reviewed v2 oracle source changed: ' + path)
    manifest_raw = blob(repo, commit, MICRO_PREFIX + 'handoff-manifest.json')
    require(digest(manifest_raw) == MANIFEST_SHA, 'screened quarter manifest differs')
    members = json.loads(manifest_raw)['files']
    require(len(members) == len({x['path'] for x in members}) == 23, 'quarter package inventory differs')
    for item in members:
        safe_name(item['path']); path = MICRO_PREFIX + item['path']; data = blob(repo, commit, path)
        require(len(data) == item['bytes'] and digest(data) == item['sha256'] and data == blob(repo, MICRO_COMMIT, path), 'screened quarter member drift: ' + path)
    micro = micro_admission(repo, commit, plan['conditional_micro_admission'])
    history = historical_half(repo, commit)
    return {'retained_source': REFERENCE, 'changed_runtime_files': changed,
        'inactive_historical_header': 'minivec/src/quantized_batch8.h', 'inactive_header_not_referenced': True,
        'candidate_sha256': {'minivec/src/distance.h': PRODUCTION_SHA}, 'source_snapshot_verified_count': SOURCE_SNAPSHOT_COUNT,
        'unchanged_training': True, 'root_Docker_delta': 'None; exact retained R Docker and four feature flags',
        'production_matches_screened_micro_candidate': True, 'screened_micro_source': MICRO_COMMIT,
        'micro_manifest_sha256': MANIFEST_SHA, 'micro_manifest_members_verified': 23, 'accepted_micro_evidence': micro,
        'native_ISA_scope': 'Original dispatch; no overrides, environment selection or ISA-based retry.',
        'historical_half_evidence': history, 'oracle_protocol_revision': 2,
        'fenv_scope': 'FP controls unchanged; additional multiplication may set FE_INEXACT, so sticky-status equivalence is not claimed.'}
