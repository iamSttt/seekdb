"""Independent v2 L2 projection checks for the separate quarter candidate.

Only Python fixture/oracle generation executes. Never starts a DB or compiler.
Current artifact files are required as-is, never reconstructed.
"""
from fractions import Fraction
import hashlib
import importlib.util
import json
import math
from pathlib import Path
import re
import struct
import sys
import tempfile

from analyze_crc_root import require, digest, sha, read, git, blob, safe_name

REFERENCE = '33a52a7dd4426af059ec2334b7c93a07c38c93c9'
MICRO_COMMIT = '001aa6b279f3c1244a7b8dc01c5c7fcbd9cc455e'
PRODUCTION_SHA = 'cfd6d6a2b111b2f9c72081bd33ba481343d375adb3b01405077e88516875284a'
REFERENCE_SHA = '7094c0892de1b56377a65675a119a942cd07959f22e128673738c6c953fc1fe9'
MANIFEST_SHA = '602bff53962b8b1711f1d2ee67431856c97e9d131e97b9a925bb0d400c7e1c70'
ORACLE_SHA = '74e1b99088943e073b5f4821844aabc7001a500ae2af9ef0c7dc309d8ed6262e'
EXPECTED_CHECKS = 11452601
KINDS = ('unindexed_all', 'indexed_top1', 'indexed_top10', 'indexed_rescue_filter', 'indexed_near_tie', 'indexed_extreme')
EXPECTED = [f'{path}_d{dimension}_{kind}' for dimension in (128,512)
            for path in ('serial','fanout') for kind in KINDS]
GATE_SOURCE_HASHES = {
 'minivec/tests/test_tighter_certificate.cpp':'b88d4cebad509dd157fcbb84a72af657e02b659e9da22c46835473901c01c532',
 'minivec/tests/tighter_certificate_comparison.h':'b445fada8862eca087758602df439aacf152f03781f0ac71aaa3c059362b0192',
 'minivec/tests/tighter_certificate_reference_distance.h':REFERENCE_SHA,
 'minivec/tests/test_tighter_certificate_db.py':'dce8ceca45e5c55effcae56b5ebebf7f05666faeb564733cfab9624c89f4a94f',
 'minivec/tools/verify_tighter_root.py':'95abe5275586f476a01fb27dead19de1139ab3ffe64734896f610b524647fe6b'}


PROJECTION_SEMANTICS='RN-even binary64 sqrt of canonical squared distance; ranking uses canonical squared distance then primary key'


def integer_sqrt_projection_bits(squared):
    """Independent isqrt grid oracle, distinct from gate's Fraction bit search."""
    require(type(squared) is float and math.isfinite(squared) and squared>=0,'invalid canonical squared value')
    if squared==0:return '0000000000000000'
    numerator,denominator=squared.as_integer_ratio()
    require(denominator&(denominator-1)==0,'non-dyadic canonical double')
    exponent=(numerator.bit_length()-denominator.bit_length())//2
    shift=exponent-52
    if shift>=0: a,b=numerator,denominator<<(2*shift)
    else: a,b=numerator<<(-2*shift),denominator
    q=math.isqrt(a//b)
    require((1<<52)<=q<(1<<53),'sqrt grid mantissa out of range')
    comparison=4*a-b*(2*q+1)**2
    if comparison>0 or (comparison==0 and q%2):q+=1
    if q==1<<53:q>>=1;exponent+=1
    require(-1022<=exponent<=1023,'normal sqrt exponent out of range')
    bits=((exponent+1023)<<52)|(q-(1<<52))
    return f'{bits:016x}'


def independently_expected(repo,commit):
    """Use fixed fixture construction, independently recompute integer squares.

    Does not call gate.expected_rows/checks or oracle.canonical_squared, and does
    not execute Session. All finite float32 values are integers times 2^-149.
    """
    with tempfile.TemporaryDirectory(prefix='mvdb-tighter-oracle-reader-') as td:
        root=Path(td)
        paths=('minivec/tests/test_tighter_certificate_db.py','minivec/tests/topk_bounds.py','protocol_check/_transport.py')
        for p in paths:
            target=root/p;target.parent.mkdir(parents=True,exist_ok=True);target.write_bytes(blob(repo,commit,p))
        old_path=sys.path[:];old_transport=sys.modules.pop('_transport',None)
        try:
            spec=importlib.util.spec_from_file_location('_independent_tighter_fixture',root/paths[0])
            gate=importlib.util.module_from_spec(spec);spec.loader.exec_module(gate)
            require(list(gate.EXPECTED_CASES)==EXPECTED,'Git fixture case plan differs')
            oracle=gate.load_oracle(root);out=[]
            for dimension in (128,512):
                rows,records,specs=gate.fixture(oracle,dimension)
                require(len(rows)==len(records)==33,'fixture shape drift')
                for path in ('serial','fanout'):
                    for kind,query,group,k in specs:
                        ranked=[]
                        for key,(category,vector) in records.items():
                            if group is not None and category!=group:continue
                            total=sum((a-b)**2 for a,b in zip(vector.scaled,query.scaled))
                            ranked.append((float(Fraction(total,1<<298)),key))
                        wanted=[[key,integer_sqrt_projection_bits(distance)] for distance,key in sorted(ranked)[:k]]
                        if kind=='indexed_near_tie':require(wanted[0][0]==-9007199254740993,'near tie oracle fixture changed')
                        h=digest(json.dumps(wanted,sort_keys=True,separators=(',',':')).encode())
                        out.append({'name':f'{path}_d{dimension}_{kind}','path':path,'dimension':dimension,'kind':kind,
                            'group':group,'k':k,'mode':'exact','expected_rows':wanted,'expected_sha256':h})
            require([i['name'] for i in out]==EXPECTED,'oracle inventory differs');return out
        finally:
            sys.path[:]=old_path;sys.modules.pop('_transport',None)
            if old_transport is not None:sys.modules['_transport']=old_transport


def verify_tighter_gate(root,gates,repo,commit,candidate):
    hashes={};counts=[]
    for mode in ('normal','sanitized'):
        path=root/f'tighter-certificate-{mode}.log';text=path.read_text(encoding='utf8');lines=text.splitlines()
        require(re.findall(r'^tighter_bound_checks=(\d+)$',text,re.M)==[str(EXPECTED_CHECKS)] and
                lines.count('tighter_bound=PASS')==1 and
                lines.count('tighter_bound_header=actual_minivec_src_distance_h')==1 and
                lines.count('tighter_bound_cases=6748 midpoint_fixtures=180 rescue_fixtures=10')==1 and
                not any(x in text for x in ('ERROR: AddressSanitizer','runtime error:','FAIL ')),
                'actual-header native inventory/diagnostic/source marker differs')
        counts.append(EXPECTED_CHECKS);hashes[path.name]=sha(path)
    path=root/'tighter-oracle.json';oracle=read(path)
    wanted={'status':'generated_independent_oracle','cases':6748,'kinds':{'0':6558,'1':180,'2':10},
            'maximum_dimension':262144,'bytes':11425564,'sha256':ORACLE_SHA,'seed':'0x6c42b9e173','native_executions':0}
    require(all(oracle.get(k)==v for k,v in wanted.items()),'independent fixture identity differs');hashes[path.name]=sha(path)
    path=root/'tighter-fixture-generation.log';require(read(path)==oracle,'fixture generation metadata differs');hashes[path.name]=sha(path)
    path=root/'image-binary-tighter-certificate.json';report=read(path);checks=report['checks']
    require(report['schema']=='actual-image-tighter-certificate-v2' and report['projection_semantics']==PROJECTION_SEMANTICS and report['status']=='passed' and
            report['binary_sha256']==candidate and report['mode']=='exact' and report['trace_enabled'] is False and
            report['expected_cases']==EXPECTED and report['checks_count']==24 and
            [x['name'] for x in checks]==EXPECTED,'actual-image identity/case inventory differs')
    for key,p in (('oracle_source_sha256','minivec/tests/topk_bounds.py'),('transport_source_sha256','protocol_check/_transport.py')):
        require(report[key]==digest(blob(repo,commit,p)),'tighter actual-image executed dependency differs')
    expected=independently_expected(repo,commit)
    for actual,want in zip(checks,expected):
        require(actual['status']=='passed' and all(actual.get(k)==v for k,v in want.items()) and
                actual['actual_rows']==want['expected_rows'] and actual['actual_sha256']==want['expected_sha256'] and
                actual['session']==f"{want['path']}_d{want['dimension']}",'actual-image projected distance bits/TopK differs')
        response=actual.get('raw_response',{});rows=response.get('rows')
        require(response.get('columns')==['id','d'] and type(rows) is list and
                all(type(row) is list and len(row)==2 and type(row[0]) is int and type(row[1]) in (int,float) and
                    math.isfinite(row[1]) for row in rows),'preserved actual response shape differs')
        require([[row[0],struct.pack('!d',float(row[1])).hex()] for row in rows]==actual['actual_rows'],
                'preserved parsed actual response differs from claimed normalized rows')
    names=[f'{path}_d{dimension}' for dimension in (128,512) for path in ('serial','fanout')]
    sessions=report['sessions'];require([x['name'] for x in sessions]==names,'actual-image session inventory differs')
    for row in sessions:
        threads=1 if row['path']=='serial' else 2;tasks=row['native_tasks'];pid=row['pid']
        require(row['binary_sha256']==candidate and type(pid) is int and pid>0 and len(tasks)==len(set(tasks))==threads and
                pid in tasks and all(type(t) is int and t>0 for t in tasks) and
                row['runtime_environment']=={'MVDB_QUERY_THREADS':str(threads),'MVDB_PARSE_THREADS':'1','MVDB_ANN_OFF':'1'} and
                row['name']==f"{row['path']}_d{row['dimension']}" and row['dimension'] in (128,512),
                'actual-image process ELF/environment/tasks differ')
    logs=report['stderr_logs'];wanted_logs={f'image-binary-tighter-certificate-logs/{name}.stderr.log' for name in names}
    require(len(logs)==4 and {x['path'] for x in logs}==wanted_logs,'actual-image stderr inventory differs')
    for entry in logs:
        file=root/entry['path'];raw=file.read_bytes()
        require(len(raw)==entry['bytes'] and digest(raw)==entry['sha256'] and b'MVDB_BATCH8_TRACE ' not in raw,
                'actual-image stderr changed or unexpected trace');hashes[entry['path']]=digest(raw)
    hashes[path.name]=sha(path)
    evidence={'schema_version':1,'checks_per_mode':EXPECTED_CHECKS,'fixture_cases':6748,'fixture_sha256':ORACLE_SHA,
        'actual_image_checks':24,'mode':'exact','projection_semantics':PROJECTION_SEMANTICS,'binary_sha256':candidate,'production_header_sha256':PRODUCTION_SHA,
        'reference_header_sha256':REFERENCE_SHA,'file_sha256':hashes}
    require(gates['tighter_certificate_evidence']==evidence,'tighter evidence not bound to root gates')
    return evidence,{'independently_recomputed_cases':expected,'session_count':4,'all_response_bits_recomputed':True,
        'oracle':'Finite binary32 integer lattice; integer squared sum then Fraction-to-binary64 once for ranking; independent integer-isqrt midpoint decision for binary64 sqrt projection.',
        'native_fixture_scope':'Actual production header; normal and ASan/UBSan source tests. Separate gate uses actual root ELF.',
        'execution_scope':'Normal process ABI FP environment, forced thread policy plus observed tasks; no per-query CW or rescue branch-count telemetry.',
        'local_database_executions':0}
