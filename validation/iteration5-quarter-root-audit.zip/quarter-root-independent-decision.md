# Quarter root independent decision

**rejected_by_frozen_screen_keep_R**. No default adoption or official submission recommendation.

| Reference | CPU | First-lifetime wall C/B | First-lifetime CPU C/B | Initial 1000 queries wall C/B | Query CPU C/B |
|---|---:|---:|---:|---:|---:|
| ee | 1 | 0.964720 | 0.929658 | 0.982288 | 0.951917 |
| ee | 2 | 0.939223 | 0.890197 | 0.897250 | 0.838569 |
| retained | 1 | 0.971569 | 0.921246 | 0.894492 | 0.857043 |
| retained | 2 | 0.987318 | 0.975871 | 0.977567 | 0.950645 |

All 22 root gate groups, 24 actual-ELF oracle cases and 24 pairs verified. 6 failed EE primary condition(s), 3 retained protection trigger(s). All 153 adverse-or-mixed metric groups are preserved in the full analysis.

First-lifetime wall is a sum of measured phases, not continuous end-to-end wall. First-lifetime CPU ends before shutdown. Each C/B uses its own same-run reference; no cross-arm or cross-run multiplication.

The actual source differs from retained R only in distance.h and exactly matches the screened quarter micro candidate. Old half-v1 failure and half-v2 rejection remain history. The micro gain does not establish a DB or official-score gain.

API artifact identity and validate success were independently checked from the supplied original API objects. The supplied jobs page is not asserted to be the whole workflow inventory.

Commit: `9a291b478d160308813d37698f771249d5c9bbbd`. Actual ELF SHA256: `77a8cfbc08169e50ba832fbfdbf7f021bf197ea605906c7d85fc448860323406`.
