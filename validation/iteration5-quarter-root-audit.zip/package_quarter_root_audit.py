"""Package completed quarter root audit; raw and repository stay untouched."""
import ast, hashlib, json, sys, zipfile
from pathlib import Path
from statistics import median

sys.dont_write_bytecode = True
from analyze_quant_batch_prototype import blob

W = Path(__file__).resolve().parent
sha = lambda path: hashlib.sha256(Path(path).read_bytes()).hexdigest()
analysis_path = W / 'quarter-root-independent-analysis.json'
analysis = json.loads(analysis_path.read_bytes())
screen = analysis['preregistered_screen']
assert analysis['status'] == 'verified' and analysis['verified_pairs'] == 24 and len(analysis['root_gates']) == 22
assert analysis['commit'] == '9a291b478d160308813d37698f771249d5c9bbbd'

# Supplement the inherited reader's compact artifact check with the actual
# provided jobs API page. Never invent job records or global pagination coverage.
api_original = json.loads((W / 'quarter-root-api.json').read_bytes())
api_receipt = json.loads((W / 'quarter-root-api-reader-receipt.json').read_bytes())
arts = api_original['artifacts_response']['artifacts']
jobs = api_original['jobs_response']['jobs']
assert api_receipt['jobs'] == jobs and len(arts) == 1 and api_receipt['artifact'] == arts[0]
assert arts[0]['id'] == 14083814687 and arts[0]['workflow_run']['id'] == 43523787713
assert arts[0]['workflow_run']['head_sha'] == analysis['commit']
assert arts[0]['digest'] == 'sha256:06c04ef7c8604a4ee18cbe57d85311948ff784885652983922556917b5b6a047'
assert arts[0]['size_in_bytes'] == 3745821
selected = [item for item in jobs if item['id'] == 132224394233]
assert len(selected) == 1
job = selected[0]
assert job['name'] == 'validate' and job['run_id'] == 43523787713 and job['status'] == 'completed' and job['conclusion'] == 'success'
assert all(item['run_id'] == 43523787713 and item['status'] == 'completed' for item in jobs)
assert [item['id'] for item in jobs if item['conclusion'] != 'skipped'] == [job['id']]
api_proof = {'status':'verified_original_artifact_and_provided_jobs_page', 'run_id':43523787713,
    'job_id':job['id'], 'job_name':job['name'], 'job_conclusion':'success', 'provided_jobs':len(jobs),
    'all_jobs_independently_enumerated':False,
    'scope':'Only the provided jobs page is asserted. validate success is independently checked; global workflow exclusivity is not inferred from a partial page.',
    'original_api_sha256':sha(W/'quarter-root-api.json'), 'reader_receipt_sha256':sha(W/'quarter-root-api-reader-receipt.json')}
(W/'quarter-root-job-api-verification.json').write_text(json.dumps(api_proof,indent=2)+'\n',encoding='utf-8')

def metrics(reference,cpu):
    output = {}
    for name, value in analysis['measurements'][reference][str(cpu)]['extra_summary']['standard10k'].items():
        rows = value['raw_pairs']
        ratios = [row['candidate']/row['baseline'] for row in rows if row['baseline']]
        output[name] = {'median_baseline_absolute':median(row['baseline'] for row in rows),
            'median_candidate_absolute':median(row['candidate'] for row in rows),
            'median_paired_candidate_over_baseline':median(ratios) if ratios else None,
            'candidate_larger_pairs':value['candidate_larger_pairs'],'pairs':len(rows)}
    return output

failures = []
for cpu, values in screen['EE_primary'].items():
    for metric, value in values['metrics'].items():
        for condition, passed in value['conditions'].items():
            if not passed:
                failures.append({'cpu_count':int(cpu),'metric':metric,'failed_condition':condition,
                    'statistics':value['statistics'],'limit':value['limit']})
eligible = screen['eligible_for_one_confirmation']
decision = {'status':'eligible_for_one_independent_confirmation_only' if eligible else 'rejected_by_frozen_screen_keep_R',
    'eligible_for_confirmation':eligible, 'adopted':False, 'official_submission_recommended':False,
    'formal_submission_by_assistant':False, 'formal_score_prediction':None,
    'commit':analysis['commit'],'binary_sha256':analysis['candidate_binary_sha256'],'image_id':analysis['candidate_image_id'],
    'raw_archive':{'repository_path':'validation/iteration5-quarter-root-raw.zip','bytes':3745821,
        'sha256':'06c04ef7c8604a4ee18cbe57d85311948ff784885652983922556917b5b6a047'},
    'API_verification':api_proof,'verified_root_gates':22,'actual_root_oracle_cases':24,
    'normal_sanitized_checks_each':11452601,'verified_performance_pairs':24,
    'screen':screen,'failed_primary_conditions':failures,
    'absolute_and_paired_default_metrics':{reference:{str(cpu):metrics(reference,cpu) for cpu in (1,2)} for reference in ('ee','retained')},
    'negative_metric_groups_preserved':len(analysis['all_negative_or_mixed_metrics']),
    'negative_metric_group_definition':'Metric/phase groups with at least one adverse pair; overlapping groups are not distinct benchmark pairs.',
    'runtime_source_audit':analysis['runtime_delta_audit'],
    'limitations':analysis['limitations']+[
        'Medians of absolute times are descriptive; the frozen decision uses median paired ratios.',
        'Imported EE and R programs were not rebuilt alongside the new candidate. Whole-version changes cannot be attributed solely to the coefficient.',
        'This root screen directly compares quarter to EE/R, not to historical half; no cross-run micro/DB ratios are multiplied.'],
    'analysis_file':{'path':analysis_path.name,'bytes':analysis_path.stat().st_size,'sha256':sha(analysis_path)}}
decision_path = W / 'quarter-root-independent-decision.json'
assert not decision_path.exists()
decision_path.write_text(json.dumps(decision,ensure_ascii=False,indent=2,allow_nan=False)+'\n',encoding='utf-8')

lines = ['# Quarter root independent decision', '', '**'+decision['status']+'**. No default adoption or official submission recommendation.', '',
    '| Reference | CPU | First-lifetime wall C/B | First-lifetime CPU C/B | Initial 1000 queries wall C/B | Query CPU C/B |',
    '|---|---:|---:|---:|---:|---:|']
keys = ('first_lifetime_no_restart','first_lifetime_cpu_to_before_shutdown_usec','first_lifetime_query_total','first_queries_cpu_usec')
for reference in ('ee','retained'):
    for cpu in (1,2):
        table = decision['absolute_and_paired_default_metrics'][reference][str(cpu)]
        lines.append('| '+reference+' | '+str(cpu)+' | '+' | '.join(f"{table[key]['median_paired_candidate_over_baseline']:.6f}" for key in keys)+' |')
lines += ['',f"All 22 root gate groups, 24 actual-ELF oracle cases and 24 pairs verified. {len(failures)} failed EE primary condition(s), {len(screen['R_guard_triggers'])} retained protection trigger(s). All {len(analysis['all_negative_or_mixed_metrics'])} adverse-or-mixed metric groups are preserved in the full analysis.", '',
    'First-lifetime wall is a sum of measured phases, not continuous end-to-end wall. First-lifetime CPU ends before shutdown. Each C/B uses its own same-run reference; no cross-arm or cross-run multiplication.', '',
    'The actual source differs from retained R only in distance.h and exactly matches the screened quarter micro candidate. Old half-v1 failure and half-v2 rejection remain history. The micro gain does not establish a DB or official-score gain.', '',
    'API artifact identity and validate success were independently checked from the supplied original API objects. The supplied jobs page is not asserted to be the whole workflow inventory.', '',
    f"Commit: `{analysis['commit']}`. Actual ELF SHA256: `{analysis['candidate_binary_sha256']}`."]
(W/'quarter-root-independent-decision.md').write_text('\n'.join(lines)+'\n',encoding='utf-8')

# Include all local Python reader dependencies, preserving historical readers.
pending = ['analyze_quarter_primary_root']; modules = {}
while pending:
    name = pending.pop()
    if name in modules:continue
    path = W/(name+'.py')
    if not path.is_file():continue
    modules[name] = path
    for node in ast.walk(ast.parse(path.read_bytes())):
        imports = [alias.name for alias in node.names] if isinstance(node,ast.Import) else [node.module] if isinstance(node,ast.ImportFrom) and node.module else []
        pending.extend(value.split('.')[0] for value in imports if (W/(value.split('.')[0]+'.py')).is_file())
members = {'readers/'+path.name:path.read_bytes() for path in modules.values()}
for name in ('quarter-root-independent-analysis.json','quarter-root-independent-decision.json','quarter-root-independent-decision.md',
    'quarter-root-api.json','quarter-root-api-reader-receipt.json','quarter-root-job-api-verification.json',
    'quarter-root-reader-static-preflight.json','quarter-root-reader-plan-binding.json','quarter-root-reader-commit-preflight.json',
    'check_quarter_root_reader.py','prepare_quarter_root_reader.py','package_quarter_root_audit.py'):
    members[name] = (W/name).read_bytes()
for path in ('validation/iteration5-quarter-margin-primary24-preregistration.json',
             'validation/iteration5-batch8-clear-gain-policy.json', 'minivec/src/distance.h',
             'minivec/tools/verify_tighter_root.py','minivec/tests/test_tighter_certificate_db.py'):
    members['git-source/'+path] = blob(W/'seekdb',analysis['commit'],path)
manifest = {'scope':'Independent read-only audit; complete raw ZIP remains separate and unchanged.',
    'commit':analysis['commit'],'raw_archive':decision['raw_archive'],
    'members':[{'path':name,'bytes':len(data),'sha256':hashlib.sha256(data).hexdigest()} for name,data in sorted(members.items())],
    'new_native_or_DB_runs_by_reader':0}
members['manifest.json'] = (json.dumps(manifest,indent=2)+'\n').encode()
archive = W/'quarter-root-independent-audit.zip'
assert not archive.exists()
with zipfile.ZipFile(archive,'w',compression=zipfile.ZIP_DEFLATED,compresslevel=9) as z:
    for name,data in sorted(members.items()):
        item = zipfile.ZipInfo(name,date_time=(2026,11,14,0,0,0));item.compress_type=zipfile.ZIP_DEFLATED
        z.writestr(item,data,compresslevel=9)
with zipfile.ZipFile(archive) as z:
    assert set(z.namelist()) == set(members) and all(z.read(name)==data for name,data in members.items())
receipt = {'status':'packaged_verified_offline_audit','path':str(archive),'bytes':archive.stat().st_size,'sha256':sha(archive),
    'members':len(members),'local_reader_dependencies':len(modules),'decision':decision['status'],
    'negative_metric_groups_preserved':decision['negative_metric_groups_preserved'],
    'analysis_sha256':sha(analysis_path),'decision_sha256':sha(decision_path),'repository_writes':0,'new_DB_runs':0}
(W/'quarter-root-independent-audit-receipt.json').write_text(json.dumps(receipt,indent=2)+'\n',encoding='utf-8')
print(json.dumps(receipt))
print(json.dumps({'primary_failures':[(item['cpu_count'],item['metric'],item['failed_condition']) for item in failures],
                 'R_guard_triggers':screen['R_guard_triggers'],
                 'default_metrics':{ref:{cpu:{key:values[key] for key in keys} for cpu,values in arms.items()}
                    for ref,arms in decision['absolute_and_paired_default_metrics'].items()}},ensure_ascii=False))
