"""Small pre-data checks of rule wiring and exact Git input binding; no DB."""
import ast,copy,hashlib,json
from pathlib import Path
import analyze_batch8_primary_root as reader
import evaluate_batch8_primary24_screen as screen
W=Path(__file__).resolve().parent;R=W/'seekdb'
files=['analyze_batch8_primary_root.py','batch8_reader_gates.py','evaluate_batch8_primary24_screen.py']
for f in files:ast.parse((W/f).read_bytes())
source=reader.runtime_guard(R,reader.CANDIDATE_COMMIT)
old=json.loads((R/screen.OLD_PLAN_PATH).read_bytes());policy=(R/screen.POLICY_PATH).read_bytes()
groups={}
for key,entries in screen.retained.expected_groups(old).items():
    times,mem=screen.retained.guard_metric_names(key[2]);names=list(times+mem)
    if key[2]=='standard10k':names+=['first_lifecycle_cpu_to_before_shutdown_usec']
    groups[key]=[{**e,'metrics':{n:{'baseline':100,'candidate':80 if key[0]=='ee' else 100} for n in names}} for e in entries]
def run(g):return screen.evaluate_screen(old,policy,g,verified_gate_checks_passed=True,preregistration_sha256=screen.PREREG_SHA)
assert run(groups)['eligible_for_one_confirmation'] is True
limited=copy.deepcopy(groups)
for pair in limited[('ee',2,'standard10k')]:pair['metrics']['first_1000_queries_cpu_usec']['candidate']=91
assert run(limited)['status']=='screen_clear_EE_gain_criteria_not_met_keep_R'
blocked=copy.deepcopy(groups)
for pair in blocked[('retained',1,'spill_high_q16')]:pair['metrics']['query_before_mutations_wall_seconds']['candidate']=103
assert run(blocked)['status']=='screen_rejected_R_regression_keep_R'
missing=copy.deepcopy(groups);del missing[('ee',1,'standard10k')][0]['metrics']['first_lifecycle_cpu_to_before_shutdown_usec']
try:run(missing)
except ValueError:pass
else:raise AssertionError('missing CPU evidence accepted')
out={'status':'passed','scope':'AST/import, exact committed 50-source binding and four synthetic numerical wiring checks only; not any DB evidence',
 'candidate_commit':reader.CANDIDATE_COMMIT,'preregistration_sha256':screen.PREREG_SHA,'synthetic_rule_checks':4,'DB_runs':0,'native_compilations':0,
 'source_guard':source,'files':{f:{'bytes':len((W/f).read_bytes()),'sha256':hashlib.sha256((W/f).read_bytes()).hexdigest()} for f in files}}
(W/'batch8-reader-preflight.json').write_text(json.dumps(out,indent=2)+'\n',encoding='utf8')
print(json.dumps({'status':'passed','numerical_synthetic_checks':4,'Git_source_files':50,'DB_runs':0}))
