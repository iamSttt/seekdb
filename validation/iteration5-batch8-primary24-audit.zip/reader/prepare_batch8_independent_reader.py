"""Derive a separate reader while preserving the older rejected-candidate audit."""
import ast
from pathlib import Path

w=Path(__file__).resolve().parent
s=(w/'analyze_norm_maxabs_primary_root.py').read_text()
def change(old,new):
    global s
    if s.count(old)!=1:raise ValueError('nonunique substitution '+old[:90])
    s=s.replace(old,new)
def function(name,new):
    global s
    nodes=[n for n in ast.parse(s).body if isinstance(n,ast.FunctionDef) and n.name==name]
    if len(nodes)!=1:raise ValueError(name)
    n=nodes[0];lines=s.splitlines(keepends=True)
    s=''.join(lines[:n.lineno-1])+new.rstrip()+'\n'+''.join(lines[n.end_lineno:])
change('independent norm/maxabs highest-primary24_v1','batch8 native-AVX2 highest-primary24_v1')
change("CANDIDATE_COMMIT = 'c30d6ec369b82c8d143b2f7cd17ab3e95e88800c'","CANDIDATE_COMMIT = 'ebd6d25f27ad1a32fa92d84bcd571ae86b55394e'")
change("'global_max_hint_equivalence_normal_and_sanitized'","'batch8_bound_normal_and_sanitized', 'actual_image_batch8_dispatch_and_oracle'")
change("PREREG_PATH = 'validation/iteration5-norm-maxabs-primary24-preregistration.json'","PREREG_PATH = 'validation/iteration5-batch8-primary24-preregistration.json'")
change("EXPERIMENT_ID = 'norm-maxabs-fusion-highest-primary24'","EXPERIMENT_ID = 'batch8-avx2-highest-primary24'")
change('import evaluate_norm_maxabs_primary24_screen as screen',"import evaluate_batch8_primary24_screen as screen\nfrom batch8_reader_gates import runtime_guard, verify_batch8_gate\nBATCH8_FLAGS = core.FLAGS + ['-DMVDB_ENABLE_BATCH8_QUANTIZED']\nINPUT_PATHS = core.INPUT_PATHS + (screen.POLICY_PATH,'minivec/tools/batch8_native_isa_probe.cpp','minivec/tools/prepare_highest_primary.py','minivec/tools/summarize_highest_primary.py','minivec/tools/ci_highest_primary.sh')")
function('runtime_guard', '# Runtime guard is imported from independent batch8_reader_gates.\n')
function('source_equivalence_gates', '''def source_equivalence_gates(root, gates, repo, commit, candidate):
    historical=quantizer_gate(root,gates)
    batch,extra=verify_batch8_gate(root,gates,repo,commit,candidate)
    return {**historical,'batch8':batch},extra
''')
change("'first_1000_queries_wall_seconds':values['first_lifetime_query_total'],","'first_1000_queries_wall_seconds':values['first_lifetime_query_total'],\n                    'first_lifecycle_cpu_to_before_shutdown_usec':values['first_lifetime_cpu_to_before_shutdown_usec'],")
change("proof['feature_flags']==core.FLAGS", "proof['feature_flags']==BATCH8_FLAGS")
change("*core.INPUT_PATHS", "*INPUT_PATHS")
change(",PREREG_PATH,'.github/workflows/minivec-score.yml'",",'.github/workflows/minivec-score.yml'")
change('training=core.training_log(root,repo,commit)','training=training_log(root,repo,commit)')
change('source_gates = source_equivalence_gates(root, gates)','source_gates, batch_details = source_equivalence_gates(root, gates, repo, commit, candidate)')
change("preregistration={'path':PREREG_PATH,'bytes':len(prereg_raw),'sha256':digest(prereg_raw)}","preregistration={'path':PREREG_PATH,'bytes':len(prereg_raw),'sha256':digest(prereg_raw)}\n    policy_raw=blob(repo,commit,screen.POLICY_PATH)\n    require(digest(policy_raw)==screen.POLICY_SHA and len(policy_raw)==2661,'clear-gain policy differs')\n    policy_identity={'path':screen.POLICY_PATH,'bytes':len(policy_raw),'sha256':digest(policy_raw)}\n    old_plan=json.loads(blob(repo,commit,screen.OLD_PLAN_PATH))")
change("binding['source_equivalence_gates']==source_gates","binding['quantizer_gate']==source_gates")
change("binding['preregistration']==preregistration","binding['acceptance_policy']==policy_identity")
change("overall['preregistration']==preregistration","overall['acceptance_policy']==policy_identity")
change("overall['experiment_id']==EXPERIMENT_ID and overall['acceptance_policy']", "'experiment_id' not in overall and overall['acceptance_policy']")
change('decision=screen.evaluate_screen(json.loads(prereg_raw),screen_groups,verified_gate_checks_passed=True)',"decision=screen.evaluate_screen(old_plan,policy_raw,screen_groups,verified_gate_checks_passed=True,preregistration_sha256=screen.PREREG_SHA)")
change("'source_equivalence_gates':source_gates,'experiment_id'","'source_equivalence_gates':source_gates,'actual_batch8_gate_detail':batch_details,'acceptance_policy':policy_identity,'experiment_id'")
change('This is a fresh candidate screen, not confirmation of the rejected quantizer.','This is a new batch8 candidate screen, not confirmation or adoption.')
change("'The cached encoder is isolated in a historical test-only header; its gate is regression evidence, not evidence that production still uses the rejected cached reciprocal. Current production norm/maxabs equivalence has its own gate.'", "'The rejected cached encoder remains test-only. Batch8 has separate normal/sanitized integer-bound and actual-ELF oracle/dispatch gates. Trace is enabled only for correctness, absent in timed process environments.',")
# The existing six training oracle/profile proof is unchanged except that one
# explicitly preregistered feature macro is allowed in the root Docker input.
c=(w/'analyze_crc_root.py').read_text();tree=ast.parse(c)
n=next(n for n in tree.body if isinstance(n,ast.FunctionDef) and n.name=='training_log')
t=''.join(c.splitlines(keepends=True)[n.lineno-1:n.end_lineno])
t=t.replace('COMPILER','core.COMPILER').replace('blob(repo, BASE, p)','blob(repo, core.BASE, p)')
t=t.replace("require(blob(repo, commit, p) == blob(repo, core.BASE, p), 'training/build policy changed: ' + p)","actual=blob(repo,commit,p)\n        if p=='Dockerfile':actual=actual.replace(b' -DMVDB_ENABLE_BATCH8_QUANTIZED',b'')\n        require(actual == blob(repo, core.BASE, p), 'training/build policy changed: ' + p)")
before='def audit(args):';change(before,t+'\n\n'+before)
change("root, repo, commit = args.input.resolve(), args.repo.resolve(), args.commit","root, repo, commit = args.input.resolve(), args.repo.resolve(), args.commit\n    receipt=read(args.api_receipt); art=receipt['artifact']; workflow=art['workflow_run']\n    require(receipt['commit']==workflow['head_sha']==commit and workflow['id']==receipt['run_id'], 'API run/commit differs')\n    require(art['name']=='root-image-validation' and art['digest']=='sha256:'+args.artifact_sha256 and art['size_in_bytes']==args.artifact_bytes and art['expired'] is False,'API artifact scope differs')\n    require(art['url']=='https://api.github.com/repos/iamSttt/seekdb/actions/artifacts/'+str(art['id']),'API artifact repository differs')\n    api_binding={'receipt_sha256':sha(args.api_receipt),'run_id':receipt['run_id'],'artifact_id':art['id'],'artifact_sha256':args.artifact_sha256,'bytes':args.artifact_bytes,'job_id_reported':receipt.get('job_id'),'job_conclusion_claim':'Not inferred from compact artifact receipt; this audit validates completed gate and measurement contents.'}")
change("'candidate_binary_sha256':candidate,'candidate_image_id':image,'baseline_binary_sha256'","'api_binding':api_binding,'candidate_binary_sha256':candidate,'candidate_image_id':image,'baseline_binary_sha256'")
change("p.add_argument('--commit',required=True);p.add_argument('--artifact-sha256',required=True)","p.add_argument('--api-receipt',type=Path,required=True);p.add_argument('--commit',required=True);p.add_argument('--artifact-sha256',required=True)")
ast.parse(s)
(w/'analyze_batch8_primary_root.py').write_text(s,encoding='utf8',newline='\n')
print('Created separate batch8 reader; no DB or raw result read.')
