"""Independent batch8 Git/dispatch/oracle checks. Python evidence only, no DB."""
import hashlib
import json
import random
import re
from analyze_crc_root import require,digest,sha,read,git,blob

REFERENCE='33a52a7dd4426af059ec2334b7c93a07c38c93c9'
PREREG='validation/iteration5-batch8-primary24-preregistration.json'
PREREG_SHA='5c9eebe2da6d65ee20ba1f0cf862cfa419909efed7346b432b45e97bbbef5ea1'
ERRATUM='validation/iteration5-batch8-primary24-prepush-erratum.json'
ERRATUM_SHA='fa89633266257bb73c00d77182625202d6cff5abdb834a395df69829b9d8aa72'
BASE_CASES=('unindexed_10','batch_1','batch_10','filter_10','desc_10','ann_exact_fallback_10','limit_zero','ratio_boundary','unbounded')
EXPECTED=[p+'_'+n for p in ('serial','fanout') for n in BASE_CASES]+['serial_tail_dimension129','serial_small7_no_batch','serial_zero_cap_no_batches']
TRACE_KEYS={'path','worker','first','last','batch_begin','batch_end','batches','dimension','k','row_isa','batch_isa'}

def runtime_guard(repo,commit):
    inventories=[]
    for rev in (REFERENCE,commit):
        paths=git(repo,'ls-tree','-r','--name-only',rev,'--','minivec/src').decode().splitlines()
        inventories.append({p:digest(blob(repo,rev,p)) for p in paths})
    before,after=inventories
    require(set(after)-set(before)=={'minivec/src/quantized_batch8.h'} and not set(before)-set(after),'unexpected runtime inventory change')
    changed=sorted(p for p in before if before[p]!=after[p])
    require(changed==['minivec/src/exec.cpp','minivec/src/quantized_bound.h'],'runtime delta exceeds frozen batch8 scope')
    docker=blob(repo,commit,'Dockerfile')
    require(docker.count(b' -DMVDB_ENABLE_BATCH8_QUANTIZED')==1 and docker.replace(b' -DMVDB_ENABLE_BATCH8_QUANTIZED',b'')==blob(repo,REFERENCE,'Dockerfile'),'root Docker changes exceed one flag')
    for p in ('.dockerignore','minivec/Makefile','minivec/tools/pgo/train.cpp','minivec/tools/pgo/run-training.sh'):
        require(blob(repo,REFERENCE,p)==blob(repo,commit,p),'build/training drift '+p)
    require(git(repo,'ls-tree','-r',REFERENCE,'--','minivec/third_party')==git(repo,'ls-tree','-r',commit,'--','minivec/third_party'),'third-party drift')
    raw=blob(repo,commit,PREREG);require(digest(raw)==PREREG_SHA,'prereg SHA differs');plan=json.loads(raw)
    require(len(plan['source_snapshot'])==50,'source inventory differs')
    for p,item in plan['source_snapshot'].items():
        b=blob(repo,commit,p);oid=hashlib.sha1(b'blob '+str(len(b)).encode()+b'\0'+b).hexdigest()
        require(item=={'bytes':len(b),'sha256':digest(b),'git_blob':oid},'frozen committed source mismatch '+p)
    eraw=blob(repo,commit,ERRATUM);require(digest(eraw)==ERRATUM_SHA,'prepush erratum differs')
    e=json.loads(eraw);original=blob(repo,commit,e['original_plan']['path'])
    require(len(original)==e['original_plan']['bytes'] and digest(original)==e['original_plan']['sha256'],'prepush original missing')
    require(e['candidate_PGO_builds_executed']==e['candidate_DB_runs_executed']==0 and e['threshold_workload_and_algorithm_changes'] is False,'prepush correction scope')
    return {'retained_source':REFERENCE,'changed_runtime_files':changed,'added_runtime_file':'minivec/src/quantized_batch8.h',
      'candidate_sha256':{p:after[p] for p in changed+['minivec/src/quantized_batch8.h']},'source_snapshot_verified_count':50,
      'source_binding_method':'Exact committed blob bytes, including retained CRLF main.cpp; no Git clean inference.',
      'prepush_erratum_sha256':ERRATUM_SHA,'unchanged_training':True,'root_Docker_delta':'one enable macro'}

def parse_traces(raw):
    out=[]
    def unique(items):
        obj={}
        for k,v in items:
            require(k not in obj,'duplicate trace field');obj[k]=v
        return obj
    for line in raw.decode('utf8').splitlines():
        if line.startswith('MVDB_BATCH8_TRACE '):
            t=json.loads(line[len('MVDB_BATCH8_TRACE '):],object_pairs_hook=unique)
            require(type(t) is dict and set(t)==TRACE_KEYS,'trace inventory differs')
            require(t['path'] in ('serial','fanout') and t['row_isa']==t['batch_isa']=='avx2','trace ISA/path differs')
            require(all(type(t[k]) is int and t[k]>=0 for k in TRACE_KEYS-{'path','row_isa','batch_isa'}),'invalid trace integer')
            out.append(t)
        else:require('MVDB_BATCH8_TRACE' not in line,'malformed trace line')
    return out

def fixture(count,dimension,zero):
    rng=random.Random(0xB87D192);keys=rng.sample(range(-500000,500000),count)
    rows=[[rng.randint(-96,96) for _ in range(dimension)] for _ in range(count)]
    if zero:rows=[[32]*dimension for _ in range(count)];query=[32]*dimension
    else:
        if count>1:rows[1]=rows[0][:]
        query=[v+8 for v in rows[0]]
    # Every stored float is an exact /64 value. The sum of squared integer
    # differences is below 2^53, hence ordering is exactly binary64 N/4096.
    result=[(sum((a-b)**2 for a,b in zip(row,query)),key,i%3) for i,(key,row) in enumerate(zip(keys,rows))]
    require(all(n<2**53 for n,_,_ in result),'fixture exceeds exact integer-square domain')
    return result

def verify_batch8_gate(root,gates,repo,commit,candidate):
    path=root/'image-binary-batch8.json';report=read(path)
    require(report['status']=='passed' and report['binary_sha256']==candidate and report['trace_schema']=='MVDB_BATCH8_TRACE/v1' and report['trace_enabled_only_for_gate'] is True,'actual binary gate status differs')
    require(report['expected_cases']==EXPECTED and [c['name'] for c in report['checks']]==EXPECTED and report['checks_count']==21,'actual gate inventory/order differs')
    for key,p in (('oracle_source_sha256','minivec/tests/topk_bounds.py'),('transport_source_sha256','protocol_check/_transport.py')):
        require(report[key]==digest(blob(repo,commit,p)),'actual gate executed dependency differs')
    logged={};identities={};fixtures={};case_details=[]
    for c in report['checks']:
        name=c['name'];fanout=name.startswith('fanout_');group='fanout' if fanout else 'serial'
        count,dim,expected=1027,128,'none';k=10;where=None;descending=False;mode='exact'
        if name.endswith('_batch_1'):k=1;expected='positive'
        elif name.endswith('_batch_10'):expected='positive'
        elif name.endswith('_filter_10'):where=1
        elif name.endswith('_desc_10'):descending=True
        elif name.endswith('_ann_exact_fallback_10'):mode='ann'
        elif name.endswith('_limit_zero'):k=0
        elif name.endswith('_ratio_boundary'):k=128
        elif name.endswith('_unbounded'):k=None
        elif name=='serial_tail_dimension129':group='tail';count=1033;dim=129;expected='positive'
        elif name=='serial_small7_no_batch':group='small';count=7;k=1
        elif name=='serial_zero_cap_no_batches':group='zero';count=33;k=1;expected='zero'
        require((c['status'],c['count'],c['dimension'],c['k'],c['group'],c['descending'],c['mode'],c['expected_trace'])==('passed',count,dim,k,where,descending,mode,expected),'gate case contract differs '+name)
        fkey=(count,dim,group=='zero')
        if fkey not in fixtures:fixtures[fkey]=fixture(*fkey)
        ranked=sorted(((-n if descending else n),key) for n,key,category in fixtures[fkey] if where is None or category==where)
        wanted=[key for _,key in ranked[:k]]
        expected_digest=hashlib.sha256(json.dumps(wanted,sort_keys=True,separators=(',',':'),allow_nan=False).encode()).hexdigest()
        require(c['result_count']==len(wanted) and c['result_sha256']==expected_digest,'independent integer oracle digest differs '+name)
        identity=c['runtime_identity'];threads=2 if fanout else 1
        require(identity['executable_sha256']==candidate and identity['runtime_environment']=={'MVDB_QUERY_THREADS':str(threads),'MVDB_PARSE_THREADS':'1','MVDB_ANN_OFF':'1','MVDB_BATCH8_TRACE':'1'},'actual gate environment/ELF differs')
        require(type(identity['pid']) is int and len(identity['native_tasks'])==len(set(identity['native_tasks']))==threads and identity['pid'] in identity['native_tasks'],'actual gate worker count differs')
        require(group not in identities or identities[group]==identity,'same gate session identity drift');identities[group]=identity
        traces=c['traces'];parse_traces(b''.join(b'MVDB_BATCH8_TRACE '+json.dumps(t).encode()+b'\n' for t in traces))
        if expected=='none':require(traces==[],'excluded path entered batch')
        else:
            spans=[(0,count//2),(count//2,count)] if fanout else [(0,count)]
            require(len(traces)==len(spans),'trace partition count')
            for worker,(t,(first,last)) in enumerate(zip(sorted(traces,key=lambda t:t['worker']),spans)):
                require((t['path'],t['worker'],t['first'],t['last'],t['dimension'],t['k'])==('fanout' if fanout else 'serial',worker,first,last,dim,k),'trace span/ordinal differs')
                begin,end=t['batch_begin'],t['batch_end']
                require(begin==first+k and first<=begin<=end<=last and (end-begin)%8==0 and t['batches']==(end-begin)//8,'current-cap loop extent invalid')
                require((t['batches']>0 and last-end<8) if expected=='positive' else (t['batches']==0 and begin==end),'gate batch activity differs')
        logged.setdefault(group,[]).extend(traces)
        case_details.append({'name':name,'integer_oracle_digest_verified':True,'trace_records':len(traces)})
    require(len(report['stderr_logs'])==5,'gate stderr inventory missing')
    found=set()
    for entry in report['stderr_logs']:
        group=entry['path'].rsplit('/',1)[-1].split('.')[0]
        require(group in logged and group not in found and entry['path']==f'image-binary-batch8-logs/{group}.stderr.log','stderr relative path differs');found.add(group)
        log=root/entry['path'];require(log.stat().st_size==entry['bytes'] and sha(log)==entry['sha256'],'stderr raw bytes differ')
        require(parse_traces(log.read_bytes())==logged[group],'raw stderr trace attribution differs')
    hashes={path.name:sha(path)};counts=[]
    for mode in ('normal','sanitized'):
        log=root/('batch8-bound-'+mode+'.log');text=log.read_text();n=re.findall(r'^batch8_bound_checks=(\d+)$',text,re.M)
        require(len(n)==1 and int(n[0])>0 and text.splitlines().count('batch8_bound=PASS')==1 and not any(m in text for m in ('ERROR: AddressSanitizer','runtime error:','FAIL ')),'native bound unit incomplete')
        counts.append(int(n[0]));hashes[log.name]=sha(log)
    require(counts[0]==counts[1],'bound unit inventory differs')
    environment=read(root/'batch8-environment.json')
    require(environment=={'schema_version':1,'status':'supported_native_avx2','native_row_isa':'avx2','selected_batch_isa':'avx2','avx2':True,'avx512':False,'database_runs':0,'pgo_builds':0,'performance_pairs':0},'native environment not admitted')
    require((root/'batch8-environment-exit-code.txt').read_text().strip()=='0','native environment exit differs')
    probe=root/'batch8-native-isa-probe';require(probe.read_bytes()[:6]==b'\x7fELF\x02\x01' and (root/'batch8-native-isa-probe.sha256').read_text().split()[0]==sha(probe),'native probe ELF identity differs')
    hashes['batch8-environment.json']=sha(root/'batch8-environment.json')
    bound={'schema_version':1,'checks_per_mode':counts[0],'actual_image_checks':21,'binary_sha256':candidate,'native_row_isa':'avx2','batch_isa':'avx2','file_sha256':hashes}
    require(gates['batch8_evidence']==bound,'root batch8 evidence binding differs')
    return bound,{'cases':case_details,'all_result_digests_reproduced_with_integer_oracle':True,'five_complete_stderr_logs_verified':True,'native_environment_probe_sha256':sha(probe),'trace_scope':'Gate-only opt-in logs; no inference of timed path frequency.'}
