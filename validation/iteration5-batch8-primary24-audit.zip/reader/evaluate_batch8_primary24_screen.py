"""Independent new clear-gain screen, reusing only the frozen retained guards."""
import hashlib
import json
from pathlib import Path
import evaluate_norm_maxabs_primary24_screen as retained

POLICY_SHA='adda2853849fbc6ac2697047d890665b3484e3028f2f1dfbff114cae8254ecde'
PREREG_SHA='5c9eebe2da6d65ee20ba1f0cf862cfa419909efed7346b432b45e97bbbef5ea1'
POLICY_PATH='validation/iteration5-batch8-clear-gain-policy.json'
OLD_PLAN_PATH='validation/iteration5-norm-maxabs-primary24-preregistration.json'
EXPERIMENT='batch8-avx2-highest-primary24'
PRIMARY={
 'first_lifecycle_wall_seconds':'first_lifecycle_wall_median_candidate_over_baseline_max',
 'first_lifecycle_cpu_to_before_shutdown_usec':'first_lifecycle_CPU_median_candidate_over_baseline_max',
 'first_1000_queries_wall_seconds':'query_1000_wall_median_candidate_over_baseline_max',
 'first_1000_queries_cpu_usec':'query_1000_CPU_median_candidate_over_baseline_max'}

def evaluate_screen(old_plan,policy_raw,groups,*,verified_gate_checks_passed,preregistration_sha256):
    retained.require(hashlib.sha256(policy_raw).hexdigest()==POLICY_SHA,'new clear-gain policy drift')
    policy=json.loads(policy_raw);rule=policy['primary_screen']['EE_each_CPU_separately']
    # This independently verifies the same fixed24 pair identities and every R
    # protection; its historical EE rule is superseded below, never reported as
    # the decision for this new candidate.
    answer=retained.evaluate_screen(old_plan,groups,verified_gate_checks_passed=verified_gate_checks_passed)
    ee={};first_cpu_negatives=[]
    for cpu in (1,2):
        pairs=groups[('ee',cpu,'standard10k')];metrics={}
        retained.require(len(pairs)==6,'EE primary pair count')
        for metric,limit_key in PRIMARY.items():
            stats=retained.summarize_metric(pairs,metric)
            conditions={'median_meets_frozen_limit':stats['median_candidate_over_baseline']<=rule[limit_key],
              'faster_count_meets_frozen_minimum':stats['candidate_faster_pairs']>=rule['each_primary_metric_strictly_faster_pairs_min'],
              'AB_median_below_one':stats['AB_median']<rule['each_primary_metric_AB_and_BA_median_strictly_below'],
              'BA_median_below_one':stats['BA_median']<rule['each_primary_metric_AB_and_BA_median_strictly_below']}
            metrics[metric]={'limit':rule[limit_key],'conditions':conditions,'passed':all(conditions.values()),'statistics':stats}
            if metric=='first_lifecycle_cpu_to_before_shutdown_usec':
                for row in stats['pairs']:
                    if row['candidate_worse']:first_cpu_negatives.append({'group':f'ee:{cpu}:standard10k','metric':metric,**row})
        ee[str(cpu)]={'metrics':metrics,'passed':all(x['passed'] for x in metrics.values())}
    pass_ee=all(x['passed'] for x in ee.values());blocked=bool(answer['R_guard_triggers'])
    if not verified_gate_checks_passed:status='inconclusive_gates_not_verified_keep_R'
    elif blocked:status='screen_rejected_R_regression_keep_R'
    elif not pass_ee:status='screen_clear_EE_gain_criteria_not_met_keep_R'
    else:status='screen_passed_eligible_for_one_independent_confirmation_only'
    answer.update(status=status,experiment_id=EXPERIMENT,preregistration_sha256=preregistration_sha256,
      acceptance_policy_sha256=POLICY_SHA,retained_guard_definition_sha256=retained.PREREG_SHA,
      EE_primary=ee,eligible_for_one_confirmation=verified_gate_checks_passed and pass_ee and not blocked,
      primary_first_lifecycle_CPU_adverse_pairs=first_cpu_negatives,
      first_lifecycle_CPU_scope='Cgroup start to before_shutdown; excludes shutdown CPU, unlike the wall stage sum.',
      required_confirmation=policy['confirmation'])
    return answer
