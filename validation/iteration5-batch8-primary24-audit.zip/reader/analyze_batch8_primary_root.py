"""Independent, read-only audit of the batch8 native-AVX2 highest-primary24_v1 screen.

Runs Python generators and evidence readers only; never launches a database.
No missing current-artifact outputs are reconstructed or accepted.
"""
import argparse
import ast
import hashlib
import importlib
import io
import json
import math
from pathlib import Path
import re
from statistics import median
import sys
import tempfile
from types import SimpleNamespace
import zipfile

import analyze_crc_root as core
import analyze_highest_compare as highest
from analyze_crc_root import (require, digest, sha, read, git, blob, safe_name,
    cpus, counters, io_counters, timings, lifecycle_timings, LABELS, TOOLS)

HIGHEST_COMMIT = '95afba3993cb21cdce32acf2502312262b8ae9ac'
CANDIDATE_COMMIT = 'ebd6d25f27ad1a32fa92d84bcd571ae86b55394e'
HIGHEST_ARCHIVE = 'validation/iteration5-highest-root-raw.zip'
HIGHEST_SHA = 'cb6a5801cf2195cfcb0aafe7067143c825c8420974ead2c9e81ab6e6c2deb599'
HIGHEST_BYTES = 3879395
EE_SHA = '9a437ae19ff20dbd7ab2e3242ce16c3b814d80536a0768c628d93d53a7b14bbd'
GATES = core.GATES | {'insert_owned_copy_normal_and_sanitized', 'actual_image_jsonl_cursor_frames', 'cached_quantizer_code_equivalence_normal_and_sanitized', 'batch8_bound_normal_and_sanitized', 'actual_image_batch8_dispatch_and_oracle'}
FAMILY = 'highest_primary24_v1'
PREREG_PATH = 'validation/iteration5-batch8-primary24-preregistration.json'
EXPERIMENT_ID = 'batch8-avx2-highest-primary24'
import analyze_cursor_root as cursor
import evaluate_batch8_primary24_screen as screen
from batch8_reader_gates import runtime_guard, verify_batch8_gate
BATCH8_FLAGS = core.FLAGS + ['-DMVDB_ENABLE_BATCH8_QUANTIZED']
INPUT_PATHS = core.INPUT_PATHS + (screen.POLICY_PATH,'minivec/tools/batch8_native_isa_probe.cpp','minivec/tools/prepare_highest_primary.py','minivec/tools/summarize_highest_primary.py','minivec/tools/ci_highest_primary.sh')
MEASURED_CASES = ('standard10k', 'spill_high_q16', 'wide768')


def plan(reference, count):
    require(reference in ('retained', 'ee') and count in (1, 2), 'unknown highest-primary plan')
    specs = [('standard10k', 6 if reference == 'ee' else 4)]
    if reference == 'retained': specs.append(('spill_high_q16' if count == 1 else 'wide768', 2))
    return [{'scenario': name, 'seed': 7319, 'pair_index': i,
             'order': ['baseline', 'candidate'] if i % 2 == 0 else ['candidate', 'baseline']}
            for name, amount in specs for i in range(amount)]


def elf(raw):
    require(len(raw) > 64 and raw[:6] == b'\x7fELF\x02\x01' and
            int.from_bytes(raw[18:20], 'little') == 62, 'not x86-64 little-endian ELF')


def clear_generator_modules():
    # Every workload rerun must import its own Git-bound generator, not the
    # previous comparison's cached Python modules.
    for name in ('small_compute', 'benchmark_iteration', 'benchmark_index_delta',
                 'benchmark_write_query', 'benchmark_projection', 'json_protocol', '_transport'):
        sys.modules.pop(name, None)


def historical_ee(repo, commit, programs):
    raw = blob(repo, commit, HIGHEST_ARCHIVE)
    require(len(raw) == HIGHEST_BYTES and digest(raw) == HIGHEST_SHA, 'pinned original highest archive differs')
    with tempfile.TemporaryDirectory(prefix='mvdb-highest-primary-ee-read-') as td:
        directory = Path(td); archive = directory / 'original.zip'; archive.write_bytes(raw)
        extracted = directory / 'raw'; extracted.mkdir()
        with zipfile.ZipFile(io.BytesIO(raw)) as z:
            names = z.namelist(); require(len(names) == len(set(names)) and len(names) < 1000, 'historical archive names invalid')
            for name in names:
                safe_name(name); target = extracted / name
                target.parent.mkdir(parents=True, exist_ok=True); target.write_bytes(z.read(name))
        clear_generator_modules()
        audited = highest.audit(SimpleNamespace(input=extracted, archive=archive, repo=repo,
            commit=HIGHEST_COMMIT, artifact_sha256=HIGHEST_SHA, artifact_bytes=HIGHEST_BYTES))
        clear_generator_modules()
        require(audited['status'] == 'verified' and audited['verified_pairs'] == 40, 'historical independent audit failed')
        old = read(extracted / 'programs/ee/proof.json'); current = read(programs / 'ee/proof.json')
        require(current['status'] == 'verified' and current['source_commit'] == highest.EE and
                current['source_tree'] == highest.EE_TREE and current['binary_sha256'] == EE_SHA and
                current['kind'] == 'imported_historical_original_root_no_pgo' and
                current['new_root_builds'] == current['new_pgo_builds'] == 0 and
                current['official_binary_identity_known'] is False, 'imported EE scope differs')
        require(current['archive_sha256'] == HIGHEST_SHA and current['archive_bytes'] == HIGHEST_BYTES and
                current['prior_harness_commit'] == HIGHEST_COMMIT and current['historical_verified_pairs'] == 40 and
                current['historical_image_id'] == old['image_id'] and current['source_sha256'] == old['source_sha256'] and
                current['source_manifest_sha256'] == old['source_manifest_sha256'] and
                current['source_archive_sha256'] == old['source_archive_sha256'], 'EE source/archive/image proof changed')
        mappings = {'original-proof.json': 'programs/ee/proof.json', 'prior-summary.json': 'summary.json',
                    'prior-binding.json': 'binding-proof.json', 'prior-prepare.json': 'prepare-proof.json',
                    'prior-hashes.json': 'hashes.json', 'source-manifest.json': 'ee-source-manifest.json'}
        for dest, source in mappings.items():
            require((programs / 'ee' / dest).read_bytes() == (extracted / source).read_bytes(), 'imported EE evidence differs: ' + dest)
        require(current['original_proof_sha256'] == sha(extracted / 'programs/ee/proof.json') and
                current['prior_summary_sha256'] == sha(extracted / 'summary.json') and
                current['prior_binding_sha256'] == sha(extracted / 'binding-proof.json') and
                current['prior_manifest_sha256'] == sha(extracted / 'hashes.json'), 'EE prior digests differ')
        require(current['raw_source_archive_complete'] is False and current['missing_raw_members'] == ['ee-context/.dockerignore'] and
                current['source_recovery'] == {'kind': 'only_known_source_file_checked_in_memory',
                    'path': 'ee-context/.dockerignore', 'sha256': old['source_sha256']['.dockerignore'],
                    'bytes': 100, 'source_archive_member': 'context/.dockerignore', 'raw_archive_modified': False},
                'historical missing-source limitation omitted/expanded')
        program = (programs / 'ee/minivec').read_bytes(); elf(program)
        require(program == (extracted / 'programs/ee/minivec').read_bytes() and digest(program) == EE_SHA, 'imported EE program bytes changed')
        return {'verified_prior_pairs': 40, 'archive_sha256': HIGHEST_SHA, 'program_sha256': EE_SHA,
                'source_audit': audited['ee_source_audit'], 'image_id': old['image_id'],
                'artifact_limitations': audited['artifact_limitations'], 'new_database_runs': 0}


def metrics(run, scenario):
    result = highest.combined_metrics(run) | highest.resource_metrics(run)
    phases = run['adapter']['phase_cgroups']; p = {x['phase']: x for x in phases}
    require(len(p) == len(phases), 'duplicate phase snapshot')
    def cpu(start, end):
        a, b = (run['cgroup']['before'] if start == '__start' else p[start]), p[end]
        value = counters(b['cpu.stat'])['usage_usec'] - counters(a['cpu.stat'])['usage_usec']
        require(value >= 0, 'negative interval CPU'); return value
    if scenario == 'standard10k':
        require(list(p) == ['before_ingest', 'after_ingest', 'after_index_build', 'query_before_update',
                'before_shutdown', 'after_restart', 'query_after_restart', 'before_final_shutdown'], 'standard snapshot inventory/order differs')
        parts = run['ingest_request_seconds']
        require(set(parts) == {'begin', 'insert', 'commit'} and all(math.isfinite(x) and x >= 0 for x in parts.values()) and
                math.isclose(math.fsum(parts.values()), run['phase_seconds']['ingest'], rel_tol=1e-12, abs_tol=1e-9),
                'ingest components do not reconcile')
        result.update({'ingest_wall_seconds': run['phase_seconds']['ingest'],
            'first_query_wall_seconds': run['query']['query_before_update']['per_request_seconds'][0],
            'ingest_cpu_usec': cpu('before_ingest', 'after_ingest'),
            'first_queries_cpu_usec': cpu('after_index_build', 'query_before_update'),
            'first_lifetime_cpu_to_before_shutdown_usec': cpu('__start', 'before_shutdown')})
        result.update({'ingest_' + k + '_wall_seconds': v for k, v in parts.items()})
    elif scenario == 'spill_high_q16':
        result['first_queries_cpu_usec'] = cpu('after_index_build', 'query_before_mutations') + sum(cpu(f'writes_cycle_{i}', f'query_cycle_{i}') for i in range(4))
    elif scenario == 'wide768':
        result['first_queries_cpu_usec'] = sum(cpu(name + '/before', name + '/after') for name in LABELS)
    else: raise ValueError('unplanned metric scenario')
    if 'resource_snapshots' in run:
        result['max_process_rss_bytes'] = max(p['process_memory_proxy']['VmRSS_bytes'] for p in run['resource_snapshots'])
    for snapshot in run.get('resource_snapshots', []):
        if snapshot['phase'] != 'after_ingest': continue
        values = snapshot['process_io_counters_proxy']
        result['after_ingest_process_wchar_proxy'] = values['wchar']
        result['after_ingest_process_write_bytes_proxy'] = values['write_bytes']
    if 'shutdown_data_file_bytes' in run:
        result['first_shutdown_logical_file_bytes'] = run['shutdown_data_file_bytes']
    require(all(math.isfinite(v) and v >= 0 for v in result.values()), 'invalid derived metric')
    return result


def extra_summary(data):
    grouped = {}
    for pair in data['pairs']:
        name = pair['scenario']; b, c = (metrics(pair[role], name) for role in ('baseline', 'candidate'))
        require(set(b) == set(c), 'paired metric inventory differs')
        for key in b:
            grouped.setdefault(name, {}).setdefault(key, []).append({'pair_index': pair['pair_index'], 'order': pair['order'],
                'baseline': b[key], 'candidate': c[key], 'baseline_over_candidate': b[key]/c[key] if c[key] else None,
                'candidate_minus_baseline': c[key]-b[key], 'candidate_larger': c[key]>b[key]})
    return {name: {key: highest.pair_summary(rows) for key, rows in values.items()} for name, values in grouped.items()}


def collector_default(derived, claimed):
    mapping = {'first_lifecycle_wall_seconds':'first_lifetime_no_restart',
        'first_lifecycle_cpu_to_before_shutdown_usec':'first_lifetime_cpu_to_before_shutdown_usec',
        'first_1000_queries_wall_seconds':'first_lifetime_query_total',
        'first_1000_queries_cpu_usec':'first_queries_cpu_usec',
        'ingest_wall_seconds':'ingest_wall_seconds','ingest_cpu_usec':'ingest_cpu_usec',
        'ingest_begin_wall_seconds':'ingest_begin_wall_seconds','ingest_insert_wall_seconds':'ingest_insert_wall_seconds',
        'ingest_commit_wall_seconds':'ingest_commit_wall_seconds','complete_lifecycle_cpu_usec':'whole_cgroup_cpu_usec',
        'memory_peak_bytes':'whole_cgroup_memory_peak_bytes','device_write_bytes':'whole_cgroup_device_write_bytes',
        'first_query_wall_seconds':'first_query_wall_seconds','max_process_rss_bytes':'max_process_rss_bytes'}
    expected = {}
    for target, source in mapping.items():
        rows = [{'pair_index':r['pair_index'],'order':r['order'],'baseline':r['baseline'],'candidate':r['candidate'],
            'baseline_over_candidate':r['baseline_over_candidate'],
            'candidate_over_baseline':r['candidate']/r['baseline'] if r['baseline'] else None,
            'candidate_greater':r['candidate_larger']} for r in derived[source]['raw_pairs']]
        ratios=[r['candidate_over_baseline'] for r in rows if r['candidate_over_baseline'] is not None]
        expected[target]={'raw_pairs':rows,'median_candidate_over_baseline':median(ratios) if ratios else None,
                          'candidate_greater_pairs':sum(r['candidate_greater'] for r in rows)}
    require(claimed['metrics']==expected,'collector default metric arithmetic differs')
    require(claimed['decision']=='pending_preregistered_independent_review','collector adoption scope differs')
    return None


def gate_artifacts(root, repo, commit, gates):
    cases = {x['id'] for x in json.loads(blob(repo, commit, 'mysqltest/manifest.json'))['cases']}
    require(len(cases) == 20, 'public inventory differs')
    for role in ('image', 'source'):
        for phase, expected in (('handshake', {'handshake'}), ('public', cases)):
            r = read(root / (role + '-' + phase) / 'result.json')
            require(r['passed'] is True and len(r['cases']) == len(expected) and {x['id'] for x in r['cases']} == expected and
                    all(x['status']=='PASS' for x in r['cases']), 'public result incomplete')
    for mode in ('normal', 'sanitized'):
        log = (root / ('insert-owned-copy-' + mode + '.log')).read_text(encoding='utf8')
        values = re.findall(r'^PASS INSERT owned-copy (\d+) checks$', log, re.M)
        require(len(values) == 1 and int(values[0]) > 0 and int(values[0]) == gates['insert_owned_copy_checks'][mode], 'INSERT gate log/count differs')
        require(not any(x in log for x in ('ERROR: AddressSanitizer', 'runtime error:', 'FAIL ')), 'INSERT gate diagnostic failure')
    u = read(root / 'image-binary-utf8.json')
    expected = {(raw, dim, path) for raw in ('ff','c080','eda080','e4b8','f4908080','80') for dim in (None,127,128)
                for path in ('ORDER BY id LIMIT 10','unbounded','ORDER BY id LIMIT 4096')}
    require(u['status']=='passed' and len(u['checks'])==54 and all(x['status']=='passed' for x in u['checks']) and
            {(x['malformed_hex'],x['projected_vector_dimension'],x['path']) for x in u['checks']}==expected, 'actual ELF UTF8 gates incomplete')
    names = ['typed_rows','row_encoding_reuse','transactions_and_invalid_input','crash_recovery','mode_switch','fragmented_jsonl','parallel_insert_errors','legacy_mode']
    require([x for x in (root/'image-binary-json.log').read_text().splitlines() if x.startswith('PASS ')]==['PASS '+x for x in names], 'actual ELF JSON gates incomplete')
    for name in ('image-binary-topk.log','image-binary-topk-parallel.log'):
        require((root/name).read_text().strip()=='PASS JSONL TopK against exact float32 oracle, including ties, filters and rollback', 'actual ELF TopK gate incomplete')


# Runtime guard is imported from independent batch8_reader_gates.


def quantizer_gate(root, gates):
    path=root/'cached-quantizer-equivalence.json'; result=read(path)
    require(result['schema_version']==1 and result==gates['cached_quantizer_equivalence'],
            'quantizer report not bound to root gates')
    hashes={path.name:sha(path)}; counts={}
    for mode in ('normal','sanitized','block-scale'):
        value=result[mode+'_checks']
        require(type(value) is int and value>0 and result[mode+'_pass'] is True,'quantizer checks/pass incomplete')
        log=root/('cached-quantizer-'+mode+'.log'); text=log.read_text()
        require(re.findall(r'^cached_quantizer_checks=(\d+)$',text,re.M)==[str(value)] and
                text.splitlines().count('cached_quantizer=PASS')==1 and
                not any(marker in text for marker in ('ERROR: AddressSanitizer','runtime error:','FAIL ')),
                'quantizer log count, pass or sanitizer evidence differs')
        counts[mode]=value;hashes[log.name]=sha(log)
    require(counts['normal']==counts['sanitized'],'quantizer normal/sanitized inventories differ')
    return {'checks_per_mode':counts['normal'],'file_sha256':hashes}


def source_equivalence_gates(root, gates, repo, commit, candidate):
    historical=quantizer_gate(root,gates)
    batch,extra=verify_batch8_gate(root,gates,repo,commit,candidate)
    return {**historical,'batch8':batch},extra


def crc_regression_unit(root, repo, commit):
    unit=root/'crc-checks/unit'; manifest=core.manifest_tree(unit); summary=read(unit/'summary.json')
    require(summary['status']=='passed' and summary['stage']=='unit' and summary['exit_code']==0 and
            summary['formal_submission'] is False and summary['performance_measurements']==0 and
            (unit/'harness-commit.txt').read_text().strip()==commit,'CRC regression unit scope differs')
    sources=read(unit/'source-sha256.json')
    require(set(sources)=={'minivec/src/crc32_ieee.h','minivec/tests/test_crc32_ieee.cpp','minivec/tools/ci_crc_checks.sh'},
            'CRC regression unit source inventory differs')
    for path,value in sources.items():
        require(digest(blob(repo,commit,path))==value==sha(unit/'source'/path),'CRC unit source differs from Git')
    counts={}
    for mode in ('normal','sanitized'):
        match=re.fullmatch(r'PASS crc32 IEEE slicing-by-8 ([0-9]+) checks\n?',(unit/(mode+'.log')).read_text())
        require(match is not None and int(match.group(1))>=34000,'CRC regression unit count incomplete')
        elf((unit/('crc-'+mode)).read_bytes());counts[mode]=int(match.group(1))
    require(counts==summary['unit_checks'] and counts['normal']==counts['sanitized'],'CRC unit count binding differs')
    return {'unit_checks':counts,'manifest':manifest,'scope':'Regression unit only; this experiment did not run the historical 18-pair CRC compatibility suite.'}


def screen_input(data, reference, count):
    groups={}
    for pair in data['pairs']:
        name=pair['scenario']; sides={}
        for role in ('baseline','candidate'):
            run=pair[role]; values=metrics(run,name)
            common={'complete_lifecycle_cpu_usec':values['whole_cgroup_cpu_usec'],
                    'memory_peak_bytes':values['whole_cgroup_memory_peak_bytes']}
            if name=='standard10k':
                selected={**common,'first_lifecycle_wall_seconds':values['first_lifetime_no_restart'],
                    'first_1000_queries_wall_seconds':values['first_lifetime_query_total'],
                    'first_lifecycle_cpu_to_before_shutdown_usec':values['first_lifetime_cpu_to_before_shutdown_usec'],
                    'first_1000_queries_cpu_usec':values['first_queries_cpu_usec'],
                    'first_query_wall_seconds':values['first_query_wall_seconds'],
                    'ingest_wall_seconds':values['ingest_wall_seconds'],
                    'ingest_cpu_usec':values['ingest_cpu_usec'],
                    'max_process_rss_bytes':values['max_process_rss_bytes']}
            elif name=='spill_high_q16':
                snapshots={item['phase']:item for item in run['adapter']['phase_cgroups']}
                require(len(run['query']['query_before_mutations']['per_request_seconds'])==16,
                        'spill initial phase is not exactly sixteen requests')
                phase_names=[item['phase'] for item in run['adapter']['phase_cgroups']]
                require(phase_names.index('after_index_build')<phase_names.index('query_before_mutations'),
                        'spill initial query snapshot order differs')
                initial_cpu=(counters(snapshots['query_before_mutations']['cpu.stat'])['usage_usec']-
                             counters(snapshots['after_index_build']['cpu.stat'])['usage_usec'])
                require(initial_cpu>=0,'negative initial spill query CPU')
                selected={**common,'first_lifecycle_wall_seconds':values['first_lifetime_no_restart'],
                    'query_before_mutations_wall_seconds':run['phase_seconds']['query_before_mutations'],
                    'query_before_mutations_cpu_usec':initial_cpu,
                    'first_query_wall_seconds':run['query']['query_before_mutations']['per_request_seconds'][0],
                    'ingest_wall_seconds':run['phase_seconds']['ingest'],
                    'max_process_rss_bytes':values['max_process_rss_bytes']}
            elif name=='wide768':
                selected={**common,'lifecycle_stage_wall_sum':values['first_lifetime_no_restart'],
                    'seven_query_phases_wall_seconds':values['first_lifetime_query_total'],
                    'seven_query_phases_cpu_usec':values['first_queries_cpu_usec']}
            else:raise ValueError('unplanned screen scenario')
            sides[role]=selected
        require(set(sides['baseline'])==set(sides['candidate']),'screen side metrics differ')
        groups.setdefault((reference,count,name),[]).append({'pair_index':pair['pair_index'],'order':pair['order'],
            'metrics':{key:{role:sides[role][key] for role in ('baseline','candidate')} for key in sides['baseline']}})
    return groups


def training_log(root, repo, commit):
    text = (root / 'docker-build.log').read_text(encoding='utf8')
    require(core.COMPILER in text and core.COMPILER.encode() in blob(repo, commit, 'Dockerfile'), 'compiler pin missing')
    records = []
    for line in text.splitlines():
        if '{' not in line: continue
        try: data = json.loads(line[line.index('{'):])
        except json.JSONDecodeError: continue
        if isinstance(data, dict) and 'actual_file' in data and 'expected_file' in data: records.append(data)
    expected = {(f'responses-{t}-{p}.jsonl', f'phase-{p}.expected.jsonl', [951, 41, 14][p]) for t in (1, 2) for p in range(3)}
    require(len(records) == 6 and {(r['actual_file'], r['expected_file'], r['responses']) for r in records} == expected and
            all(r['status'] == 'passed' for r in records), 'six PGO training oracle records missing')
    profiles = re.findall(r'\b([0-9a-f]{64})\s+(/pgo/minivec-[A-Za-z_]+\.gcda)', text)
    require(len(profiles) == 6 and {p for _, p in profiles} == {'/pgo/minivec-' + n + '.gcda' for n in ('db', 'exec', 'flat_index', 'main', 'sql', 'value')}, 'PGO profile inventory differs')
    for p in ('minivec/tools/pgo/train.cpp', 'minivec/tools/pgo/run-training.sh', 'Dockerfile'):
        actual=blob(repo,commit,p)
        if p=='Dockerfile':actual=actual.replace(b' -DMVDB_ENABLE_BATCH8_QUANTIZED',b'')
        require(actual == blob(repo, core.BASE, p), 'training/build policy changed: ' + p)
    return {'oracle': records, 'profile_hashes_from_build_log': dict((p, h) for h, p in profiles),
            'scope': 'Build log records six independent oracle successes and six profile digests; release artifact does not include raw gcda bytes.'}


def audit(args):
    root, repo, commit = args.input.resolve(), args.repo.resolve(), args.commit
    receipt=read(args.api_receipt); art=receipt['artifact']; workflow=art['workflow_run']
    require(receipt['commit']==workflow['head_sha']==commit and workflow['id']==receipt['run_id'], 'API run/commit differs')
    require(art['name']=='root-image-validation' and art['digest']=='sha256:'+args.artifact_sha256 and art['size_in_bytes']==args.artifact_bytes and art['expired'] is False,'API artifact scope differs')
    require(art['url']=='https://api.github.com/repos/iamSttt/seekdb/actions/artifacts/'+str(art['id']),'API artifact repository differs')
    api_binding={'receipt_sha256':sha(args.api_receipt),'run_id':receipt['run_id'],'artifact_id':art['id'],'artifact_sha256':args.artifact_sha256,'bytes':args.artifact_bytes,'job_id_reported':receipt.get('job_id'),'job_conclusion_claim':'Not inferred from compact artifact receipt; this audit validates completed gate and measurement contents.'}
    require(commit == CANDIDATE_COMMIT, 'reader is pinned to the reviewed highest-primary experiment')
    count = core.verify_archive(root,args.archive.resolve(),args.artifact_sha256,args.artifact_bytes)
    small = root/'highest-primary-root'; programs=small/'programs'; core.manifest_tree(small)
    gates, final, proof, overall = [read(p) for p in (root/'root-gates-summary.json',root/'verification-summary.json',programs/'root-proof.json',small/'summary.json')]
    require(gates['passed'] is True and set(gates['checks'])==GATES and all(x is True for x in gates['checks'].values()), 'root gates incomplete')
    require(final['passed'] is True and set(final['checks'])==GATES|{'actual_root_highest_primary_24_pairs'} and all(x is True for x in final['checks'].values()), 'combined highest-primary gates incomplete')
    require(gates['runtime_commit']==final['runtime_commit']==proof['source_commit']==commit==(root/'runtime-commit.txt').read_text().strip(), 'current commit differs')
    require(gates['selected_feature_flags']==final['selected_feature_flags']==proof['feature_flags']==BATCH8_FLAGS, 'features changed')
    image=(root/'image-id.txt').read_text().strip(); binary=programs/'actual-image-minivec'; candidate=sha(binary);elf(binary.read_bytes())
    require(re.fullmatch(r'sha256:[0-9a-f]{64}',image) and gates['image_id']==final['image_id']==proof['image_id']==image, 'root image differs')
    inspection=read(root/'image-inspect.json');require(len(inspection)==1 and inspection[0]['Id']==image and inspection[0]['Config']['Entrypoint']==['/minivec','--data','/data'], 'root image inspection differs')
    require(candidate==gates['image_binary_sha256']==final['image_binary_sha256']==proof['binary_sha256']==(root/'image-binary-sha256.txt').read_text().split()[0], 'root ELF differs')
    require(proof['status']=='verified' and proof['harness_matches_git'] is True and proof['official_binary_identity_known'] is False, 'root scope differs')
    require(sha(programs/'root-gates-summary.json')==sha(root/'root-gates-summary.json')==proof['root_gate_summary_sha256'] and
            sha(programs/'root-input-sha256.txt')==sha(root/'input-sha256.txt')==proof['root_input_manifest_sha256'], 'root manifests differ')
    inputs={}
    for line in (root/'input-sha256.txt').read_text().splitlines():
        h,path=line.split(maxsplit=1);path=path.lstrip('*');safe_name(path);require(path not in inputs,'duplicate root input');inputs[path]=h
    require(set(inputs)==set(git(repo,'ls-tree','-r','--name-only',commit,'--',*INPUT_PATHS).decode().splitlines()) and inputs==proof['root_input_sha256'], 'complete root Git inputs differ')
    for path,h in inputs.items():require(digest(blob(repo,commit,path))==h,'Git root input differs: '+path)
    runtime = runtime_guard(repo, commit)
    required_tools=TOOLS|{'minivec/tools/prepare_insert_copy_root.py','minivec/tools/ci_insert_copy_root.sh','minivec/tools/summarize_insert_copy_root.py','minivec/tools/prepare_highest_compare.py','minivec/tools/prepare_highest_primary.py','minivec/tools/ci_highest_primary.sh','minivec/tools/summarize_highest_primary.py','.github/workflows/minivec-score.yml'}
    require(required_tools.issubset(proof['harness_file_sha256']), 'required harness proof incomplete')
    importer_ast=ast.parse(blob(repo,commit,'minivec/tools/prepare_small_compute.py'))
    tool_assignments=[x for x in ast.walk(importer_ast) if isinstance(x,ast.Assign) and any(isinstance(t,ast.Name) and t.id=='tool_paths' for t in x.targets)]
    require(len(tool_assignments)==1 and set(ast.literal_eval(tool_assignments[0].value))==set(proof['harness_file_sha256']),
            'complete transitive harness/archive inventory differs')
    for path,h in proof['harness_file_sha256'].items():require(digest(blob(repo,commit,path))==h,'Git harness differs: '+path)
    retained=read(programs/'retained/provenance.json')
    require(retained['status']=='verified' and retained['binary_sha256']==core.BASE_BINARY and retained['source_commit']==core.BASE and retained['harness_commit']==commit and retained['harness_matches_git'] is True and retained['new_pgo_builds']==0, 'retained import differs')
    require(retained['retained_archive_sha256']=='88e4a73af9d333b08a6db817a78c7cb06357fcfddc05eee1b31c2a065aebfef2' and retained['retained_archive_bytes']==49685962 and retained['feature_flags']==core.FLAGS and retained['compiler_image']==core.COMPILER, 'retained archive/build policy differs')
    old_paths=set(git(repo,'ls-tree','-r','--name-only',core.BASE,'--','minivec/src').decode().splitlines())|{'minivec/tools/pgo/train.cpp','minivec/tools/pgo/run-training.sh'}
    require(set(retained['source_and_training_sha256'])==old_paths,'retained source inventory differs')
    for path,h in retained['source_and_training_sha256'].items():require(digest(blob(repo,core.BASE,path))==h,'retained Git input differs')
    require(sha(programs/'retained/prior-context.json')==retained['retained_context_sha256'],'retained prior context differs')
    gate_artifacts(root,repo,commit,gates); training=training_log(root,repo,commit)
    source_gates, batch_details = source_equivalence_gates(root, gates, repo, commit, candidate)
    framing = cursor.cursor_gate(root,repo,commit,candidate)
    crc_unit = crc_regression_unit(root,repo,commit)
    ee=historical_ee(repo,commit,programs)
    prereg_raw=blob(repo,commit,PREREG_PATH)
    require(digest(prereg_raw)==screen.PREREG_SHA, 'fresh preregistration Git bytes differ')
    preregistration={'path':PREREG_PATH,'bytes':len(prereg_raw),'sha256':digest(prereg_raw)}
    policy_raw=blob(repo,commit,screen.POLICY_PATH)
    require(digest(policy_raw)==screen.POLICY_SHA and len(policy_raw)==2661,'clear-gain policy differs')
    policy_identity={'path':screen.POLICY_PATH,'bytes':len(policy_raw),'sha256':digest(policy_raw)}
    old_plan=json.loads(blob(repo,commit,screen.OLD_PLAN_PATH))
    binding=read(programs/'highest-primary-binding-proof.json')
    require(binding['status']=='verified' and binding['measurement_family']==FAMILY and binding['primary_reference']=='ee' and
            binding['quantizer_gate']==source_gates and binding['experiment_id']==EXPERIMENT_ID and
            binding['acceptance_policy']==policy_identity and binding['candidate_source_commit']==commit and binding['candidate_binary_sha256']==candidate and binding['candidate_image_id']==image and
            binding['current_root_proof_sha256']==sha(programs/'root-proof.json') and binding['ee_import_proof_sha256']==sha(programs/'ee/proof.json') and
            binding['new_ee_builds']==binding['new_pgo_builds']==0, 'highest-primary import binding differs')
    require(overall==final['highest_primary_screen'] and overall['measurement_family']==FAMILY and overall['primary_reference']=='ee' and
            'experiment_id' not in overall and overall['acceptance_policy']==policy_identity and overall['status']=='passed' and overall['exit_code']==0 and overall['completed_pairs']==overall['expected_pairs']==24 and
            overall['new_pgo_builds']==1 and overall['rebuilt_reference_programs']==0 and overall['candidate_source_commit']==commit and overall['candidate_image_id']==image and
            overall['candidate_binary_sha256']==candidate and overall['automatic_adoption'] is False and overall['official_score'] is None and overall['formal_submission'] is False, '24-pair summary differs')
    clear_generator_modules();local=core.reproduce_workloads(repo,commit);clear_generator_modules()
    reports={}; negatives=[]; hosts=[]; tasks=[]; masks={}; total=0; reviewed_labels=set(); screen_groups={}
    for reference in ('ee','retained'):
        ids_path=programs/(reference+'-identities.json');ids=read(ids_path)
        require(set(ids)=={'baseline','candidate'} and binding[reference+'_identity_sha256']==sha(ids_path), 'comparison identity binding differs')
        require(ids['candidate']['binary_sha256']==candidate and ids['candidate']['source_commit']==commit and ids['candidate']['evidence_file']=='root-proof.json', 'candidate identity differs')
        require(ids['baseline']['binary_sha256']==(core.BASE_BINARY if reference=='retained' else EE_SHA) and ids['baseline']['source_commit']==(core.BASE if reference=='retained' else highest.EE), 'reference identity differs')
        if reference=='retained':require(ids_path.read_bytes()==(programs/'identities.json').read_bytes(),'original retained identity changed')
        for role,item in ids.items():
            safe_name(item['binary']);safe_name(item['evidence_file']);elf((programs/item['binary']).read_bytes())
            require(sha(programs/item['binary'])==item['binary_sha256'] and sha(programs/item['evidence_file'])==item['evidence_sha256'] and item['environment']=={} and
                    item['evidence_binary_pointer']==['binary_sha256'] and item['evidence_commit_pointer']==['source_commit'], 'immutable program identity differs')
        reports[reference]={}
        for cpu in (1,2):
            data=read(small/f'{reference}-{cpu}cpu.json');cases=tuple(dict.fromkeys(p['scenario'] for p in plan(reference,cpu)))
            require(data['workloads']==[local[x] for x in cases], 'full current SQL/oracle content does not reproduce')
            report=verify_highest_measurements(data,cpu,cases,programs,ids,proof,local,reference)
            report['extra_summary']=extra_summary(data);reports[reference][str(cpu)]=report;total+=report['verified_pairs']
            label=f'{reference}-{cpu}cpu'
            collector_default(report['extra_summary']['standard10k'],overall['standard_comparisons'][label]); reviewed_labels.add(label)
            screen_groups.update(screen_input(data,reference,cpu))
            require(overall['protection_summaries'][label]=={k:v for k,v in report['summary'].items() if k!='standard10k'},
                    'collector protection summaries differ')
            hosts.append(data['host']);tasks.append(data['taskset']);require(re.fullmatch('[0-9a-f]{64}',data['taskset']['sha256']),'taskset SHA absent')
            require(cpu not in masks or masks[cpu]==data['db_cpus'],'CPU masks differ between contrasts');masks[cpu]=data['db_cpus']
            for name,values in report['extra_summary'].items():
                for metric,item in values.items():
                    if item['candidate_larger_pairs']:negatives.append({'comparison':reference+'_vs_candidate','cpu_count':cpu,'scenario':name,'metric':metric,**item})
            for name,values in report['summary'].items():
                for phase,item in values.items():
                    if item['candidate_slower_pairs']:negatives.append({'comparison':reference+'_vs_candidate','cpu_count':cpu,'scenario':name,'phase':phase,**item})
    require(total==24 and all(h==hosts[0] for h in hosts) and all(t==tasks[0] for t in tasks),'24-pair same-run host/taskset mismatch')
    require(set(overall['standard_comparisons'])==reviewed_labels==set(overall['protection_summaries']), 'combined comparison inventory differs')
    require(masks[1]==masks[2][:1], 'one/two CPU affinity selection differs')
    decision=screen.evaluate_screen(old_plan,policy_raw,screen_groups,verified_gate_checks_passed=True,preregistration_sha256=screen.PREREG_SHA)
    return {'status':'verified','verified_pairs':24,'commit':commit,'artifact_sha256':args.artifact_sha256,'artifact_files':count,
        'api_binding':api_binding,'candidate_binary_sha256':candidate,'candidate_image_id':image,'baseline_binary_sha256':{'retained':core.BASE_BINARY,'ee':EE_SHA},
        'root_git_input_count':len(inputs),'root_gates':gates['checks'],'root_pgo_evidence':training,'historical_ee_audit':ee,
        'workload_identity_audit':{x:local[x] for x in MEASURED_CASES},'measurements':reports,'all_negative_or_mixed_metrics':negatives,
        'preregistered_screen':decision,'runtime_delta_audit':runtime,'source_equivalence_gates':source_gates,'actual_batch8_gate_detail':batch_details,'acceptance_policy':policy_identity,'experiment_id':EXPERIMENT_ID,'preregistration':preregistration,'cursor_framing_regression':framing,'crc_unit_regression':crc_unit,
        'host':hosts[0],'actual_cpu_model':(small/'lscpu.txt').read_text(),'official_score':None,'score_floor_proven':False,'automatic_adoption':False,
        'limitations':['24 pairs at one seed: primary EE defaults 6 per CPU, retained defaults 4 per CPU; two retained protection pairs each. No confidence interval or formal-score floor.',
        'Each ratio uses its own same-run paired reference. No cross-arm or cross-run ratio inference. All adverse pairs retained.',
        'The fresh preregistration directly guards the initial sixteen query_before_mutations requests. All four later cycles and the complete eighty-query pre-restart aggregate remain reported. This is a new batch8 candidate screen, not confirmation or adoption.',
        'The rejected cached encoder remains test-only. Batch8 has separate normal/sanitized integer-bound and actual-ELF oracle/dispatch gates. Trace is enabled only for correctness, absent in timed process environments.',
        'First lifetime wall is a sum of measured startup/request/shutdown timers, not elapsed end-to-end time including driver oracle/telemetry gaps. Restart-inclusive timers are separate.',
        'First-lifetime CPU ends before shutdown, unlike first-lifetime wall. Ingest CPU is whole before/after interval; BEGIN/INSERT/COMMIT have wall subtotals only. No invented per-class CPU attribution.',
        'Whole-cgroup CPU/memory/IO include restart verification. Device writes are cgroup block accounting; process wchar includes protocol output; file sizes are not IO traffic or official B.',
        'EE program is a prior rebuild from original Git sources, not a recovered formal executable. Original source artifact omits one hidden file; current raw evidence must be complete.',
        'PGO profile hashes and six oracle outcomes come from the build log; gcda files are not archived. Ownership sanitizer fixture is source-built, while image JSON/TopK and paired queries exercise actual root ELF.',
        'Workload generators are repeated in Python only; all three current complete-content hashes must reproduce. Raw response bodies are not all archived; independent oracle checks and digests are bound to executed Git source. No local DB run claimed.']}


def main():
    p=argparse.ArgumentParser(description=__doc__)
    for name in ('input','archive','output'):p.add_argument('--'+name,type=Path,required=True)
    p.add_argument('--repo',type=Path,default=Path(__file__).resolve().parent/'seekdb')
    p.add_argument('--api-receipt',type=Path,required=True);p.add_argument('--commit',required=True);p.add_argument('--artifact-sha256',required=True);p.add_argument('--artifact-bytes',type=int,required=True)
    args=p.parse_args();require(not args.output.exists(),'refuse overwrite')
    require(not args.output.resolve().is_relative_to(args.input.resolve()),'analysis must be outside raw evidence')
    require(re.fullmatch('[0-9a-f]{40}',args.commit) and re.fullmatch('[0-9a-f]{64}',args.artifact_sha256),'full expected identity required')
    result=audit(args);args.output.write_text(json.dumps(result,ensure_ascii=False,indent=2,allow_nan=False)+'\n',encoding='utf8')
    print(json.dumps({'status':result['status'],'verified_pairs':result['verified_pairs'],'negative_metrics':len(result['all_negative_or_mixed_metrics']),'output':str(args.output)}))



# The previous independent measurement verifier is copied here with only the
# frozen plan, identity file and standard snapshot-count changes. Its resource,
# oracle, output and timer arithmetic checks remain intact.
def verify_highest_measurements(data, count, cases, programs, ids, proof, workloads, reference):
    expected = plan(reference, count)
    require(data.get('measurement_family')==FAMILY and data.get('highest_primary_reference')==reference and
            data.get('insert_copy_reference') is None and data.get('insert_thread_control') is False and data.get('matched_insert_roots') is False, 'highest-primary family differs')
    require(data['status'] == 'passed' and data['expected_pairs'] == data['completed_pairs'] == len(data['pairs']) == len(expected), 'measurement incomplete')
    require(data['plan'] == expected and [{k: p[k] for k in ('scenario', 'seed', 'pair_index', 'order')} for p in data['pairs']] == expected, 'measurement plan mismatch')
    require(data['query_mode_policy']=='exact','measurement mode is not exact')
    require(data['comparison_kind'] == 'whole_version_diagnostic' and data['official_score'] is None and data['official_binary_identity_known'] is False, 'scope mismatch')
    require(data['identity_record_sha256'] == sha(programs / (reference + '-identities.json')), 'identity JSON mismatch')
    require(data['workloads'] == [workloads[n] for n in cases], 'regenerated workload/oracle hash mismatch')
    require(data['db_cpu_count'] == count and len(set(data['db_cpus'])) == count and data['protection_only'] is False, 'CPU plan mismatch')
    require(set(data['db_cpus']).issubset(set(data['host']['driver_affinity'])), 'CPU selection outside inherited driver affinity')
    require(data['requested_limits'] == {'cpu_quota_us': count * 100000, 'cpu_period_us': 100000, 'memory_max': '2147483648', 'swap_max': '0'}, 'resource request mismatch')
    require(data['launcher_sha256'] == sha(programs.parent / 'cgroup_exec'), 'actual launcher differs')
    seen = {}
    for path, h in data['tool_hashes'].items():
        names = [name for name in TOOLS if path.endswith('/' + name)]
        require(len(names) == 1 and names[0] not in seen, 'tool path inventory mismatch')
        name = names[0]; seen[name] = h; require(proof['harness_file_sha256'][name] == h, 'executed tool differs from Git proof')
    require(set(seen) == TOOLS, 'tool set incomplete')
    for role in ('baseline', 'candidate'):
        item = data['identities'][role]
        for key in ('binary_sha256', 'source_commit', 'evidence_sha256', 'environment'):
            require(item[key] == ids[role][key], 'measured role identity mismatch')
        require(item['environment'] == {}, 'unexpected runtime override')
    details, grouped, lifecycle_grouped = [], {}, {}
    for pair in data['pairs']:
        name = pair['scenario']; require(pair['all_responses_identical'] is True, 'output equivalence absent')
        b, c = pair['baseline'], pair['candidate']; detail = {k: pair[k] for k in ('scenario', 'seed', 'pair_index', 'order')}; detail['sides'] = {}
        for role, run in (('baseline', b), ('candidate', c)):
            g, adapter, policy = run['cgroup'], run['adapter'], run['thread_policy_observations']
            require(run['declared_environment'] == run['effective_environment'] == {} and run['query_mode_policy']=='exact', 'run override/mode differs')
            modes = adapter['completed_request_modes']
            require(set(modes) == {'exact'} and modes['exact'] > 0 and modes['exact'] == adapter['completed_transport_requests'],
                    'actual transport request mode differs')
            require(not g['timeout'] and not g.get('request_timeout_observed') and not g.get('cleanup_kill_required') and not g.get('watchdog_error') and not any(g['oom_events_delta'].values()), 'timeout/OOM/process failure')
            for when in ('before', 'after'):
                require(g[when]['cpu.max'].split() == [str(count * 100000), '100000'], 'actual quota differs')
                require(g[when]['memory.max'] == '2147483648' and g[when]['memory.swap.max'] == '0', 'actual 2GiB/swap0 differs')
            for ancestor in g['ancestor_constraints']:
                cap = ancestor['memory.max']
                require(not isinstance(cap, str) or not cap.isdigit() or int(cap) >= 2147483648,
                        'ancestor memory constraint below 2GiB')
            require(not g['after']['cgroup.procs'].strip(), 'live DB remains')
            ready = adapter['ready_memberships']; require(len(ready) == (1 if name == 'wide768' else 2), 'ready/restart evidence missing')
            for item in ready:
                require(item['runtime_environment']=={}, 'actual ready process environment differs')
                require(item['pid'] in item['members'] and item['driver_pid'] not in item['members'] and
                        item['actual_exe'] == data['identities'][role]['binary'] and cpus(item['cpus_allowed_list']) == set(data['db_cpus']), 'actual executable/cgroup/affinity mismatch')
            phases = adapter['phase_cgroups']; require(len(phases) == (14 if name == 'wide768' else 15 if name.startswith('spill_') else 8), 'phase observations missing')
            for phase in phases:
                require(phase['memory.max'] == '2147483648' and phase['memory.swap.max'] == '0', 'phase memory/swap cap differs')
                require(not phase.get('native_tasks_error') and not phase.get('task_read_errors') and phase['native_tasks'] and sum(t['main'] for t in phase['native_tasks']) == 1, 'native task evidence missing')
                require(all(cpus(t['cpus_allowed_list']) == set(data['db_cpus']) for t in phase['native_tasks']), 'native task affinity drift')
            before, after = counters(g['before']['cpu.stat']), counters(g['after']['cpu.stat'])
            require(g['resource_delta']['cpu_stat_delta'] == {k: v - before.get(k, 0) for k, v in after.items()} and
                    g['resource_delta']['memory_peak_bytes'] == int(g['after']['memory.peak']), 'resource arithmetic differs')
            ib, ia = io_counters(g['before']['io.stat']), io_counters(g['after']['io.stat'])
            require(g['resource_delta']['io_stat_delta'] == {dev: {k: v - ib.get(dev, {}).get(k, 0) for k, v in fields.items()} for dev, fields in ia.items()}, 'device IO counter arithmetic differs')
            require(policy['stderr_complete'] is True and policy['requested_query_threads'] == 'automatic', 'policy observations incomplete')
            logs = policy['fanout_log_lines']; wake = [x for x in logs if '(measured, median of 200 handshakes)' in x]
            require(len(wake) == len(ready), 'real startup calibration missing')
            marker = 'single-CPU affinity; adaptive query fanout disabled, startup calibration retained'
            require(not any(marker in x for x in logs), 'rejected affinity policy unexpectedly active')
            cpu_intervals = {}
            by_phase = {x['phase']: x for x in phases}
            for start, end in (('after_index_build', 'query_before_update'), ('after_restart', 'query_after_restart')):
                if start in by_phase and end in by_phase:
                    left, right = by_phase[start], by_phase[end]
                    old = {(t['tid'], t['starttime_ticks']): t['cpu_ticks'] for t in left['native_tasks']}
                    cpu_intervals[end] = {'start': start, 'end': end, 'cpu_usage_usec': counters(right['cpu.stat'])['usage_usec'] - counters(left['cpu.stat'])['usage_usec'],
                        'nonmain_cpu_ticks_delta': sum(t['cpu_ticks'] - old.get((t['tid'], t['starttime_ticks']), 0) for t in right['native_tasks'] if not t['main']),
                        'scope': 'Includes restart ID/vector/payload verification.' if start == 'after_restart' else 'Post-index snapshot through first query phase; excludes restart verification.',
                        'nonmain_scope': 'All nonmain native tasks, not exclusively a named query worker.'}
            detail['sides'][role] = {'resources': g['resource_delta'], 'policy': policy, 'cpu_intervals': cpu_intervals}
        if name == 'wide768':
            for run in (b, c):
                require(run['status'] == 'passed' and set(run['phases']) == LABELS, 'projection phase schema differs')
                for phase in run['phases'].values():
                    require(all(r['search_mode']=='exact' for r in phase['requests']), 'projection sent a non-exact request')
                    require(len(phase['requests']) == 3 and phase['independent_oracle'] and phase['wall_seconds'] == sum(r['seconds'] for r in phase['requests']), 'projection oracle/timer evidence missing')
            for label in LABELS:
                require([(r['response_sha256'], r['response_bytes']) for r in b['phases'][label]['requests']] == [(r['response_sha256'], r['response_bytes']) for r in c['phases'][label]['requests']], 'projection responses differ')
        else:
            require(b['response_sha256'] == c['response_sha256'], 'lifecycle responses differ')
            for run in (b, c):
                require(all(q['modes']==['exact']*len(q['per_request_seconds']) for q in run['query'].values()), 'query mode trace is not all exact')
                if name.startswith('spill_'):
                    require(run['real_spill_observed'] is True and run['correctness']['all_query_responses_independent_oracle'] is True and len(run['write_cycles']) == 4 and len(run['query']) == 6 and
                            all(len(q['per_request_seconds']) == (16 if name.endswith('q16') else 1) for q in run['query'].values()), 'spill independent oracle/counts missing')
                    require(run['correctness']['all_restarted_ids_checked'] == 5000 and run['correctness']['all_mutated_payloads_and_tombstones_checked'] == [0, 1, 7, 1007], 'spill restart verification missing')
                else:
                    require(set(run['query']) == {'query_before_update', 'query_after_restart'} and all(len(q['per_request_seconds']) == 1000 for q in run['query'].values()) and
                            run['correctness']['sampled_topk_oracle_queries'] == [0, 1, 999], 'resident oracle/counts missing')
                    rows = workloads[name]['rows']
                    require(run['correctness']['all_restarted_ids_checked'] == rows and run['correctness']['restarted_vector_ids_checked'] == [0, 1, rows // 2, rows - 1], 'resident restart verification missing')
        bv, cv = timings(b), timings(c); require(set(bv) == set(cv), 'phase timers differ')
        for phase in bv:
            require(math.isfinite(bv[phase]) and math.isfinite(cv[phase]) and bv[phase] >= 0 and cv[phase] > 0, 'invalid measured timer')
            grouped.setdefault(name, {}).setdefault(phase, []).append({'pair_index': pair['pair_index'], 'order': pair['order'], 'baseline_seconds': bv[phase], 'candidate_seconds': cv[phase], 'baseline_over_candidate': bv[phase] / cv[phase], 'candidate_slower': cv[phase] > bv[phase]})
        bl, cl = lifecycle_timings(b), lifecycle_timings(c)
        require(set(bl) == set(cl), 'derived lifecycle boundaries differ')
        for phase in bl:
            require(math.isfinite(bl[phase]) and math.isfinite(cl[phase]) and bl[phase] >= 0 and cl[phase] > 0,
                    'invalid derived lifecycle timer')
            lifecycle_grouped.setdefault(name, {}).setdefault(phase, []).append({'pair_index': pair['pair_index'],
                'order': pair['order'], 'baseline_seconds': bl[phase], 'candidate_seconds': cl[phase],
                'baseline_over_candidate': bl[phase] / cl[phase], 'candidate_slower': cl[phase] > bl[phase]})
        details.append(detail)
    summary = {name: {phase: {'raw_pairs': rows, 'median_baseline_over_candidate': median(r['baseline_over_candidate'] for r in rows), 'candidate_slower_pairs': sum(r['candidate_slower'] for r in rows)} for phase, rows in phases.items()} for name, phases in grouped.items()}
    require(summary == data['summary'], 'independent summary arithmetic differs')
    lifecycle_summary = {name: {phase: {'raw_pairs': rows, 'median_baseline_over_candidate': median(r['baseline_over_candidate'] for r in rows),
        'candidate_slower_pairs': sum(r['candidate_slower'] for r in rows)} for phase, rows in phases.items()} for name, phases in lifecycle_grouped.items()}
    return {'verified_pairs': len(expected), 'summary': summary, 'derived_lifecycle_summary': lifecycle_summary,
            'lifecycle_scope': 'First lifetime sums startup, all measured requests and first shutdown; excludes restart and its verification/query/shutdown. Restart-inclusive totals are shown separately. These are sums of measured request/lifecycle timers, not end-to-end wall time including oracle work and telemetry gaps. Wide projection has no restart. No first-lifetime cgroup CPU total is inferred across unavailable shutdown boundaries.',
            'resources_and_policy': details,
            'host': data['host'], 'db_cpus': data['db_cpus'], 'ancestor_constraints': data['pairs'][0]['baseline']['cgroup']['ancestor_constraints']}

if __name__ == '__main__': main()
