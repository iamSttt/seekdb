"""Prepare a compact material preview and immutable complete audit; no default apply."""
import argparse,ast,copy,hashlib,importlib.util,io,json,zipfile
from pathlib import Path
from analyze_crc_root import blob,require,digest
W=Path(__file__).resolve().parent;R=W/'seekdb'
COMMIT='ebd6d25f27ad1a32fa92d84bcd571ae86b55394e'
BASE='a4755220002460335f2d7b8315c5f9cec17347c979d3fdc15ec9c9cd0e69893f'
RAW='validation/iteration5-batch8-primary24-raw.zip'
RAWSHA='23f82b4477c1c880a03f97a8a33742ae121950a874e8cef2a8b5b6677c821d52'
AUDIT='validation/iteration5-batch8-primary24-audit.zip'
PLAN='validation/iteration5-batch8-primary24-preregistration.json'
def enc(v):return (json.dumps(v,ensure_ascii=False,separators=(',',':'),allow_nan=False)+'\n').encode()
def sha(p):return digest(p.read_bytes())
parser=argparse.ArgumentParser();parser.add_argument('--apply',action='store_true');args=parser.parse_args()
analysis_raw=(W/'batch8-primary24-independent-analysis.json').read_bytes();a=json.loads(analysis_raw);screen=a['preregistered_screen']
require(a['status']=='verified' and a['verified_pairs']==24 and len(a['root_gates'])==22 and a['commit']==COMMIT,'independent analysis scope')
require(a['artifact_sha256']==RAWSHA and len((R/RAW).read_bytes())==3769049 and sha(R/RAW)==RAWSHA,'raw changed')
require(screen['status']=='screen_rejected_R_regression_keep_R' and not screen['eligible_for_one_confirmation'] and not screen['automatic_adoption'],'decision drift')
require(len(a['all_negative_or_mixed_metrics'])==131 and len(screen['all_guard_adverse_pairs'])==45 and len(screen['R_guard_triggers'])==1,'negative inventory drift')
require(screen['R_guard_triggers'][0]['group']=='retained:1:spill_high_q16' and screen['R_guard_triggers'][0]['metric']=='query_before_mutations_cpu_usec','guard identity drift')
decision={'status':screen['status'],'candidate_commit':COMMIT,'run_id':43506915917,'run_attempt':2,'job_id':132168838426,'artifact_id':14077512570,
 'candidate_binary_sha256':a['candidate_binary_sha256'],'analysis_sha256':digest(analysis_raw),'analysis_bytes':len(analysis_raw),
 'root_gate_groups':22,'actual_root_batch8_cases':21,'bound_checks_per_mode':3578261,'PGO_builds':1,'measurement_pairs_verified':24,
 'EE_primary':screen['EE_primary'],'R_guard_triggers':screen['R_guard_triggers'],'guard_metrics':screen['guard_metrics'],
 'all_guard_adverse_pairs':screen['all_guard_adverse_pairs'],'all_guard_adverse_pair_count':45,
 'negative_or_mixed_metric_summary_count':131,'negative_summary_location':{'path':'analysis.json','json_pointer':'/all_negative_or_mixed_metrics','sha256':digest(analysis_raw)},
 'selected_runtime':'unchanged R; experimental candidate remains in worktree, no rollback claimed',
 'recommend_formal_attempt':False,'independent_confirmation_eligible':False,'official_score':None,
 'reader_correction':{'first_pass':'KeyError: experiment_id in overall summary','cause':'Reader inherited a field emitted by the older norm collector. Frozen current collector emits experiment_id only in binding proof, which was already verified.',
   'change':'Require absence in overall summary, retain exact matching experiment_id in binding proof, acceptance policy and all identity gates. No raw or threshold changes.',
   'first_pass_DB_runs':0,'second_pass':'complete verified'},
 'limitations':['131 mixed/adverse summaries and 45 guard adverse pairs overlap; do not add them as unique failed requests.',
 'Spill first16 CPU increases are 175/321 us (2.194/4.211%); absolute smallness does not waive the prospectively frozen rule.',
 'EE default single-CPU query wall/CPU improve but miss the <=0.90 acceptance threshold. Two-CPU passing does not offset it.',
 'All 24 raw pairs retained; no official-score forecast and no formal submission. Correctness/identity verification does not imply performance acceptance.']}
d_raw=enc(decision);(W/'batch8-primary24-decision.json').write_bytes(d_raw)
files={'analysis.json':analysis_raw,'decision.json':d_raw,'api-receipt.json':(W/'batch8-primary24-api-receipt.json').read_bytes(),
 'reader-preflight.json':(W/'batch8-reader-preflight.json').read_bytes(),'reader-correction.json':enc(decision['reader_correction']),
 'record_batch8_primary_result.py':Path(__file__).read_bytes()}
pending=['analyze_batch8_primary_root','evaluate_batch8_primary24_screen','batch8_reader_gates','prepare_batch8_independent_reader','check_batch8_reader_preflight'];done=set()
while pending:
    name=pending.pop()
    if name in done:continue
    done.add(name);raw=(W/(name+'.py')).read_bytes();files['reader/'+name+'.py']=raw
    for node in ast.walk(ast.parse(raw)):
        names=[x.name for x in node.names] if isinstance(node,ast.Import) else [node.module] if isinstance(node,ast.ImportFrom) and node.module else []
        for child in names:
            if (W/(child+'.py')).is_file():pending.append(child)
plan_raw=blob(R,COMMIT,PLAN);plan=json.loads(plan_raw)
for p,item in plan['source_snapshot'].items():
    raw=blob(R,COMMIT,p);require(len(raw)==item['bytes'] and digest(raw)==item['sha256'],'frozen source drift');files['source/'+p]=raw
for p in [PLAN,'validation/iteration5-batch8-primary24-prepush-erratum.json','validation/iteration5-batch8-primary24-prepush-original.json','validation/iteration5-norm-maxabs-primary24-preregistration.json']:
    files['source/'+p]=blob(R,COMMIT,p)
manifest={'scope':'Attempt2 actual root 24-pair evidence; negative screen, not adopted. Earlier attempt1 ISA exclusion remains separate.',
 'source_commit':COMMIT,'raw':{'path':RAW,'bytes':3769049,'sha256':RAWSHA},'files':{n:{'bytes':len(b),'sha256':digest(b)} for n,b in sorted(files.items())}}
files['manifest.json']=enc(manifest);stream=io.BytesIO()
with zipfile.ZipFile(stream,'w',zipfile.ZIP_DEFLATED,compresslevel=9) as z:
    for name,raw in sorted(files.items()):
        entry=zipfile.ZipInfo(name,(2026,11,14,0,0,0));entry.external_attr=0o100644<<16;z.writestr(entry,raw,compress_type=zipfile.ZIP_DEFLATED,compresslevel=9)
audit=stream.getvalue();(W/'batch8-primary24-audit.zip').write_bytes(audit)
raw=(R/'conversation.json').read_bytes();require(digest(raw)==BASE and (R/'agent/conversation.json').read_bytes()==raw,'material drift')
before=json.loads(raw);after=copy.deepcopy(before);e=after['experiments'][-1];require(e['id']=='batch8-avx2-highest-primary24','experiment changed')
e.update(status='verified_performance_screen_rejected_keep_R',database_pairs_executed=24,new_PGO_builds_executed=1,environment_attempts_completed=2)
e['artifacts'] += [{'path':RAW,'sha256':RAWSHA},{'path':AUDIT,'sha256':digest(audit)}]
after['messages'].append({'id':'assistant-batch8-db-result','role':'assistant','content':'第2环境实际根PGO1次；22正确性门禁通过、24对核验有效，但性能筛选失败。C/EE单核查询wall/CPU=.9390/.9126未达.90；双核=.8732/.7983。R spill首16查询CPU两对+2.19%/+4.21%（175/321µs）触发保护；wide无触发。131条负面/混合汇总、45条保护负面对照完整归档。R默认不变，batch仅实验，未回退源码也未推荐/正式提交。'})
require(after['messages'][:-1]==before['messages'] and after['experiments'][:-1]==before['experiments'][:-1],'historical record changed')
require([m for m in before['messages'] if m['role']=='user']==[m for m in after['messages'] if m['role']=='user'],'user objects changed')
material=enc(after);require(len(material)<=131072 and len(material)-len(raw)<=1200,'preview too large')
(W/'batch8-primary24-material-preview.json').write_bytes(material)
spec=importlib.util.spec_from_file_location('validate_batch8_result',R/'minivec/tools/validate_iteration_material.py');v=importlib.util.module_from_spec(spec);spec.loader.exec_module(v);v.check_structure(after,after)
out={'status':'preview','source_material_sha256':BASE,'material_bytes':len(material),'material_sha256':digest(material),'added_bytes':len(material)-len(raw),'remaining_bytes':131072-len(material),
 'audit_bytes':len(audit),'audit_sha256':digest(audit),'audit_files':len(files),'analysis_bytes':len(analysis_raw),'analysis_sha256':digest(analysis_raw),
 'decision_bytes':len(d_raw),'decision_sha256':digest(d_raw),'49_user_objects_unchanged':True,'old_messages_unchanged':True,'DB_runs_by_reader':0,'Git_mutations':0}
if args.apply:
    require(not (R/AUDIT).exists(),'audit already exists');require((R/'conversation.json').read_bytes()==raw,'material changed before apply')
    (R/AUDIT).write_bytes(audit);(R/'conversation.json').write_bytes(material);(R/'agent/conversation.json').write_bytes(material)
    out['validation']=v.validate(R);out['status']='applied'
(W/'batch8-primary24-result-preview-receipt.json').write_bytes(enc(out));print(json.dumps(out,indent=2))
