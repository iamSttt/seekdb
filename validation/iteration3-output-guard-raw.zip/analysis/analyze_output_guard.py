#!/usr/bin/env python3
"""Validate and summarize the 18 saved output-guard reports; never run a benchmark.

Missing/failed evidence aborts before writing a result. Native Python JSON ints
preserve source integers; only explicitly named timing/resource ratios are floats.
"""
import argparse
from collections import Counter
import hashlib
import json
import math
from pathlib import Path
import re
from statistics import median

HERE = Path(__file__).resolve().parent
BASELINE = '969ecca98f817ecdef9b0c378fc99a0d6cef510d'
SEEDS = (7319, 8911, 13337)
ROLES = ('spill', 'broad', 'guard')
FLAGS = {'baseline': [], 'spill': ['-DMVDB_ENABLE_SPILL_FILTER'],
         'broad': ['-DMVDB_ENABLE_SPILL_FILTER', '-DMVDB_ENABLE_TYPED_JSON'],
         'guard': ['-DMVDB_ENABLE_SPILL_FILTER', '-DMVDB_ENABLE_TYPED_JSON', '-DMVDB_TYPED_WIDE_VECTOR_ONLY']}
SCENARIOS = {'projections': ('wide768', 'many16'), 'standard': ('standard10k',)}
PAIRS = {'projections': 1, 'standard': 5}
PROJECTION_LABELS = {'wide_top10', 'narrow_top10', 'wide_large4096', 'narrow_large4096',
                     'wide_all', 'narrow_all', 'wide_distance10'}


def require(ok, message):
    if not ok:
        raise ValueError(message)


def unique_object(items):
    result = {}
    for k, v in items:
        require(k not in result, 'duplicate JSON key: ' + k)
        result[k] = v
    return result


def finite_float(text):
    value = float(text)
    require(math.isfinite(value), 'nonfinite JSON float')
    return value


def read(path):
    return json.loads(path.read_bytes().decode('utf-8'), object_pairs_hook=unique_object,
                      parse_float=finite_float,
                      parse_constant=lambda s: (_ for _ in ()).throw(ValueError('nonfinite JSON constant: ' + s)))


def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def check_hash(value):
    require(isinstance(value, str) and re.fullmatch('[0-9a-f]{64}', value), 'invalid SHA256')


def check_hash_map(value):
    require(isinstance(value, dict) and value, 'missing hash map')
    for name, digest in value.items():
        require(isinstance(name, str) and name, 'empty hash-map name')
        check_hash(digest)


def local_report(root, name):
    require(isinstance(name, str) and Path(name).name == name, 'report must be a direct child filename')
    path = (root / name).resolve()
    require(path.parent == root and path.is_file(), 'missing/escaping report: ' + name)
    return path


def identity(p):
    return {k: p[k] for k in ('candidate_role', 'scenario', 'seed', 'pair_index', 'order', 'report')}


def stats(values):
    if not values:
        return {'count': 0, 'median': None, 'min': None, 'max': None}
    return {'count': len(values), 'median': median(values), 'min': min(values), 'max': max(values)}


def aggregate(rows):
    ratios = [r['baseline_over_candidate'] for r in rows if r['baseline_over_candidate'] is not None]
    return {'pairs': len(rows), 'baseline_over_candidate': stats(ratios),
            'candidate_value_larger_pairs': sum(x < 1 for x in ratios),
            'undefined_ratio_pairs': len(rows) - len(ratios),
            'baseline': stats([r['baseline'] for r in rows]),
            'candidate': stats([r['candidate'] for r in rows])}


def metric(pairs, getter):
    rows = []
    for p in pairs:
        b, c = [getter(p[s]) for s in ('baseline', 'candidate')]
        require(type(b) in (int, float) and type(c) in (int, float) and b >= 0 and c >= 0,
                'invalid nonnegative numeric metric')
        rows.append(dict(identity(p), baseline=b, candidate=c,
                         baseline_over_candidate=b/c if c else None))
    return {**aggregate(rows), 'by_seed': {str(seed): aggregate([r for r in rows if r['seed'] == seed]) for seed in SEEDS},
            'by_order': {order: aggregate([r for r in rows if r['order'][0] == first])
                         for order, first in [('AB', 'baseline'), ('BA', 'candidate')]}, 'raw_pairs': rows}


def fanout(run):
    stderr = run.get('stderr', {})
    text = stderr.get('tail_utf8', stderr.get('tail', ''))
    return {'decisions': [int(x) for x in re.findall(r'-> ([12]) threads?', text)],
            'wake_us': [float(x) for x in re.findall(r'wake_us=([\d.]+)', text)],
            'stderr_complete': not stderr.get('truncated', stderr.get('bytes', 0) > 4096)}


def standard_metrics(group):
    phases = set(group[0]['baseline']['phase_seconds'])
    require(all(set(p[s]['phase_seconds']) == phases for p in group for s in ('baseline', 'candidate')), 'phase schema mismatch')
    result = {'phase_seconds': {name: metric(group, lambda r, n=name: r['phase_seconds'][n]) for name in sorted(phases)},
              'queries': {}, 'resource_snapshots': {}, 'fanout': []}
    for phase in ('query_before_update', 'query_after_restart'):
        for p in group:
            for side in ('baseline', 'candidate'):
                values = p[side]['query'][phase]['per_request_seconds']
                require(len(values) == 1000 and all(type(v) is float and v > 0 for v in values), 'incomplete standard requests')
                require(math.isclose(math.fsum(values), p[side]['phase_seconds'][phase], rel_tol=1e-12, abs_tol=1e-12), 'query total mismatch')
        result['queries'][phase] = {label: metric(group, lambda r, ph=phase, a=offset, stride=step:
            math.fsum(r['query'][ph]['per_request_seconds'][a::stride]))
            for label, offset, step in [('steady_after_first_two', 2, 1), ('unfiltered_exact_after_first', 2, 2), ('single_filter_ann_after_first', 3, 2)]}
        result['queries'][phase]['first_request_seconds'] = metric(group, lambda r, ph=phase: r['query'][ph]['per_request_seconds'][0])
    snapshot_names = {s['phase'] for s in group[0]['baseline']['resource_snapshots']}
    for name in sorted(snapshot_names):
        def snap(run):
            matches = [s for s in run['resource_snapshots'] if s['phase'] == name]
            require(len(matches) == 1, 'missing/duplicate resource snapshot')
            return matches[0]
        result['resource_snapshots'][name] = {}
        for family in ('process_memory_proxy', 'process_io_counters_proxy'):
            keys = set(snap(group[0]['baseline']).get(family, {}))
            require(all(set(snap(p[s]).get(family, {})) == keys for p in group for s in ('baseline', 'candidate')), 'resource proxy unavailable or schema changed')
            result['resource_snapshots'][name][family] = {
                k: metric(group, lambda r, f=family, key=k: snap(r)[f][key]) for k in sorted(keys)}
        if all('process_cpu_seconds' in snap(p[s]) for p in group for s in ('baseline', 'candidate')):
            result['resource_snapshots'][name]['cumulative_process_cpu_seconds'] = metric(group, lambda r: snap(r)['process_cpu_seconds'])
        else:
            result['resource_snapshots'][name]['cumulative_process_cpu_seconds'] = None
        result['resource_snapshots'][name]['spill_files_raw'] = [dict(identity(p), **{s: snap(p[s]).get('open_rebuildable_files') for s in ('baseline', 'candidate')}) for p in group]
    result['fanout'] = [dict(identity(p), **{s: fanout(p[s]) for s in ('baseline', 'candidate')}) for p in group]
    return result


def projection_metrics(group):
    labels = set(group[0]['baseline']['phases'])
    require(labels == PROJECTION_LABELS, 'missing/extra projection label')
    require(all(set(p[s]['phases']) == labels and p[s]['status'] == 'passed' for p in group for s in ('baseline', 'candidate')), 'projection phase/status mismatch')
    result = {'projection_labels': {}, 'lifecycle_seconds': {}, 'resources': None,
              'resource_limit': 'Projection harness did not collect RSS/HWM/CPU/I/O; no resource conclusion is derivable.'}
    for label in sorted(labels):
        rows = []
        for p in group:
            b, c = [p[s]['phases'][label] for s in ('baseline', 'candidate')]
            require(b['columns'] == c['columns'] and b['rows_per_response'] == c['rows_per_response'], 'projection shape mismatch')
            require(b['independent_oracle'] and c['independent_oracle'], 'missing independent projection oracle')
            require(len(b['requests']) == len(c['requests']) == 3, 'projection needs three raw repeats')
            require([v['response_sha256'] for v in b['requests']] == [v['response_sha256'] for v in c['requests']], 'projection raw response mismatch')
            for side in (b, c):
                require(math.isclose(math.fsum(x['seconds'] for x in side['requests']), side['wall_seconds'], rel_tol=1e-12, abs_tol=1e-12), 'projection wall total mismatch')
                require(sum(x['response_bytes'] for x in side['requests']) == side['response_bytes'], 'projection bytes total mismatch')
            require(b['response_bytes'] == c['response_bytes'], 'projection byte counts differ')
            rows.append(dict(identity(p), rows_per_response=b['rows_per_response'], columns=b['columns'],
                baseline=b['requests'], candidate=c['requests'],
                sample_ratios=[x['seconds']/y['seconds'] for x, y in zip(b['requests'], c['requests'])]))
        result['projection_labels'][label] = {
            'wall_seconds': metric(group, lambda r, n=label: r['phases'][n]['wall_seconds']),
            'first_request_seconds': metric(group, lambda r, n=label: r['phases'][n]['requests'][0]['seconds']),
            'remaining_two_request_seconds': metric(group, lambda r, n=label: math.fsum(v['seconds'] for v in r['phases'][n]['requests'][1:])),
            'response_bytes': metric(group, lambda r, n=label: r['phases'][n]['response_bytes']),
            'nested_sample_counts': {'samples': sum(len(r['sample_ratios']) for r in rows),
                                     'candidate_slower_samples': sum(x < 1 for r in rows for x in r['sample_ratios']),
                                     'independent_measurement_units': len(rows)},
            'raw_repeats_nested_within_pairs': rows}
    names = set(group[0]['baseline']['lifecycle_seconds'])
    require(all(set(p[s]['lifecycle_seconds']) == names for p in group for s in ('baseline', 'candidate')), 'projection lifecycle schema mismatch')
    result['lifecycle_seconds'] = {n: metric(group, lambda r, key=n: r['lifecycle_seconds'][key]) for n in sorted(names)}
    result['derived_accounted_timed_seconds'] = metric(group, lambda r: math.fsum(r['lifecycle_seconds'].values()) + math.fsum(v['wall_seconds'] for v in r['phases'].values()))
    result['derived_accounted_limit'] = 'Sum of reported timers only; excludes untimed Python parsing/oracle/setup, and is not total elapsed wall time.'
    return result


def analyze(root, expected_candidate):
    root = root.resolve()
    require(root.is_dir(), 'raw output-guard extraction directory is not present')
    common = {n: read(local_report(root, n + '.json')) for n in ('context', 'summary', 'build-input', 'correctness', 'run-status')}
    context, summ, build = common['context'], common['summary'], common['build-input']
    require(summ['status'] == 'passed' and common['run-status']['exit_code'] == 0, 'CI is incomplete or failed')
    require(context['baseline_commit'] == summ['baseline_commit'] == BASELINE, 'wrong historical baseline')
    candidate = context['candidate_commit']
    require(re.fullmatch('[0-9a-f]{40}', expected_candidate), 'expected candidate must be a complete40-character lowercase commit ID')
    require(re.fullmatch('[0-9a-f]{40}', candidate) and candidate == expected_candidate, 'unexpected candidate commit')
    require(summ['candidate_commit'] == context['harness_commit'] == candidate, 'candidate/harness commit mismatch')
    require(context['measurement_schedule'] == summ['measurement_schedule'] == build['measurement_schedule'], 'schedule mismatch')
    require(context['compiler'] == build['compiler_image'] == 'gcc:13.3.0-bookworm@sha256:1d71f0f3450214bef38fe09e6f610fb6cca90cf97b43f4ce845bfc32a4168818', 'wrong compiler proof')
    require(context['profile_generate_flags'] == ['-fprofile-generate=/pgo', '-fprofile-update=atomic'] and
            context['profile_use_flags'] == ['-fprofile-use=/pgo', '-Werror=missing-profile', '-Werror=coverage-mismatch'], 'profile flags changed')
    require(summ['verified_total_pairs'] == 63 and summ['verified_reports'] == 18 and summ['global_identity_uniqueness_verified'] is True, 'wrong claimed matrix size')
    require(summ['binary_unchanged'] is True and summ['profile_source_verified'] is True and summ['correctness_passed'] is True, 'missing CI proof gate')
    proof = context['profile_source_proof']
    require(set(proof) == set(FLAGS) == set(build['roles']), 'wrong PGO roles')
    require(context['candidate_flags_by_role'] == summ['candidate_flags_by_role'] == {r: FLAGS[r] for r in ROLES}, 'wrong feature flags')
    for role, item in proof.items():
        source = build['roles'][role]
        require(item['source_commit'] == source['source_commit'] == (BASELINE if role == 'baseline' else candidate), 'role source mismatch')
        require(item['feature_flags'] == source['feature_flags'] == FLAGS[role], 'role flags mismatch')
        require(item['source_sha256'] == source['engine_source'] and item['training_source_sha256'] == source['training_source'], 'source/training proof mismatch')
        require(item['build_dockerfile_sha256'] == source['build_dockerfile_sha256'], 'Dockerfile proof mismatch')
        for name in ('binary_sha256', 'instrumented_binary_sha256', 'build_dockerfile_sha256'):
            check_hash(item[name])
        for name in ('source_sha256', 'training_source_sha256', 'profile_sha256', 'training_corpus_sha256', 'training_response_sha256'):
            check_hash_map(item[name])
        require(len(item['profile_sha256']) == sum(n.endswith('.cpp') for n in item['source_sha256']), 'profile/source count mismatch')
        require(all(n.endswith('.gcda') for n in item['profile_sha256']), 'invalid profile file type')
        oracle = item['training_oracle']
        require(len(oracle) == 6 and all(x['status'] == 'passed' and type(x['responses']) is int and x['responses'] > 0 for x in oracle), 'incomplete original training oracle')
        require({x['actual_file'] for x in oracle} == set(item['training_response_sha256']), 'oracle/response binding mismatch')
        if role != 'baseline':
            require(item['source_sha256'] == proof['guard']['source_sha256'] and item['training_source_sha256'] == proof['guard']['training_source_sha256'], 'candidate source differs')
    corpus_equal = all(item['training_corpus_sha256'] == proof['baseline']['training_corpus_sha256'] for item in proof.values())
    require(context['training_corpora_equal'] is corpus_equal, 'corpus equality claim mismatch')
    correct = common['correctness']
    require(correct['status'] == 'passed', 'correctness failed')
    expected_tests = {(r, t) for r in FLAGS for t in ('json_protocol', 'utf8_atomicity', 'topk_serial', 'topk_parallel')}
    require(len(correct['checks']) == 16 and {(x['role'], x['test']) for x in correct['checks']} == expected_tests, 'missing correctness tests')
    require(all(x['returncode'] == 0 and x['binary_sha256'] == proof[x['role']]['binary_sha256'] for x in correct['checks']), 'correctness tested a different binary')
    expected = {(r, case, seed, i) for r in ROLES for plan, cases in SCENARIOS.items() for case in cases for seed in SEEDS for i in range(PAIRS[plan])}
    seen, report_names, pairs, raw_hashes, input_hashes = set(), set(), [], {}, {}
    require(len(summ['measurements']) == 18, 'summary must name 18 reports')
    for record in summ['measurements']:
        role, plan, seed = record['candidate_role'], record['name'], record['seed']
        require(role in ROLES and plan in SCENARIOS and type(seed) is int and seed in SEEDS, 'unexpected comparison')
        name = f'pgo-{role}-{plan}-{seed}.json'
        require(record['report'] == name and name not in report_names, 'wrong/duplicate report filename')
        report_names.add(name)
        path = local_report(root, name)
        require(sha(path) == record['report_sha256'], 'report bytes differ from CI summary: ' + name)
        data = read(path)
        require(data['status'] == 'passed', 'failed benchmark report')
        require(data['host']['platform'] == context['platform'], 'report platform differs from CI context')
        affinity = data['host'].get('cpu_affinity', data['host'].get('affinity'))
        require(affinity == context['measurement_affinity'], 'measurement affinity mismatch')
        if plan == 'projections':
            require(data['harness_sha256'] == build['harness_source']['minivec/tools']['benchmark_projection.py'], 'projection harness differs from committed harness')
        require(data['binaries']['baseline']['sha256'] == proof['baseline']['binary_sha256'] and data['binaries']['candidate']['sha256'] == proof[role]['binary_sha256'], 'measured binary mismatch')
        actual = {(role, p['scenario'], p['seed'], p['pair_index']) for p in data['pairs']}
        want = {(role, case, seed, i) for case in SCENARIOS[plan] for i in range(PAIRS[plan])}
        require(actual == want and len(data['pairs']) == len(want) == record['verified_pairs'] and not seen.intersection(actual), 'missing/duplicate pair identities')
        seen.update(actual)
        raw_hashes[name] = sha(path)
        for pair in data['pairs']:
            require(type(pair['seed']) is int and type(pair['pair_index']) is int, 'identity integers required')
            require(pair['order'] in (['baseline', 'candidate'], ['candidate', 'baseline']), 'invalid AB/BA order')
            flag = 'all_responses_identical' if plan == 'standard' else 'all_responses_identical_and_independently_verified'
            require(pair[flag] is True, 'missing response/oracle validation')
            if plan == 'standard':
                require(pair['baseline']['response_sha256'] == pair['candidate']['response_sha256'], 'standard response digest mismatch')
            key = (pair['scenario'], pair['seed'])
            digest = pair['workload_sha256' if plan == 'standard' else 'input_sha256'];check_hash(digest)
            require(key not in input_hashes or input_hashes[key] == digest, 'different workload across candidates')
            input_hashes[key] = digest
            pairs.append(dict(pair, candidate_role=role, report=name, plan=plan))
    require(seen == expected and len(pairs) == 63, 'global63 identity coverage failed')
    require({p.name for p in root.glob('pgo-*.json')} == report_names, 'unaccounted raw comparison report')
    groups = {}
    for role in ROLES:
        groups[role] = {}
        for scenario in ('standard10k', 'wide768', 'many16'):
            group = [p for p in pairs if p['candidate_role'] == role and p['scenario'] == scenario]
            groups[role][scenario] = {'verified_pairs': len(group), 'order_counts': dict(Counter('AB' if p['order'][0] == 'baseline' else 'BA' for p in group)),
                                     'metrics': standard_metrics(group) if scenario == 'standard10k' else projection_metrics(group)}
    return {'status': 'analysis_of_complete_verified_reports', 'source_commit': candidate, 'historical_baseline_commit': BASELINE,
            'official_score': None, 'automatic_adoption': False, 'verified_reports': 18, 'verified_pairs': 63,
            'source_profile_binding': context, 'summary_binding': summ,
            'input_file_sha256': {**{name + '.json': sha(root / (name + '.json')) for name in common}, **raw_hashes},
            'analysis_generator_sha256': sha(Path(__file__)), 'candidate_results': groups,
            'integer_handling': 'Python json uses arbitrary-precision integers; raw counts/bytes retained as integers, ratios explicitly computed.',
            'metric_interpretation': 'candidate_value_larger_pairs means slower for seconds, higher for bytes/counters; it is not always a latency statement.',
            'limits': ['No official score or automatic selection. Every negative pair remains in raw_pairs.',
                'Historical baseline differs in source; current candidates share source/training but each has its own PGO.',
                'Candidates rotate by seed; they are each paired against separate historical-baseline processes, not directly against one another.',
                'standard10k has15 pairs/role with AB9 BA6; projection has3 pairs/scenario/role and three repeats nested within each pair.',
                'First requests are retained in primary totals. Secondary steady excludes the first two standard requests only.',
                'Projection timers include transport/projection/sort but exclude response parse/oracle; standard request timers include decode.',
                'Projection did not sample resource counters. Standard proc counters are cumulative proxies, not official cgroup metrics; CPU quantized to clock ticks.',
                'Extracted JSON hash consistency does not independently re-execute builds; CI source/profile/runtime proof is cross-checked as recorded.']}


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--input', type=Path, default=HERE / 'performance/output-guard')
    parser.add_argument('--output', type=Path, default=HERE / 'output-guard-analysis.json')
    parser.add_argument('--candidate-commit', required=True,
                        help='complete40-character lowercase commit ID explicitly selected by the caller; prefixes rejected')
    args = parser.parse_args()
    require(not args.output.exists(), 'refusing to overwrite an existing analysis')
    require(re.fullmatch('[0-9a-f]{40}', args.candidate_commit), 'candidate commit must contain exactly40 lowercase hex characters')
    result = analyze(args.input, args.candidate_commit)
    args.output.parent.mkdir(parents=True, exist_ok=True)
    args.output.write_text(json.dumps(result, indent=2, ensure_ascii=False, allow_nan=False) + '\n', encoding='utf-8')
    print(f'Saved complete63-pair analysis: {args.output}')


if __name__ == '__main__':
    main()
