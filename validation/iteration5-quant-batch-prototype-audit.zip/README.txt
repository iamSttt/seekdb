Standalone batch8 microbenchmark only. No DB/PGO/automatic adoption or formal submission.
Replay: python audit/analyze_quant_batch_prototype.py --repo <seekdb Git checkout> --archive <iteration5-quant-batch-prototype-raw.zip> --receipt audit/quant-batch-api-receipt.json --commit 1486aa80fcd8fdab7cd879588f3bf752baa14066 --output <analysis.json>
The original raw archive contains all three native binaries, complete logs, pair data, Docker identities and actual cgroup resource observations.
AVX512 control did not run; an unknown control must not be presented as passed. All measured pair-by-metric ratios were improvements, with none omitted.
