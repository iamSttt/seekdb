"""Read-only GitHub expression truth-table and bounded workflow shape check."""
import ast
import hashlib
import json
from pathlib import Path
import re
import subprocess

repo=Path(__file__).resolve().parent/'seekdb'
path=repo/'.github/workflows/minivec-score.yml'
current=path.read_text(encoding='utf8')
previous=subprocess.check_output(['git','-c','safe.directory='+repo.as_posix(),'show','f779e6b27c13e50706fc6a4c2ff8e49c778417b1:.github/workflows/minivec-score.yml'],cwd=repo).decode()
def need(ok,message):
    if not ok:raise ValueError(message)
def jobs(source):
    need(source.count('\njobs:\n')==1,'jobs root differs')
    body=source.split('\njobs:\n')[1]
    found=list(re.finditer(r'^  ([a-z][a-z0-9-]*):\s*$',body,re.M))
    return {m.group(1):body[m.end():found[i+1].start() if i+1<len(found) else len(body)] for i,m in enumerate(found)}
old,new=jobs(previous),jobs(current)
need(set(new)==set(old)|{'quantized-batch-prototype'},'unexpected job inventory')
def expression(body):
    matches=re.findall(r'^    if: \$\{\{ (.*) \}\}\s*$',body,re.M)
    need(len(matches)==1,'job if count')
    return matches[0]
def evaluate(expression,message,inputs):
    expression=expression.replace('github.event.head_commit.message',repr(message))
    expression=re.sub(r'inputs\.([a-z_]+)',lambda m:repr(inputs.get(m.group(1),False)),expression)
    expression=expression.replace('&&',' and ').replace('||',' or ')
    expression=re.sub(r'!(?!=)',' not ',expression).strip()
    node=ast.parse(expression,mode='eval')
    allowed=(ast.Expression,ast.BoolOp,ast.UnaryOp,ast.And,ast.Or,ast.Not,ast.Call,ast.Name,ast.Constant,ast.Load)
    for n in ast.walk(node):
        need(isinstance(n,allowed),'unexpected expression syntax')
        if isinstance(n,ast.Name):need(n.id=='contains','unexpected name')
        if isinstance(n,ast.Call):need(isinstance(n.func,ast.Name) and n.func.id=='contains' and len(n.args)==2 and not n.keywords,'unexpected call')
    return bool(eval(compile(node,'<workflow-if>','eval'),{'__builtins__':{},'contains':lambda text,part:part in text}))
def selected(data,message,inputs):return [name for name,body in data.items() if evaluate(expression(body),message,inputs)]
for name in old:
    need('[quant-batch-prototype]' in expression(new[name]),'old job lacks exact exclusion '+name)
    stripped=lambda body:re.sub(r'^    if: .*\n','',body,flags=re.M).strip()
    need(stripped(old[name])==stripped(new[name]),'old job non-condition content changed '+name)
markers=sorted(set(re.findall(r"contains\(github\.event\.head_commit\.message, '(\[[^']+\])'\)",previous)))
inputs=sorted(set(re.findall(r'inputs\.([a-z_]+)', '\n'.join(expression(b) for b in old.values()))))
cases=[]
for message,flags in [('',{}),*[(marker,{}) for marker in markers],*[( '',{i:True}) for i in inputs],(' '.join(markers),{i:True for i in inputs})]:
    before=selected(old,message,flags);after=selected(new,message,flags)
    need(before==after,'ordinary selection changed '+message+' '+str(flags))
    exact=selected(new,message+' [quant-batch-prototype]',flags)
    need(exact==['quantized-batch-prototype'],'diagnostic marker not exclusive')
    cases.append({'message':message,'inputs':flags,'ordinary_jobs':before,'with_quant_batch':exact})
job=new['quantized-batch-prototype']
need('    runs-on: ubuntu-24.04' in job and '    timeout-minutes: 20' in job,'runner/timeout shape')
need('run: bash minivec/tools/quant_batch/ci_prototype.sh --repo "$GITHUB_WORKSPACE" --output "$GITHUB_WORKSPACE/quant-batch-results"' in job,'script path/args')
need('          include-hidden-files: true' in job and '          path: quant-batch-results/' in job,'archive shape')
need('        if: always()' in job and 'contents: read' in current,'artifact failure retention/permissions')
report={'status':'passed_bounded_static_review','workflow_sha256':hashlib.sha256(path.read_bytes()).hexdigest(),'old_jobs':len(old),'new_jobs':len(new),
 'case_pairs':len(cases),'selection_cases':len(cases)*2,'all_old_markers_and_boolean_inputs_preserved':True,'quant_batch_always_exclusive_in_cases':True,
 'YAML_parser_or_GitHub_schema_validator_used':False,'limitation':'PyYAML/actionlint unavailable locally; this checks existing bounded indentation/job shape, exact unchanged old job bodies, and actual if-expression semantics, not complete GitHub schema validation.',
 'database_runs':0,'git_mutations':0,'cases':cases}
target=Path(__file__).resolve().parent/'quant-batch-workflow-review.json'
target.write_text(json.dumps(report,indent=2)+'\n',encoding='utf8')
print(json.dumps({k:v for k,v in report.items() if k!='cases'},indent=2))
