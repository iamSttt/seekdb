"""Pre-push byte normalization only, before the microbenchmark was executed."""
import hashlib
import importlib.util
import json
from pathlib import Path

def sha(b):return hashlib.sha256(b).hexdigest()
def enc(x):return (json.dumps(x,ensure_ascii=False,separators=(',',':'),allow_nan=False)+'\n').encode('utf8')
def need(ok,msg):
    if not ok:raise ValueError(msg)

w=Path(__file__).resolve().parent;repo=w/'seekdb'
plan_path=repo/'validation/iteration5-quant-batch-prototype-preregistration.json'
old_plan_raw=plan_path.read_bytes();plan=json.loads(old_plan_raw)
need(sha(old_plan_raw)=='92af7609ed9e8323f385f3955d08cc8b2b8d19ca575544c88923518d2b1ceb4f','plan drift')
prior=(repo/'conversation.json').read_bytes();need(sha(prior)=='6489be75f431e7d4ae8843e32d9cef15884652f8909a9904a2c2a9dcc4d4b4e5' and (repo/'agent/conversation.json').read_bytes()==prior,'material drift')
material=json.loads(prior);need(plan['native_compilations_executed']==plan['micro_pairs_executed']==0,'plan already executed')
changes={};backups={}
for name in ['.github/workflows/minivec-score.yml','.gitattributes']:
    raw=(repo/name).read_bytes();need(sha(raw)==plan['source_snapshot'][name]['sha256'],'source drift '+name)
    normalized=raw.replace(b'\r\n',b'\n');need(b'\r' not in normalized,'not simple CRLF normalization')
    backups[name]=raw
    changes[name]={'changed':raw!=normalized,'old_bytes':len(raw),'old_sha256':sha(raw),'new_bytes':len(normalized),'new_sha256':sha(normalized)}
    plan['source_snapshot'][name]={'bytes':len(normalized),'sha256':sha(normalized)}
    (repo/name).write_bytes(normalized)
need(any(x['changed'] for x in changes.values()),'nothing needed normalization')
plan['pre_push_line_ending_correction']={'status':'before_push_and_before_native_execution','original_work_draft_sha256':sha(old_plan_raw),
  'scope':'Checked workflow and gitattributes LF bytes; workflow was already LF, gitattributes changed CRLF to LF. Rules, source code and workload unchanged.',
  'files':changes}
new_plan=enc(plan)
e=material['experiments'][-1];need(e['id']=='quantized-batch8-integer-prototype' and len(e['artifacts'])==1,'experiment drift')
need(e['artifacts'][0]['sha256']==sha(old_plan_raw),'artifact pointer drift')
e['artifacts'][0]['sha256']=sha(new_plan);new_material=enc(material)
need(len(new_material)==len(prior),'material shape drift')
spec=importlib.util.spec_from_file_location('qb_lf_validator',repo/'minivec/tools/validate_iteration_material.py');v=importlib.util.module_from_spec(spec);spec.loader.exec_module(v)
try:
    plan_path.write_bytes(new_plan);(repo/'conversation.json').write_bytes(new_material);(repo/'agent/conversation.json').write_bytes(new_material)
    validation=v.validate(repo)
except BaseException:
    plan_path.write_bytes(old_plan_raw);(repo/'conversation.json').write_bytes(prior);(repo/'agent/conversation.json').write_bytes(prior)
    for name,b in backups.items():(repo/name).write_bytes(b)
    raise
(w/'quant-batch-prototype-preregistration-lf.json').write_bytes(new_plan)
(w/'quant-batch-material-lf.json').write_bytes(new_material)
receipt={'status':'applied_before_push','source_material_sha256':sha(prior),'validation':validation,
  'old_plan_sha256':sha(old_plan_raw),'plan_bytes':len(new_plan),'plan_sha256':sha(new_plan),'files':changes,
  'all_messages_unchanged':True,'all_user_objects_unchanged':True,'thresholds_and_workload_unchanged':True,
  'new_native_runs':0,'new_DB_runs':0,'git_mutations':0}
(w/'quant-batch-prepush-lf-correction.json').write_bytes(enc(receipt));print(json.dumps(receipt,indent=2))
