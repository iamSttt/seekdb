"""Independent read-only raw-artifact reader. No native execution or database."""
import argparse
import hashlib
import io
import json
import math
from pathlib import Path, PurePosixPath
import re
from statistics import median
import subprocess
import zipfile

PLAN='validation/iteration5-quant-batch-prototype-preregistration.json'
PLAN_SHA='d2c6d0076c7b7681c88322e81419a6491c620541e2153cf51dccc37f74f43d70'
MANIFEST_SHA='6da928ce6aff24df396e94fa2182c77bc689729b312ea85dc1b463a5710ce05d'
PREFIX='minivec/tools/quant_batch/'

def need(ok,message):
    if not ok:raise ValueError(message)
def sha(b):return hashlib.sha256(b).hexdigest()
def readjson(b):return json.loads(b.decode('utf8'),parse_constant=lambda _:(_ for _ in ()).throw(ValueError('nonfinite JSON')))
def blob(repo,commit,path):
    git=['git','-c','safe.directory='+repo.as_posix(),'-C',str(repo)]
    data=subprocess.check_output(git+['show',commit+':'+path])
    oid=subprocess.check_output(git+['rev-parse',commit+':'+path],text=True).strip()
    need(hashlib.sha1(b'blob '+str(len(data)).encode()+b'\0'+data).hexdigest()==oid,'Git blob differs '+path)
    return data

class Archive:
    def __init__(self,raw):
        self.z=zipfile.ZipFile(io.BytesIO(raw));names=self.z.namelist();need(len(names)==len(set(names)) and len(names)<500,'archive inventory')
        self.inventory={}
        for name in names:
            path=PurePosixPath(name);need(not path.is_absolute() and '..' not in path.parts and '\\' not in name,'unsafe ZIP member')
            if name.endswith('/'):continue
            need(self.z.getinfo(name).file_size<100_000_000,'oversized member')
            b=self.z.read(name);self.inventory[name]={'bytes':len(b),'sha256':sha(b)}
    def data(self,path):return self.z.read(path)
    def json(self,path):return readjson(self.data(path))

def api_binding(receipt,raw,expected_commit):
    if 'artifact' in receipt:
        need(receipt['commit']==expected_commit,'wrong expected source commit')
        art=receipt['artifact'];need(art['name']=='quantized-batch-prototype' and not art['expired'],'wrong/expired artifact')
        need(art['workflow_run']['id']==receipt['run_id'] and art['workflow_run']['head_sha']==expected_commit,'artifact source/run')
        need(art['digest']=='sha256:'+sha(raw) and art['size_in_bytes']==len(raw),'API size/SHA')
        return {'source_commit':expected_commit,'run_id':receipt['run_id'],'artifact_id':art['id'],'bytes':len(raw),'sha256':sha(raw),
          'receipt_job_id':receipt['job_id'],'job_id_independently_API_verified':False,'conclusion':None,'all_jobs_enumerated':False,
          'API_scope':'Compact artifact API object verifies run/source/digest/size. No jobs API object is supplied; job conclusion/id and global exclusivity are not independently established from this receipt.'}
    need(receipt['head_sha']==expected_commit,'wrong expected source commit')
    found=[x for x in receipt['artifacts_api_response']['artifacts'] if x['id']==receipt['artifact_id']];need(len(found)==1,'artifact identity')
    art=found[0];need(art['name']=='quantized-batch-prototype' and not art['expired'],'wrong/expired artifact')
    need(art['workflow_run']['id']==receipt['run_id'] and art['workflow_run']['head_sha']==expected_commit,'artifact source/run')
    need(art['digest']=='sha256:'+sha(raw) and art['size_in_bytes']==len(raw),'API size/SHA')
    need(receipt['expected_sha256']==sha(raw) and receipt['expected_bytes']==len(raw),'download receipt differs')
    jobs=receipt['jobs_api_response']['jobs'];active=[j for j in jobs if j['conclusion']!='skipped']
    need(0<len(jobs)<=36 and len(active)==1 and active[0]['name']=='quantized-batch-prototype','provided jobs selection')
    need(all(j['run_id']==receipt['run_id'] and j['status']=='completed' for j in jobs),'unfinished/mismatched job')
    return {'source_commit':expected_commit,'run_id':receipt['run_id'],'artifact_id':receipt['artifact_id'],'bytes':len(raw),'sha256':sha(raw),
      'job_id':active[0]['id'],'conclusion':active[0]['conclusion'],'provided_jobs':len(jobs),'all_jobs_enumerated':len(jobs)==36,
      'API_scope':'Only the provided jobs page is asserted; partial pages cannot prove global exclusivity.'}

def source_binding(repo,commit,a):
    raw=blob(repo,commit,PLAN);need(sha(raw)==PLAN_SHA,'pre-registration changed');plan=readjson(raw)
    files={}
    for name,item in plan['source_snapshot'].items():
        b=blob(repo,commit,name);need(len(b)==item['bytes'] and sha(b)==item['sha256'],'plan/Git input differs '+name);files[name]=b
    manifest=readjson(files[PREFIX+'manifest.json']);need(sha(files[PREFIX+'manifest.json'])==MANIFEST_SHA,'prototype manifest')
    for name,item in manifest['files'].items():
        b=files[PREFIX+name];need(len(b)==item['bytes'] and sha(b)==item['sha256'],'manifest input differs '+name)
    reference=readjson(files[PREFIX+'reference-manifest.json'])
    for name,item in reference['files'].items():
        b=files[PREFIX+'reference/'+name]
        need(sha(b)==item['sha256'] and len(b)==item['bytes'],'reference bytes')
        need(hashlib.sha1(b'blob '+str(len(b)).encode()+b'\0'+b).hexdigest()==item['git_blob'],'reference Git blob')
    need(a.data('harness-commit.txt').decode().strip()==commit,'actual harness commit')
    observed={}
    for line in a.data('input-sha256.txt').decode().splitlines():
        match=re.fullmatch(r'([0-9a-f]{64})  (.+)',line);need(match is not None,'input hash format')
        need(match[2] not in observed,'duplicate input');observed[match[2]]=match[1]
    expected={n:sha(b) for n,b in files.items() if n!='.gitattributes'}
    need(observed==expected,'CI Git-file byte inventory differs')
    return plan,files

def resources(a,summary):
    requested=int(a.data('requested-cpu.txt').decode());need(requested>=0,'CPU id')
    need(summary['cpu_affinity']=={'before':[requested],'selected':[requested]} and not summary.get('unavailable_resource_files'),'actual affinity/missing files')
    quota,period=map(int,a.data('results/cpu-max.txt').decode().split());need(quota==period and period>0,'CPU quota')
    need(a.data('results/memory-max.txt').strip()==b'2147483648' and a.data('results/memory-swap-max.txt').strip()==b'0','memory/swap')
    need(a.data('results/cpuset-effective.txt').decode().strip()==str(requested),'effective CPU set')
    status=dict(line.split(':',1) for line in a.data('results/proc-status.txt').decode().splitlines() if ':' in line)
    need(status['Cpus_allowed_list'].strip()==str(requested),'actual driver affinity')
    observed=a.json('resource-verification.json')
    need(observed=={'status':'verified','cpu_quota':quota,'cpu_period':period,'memory_max':2147483648,'swap_max':0,'cpu_affinity':[requested],'database_runs':0,'root_pgo_builds':0},'wrapper resource gate')
    start=a.json('container-start-inspect.json');end=a.json('container-final-inspect.json');images=a.json('tooling-image-inspect.json')
    need(len(start)==len(end)==len(images)==1,'Docker identity inventory');start,end,image=start[0],end[0],images[0]
    need(start['Id']==end['Id']==a.data('container-id.txt').decode().strip(),'actual container identity')
    need(start['Image']==end['Image']==image['Id'],'actual image identity')
    need(end['State']['ExitCode']==0 and not end['State']['OOMKilled'] and not end['State']['Running'],'container completion/OOM')
    for obj in [start,end]:
        host=obj['HostConfig'];need(host['NetworkMode']=='none' and host['CpusetCpus']==str(requested) and host['NanoCpus']==1000000000,'Docker CPU/network request')
        need(host['Memory']==2147483648 and host['MemorySwap']==2147483648 and host['PidsLimit']==128,'Docker memory/swap request')
        mounts={x['Destination']:x for x in obj['Mounts']};need(mounts['/prototype']['RW'] is False and mounts['/out']['RW'] is True,'source/output mounts')
        need(obj['Config']['Cmd']==['python3','/prototype/run_linux.py','--output','/out/results','--pairs','4','--queries','64'],'container command')
    return {'actual_cpu':requested,'cpu_max':[quota,period],'memory_max':2147483648,'swap_max':0,'container_id':end['Id'],'image_id':image['Id'],
      'scope':'Actual container caps and driver affinity verified; native children inherit them from the Git-bound runner. No per-kernel process-task telemetry or memory-growth comparison exists.'}

def native_evidence(a,summary,files):
    expected={n[len(PREFIX):]:sha(b) for n,b in files.items() if n.startswith(PREFIX)}
    need(summary['source_sha256']==expected,'actual mounted source inventory')
    need(summary['database_runs']==summary['pgo_builds']==0 and summary['native_compilations']==summary['native_executions']==3,'native/DB count')
    need(summary['reference']==readjson(files[PREFIX+'reference-manifest.json']),'reference summary')
    flags=['g++','-std=c++17','-ffp-contract=off','-fno-math-errno','-pthread']
    expected_commands=[('compiler',['g++','--version']),('cpu',['lscpu']),
      ('build-normal',flags+['-O3','/prototype/test_batch8.cpp','-o','/out/results/normal']),
      ('correctness-normal',['/out/results/normal']),
      ('build-sanitized',flags+['-O1','-g','-fno-omit-frame-pointer','-fsanitize=address,undefined','-no-pie','/prototype/test_batch8.cpp','-o','/out/results/sanitized']),
      ('correctness-sanitized',['/out/results/sanitized']),
      ('build-microbenchmark',flags+['-O3','/prototype/benchmark_batch8.cpp','-o','/out/results/microbenchmark']),
      ('microbenchmark',['/out/results/microbenchmark','4','64'])]
    need([(x['name'],x['argv']) for x in summary['commands']]==expected_commands,'commands/flags differ')
    need(all(x.get('exit_code')==0 for x in summary['commands']),'failed native command')
    compiler=a.data('results/compiler.log').decode().splitlines()[0]
    need(summary['compiler']==compiler and '13.3.0' in compiler,'compiler version')
    need(b'gcc:13.3.0-bookworm@sha256:1d71f0f3450214bef38fe09e6f610fb6cca90cf97b43f4ce845bfc32a4168818' in a.data('tooling-image-build.log'),'compiler image build digest absent')
    binaries={}
    for name in ['normal','sanitized','microbenchmark']:
        b=a.data('results/'+name);need(b[:6]==b'\x7fELF\x02\x01' and int.from_bytes(b[18:20],'little')==62,'invalid x86-64 ELF')
        binaries[name]=sha(b)
    need(binaries==summary['binary_sha256'],'binary hashes')
    counts=[]
    for name in ['normal','sanitized']:
        log=a.data('results/correctness-'+name+'.log').decode();need('batch8=PASS' in log.splitlines(),'native correctness PASS absent')
        values=re.findall(r'^batch8_checks=(\d+)$',log,re.M);need(len(values)==1 and int(values[0])>0,'native count');counts.append(int(values[0]))
        need(not re.search(r'AddressSanitizer|runtime error:',log),'sanitizer report')
    need(counts[0]==counts[1] and summary['correctness_checks']=={'normal':counts[0],'sanitized':counts[1]},'native check counts')
    return {'compiler':compiler,'binary_sha256':binaries,'correctness_checks':summary['correctness_checks'],'native_compilations':3,'native_executions':3,'DB_runs':0,'PGO_builds':0}

def measurements(a,summary,plan):
    pairs=[readjson(line) for line in a.data('results/microbenchmark.log').splitlines() if line]
    need(pairs==summary['pairs'],'raw pair transcript differs');labels={x['comparison'] for x in pairs}
    need(labels in ({'same_isa_avx2'},{'same_isa_avx2','native_baseline_vs_avx2_batch'}),'ISA arm inventory')
    wanted=[(label,n,rows,pair) for n in [128,512] for rows in [10000,10003]
      for label in ['same_isa_avx2','native_baseline_vs_avx2_batch'] if label in labels for pair in range(4)]
    need([(x['comparison'],x['dimension'],x['rows'],x['pair']) for x in pairs]==wanted,'pair order/count differs')
    groups={};negative=[];primary_fail=[];guard_fail=[];native_fail=[]
    rules=plan['frozen_screen_rules']
    for label,n,rows,_ in wanted[::4]:
        values=[x for x in pairs if (x['comparison'],x['dimension'],x['rows'])==(label,n,rows)];name=f'{label}/n{n}/rows{rows}';group={}
        for x in values:
            need(x['queries']==64 and x['order']==('AB' if x['pair']%2==0 else 'BA'),'pair queries/order')
            need(x['candidate_isa']=='avx2' and x['baseline_isa']==('avx2' if label=='same_isa_avx2' else 'avx512'),'ISA labels')
            need(type(x['baseline_checksum']) is int and x['baseline_checksum']==x['candidate_checksum'] and 0<x['baseline_checksum']<2**64,'checksum')
        need(len({x['baseline_checksum'] for x in values})==1,'same corpus checksum drifts')
        for metric in ['wall','cpu']:
            need(all(type(x[side+'_'+metric]) in (int,float) and math.isfinite(x[side+'_'+metric]) and x[side+'_'+metric]>0 for x in values for side in ['baseline','candidate']),'invalid timing')
            ratios=[x['candidate_'+metric]/x['baseline_'+metric] for x in values]
            stats={'median':median(ratios),'AB_median':median(ratios[::2]),'BA_median':median(ratios[1::2]),'strictly_faster_pairs':sum(r<1 for r in ratios),'ratios':ratios,
              'baseline_seconds':[x['baseline_'+metric] for x in values],'candidate_seconds':[x['candidate_'+metric] for x in values]}
            observed=summary['groups'][name][metric]
            need(observed['ratios']==ratios and observed['median_candidate_over_baseline']==stats['median'] and observed['candidate_worse_pairs']==sum(r>1 for r in ratios),'runner group summary differs')
            need(observed['baseline_seconds']==stats['baseline_seconds'] and observed['candidate_seconds']==stats['candidate_seconds'],'absolute group values differ')
            group[metric]=stats
            for x,r in zip(values,ratios):
                if r>1:negative.append({'group':name,'metric':metric,'pair':x['pair'],'order':x['order'],'ratio':r,'baseline_seconds':x['baseline_'+metric],'candidate_seconds':x['candidate_'+metric]})
            if label=='same_isa_avx2' and n==128:
                rule=rules['primary_AVX2_128'];checks={'median':stats['median']<=rule['median_candidate_over_baseline_max'],
                  'faster_count':stats['strictly_faster_pairs']>=rule['strictly_faster_pairs_min'],'AB':stats['AB_median']<rule['AB_median_strictly_below'],'BA':stats['BA_median']<rule['BA_median_strictly_below']}
                if not all(checks.values()):primary_fail.append({'group':name,'metric':metric,'checks':checks,'observed':stats})
            elif label=='same_isa_avx2':
                if stats['median']>rules['AVX2_512_guard']['median_candidate_over_baseline_max']:guard_fail.append({'group':name,'metric':metric,'observed':stats})
            else:
                rule=rules['optional_AVX512_enablement_guard'];checks={key:stats[key]<=rule[bound] for key,bound in [('median','overall_median_max'),('AB_median','AB_median_max'),('BA_median','BA_median_max')]}
                if not all(checks.values()):native_fail.append({'group':name,'metric':metric,'checks':checks,'observed':stats})
        groups[name]=group
    need(set(summary['groups'])==set(groups),'unexpected group summary')
    return {'pair_count':len(pairs),'groups':groups,'all_negative_pair_metrics':negative,'primary_failed_metrics':primary_fail,'AVX2_512_failed_metrics':guard_fail,
      'native_AVX512_failed_metrics':native_fail,'AVX2_eligible_for_DB_integration_investigation':not primary_fail and not guard_fail,
      'AVX512_path_replacement_allowed_by_micro_guard':None if len(labels)==1 else not native_fail,
      'native_control_unavailable':len(labels)==1,'automatic_adoption':False,'score_prediction':None,
      'limitations':['Only four balanced pairs per group; thresholds are screens, not statistical significance.',
        'Standalone full-range int8 immutable scans exclude quantization/cap/TopK/filter/float distances/SQL/storage/workers and all database lifecycle costs.',
        'Equality is based on exact native unit tests plus repeated complete-scan checksums. Individual distance arrays are not archived for an offline numerical oracle replay.',
        'No EE database or retained R database throughput comparison occurs here; ISA arms and historical ratios must not be combined.']}

def audit(args):
    raw=args.archive.read_bytes();a=Archive(raw);api=api_binding(readjson(args.receipt.read_bytes()),raw,args.commit)
    plan,files=source_binding(args.repo.resolve(),args.commit,a);status=a.json('ci-status.json')
    need(status['database_runs']==status['root_pgo_builds']==0,'wrapper DB/PGO count')
    result={'api':api,'preregistration_sha256':PLAN_SHA,'source_files_verified':len(files),'artifact_manifest':a.inventory,
      'reader_sha256':sha(Path(__file__).read_bytes()),'API_receipt_sha256':sha(args.receipt.read_bytes()),'new_DB_runs_by_reader':0,'new_native_executions_by_reader':0,'automatic_adoption':False,'formal_submission':False}
    if api['conclusion'] not in (None,'success') or status['exit_code']!=0:
        summary=a.json('results/summary.json') if 'results/summary.json' in a.inventory else None
        return {**result,'status':'verified_failed_or_incomplete_attempt','wrapper_exit_code':status['exit_code'],
          'runner_reported_partial_state':summary,'performance_screen_evaluated':False,'note':'Preserve partial evidence; no successful microbenchmark or database outcome is inferred.'}
    summary=a.json('results/summary.json');need(summary['status']=='native_correctness_and_microbenchmark_completed','incomplete runner')
    return {**result,'status':'verified_microbenchmark_evidence','resources':resources(a,summary),'native':native_evidence(a,summary,files),'screen':measurements(a,summary,plan)}

def main():
    p=argparse.ArgumentParser();p.add_argument('--repo',type=Path,default=Path(__file__).resolve().parent/'seekdb');p.add_argument('--archive',type=Path,required=True)
    p.add_argument('--receipt',type=Path,required=True);p.add_argument('--commit',required=True);p.add_argument('--output',type=Path,required=True);args=p.parse_args()
    try:result=audit(args)
    except BaseException as exc:
        args.output.write_text(json.dumps({'status':'reader_rejected_evidence_not_verified','error':str(exc),'new_DB_runs':0},indent=2)+'\n',encoding='utf8');raise
    args.output.write_text(json.dumps(result,indent=2,allow_nan=False)+'\n',encoding='utf8')
    print(json.dumps({'status':result['status'],'pairs':result.get('screen',{}).get('pair_count'),'AVX2_eligible':result.get('screen',{}).get('AVX2_eligible_for_DB_integration_investigation'),'native_AVX512_guard':result.get('screen',{}).get('AVX512_path_replacement_allowed_by_micro_guard')}))

if __name__=='__main__':main()
