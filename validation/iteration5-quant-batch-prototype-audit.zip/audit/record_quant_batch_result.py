"""Archive the fixed batch8 microbenchmark and prepare material; no Git changes."""
import argparse
import copy
import hashlib
import importlib.util
import io
import json
from pathlib import Path
import subprocess
import zipfile

BASE='4e540f8bbaeb6d783cd58880a762aa01a7efd362ec11c3aa82af8570e18e5520'
COMMIT='1486aa80fcd8fdab7cd879588f3bf752baa14066'
RAW='validation/iteration5-quant-batch-prototype-raw.zip'
RAW_SHA='b658ec9112ee52c57cbdeff1ed3d3e4d0bb3621ff35a346ab9d474ac4f14a00c'
AUDIT='validation/iteration5-quant-batch-prototype-audit.zip'
PLAN='validation/iteration5-quant-batch-prototype-preregistration.json'
PLAN_SHA='d2c6d0076c7b7681c88322e81419a6491c620541e2153cf51dccc37f74f43d70'

def sha(b):return hashlib.sha256(b).hexdigest()
def enc(x):return (json.dumps(x,ensure_ascii=False,separators=(',',':'),allow_nan=False)+'\n').encode('utf8')
def need(ok,message):
    if not ok:raise ValueError(message)
def git(repo,path):return subprocess.check_output(['git','-c','safe.directory='+repo.as_posix(),'-C',str(repo),'show',COMMIT+':'+path])

def main():
    parser=argparse.ArgumentParser();parser.add_argument('--apply',action='store_true');args=parser.parse_args()
    w=Path(__file__).resolve().parent;repo=w/'seekdb';prior=(repo/'conversation.json').read_bytes()
    need(sha(prior)==BASE and (repo/'agent/conversation.json').read_bytes()==prior,'material drift')
    old=json.loads(prior);need(len(old['messages'])==146 and len(old['experiments'])==58,'inventory')
    raw=(repo/RAW).read_bytes();need(sha(raw)==RAW_SHA and len(raw)==240756,'raw mismatch')
    analysis_raw=(w/'quant-batch-independent-analysis.json').read_bytes();analysis=json.loads(analysis_raw)
    need(analysis['status']=='verified_microbenchmark_evidence' and analysis['api']['source_commit']==COMMIT and analysis['api']['sha256']==RAW_SHA,'analysis identity/status')
    need(analysis['reader_sha256']==sha((w/'analyze_quant_batch_prototype.py').read_bytes()),'reader drift')
    screen=analysis['screen'];need(screen['pair_count']==16 and screen['AVX2_eligible_for_DB_integration_investigation'] is True,'screen differs')
    need(screen['native_control_unavailable'] and screen['AVX512_path_replacement_allowed_by_micro_guard'] is None,'unmeasured native control')
    need(screen['all_negative_pair_metrics']==[],'unexpected negative records')
    decision={'experiment_id':'quantized-batch8-integer-prototype','status':'micro_screen_passed_DB_unvalidated','source_commit':COMMIT,
      'run_id':43503133588,'artifact_id':14074977310,'raw':{'path':RAW,'bytes':len(raw),'sha256':RAW_SHA},
      'preregistration_sha256':PLAN_SHA,'independent_analysis_sha256':sha(analysis_raw),'native':analysis['native'],'resources':analysis['resources'],
      'screen':screen,'missing_or_limited_evidence':[
        'Native AVX512 control was not executed on this host. Its guard is unmeasured, not passed; no AVX512 enablement is established.',
        'No DB was built/executed and no PGO was trained. Approximately21% less time concerns only the128-dimensional synthetic AVX2 integer scans.',
        'Only four AB/BA-balanced pairs per group on one host; this is screening evidence, not independent confirmation or a formal-score forecast.',
        analysis['api']['API_scope'],
        'No individual-distance result arrays are archived; independent native uint64 tests and checksums are source-bound, and complete pair logs are retained.'
      ],'negative_results':'All32 observed pair-by-metric ratios are below1; none omitted. The absent AVX512 arm remains explicitly unknown.',
      'decision':'Eligible for separately preregistered DB integration investigation. Preserve current row order/cap/fallback and direct EE/R controls; do not adopt from micro data.',
      'default_adopted':False,'formal_submission':False,'new_DB_runs_by_reader':0}
    files={}
    for name in ['quant-batch-api-receipt.json','quant-batch-independent-analysis.json','analyze_quant_batch_prototype.py',
      'check_quant_batch_workflow.py','quant-batch-workflow-review.json','quant-batch-prepush-lf-correction.json','fix_quant_batch_prereg_lf.py',Path(__file__).name]:
        files['audit/'+name]=(w/name).read_bytes()
    files['decision.json']=enc(decision)
    files['reader-development-note.json']=enc({'scope':'Offline reader entry only; zero DB/native execution',
      'initial_error':"KeyError: 'head_sha' in receipt driver before reader invocation",
      'cause':'This API receipt is compact and uses commit/artifact, unlike the older exact-cost receipt.',
      'resolution':'Accept the actual compact artifact object, verify digest/size/run/source; explicitly leave missing jobs API conclusion/id/enumeration unverified. No changes to native results or raw archive.'})
    plan_raw=git(repo,PLAN);need(sha(plan_raw)==PLAN_SHA,'plan drift');plan=json.loads(plan_raw);files['frozen/'+PLAN]=plan_raw
    for name,p in plan['source_snapshot'].items():
        b=git(repo,name);need(len(b)==p['bytes'] and sha(b)==p['sha256'],'frozen input mismatch '+name);files['frozen/'+name]=b
    old_draft=(w/'quant-batch-prototype-preregistration.json').read_bytes()
    need(sha(old_draft)==plan['pre_push_line_ending_correction']['original_work_draft_sha256'],'old draft lineage')
    files['prepush-original-plan.json']=old_draft
    files['README.txt']=(
      'Standalone batch8 microbenchmark only. No DB/PGO/automatic adoption or formal submission.\n'
      'Replay: python audit/analyze_quant_batch_prototype.py --repo <seekdb Git checkout> --archive <iteration5-quant-batch-prototype-raw.zip> --receipt audit/quant-batch-api-receipt.json --commit '+COMMIT+' --output <analysis.json>\n'
      'The original raw archive contains all three native binaries, complete logs, pair data, Docker identities and actual cgroup resource observations.\n'
      'AVX512 control did not run; an unknown control must not be presented as passed. All measured pair-by-metric ratios were improvements, with none omitted.\n'
    ).encode()
    manifest={'scope':'Successful micro screening; not DB or score improvement','source_commit':COMMIT,'raw':{'path':RAW,'bytes':len(raw),'sha256':RAW_SHA},
      'files':{name:{'bytes':len(b),'sha256':sha(b)} for name,b in sorted(files.items())}}
    out=io.BytesIO()
    with zipfile.ZipFile(out,'w',zipfile.ZIP_DEFLATED,compresslevel=9) as z:
        for name,b in sorted({**files,'manifest.json':enc(manifest)}.items()):
            info=zipfile.ZipInfo(name,(2026,11,14,0,0,0));info.external_attr=0o100644<<16;z.writestr(info,b,compress_type=zipfile.ZIP_DEFLATED,compresslevel=9)
    audit=out.getvalue()
    with zipfile.ZipFile(io.BytesIO(audit)) as z:
        for name,b in files.items():need(z.read(name)==b,'audit member differs')
    new=copy.deepcopy(old);e=new['experiments'][-1];need(e['id']=='quantized-batch8-integer-prototype','wrong final experiment')
    e.update(status='micro_screen_passed_DB_unvalidated',native_compilations_executed=3,micro_pairs_executed=16,
      native_executions=3,result_message='assistant-quant-batch-prototype-result',native_AVX512_control_executed=False)
    e['artifacts'] += [{'path':RAW,'sha256':RAW_SHA},{'path':AUDIT,'sha256':sha(audit)}]
    new['messages'].append({'id':'assistant-quant-batch-prototype-result','role':'assistant','content':
      'batch8独立微基准实测：正常/ASan+UBSan各30891检查通过，实际单CPU/2GiB/swap0；3次native编译/执行、16对，DB/PGO为0。128维两组wall中位C/B=.791160/.788097、CPU=.791055/.788106；512维wall=.769617/.740390、CPU=.769671/.740475，均4/4改善，32项对子指标无退化。预登记AVX2筛选通过，约21%仅为128维整数扫描耗时减少；native AVX512控制未执行，不能判通过。仅支持下一步DB集成验证，R不变，未正式提交。'})
    need(new['messages'][:-1]==old['messages'] and new['experiments'][:-1]==old['experiments'][:-1],'old history changed')
    need({k:v for k,v in new.items() if k not in ('messages','experiments')}=={k:v for k,v in old.items() if k not in ('messages','experiments')},'other root metadata changed')
    material=enc(new);need(len(material)<=131072,'overflow')
    spec=importlib.util.spec_from_file_location('qb_result_validator',repo/'minivec/tools/validate_iteration_material.py');checker=importlib.util.module_from_spec(spec);spec.loader.exec_module(checker)
    checker.validate(repo);checker.check_structure(new,new)
    for name,b in [('quant-batch-decision.json',enc(decision)),('quant-batch-prototype-audit.zip',audit),('quant-batch-result-material-preview.json',material)]:
        (w/name).write_bytes(b)
    receipt={'status':'preview_only','source_material_sha256':BASE,'material_bytes':len(material),'material_sha256':sha(material),
      'remaining_bytes':131072-len(material),'messages':147,'users':49,'experiments':58,'audit_bytes':len(audit),'audit_sha256':sha(audit),
      'audit_members':len(files),'decision_sha256':sha(enc(decision)),'all_old_messages_users_results_preserved':True,'new_DB_runs':0,'git_mutations':0}
    if args.apply:
        need((repo/'conversation.json').read_bytes()==prior and (repo/'agent/conversation.json').read_bytes()==prior,'material drift before apply')
        dest=repo/AUDIT;need(not dest.exists(),'audit destination exists');dest.write_bytes(audit)
        try:
            (repo/'conversation.json').write_bytes(material);(repo/'agent/conversation.json').write_bytes(material);receipt['validation']=checker.validate(repo);receipt['status']='applied'
        except BaseException:
            (repo/'conversation.json').write_bytes(prior);(repo/'agent/conversation.json').write_bytes(prior);dest.unlink();raise
    (w/'quant-batch-result-material-receipt.json').write_bytes(enc(receipt));print(json.dumps(receipt,indent=2))

if __name__=='__main__':main()
