# Localized bulk guard preflight

This archive records local Windows static and synthetic evidence only. It does not
claim Linux compilation, sanitizer execution, database correctness execution, or
performance success. The pending Linux job is the actual confirmation.

The explicit plan has 150 candidate pairs (10 cases x 3 seeds x 5 pairs), plus
42 same-program A/A pairs (7 cases x 3 seeds x 2 pairs). Two PGO roles are built,
not 192 independent PGO trainings. Baseline is e020fdeb67dd8b64b77f0f8c2905f137f0112bba.
The bulk macro stays off in production until evidence supports adoption.

The 12 fixture checks cover full identity/counts, missing/duplicate/wrong binary,
AB/BA and oracle rejection, collector failures, the original84 protocol remaining
unchanged, and exact compiler digest plus baseline commit. Source diagnostics
are independently described in work/localized-bulk-cpp-static-validation.json.
Both the shell and template retain the pinned GCC13.3 image and original PGO
training corpus. A peer-reviewed accidental digest text substitution was fixed
before these final static checks; the exact pin is now asserted by the fixture.

After extracting, run: python -B work/check_bulk_guard.py
Dependencies needed by this synthetic test are included. The three engine files
are retained to bind the C++ static report; this archive is not a complete engine
source checkout. The executable Linux job uses its own complete Git archive.
The manifest hashes every member except itself. No formal submission is authorized.
